﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace XSpace.Commom.Logging.Model
{
    [DataContract]
    public class LogData
    {
        [DataMember]
        public string xhrStatus { get; set; }

        [DataMember]
        public string xhrResponseText { get; set; }

        [DataMember]
        public string methodName { get; set; }

        [DataMember]
        public string errorLocation { get; set; }

        [DataMember]
        public string methodParameters { get; set; }        
    }

}
