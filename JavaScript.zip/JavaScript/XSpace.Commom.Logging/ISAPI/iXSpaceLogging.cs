﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;
using XSpace.Commom.Logging.Model;
using System.IO;

namespace XSpace.Commom.Logging
{
    [ServiceContract]
    interface iXSpaceLogging
    {
        [OperationContract]
        [WebGet(UriTemplate = "GetAllWells",
            ResponseFormat = WebMessageFormat.Json)]
        List<WellData> GetAllWells();

        [OperationContract]
        [WebInvoke(Method = "POST",
                    RequestFormat = WebMessageFormat.Json,
                    ResponseFormat = WebMessageFormat.Json,
                    UriTemplate = "LogException")]
        string LogException(Stream postdata);
    }

}

