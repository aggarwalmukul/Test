﻿using Microsoft.SharePoint.Client.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Activation;
using XSpace.Commom.Logging.Model;
using System.IO;
using Newtonsoft.Json;

namespace XSpace.Commom.Logging
{
    [BasicHttpBindingServiceMetadataExchangeEndpoint]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]

    public class XSpaceLogging : iXSpaceLogging
    {
        #region Private Members

        private List<WellData> _WellData;
        private List<WellData> WellDatas
        {
            get
            {
                // If there aren't any presidents in our list, populate with samples
                _WellData = _WellData ?? new List<WellData>(SampleData.SamplePresidents);
                return _WellData;
            }
        }

        #endregion

        #region IPresidentsService Implementation

        public List<WellData> GetAllWells()
        {

            return WellDatas;
        }

        public string LogException(Stream postdata)
        {
            StreamReader reader = new StreamReader(postdata);
            string reqServerData = reader.ReadToEnd();
            LogData ld;
            ld = JsonConvert.DeserializeObject<LogData>(reqServerData);

            try
            {
                string message = ld.xhrStatus + ":" + ld.xhrResponseText;
                
                message += "   Getting exception while calling WEB SERVICE : '" + ld.methodName + "' AT : '" + ld.errorLocation + "' PARAMETERS : " + ld.methodParameters;
                LoggingService.LogErrorInULS(message);
            }
            catch (Exception ex)
            {
               
            }
            return "0";
        }

        #endregion

    }
}