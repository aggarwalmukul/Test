﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace XSpace.Commom.Logging
{
    public class LoggingService : SPDiagnosticsServiceBase
    {
        public static string vsDiagnosticAreaName = "Xspace SharePoint Logging Service";
        public static string CategoryName = "Xspace";
        public static uint uintEventID = 700; // Event ID
        private static LoggingService _Current;
        public static LoggingService Current
        {
            get
            {
                if (_Current == null)
                {
                    _Current = new LoggingService();
                }
                return _Current;
            }
        }
        private LoggingService()
            : base("Xspace SharePoint Logging Service", SPFarm.Local)
        { }
        protected override IEnumerable<SPDiagnosticsArea> ProvideAreas()
        {
            List<SPDiagnosticsArea> areas = new List<SPDiagnosticsArea> { new SPDiagnosticsArea(vsDiagnosticAreaName, new List<SPDiagnosticsCategory> { new SPDiagnosticsCategory(CategoryName, TraceSeverity.Medium, EventSeverity.Error) }) };
            return areas;
        }

        public static string LogErrorInULS(string errorMessage)
        {
            string strExecutionResult = "Message Not Logged in ULS. ";
            try
            {
                SPDiagnosticsCategory category = LoggingService.Current.Areas[vsDiagnosticAreaName].Categories[CategoryName];
                LoggingService.Current.WriteTrace(uintEventID, category, TraceSeverity.Unexpected, errorMessage);
                strExecutionResult = "Message Logged";
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    EventLog.WriteEntry("XSpace Error", errorMessage, EventLogEntryType.Error);        
                });    

            }
            catch (Exception ex)
            {
                strExecutionResult += ex.Message;
            }
            return strExecutionResult;
        }
        public static string LogErrorInULS(string errorMessage, TraceSeverity tsSeverity)
        {
            string strExecutionResult = "Message Not Logged in ULS. ";
            try
            {
                SPDiagnosticsCategory category = LoggingService.Current.Areas[vsDiagnosticAreaName].Categories[CategoryName];
                LoggingService.Current.WriteTrace(uintEventID, category, tsSeverity, errorMessage);
                strExecutionResult = "Message Logged";
            }
            catch (Exception ex)
            {
                strExecutionResult += ex.Message;
            }
            return strExecutionResult;
        }
    }
}
