﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Runtime.InteropServices;
using System.Drawing;
using System.IO;
using System.Collections.Generic;
using System.Web;
using Westwind.plUpload;
//using ICSharpCode.SharpZipLib.Core;
//using ICSharpCode.SharpZipLib.Zip;
using System.Text;
using System.Linq;
//using Newtonsoft.Json;
using System.Net;
//using Newtonsoft.Json.Linq;
using XSpace.Upload.Download.Files.Layouts;
using System.Data;
using XSpace.Upload.Download.Files.Layouts.FileHandler;
using XSpace.Data.Library;


namespace Xspace.Upload.Files.Layouts.Upload
{
    [Guid("755a33da-25f4-4266-a202-d410d9227faf")]
    public class UploadHandler : plUploadFileHandler
    {

        public static int ImageHeight = 480;


        public UploadHandler()
        {
            // Normally you'd set these values from config values
            MaxUploadSize = 0;
            AllowedExtensions = ".jpg,.jpeg,.png,.gif,.bmp,.mkv,.pdf,.docx,.txt";
        }

        public void InsertData(string FileName, string FilePath , string size)
        {
            DataAccess dataAccess = new DataAccess();
            
            var param = "DriveGuid=" + "'" + HttpUtility.UrlEncode(DriveGuid) + "'&" + "FileName=" + "'" + HttpUtility.UrlEncode(FileName) + "'&" + "FilePath=" + "'" + HttpUtility.UrlEncode(FilePath)
             + "'&" + "Status=" + "'" + HttpUtility.UrlEncode(Status) + "'&" + "Comment=" + "'" + HttpUtility.UrlEncode(Comment) + "'&" + "UserID='" + UserID + "'&" + "Size=" + HttpUtility.UrlEncode(size);
            dataAccess.ExecuteProcedure("InsertDataFile_SP", param);

            string datafileguid = "";

            datafileguid = dataAccess.GetData("DATA_FILE_GUID");

                if (WBGuid != null)
                {
                    param = "WBJobGuid=" + "'" + WBGuid + "'&" + "DataFileGuid=" + "'" + datafileguid + "'&" + "FolderType=" + "'" + FolderID + "'&"  + "UserID='" + UserID + "'";

                    dataAccess.ExecuteProcedure("InsertWBJobDataFile_SP", param);
                }
                param = "UploadSessGuid=" + "'" + UploadSessionGuid + "'&" + "FileUploadGuid=" + "'" + UploadSessionGuid + "'&" + "DataFileGuid=" + "'" +
                    datafileguid + "'&" + "TempDriveGuid=" + "'" + DestinationDriveGuid + "'&" + "TempPath=" + "'" + FilePath + "'&" + "DestDriveGuid=" + "'"
                    + DestinationDriveGuid + "'&" + "DestPath=" + "'" + FilePath + "'&" + "UserID='" + UserID + "'";
                dataAccess.ExecuteProcedure("InsertFileUpload_SP", param);

       }

        public bool ExtractZipFile(string archiveFilenameIn, string outFolder)
        {
            if( archiveFilenameIn.Contains(".zip") == false || ZipFlag == "1")
                return false;
            Ionic.Zip.ZipFile zf = null;
            try
            {
                //FileStream fs = File.OpenRead(archiveFilenameIn);
                zf = new Ionic.Zip.ZipFile(archiveFilenameIn);
                if (zf.Count > 25)
                {
                    //zf.IsStreamOwner = true; // Makes close also shut the underlying stream
                    zf.Dispose(); // Ensure we release resources
                    return false;

                }


                foreach (Ionic.Zip.ZipEntry zipEntry in zf)
                {
                    if (zipEntry.IsDirectory)
                    {
                        continue;           // Ignore directories
                    }
                    String entryFileName = zipEntry.FileName;
                    // to remove the folder from the entry:- entryFileName = Path.GetFileName(entryFileName);
                    // Optionally match entrynames against a selection list here to skip as desired.
                    // The unpacked length is available in the zipEntry.Size property.

                    byte[] buffer = new byte[4096];     // 4K is optimum
                    Stream zipStream = zipEntry.InputStream;

                    // Manipulate the output filename here as desired.
                    String fullZipToPath = Path.Combine(outFolder, entryFileName);
                    string directoryName = Path.GetDirectoryName(fullZipToPath);
                    if (directoryName.Length > 0)
                        Directory.CreateDirectory(directoryName);

                    // Unzip file in buffered chunks. This is just as fast as unpacking to a buffer the full size
                    // of the file, but does not waste memory.
                    // The "using" will close the stream even if an exception occurs.
                    FileStream streamWriter = File.Create(fullZipToPath);
                    zipEntry.Extract(streamWriter);
                    streamWriter.Close();
                    double size = FileService.ConvertSizeFromKBtoMB(zipEntry.CompressedSize);
                    InsertData(entryFileName, FileDestinationPath, size.ToString());
                }
            }
            finally
            {
                if (zf != null)
                {
                    //zf.IsStreamOwner = true; // Makes close also shut the underlying stream
                    zf.Dispose(); // Ensure we release resources
                }
            }
            return true;
        }


        protected override void OnUploadCompleted(string fileName)
        {

            var Server = Context.Server;

            // Physical Path is auto-transformed
            var path = FileUploadPhysicalPath;
            var fullUploadedFileName = Path.Combine(path, fileName);

            // Typically you'd want to ensure that the filename is unique
            // Some ID from the database to correlate - here I use a static img_ prefix
            string generatedFilename = "img_" + fileName;

            //string imagePath = Server.MapPath(ImageStoragePath);
            //string url = "http://" + Request.Url.Host + ":" + Request.Url.Port.ToString();
            string url = SPContext.Current.Web.Url.ToString();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {

                        if (!Directory.Exists(ImageStoragePath))
                        {
                            try
                            {
                                Directory.CreateDirectory(ImageStoragePath);
                            }
                            catch
                            {
                                WriteErrorResponse("Unable to create uploaded file directory.");
                                return;
                            }
                        }

                        try
                        {
                            //,@"\\192.100.0.2\temp\text.txt"
                            // resize the image and write out in final image folder
                            //ResizeImage(fullUploadedFileName, Path.Combine(imagePath, generatedFilename), ImageHeight);
                            File.Delete(Path.Combine(ImageStoragePath, fileName));
                            if (DataUpdate == "true")
                            {
                                if (ExtractZipFile(fullUploadedFileName, ImageStoragePath) == false)
                                {
                                    File.Copy(fullUploadedFileName, Path.Combine(ImageStoragePath, fileName));

                                    InsertData(fileName, FileDestinationPath, Size);


                                }
                            }
                            else
                            {
                                File.Copy(fullUploadedFileName, Path.Combine(ImageStoragePath, fileName));
                                // delete the temp file
                                File.Delete(fullUploadedFileName);
                            }
                        }
                        catch (Exception ex)
                        {
                            WriteErrorResponse("Unable to write out uploaded file: " + ex.Message);
                            return;
                        }

                    }

                    // implementation details omitted
                }
            });

            //string relativePath = VirtualPathUtility.ToAbsolute(ImageStoragePath);
            //string finalImageUrl = relativePath + "/" + generatedFilename;

            // return just a string that contains the url path to the file
            WriteUploadCompletedMessage("");
        }

        protected override bool OnUploadStarted(int chunk, int chunks, string name)
        {
            // time out files after 15 minutes - temporary upload files
            //DeleteTimedoutFiles(Path.Combine(FolderTempPath, "*.*"), 2000);

            // clean out final image folder too
            //DeleteTimedoutFiles(Path.Combine(Context.Server.MapPath(ImageStoragePath), "*.*"), 2000);
            //DeleteTimedoutFiles(Path.Combine(ImageStoragePath, "*.*"), 2000);

            return base.OnUploadStarted(chunk, chunks, name);
        }

        // these aren't needed in this example and with files in general
        // use these to stream data into some alternate data source
        // when directly inheriting from the base handler

        //protected override bool  OnUploadChunk(Stream chunkStream, int chunk, int chunks, string fileName)
        //{
        //     return base.OnUploadChunk(chunkStream, chunk, chunks, fileName);
        //}

        //protected override bool OnUploadChunkStarted(int chunk, int chunks, string fileName)
        //{
        //    return true;
        //}




        #region Sample Helpers
        /// <summary>
        /// Deletes files based on a file spec and a given timeout.
        /// This routine is useful for cleaning up temp files in 
        /// Web applications.
        /// </summary>
        /// <param name="filespec">A filespec that includes path and/or wildcards to select files</param>
        /// <param name="seconds">The timeout - if files are older than this timeout they are deleted</param>
        public static void DeleteTimedoutFiles(string filespec, int seconds)
        {
            string path = Path.GetDirectoryName(filespec);
            string spec = Path.GetFileName(filespec);
            string[] files = Directory.GetFiles(path, spec);

            foreach (string file in files)
            {
                try
                {
                    if (File.GetLastWriteTimeUtc(file) < DateTime.UtcNow.AddSeconds(seconds * -1))
                        File.Delete(file);
                }
                catch { }  // ignore locked files
            }
        }

        /// <summary>
        /// Creates a resized bitmap from an existing image on disk. Resizes the image by 
        /// creating an aspect ratio safe image. Image is sized to the larger size of width
        /// height and then smaller size is adjusted by aspect ratio.
        /// 
        /// Image is returned as Bitmap - call Dispose() on the returned Bitmap object
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns>Bitmap or null</returns>
        public static bool ResizeImage(string filename, string outputFilename,
                                       int height)
        {
            Bitmap bmpOut = null;

            try
            {
                Bitmap bmp = new Bitmap(filename);
                System.Drawing.Imaging.ImageFormat format = bmp.RawFormat;

                decimal ratio;
                int newWidth = 0;
                int newHeight = 0;

                //*** If the image is smaller than a thumbnail just return it
                if (bmp.Height < height)
                {
                    if (outputFilename != filename)
                        bmp.Save(outputFilename);
                    bmp.Dispose();
                    return true;
                }

                ratio = (decimal)height / bmp.Height;
                newHeight = height;
                newWidth = Convert.ToInt32(bmp.Width * ratio);


                bmpOut = new Bitmap(newWidth, newHeight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.FillRectangle(Brushes.White, 0, 0, newWidth, newHeight);
                g.DrawImage(bmp, 0, 0, newWidth, newHeight);

                bmp.Dispose();

                bmpOut.Save(outputFilename, format);
                bmpOut.Dispose();
            }
            catch (Exception ex)
            {
                var msg = ex.GetBaseException();
                return false;
            }

            return true;
        }

        #endregion

    }
}
