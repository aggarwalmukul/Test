﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using System.Net;
using System.IO;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Collections;
using XSpace.Upload.Download.Files.Layouts;
using XSpace.Common.Services;
using Microsoft.SharePoint.Administration;
namespace Xspace.Upload.Files.Layouts
{
    public struct FileDetails
    {
        public int RowId;
        public string FileName;
        public long Size;

    }

    public struct UserInformation
    {
        public string domain;
        public string userid;
    
    }
    public partial class DownloadFile : LayoutsPageBase
    {
        [WebMethod]
        public static void ShowXspaceLog(string sEvent)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
                    diagSvc.WriteTrace(123456, new SPDiagnosticsCategory("xSpace", TraceSeverity.Monitorable, EventSeverity.Error), TraceSeverity.Monitorable, "{0}:{1}", new object[] { "XSpace Method_Name", sEvent });
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        [WebMethod]
        public static string GetCurrentUser()
        {
            string validID = string.Empty;
            try
            {

                validID = ServiceData.GetCurrentUser();

            }
            catch (Exception ex)
            {
                ShowXspaceLog(ex.Message.ToString());
            }
            //Used ServiceData.GetCurrentUser() to fix the issue on IT QA - mentioned by chithrai
            return validID;
        }



        //var o = { PathUrl: FilePath, machine:machine, folder:foldername, WellGuid:WellGuid };

        //[WebMethod]
        //public static string GetWellFileDetails(string PathUrl, string machine, string folder
        //    , string WellGuid)
        //{


        //    string UploadStorageDrive;
        //    UploadStorageDrive = Path.Combine(machine, "");
        //    UploadStorageDrive = Path.Combine(UploadStorageDrive, "WELLS");
        //    UploadStorageDrive = Path.Combine(UploadStorageDrive, WellGuid);

        //    UploadStorageDrive = Path.Combine(UploadStorageDrive, folder);
        //    UploadStorageDrive = Path.Combine(UploadStorageDrive, PathUrl);


        //    WebClient req = new WebClient();


        //    ArrayList myAL = new ArrayList();

        //    try
        //    {
        //        Stream myStream = req.OpenRead(UploadStorageDrive);
        //        if (UploadStorageDrive.Contains(".zip") == true)
        //        {
        //            ZipInputStream zip = new ZipInputStream(myStream);


        //            ZipEntry item;

        //            int i = 0;

        //            while ((item = zip.GetNextEntry()) != null)
        //            {
        //                FileDetails details = new FileDetails();

        //                {
        //                    details.RowId = i;
        //                    details.FileName = item.Name;
        //                    details.Size = item.Size;
        //                    myAL.Add(details);
        //                    i++;
        //                }

        //            }
        //            zip.Close();
        //        }
        //        else
        //        {

        //            long size = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));
        //            FileDetails details = new FileDetails();

        //            {
        //                details.RowId = 0;
        //                details.FileName = PathUrl;
        //                details.Size = size;
        //                myAL.Add(details);

        //            }


        //        }
        //        myStream.Close();

        //    }
        //    catch (Exception ex)
        //    {
        //        JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

        //        //optional: you can create your own custom converter

        //        var TheJsonEx = TheSerializerEx.Serialize(myAL);

        //        return TheJsonEx;

        //    }


        //    JavaScriptSerializer TheSerializer = new JavaScriptSerializer();

        //    //optional: you can create your own custom converter

        //    var TheJson = TheSerializer.Serialize(myAL);

        //    return TheJson;
        //}

        protected void Page_Load(object sender, EventArgs e)
        {

            //var qs = HttpUtility.ParseQueryString(Request.Url.Query);
            //string guids = qs["GUID"]; // Folder Names.
            //string wellordropbox = qs["FLAG"];
            //string fileNames = qs["Files"];
            //string machine = qs["machinename"];
            //string WellGuid = qs["WBGuid"];
            //string folderPath = qs["FolderPath"];
            //string Operator = qs["Operator"];
            //string Feild = qs["Field"];
            //string WellName = qs["WellName"];

            //char[] delimitedChars = { ',' };
            //if (fileNames != null)
            //{
            //    string[] files = fileNames.Split(delimitedChars);
            //    string[] folders = guids.Split(delimitedChars);


            //    string UploadStorageDrive;
            //    UploadStorageDrive = Path.Combine(machine, folderPath);
            //    UploadStorageDrive = Path.Combine(UploadStorageDrive, "WELLS");
            //    UploadStorageDrive = Path.Combine(UploadStorageDrive, WellGuid);
            //    //"&machinename=" + machine + "&WBGuid=" + WellGuid + "&FolderPath=" + folderpath ;
            //    string userid = User.Identity.Name;
            //    string username = Request.LogonUserIdentity.Name;
            //    Array array = Array.CreateInstance(typeof(string), files.Length);
            //    Array arrZipEntry = Array.CreateInstance(typeof(string), files.Length);
            //    for (int i = 0; i < files.Length; i++)
            //    {
            //        string FilePath;
            //        FilePath = Path.Combine(UploadStorageDrive, folders[i]);
            //        FilePath = Path.Combine(FilePath, files[i]);
            //        array.SetValue(FilePath, i);
            //        arrZipEntry.SetValue(@"WELLS\" + Operator + Feild + WellName + @"\" + folders[i] + @"\" + files[i], i);
            //    }

            //    //array.SetValue(@"\\hssan\test\Mukul\Test1.png", 1);
            //    //array.SetValue(@"\\hssan\test\Nilesh\FileSystemScanner.cs", 2);
            //    //array.SetValue(@"\\hssan\test\Mukul\Mukul.zip", 3);
            //    //array.SetValue(@"\\hssan\test\Mukul\Test.png", 4);
            //    string zipFileName = "LogData.zip";
            //    Response.ContentType = "application/zip";
            //    Response.AddHeader("content-disposition", "attachment; fileName=" + zipFileName);
                
            //    Response.AppendCookie(new HttpCookie("fileDownload", "true") { Path = "/" });
            //    byte[] buffer = new byte[4096];
            //    ZipOutputStream zipOutputStream = new ZipOutputStream(Response.OutputStream);
            //    zipOutputStream.SetLevel(3);


            //    try
            //    {
            //        //DirectoryInfo DI = new DirectoryInfo(Server.MapPath("~/DownloadFolder"));
            //        //foreach (var i in DI.GetFiles())
            //        {
            //            //Stream fs = File.OpenRead("//hssan/test/Mukul/Test.png");

            //            //int count = fs.Read(buffer, 0, buffer.Length);  
            //            //while (count > 0)
            //            for (int i = 0; i < array.Length; i++)
            //            {
            //                //if (File.Exists((string)(array.GetValue(i))) == true)
            //                {
            //                    WebClient req = new WebClient();


            //                    //byte[] data = req.DownloadData((string)(array.GetValue(i)));
            //                    ZipEntry zipEntry = new ZipEntry(ZipEntry.CleanName((string)(arrZipEntry.GetValue(i))));
            //                    Stream myStream = null;
            //                    try
            //                    {
            //                        myStream = req.OpenRead((string)(array.GetValue(i)));
            //                    }
            //                    catch (Exception ex)
            //                    {
            //                        continue;
            //                    }
            //                    if (myStream != null)
            //                    {
            //                        zipEntry.Size = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));
            //                        zipOutputStream.PutNextEntry(zipEntry);


            //                        Int64 count = zipEntry.Size;

            //                        while (count > 0)
            //                        {
            //                            int bytesRead = myStream.Read(buffer, 0, 4096);
            //                            count = count - bytesRead;

            //                            zipOutputStream.Write(buffer, 0, bytesRead);
            //                            //count = fs.Read(buffer, 0, buffer.Length);
            //                            if (!Response.IsClientConnected)
            //                            {

            //                            }
            //                            Response.Flush();

            //                        }
            //                        myStream.Close();
            //                    }
            //                }


            //            }
            //            //fs.Close();
            //        }
            //        zipOutputStream.Close();
            //        Response.Flush();


            //        //HttpContext.Current.ApplicationInstance.CompleteRequest();
            //    }
            //    catch (Exception ex)
            //    {
            //        throw;
            //    }
            //}
            //else {
            //    Response.Flush();
            //}

        }
    }
}
