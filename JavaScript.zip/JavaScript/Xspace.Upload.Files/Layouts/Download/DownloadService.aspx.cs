﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using System.Net;
using System.IO;
using System.Web;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Collections;
//using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Text;
using System.Linq;
//using Newtonsoft.Json;
using XSpace.Upload.Download.Files.Layouts;
using System.Data;
using Ionic.Zip;
using XSpace.Upload.Download.Files.Layouts.FileHandler;
using XSpace.Data.Library;

namespace Xspace.Upload.Files.Layouts.Download
{
    public partial class DownloadService : LayoutsPageBase
    {
        public List<string> path = new List<string>();
        public List<string> filenameArray = new List<string>();
        public List<string> DataFileGuids = new List<string>();
        public List<string> UploadType = new List<string>();
        public List<string> FolderName = new List<string>();
        public List<string> WellboreGuid = new List<string>();
        public List<string> WellName = new List<string>();
        public List<string> OperatorID = new List<string>();
        public List<string> Fieldname = new List<string>();
        string[] datafileGuids = null;
        string userguid = "";
        string machine = "";
        public DataService service = new DataService();
        public bool link = false;


        protected void QuerydataFiles()
        {
            
            var qs = HttpUtility.ParseQueryString(Request.Url.Query);
            string guids = Request["GUID"]; // Folder Names.
            if (Request["link"] == "true")
                link = true;
            char[] delimitedChars = { ',' };
            datafileGuids = guids.Split(delimitedChars);

            for (int i = 0; i < datafileGuids.Count(); i++)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + datafileGuids[i] + "'");

                dataAccess.GetData(filenameArray, "DATA_FILE_LNM");
                dataAccess.GetData(path, "FILE_PATH");
                dataAccess.GetData(DataFileGuids, "DATA_FILE_GUID");
                dataAccess.GetData(UploadType, "UPL_TYP_CD");
                dataAccess.GetData(FolderName, "FLDR_TYP_NM");
                dataAccess.GetData(WellboreGuid, "WB_JOB_GUID");
            }

        }

        protected void QueryWellData()
        {
            Dictionary<string, int> WellGuidHash = new Dictionary<string, int>();
            for (int i = 0; i < WellboreGuid.Count(); i++)
            {

                if (WellboreGuid[i] != null && WellboreGuid[i] != "")
                {
                    if (WellGuidHash.ContainsKey(WellboreGuid[i]) == false)
                    {
                        WellGuidHash.Add(WellboreGuid[i], i);
                    }
                    else
                    {
                        int index = 0;
                        if( WellGuidHash.TryGetValue(WellboreGuid[i], out index) == true )
                        {
                            WellName.Add(WellName[index]);
                            OperatorID.Add(OperatorID[index]);
                            Fieldname.Add(Fieldname[index]);
                            continue;
                        }
                    }

                    DataAccess dataAccess = new DataAccess();
                    dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + WellboreGuid[i] + "'");

                    dataAccess.GetData(WellName, "WELL_NM");
                    dataAccess.GetData(OperatorID, "CO_NM");
                    dataAccess.GetData(Fieldname, "FLD_NM");

                }
                else
                {
                    WellName.Add("");
                    OperatorID.Add("");
                    Fieldname.Add("");

                }

            }
            if (OperatorID.Count == 0)
            {
                for (int j = 0; j < Fieldname.Count; j++)
                {
                    OperatorID.Add(Fieldname[j]);
                }

            }
        }


        string UserID = "";

        protected void QueryUserData()
        {
            DataService dataservice = new DataService();
            string user = dataservice.GetCurrentUser();
            UserID = user;
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");

            userguid = "";

            userguid = dataAccess.GetData("USR_GUID");

        }

        protected void QueryMachineDrive()
        {
            if (AppCache.Drive == null)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

                string drive = "";

                drive = dataAccess.GetData("DRV_PATH");
                machine = drive;

                AppCache.Drive = drive;
            }
            else
            {
                machine = AppCache.Drive;
            }
            //machine = (string)Application["STORAGE_DRIVE"];
        }


        protected void QueryAllFileData()
        {
            QuerydataFiles();
            QueryWellData();
            QueryUserData();
            QueryMachineDrive();
        }

        protected void DownloadSelectedFiles(string[] selectedFiles, string archiveFilenameIn)
        {
            string zipFileName = "";
            {
                string strDate = DateTime.Now.ToString("yyyyMMddhhmmss");
                zipFileName = "XSpaceFiles" + strDate + ".zip";
            }
            Response.ContentType = "application/zip";
            Response.AddHeader("content-disposition", "attachment; fileName=" + zipFileName);
            Response.AppendCookie(new HttpCookie("fileDownload", "true") { Path = "/" });
            byte[] buffer = new byte[4096];
            ZipOutputStream zipOutputStream = new ZipOutputStream(Response.OutputStream);
            zipOutputStream.EnableZip64 = Zip64Option.AsNecessary;
            //ZipOutputStream zipOutputStream = new ZipOutputStream(Response.OutputStream);
            //zipOutputStream.SetLevel(3);


            ZipFile zf = null;
            try
            {
                //WebClient req = new WebClient();

            //string url = "http://" + Request.Url.Host + ":" + Request.Url.Port.ToString();
            string url = SPContext.Current.Web.Url.ToString();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        //Stream fs = req.OpenRead(archiveFilenameIn);
                        //Stream fs = new FileStream((string)(archiveFilenameIn),
                        //   FileMode.Open,
                        //   FileAccess.Read);

                        //= File.OpenRead(archiveFilenameIn);
                        zf = new ZipFile(archiveFilenameIn);
                        //zf = new ZipFile(fs);

                        foreach (ZipEntry zipEntry in zf)
                        {
                            if (zipEntry.IsDirectory == true || selectedFiles.Contains(zipEntry.FileName) == false)
                            {
                                continue;           // Ignore directories
                            }
                            String entryFileName = zipEntry.FileName;
                            buffer = new byte[4096];     // 4K is optimum


                            //ZipEntry zipNewEntry = new ZipEntry((string)(zipEntry.FileName));
                            ////zipNewEntry.Size = (Convert.ToInt64(zipEntry.Size));
                            Stream myStream = zipEntry.OpenReader();
                            if (myStream != null)
                            {
                                if (zipOutputStream.ContainsEntry((string)(zipEntry.FileName)) == false)
                                {
                                    zipOutputStream.PutNextEntry((string)(zipEntry.FileName));
                                }
                                else
                                {
                                    myStream.Close();
                                    continue;
                                }


                                Int64 count = zipEntry.UncompressedSize;

                                while (count > 0)
                                {
                                    int bytesRead = myStream.Read(buffer, 0, 4096);
                                    count = count - bytesRead;

                                    zipOutputStream.Write(buffer, 0, bytesRead);
                                    //count = fs.Read(buffer, 0, buffer.Length);
                                    if (!Response.IsClientConnected)
                                    {

                                    }
                                    Response.Flush();

                                }
                                myStream.Close();

                            }

                        }
                        zipOutputStream.Close();
                    }
                }
            });
            }
            finally
            {
                if (zf != null)
                    zf.Dispose();
                //if (zf != null)
                {
                    //zf. = true; // Makes close also shut the underlying stream
                    //zf.Close(); // Ensure we release resources
                }
            }
        }


        public string serviceUrlConfig = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            serviceUrlConfig = FileService.GetDataServiceUrl();
            QueryAllFileData();
            var qs = HttpUtility.ParseQueryString(Request.Url.Query);
            string FileNames = Request["FileNames"]; // Folder Names.

            string[] selectedFiles = null;
            if (string.IsNullOrEmpty(FileNames) == false)
            {
                selectedFiles = FileNames.Split(',');
            }
            

            for (int i = 0; i < WellboreGuid.Count(); i++)
            {
                if (string.IsNullOrEmpty(WellboreGuid[i]) == false)
                    UploadType[i] = "WELL";
                else
                    UploadType[i] = "USER";

            }

            Array array = Array.CreateInstance(typeof(string), datafileGuids.Count());


            List<string> ResultFileNameArray = new List<string>();
            for (int i = 0; i < path.Count(); i++)
            {
                string FilePath;
                path[i] = path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(machine, path[i]);
                FilePath = Path.Combine(FilePath, filenameArray[i]);
                FilePath = machine + FilePath;
                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(filenameArray[i]);

            }

            Response.Clear();
            if (selectedFiles != null)
            {
                if (selectedFiles.Count() > 0)
                {
                    DownloadSelectedFiles(selectedFiles, (string)(array.GetValue(0)));
                    return;
                }
            }

             // User to User File download or Already zipped well file download.
            if (DataFileGuids.Count() == 1 && (string.Compare(UploadType[0], "User", true) == 0 || ResultFileNameArray[0].Contains(".zip") || link == true))
            {
                for (int i = 0; i < 1; i++)
                {
                    Response.ContentType = "application/zip";
                    Response.AddHeader("content-disposition", "attachment; fileName=" + ResultFileNameArray[i]);

                    Response.AppendCookie(new HttpCookie("fileDownload", "true") { Path = "/" });
                    string filepath = (string)array.GetValue(i);

                    //WebClient req = new WebClient();

                    string url = SPContext.Current.Web.Url.ToString();
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        using (SPSite site = new SPSite(url))
                        {
                            using (SPWeb web = site.OpenWeb())
                            {

                                Stream myStream = null;
                                try
                                {
                                    myStream = new FileStream((string)(array.GetValue(i)),
                                       FileMode.Open,
                                       FileAccess.Read);
                                    //myStream = req.OpenRead((string)(array.GetValue(i)));
                                }
                                catch (Exception ex)
                                {

                                }

                                if (myStream != null)
                                {
                                    Int64 count = myStream.Length;
                                    //Int64 count = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));
                                    Response.AddHeader("Content-Length", count.ToString());
                                    byte[] buffer = new byte[4096];
                                    int bytesRead = 0;

                                    while (count > 0)
                                    {

                                        bytesRead = myStream.Read(buffer, 0, 4096);
                                        count = count - bytesRead;

                                        Response.BinaryWrite(buffer);

                                        if (!Response.IsClientConnected)
                                        {

                                        }
                                        Response.Flush();

                                    }
                                    myStream.Close();
                                    if (count <= 0)
                                    {
                                        if (UploadType[i] == null)
                                            UploadType[i] = "";
                                        var param = "UserGuid='" + userguid + "'&DataFileGuid='" + datafileGuids[i] + "'" + "&TypeCode='"
                                     + UploadType[i] + "'" + "&RepeatFlag='" + "f" + "'" + "&UserID='" + UserID + "'";
                                        DataAccess dataAccess = new DataAccess();
                                        dataAccess.ExecuteProcedure("InsertFileDownload_SP", param);
                                    }
                                    Response.Close();
                                }
                            }
                        }
                    });

                    // Zip single well file download.
                }
            }
            else
            {
                string zipFileName = "";
                if (DataFileGuids.Count() == 1)
                {
                    int index = filenameArray[0].LastIndexOf(".");
                    if (index >= 0)
                    {
                        zipFileName = filenameArray[0].Substring(0, index) + ".zip";
                    }
                    else
                        zipFileName = "LogData.zip";
                }
                else
                {
                    string strDate = DateTime.Now.ToString("yyyyMMddhhmmss");
                    zipFileName = "XSpaceFiles" + strDate + ".zip";
                }
                Response.ContentType = "application/zip";
                Response.AddHeader("content-disposition", "attachment; fileName=" + zipFileName);

                Response.AppendCookie(new HttpCookie("fileDownload", "true") { Path = "/" });
                Response.CacheControl = "Private";
                Response.Cache.SetExpires(DateTime.Now.AddMinutes(3)); // or put
                byte[] buffer = new byte[4096];
                ZipOutputStream zipOutputStream = new ZipOutputStream(Response.OutputStream);
                zipOutputStream.EnableZip64 = Zip64Option.AsNecessary;

                string url = SPContext.Current.Web.Url.ToString();
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    using (SPSite site = new SPSite(url))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            try
                            {
                                {
                                    Dictionary<string, int> fileMap = new Dictionary<string, int>();
                                    for (int i = 0; i < array.Length; i++)
                                    {

                                        {
                                            //WebClient req = new WebClient();


                                            if (string.Compare(UploadType[i], "User", true) == 0)
                                            {

                                                if (fileMap.ContainsKey((string)(ResultFileNameArray[i])) == false)
                                                {
                                                    fileMap.Add((string)(ResultFileNameArray[i]), i);
                                                    zipOutputStream.PutNextEntry((string)(ResultFileNameArray[i]));
                                                }

                                                else
                                                    continue;

                                            }
                                            else if (string.IsNullOrEmpty(UploadType[i]) == true)
                                            {
                                                if (fileMap.ContainsKey((string)(ResultFileNameArray[i])) == false)
                                                {
                                                    fileMap.Add((string)(ResultFileNameArray[i]), i);
                                                    zipOutputStream.PutNextEntry((string)(ResultFileNameArray[i]));
                                                }
                                                //if (zipOutputStream.ContainsEntry((string)(ResultFileNameArray[i])) == false)
                                                //{
                                                //    zipOutputStream.PutNextEntry((string)(ResultFileNameArray[i]));
                                                //}

                                                else
                                                    continue;

                                            }
                                            else
                                            {
                                                string entry = "Wells" + "\\" + OperatorID[i] + Fieldname[i] + WellName[i] + "\\" + FolderName[i]
                                                    + "\\" + ResultFileNameArray[i];

                                                if (fileMap.ContainsKey(entry) == false)
                                                {
                                                    fileMap.Add(entry, i);
                                                    zipOutputStream.PutNextEntry(entry);
                                                }
                                                //if (zipOutputStream.ContainsEntry(entry) == false)
                                                //{
                                                //    zipOutputStream.PutNextEntry(entry);
                                                //}

                                                else
                                                    continue;

                                            }
                                            Stream myStream = null;
                                            try
                                            {
                                                myStream = new FileStream((string)(array.GetValue(i)),
                                                    FileMode.Open,
                                                    FileAccess.Read);
                                                //myStream = req.OpenRead((string)(array.GetValue(i)));
                                            }
                                            catch (Exception ex)
                                            {
                                                continue;
                                            }
                                            if (myStream != null)
                                            {
                                                Int64 count = myStream.Length;

                                                while (count > 0)
                                                {
                                                    int bytesRead = myStream.Read(buffer, 0, 4096);
                                                    count = count - bytesRead;

                                                    zipOutputStream.Write(buffer, 0, bytesRead);
                                                    if (!Response.IsClientConnected)
                                                    {

                                                    }
                                                    Response.Flush();

                                                }
                                                myStream.Close();
                                                if (count <= 0)
                                                {
                                                    if (UploadType[i] == null)
                                                        UploadType[i] = "D";
                                                    var param = "UserGuid='" + userguid + "'&DataFileGuid='" + datafileGuids[i] + "'" + "&TypeCode='"
                                                 + UploadType[i] + "'" + "&RepeatFlag='" + "f" + "'" + "&UserID='" + UserID + "'";
                                                    DataAccess dataAccess = new DataAccess();
                                                    dataAccess.ExecuteProcedure("InsertFileDownload_SP", param);
                                                }
                                            }
                                        }

                                    }
                                    fileMap.Clear();

                                }

                                zipOutputStream.Close();

                                Response.Flush();
                                HttpContext.Current.ApplicationInstance.CompleteRequest();
                            }
                            catch (Exception ex)
                            {
                                throw;
                            }
                        }
                    }
                });
            }

        }
    
     }
}
