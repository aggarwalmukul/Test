﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Data.Library
{
    public class AppCache
    {
        public static string Drive
        {
            get
            {
                return (string)System.Web.HttpRuntime.Cache["Drive"];
            }
            set
            {
                System.Web.HttpRuntime.Cache["Drive"] = value;
            }
        }

        public static string DriveGuid
        {
            get
            {
                return (string)System.Web.HttpRuntime.Cache["DriveGuid"];
            }
            set
            {
                System.Web.HttpRuntime.Cache["DriveGuid"] = value;
            }
        }
    }
}
