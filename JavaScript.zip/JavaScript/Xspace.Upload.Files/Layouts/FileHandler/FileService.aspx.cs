﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.Services;
//using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using XSpace.Upload.Download.Files.Layouts;
using System.Web;
using System.Linq;
using System.IO;
//using ICSharpCode.SharpZipLib.Zip;
using System.Collections;
using System.Web.Script.Serialization;
//using ICSharpCode.SharpZipLib.Core;
using System.Data;
using Microsoft.SharePoint.Utilities;
using System.Configuration;
using System.Security.AccessControl;
using XSpace.Data.Library;

namespace XSpace.Upload.Download.Files.Layouts.FileHandler
{
    public partial class FileService : LayoutsPageBase
    {
        public static string GetSettingsKeyValue(string keyName)
        {
            string keyvalue = string.Empty;
            
                    using (SPWeb mySite = SPContext.Current.Web)
                    {

                        SPList list = mySite.Lists["XSpaceSettings"];

                        SPListItemCollection oSpListCln = list.Items;
                        foreach (SPListItem item in oSpListCln)
                        {
                            if ((string)item["KeyName"] == keyName)
                            {

                                keyvalue = (string)item["KeyValue"];
                            }

                        }

                    }

              

            return keyvalue;
        }

        [WebMethod]
        public static string CheckIfStorageDrivePermissionExists()
        {

            string machine;
            //DataService service = new DataService();
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

            string drive = "";
            //DataTable table = service.GetDatatable(storagedrive);
            drive = dataAccess.GetData( "DRV_PATH");

            machine = drive;
            string directoryPath = machine; //folderBrowserDialog.SelectedPath;
            string isWriteAccess = "true";

            string url = SPContext.Current.Web.Url.ToString();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                        try
                        {

                            string uploadFilePath = Path.Combine(machine, Path.GetRandomFileName());
                            Stream stream = new FileStream(uploadFilePath, FileMode.CreateNew);
                            if (stream == null)
                            {
                                isWriteAccess = "false";
                            }
                            else
                            {
                                stream.Close();
                                File.Delete(uploadFilePath);
                            }
                        }
                        catch (UnauthorizedAccessException ex)
                        {
                            isWriteAccess = "false";
                        }
                        catch (Exception ex)
                        {
                            isWriteAccess = "false";
                        }


                    // implementation details omitted
                }
            });
    
            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize(isWriteAccess);

            return TheJsonEx;
        }



        [WebMethod]
        public static string GetDataService()
        {
            
            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize(GetDataServiceUrl());

            return TheJsonEx;

        }
        [WebMethod]
        public static string GetTextService()
        {

            string textserviceurl;
            string Server = (string)GetSettingsKeyValue("DataServiceUrl");
            string port = (string)GetSettingsKeyValue("Port");
            textserviceurl = SPContext.Current.Web.Url.ToString()+"/_vti_bin/XSpace.Common.Services/EmailSmsService.svc/";

            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize(textserviceurl);

            return TheJsonEx;

        }
        public static string GetDataServiceUrl()
        {
            //if (string.IsNullOrEmpty(serviceurl) == true)
            string serviceurl;


            string Server = (string)GetSettingsKeyValue("DataServiceUrl");
            string port = (string)GetSettingsKeyValue("Port");
            serviceurl = SPContext.Current.Web.Url.ToString() +"/_vti_bin/XSpace.Common.Services/DataService.svc/ExecuteProcedure/XSPACE/";

            return serviceurl;
        }
         [WebMethod]
        public static string DeleteXSpaceCookie(string cookieName)
        {
            var arrCookie = cookieName.Split(';');
            if (arrCookie.Length > 0)
            {
                for (int i = 0; i < arrCookie.Length; i++)
                {
                    if (arrCookie[i] !="" && HttpContext.Current.Request.Cookies[arrCookie[i]] != null)
                    {
                        HttpCookie myCookie = new HttpCookie(arrCookie[i]);
                        myCookie.Expires = DateTime.Now.AddDays(-1d);
                        HttpContext.Current.Response.Cookies.Add(myCookie);
                    }
                }               
            }
            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize("success");

            return TheJsonEx;
        }
        
        

        public class DataFile
        {

            public List<string> path = new List<string>();
            public List<string> filenameArray = new List<string>();
            public List<string> DataFileGuids = new List<string>();
            public List<string> UploadType = new List<string>();
            public List<string> FolderName = new List<string>();
            public List<string> WellboreGuid = new List<string>();
            public List<string> WellName = new List<string>();
            public List<string> OperatorID = new List<string>();
            public List<string> Fieldname = new List<string>();
            public List<string> FolderType = new List<string>();
            public string[] datafileGuids = null;
            public string userguid = "";
            public string machine = "";
            public string DriveGuid = "";
            public DataAccess dataAccess = new DataAccess();
            public string Guids;
            public string UserID = "";


        }


        protected static void ClearFields()
        {
        }
        protected static void QuerydataFiles(DataFile XSpaceFile)
        {
            //var qs = HttpUtility.ParseQueryString(HttpContext.Current.Request.Url.Query);
            string guids = XSpaceFile.Guids; // Folder Names.
            char[] delimitedChars = { ',' };
            XSpaceFile.datafileGuids = guids.Split(delimitedChars);

            for (int i = 0; i < XSpaceFile.datafileGuids.Count(); i++)
            {
                XSpaceFile.dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + XSpaceFile.datafileGuids[i] + "'");
                XSpaceFile.dataAccess.GetData( XSpaceFile.filenameArray, "DATA_FILE_LNM");
                XSpaceFile.dataAccess.GetData( XSpaceFile.path, "FILE_PATH");
                XSpaceFile.dataAccess.GetData( XSpaceFile.DataFileGuids, "DATA_FILE_GUID");
                XSpaceFile.dataAccess.GetData( XSpaceFile.UploadType, "UPL_TYP_CD");
                XSpaceFile.dataAccess.GetData( XSpaceFile.FolderName, "FLDR_TYP_NM");
                XSpaceFile.dataAccess.GetData( XSpaceFile.FolderType, "FLDR_TYP_ID");

                XSpaceFile.dataAccess.GetData( XSpaceFile.WellboreGuid, "WB_JOB_GUID");


            }

        }

        protected static void QueryWellData(DataFile XSpaceFile)
        {
            Dictionary<string, int> WellGuidHash = new Dictionary<string, int>();
            for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
            {
                if (XSpaceFile.WellboreGuid[i] != null && XSpaceFile.WellboreGuid[i] != "")
                {
                    if (WellGuidHash.ContainsKey(XSpaceFile.WellboreGuid[i]) == false)
                    {
                        WellGuidHash.Add(XSpaceFile.WellboreGuid[i], i);
                    }
                    else
                    {
                        int index = 0;
                        if (WellGuidHash.TryGetValue(XSpaceFile.WellboreGuid[i], out index) == true)
                        {
                            XSpaceFile.WellName.Add(XSpaceFile.WellName[index]);
                            XSpaceFile.OperatorID.Add(XSpaceFile.OperatorID[index]);
                            XSpaceFile.Fieldname.Add(XSpaceFile.Fieldname[index]);
                            continue;
                        }
                    }

                    DataAccess dataAccess = new DataAccess();
                    dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + XSpaceFile.WellboreGuid[i] + "'");

                    dataAccess.GetData(XSpaceFile.WellName, "WELL_NM");
                    dataAccess.GetData(XSpaceFile.OperatorID, "CO_NM");
                    dataAccess.GetData(XSpaceFile.Fieldname, "FLD_NM");

                }
                else
                {
                    XSpaceFile.WellName.Add("");
                    XSpaceFile.OperatorID.Add("");
                    XSpaceFile.Fieldname.Add("");

                }

            }
        }




        protected static void QueryUserData(DataFile XSpaceFile)
        {
            DataService dataservice = new DataService();
            string user = dataservice.GetCurrentUser();
            XSpaceFile.dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");
            XSpaceFile.UserID = user;

            XSpaceFile.userguid = "";

            XSpaceFile.userguid = XSpaceFile.dataAccess.GetData("USR_GUID");
         
        }

        protected static void QueryMachineDrive(DataFile XSpaceFile)
        {
            if (AppCache.Drive == null || AppCache.DriveGuid == null)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

                string drive = "";

                drive = dataAccess.GetData("DRV_PATH");
                XSpaceFile.machine = drive;
                XSpaceFile.DriveGuid = dataAccess.GetData("DRV_GUID");

                AppCache.Drive = drive;
                AppCache.DriveGuid = XSpaceFile.DriveGuid;
            }
            else
            {
                XSpaceFile.machine = AppCache.Drive;
                XSpaceFile.DriveGuid = AppCache.DriveGuid; 
            }
            //machine = (string)Application["STORAGE_DRIVE"];
        }

       


        protected static void QueryAllFileData( DataFile XSpaceFile)
        {

            ClearFields();
            QuerydataFiles(XSpaceFile);
            QueryWellData(XSpaceFile);
            QueryUserData(XSpaceFile);
            QueryMachineDrive(XSpaceFile);
        }

        [WebMethod]
        public static string RenameFile(string Guid, string FileName)
        {

            DataFile XSpaceFile = new DataFile();
            XSpaceFile.Guids = Guid;
            QueryAllFileData(XSpaceFile);
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();
            List<string> NewNames = new List<string>();
            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;
                string NewPath;
                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);
                NewPath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                NewPath = Path.Combine(NewPath, FileName);
                FilePath = XSpaceFile.machine + FilePath;
                NewPath = XSpaceFile.machine + NewPath;
                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);
                NewNames.Add(NewPath);

            }
            string url = SPContext.Current.Web.Url.ToString();
            string status = "success";
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        for (int i = 0; i < XSpaceFile.path.Count(); i++)
                        {
                            if (File.Exists(NewNames[i]) == false)
                            {
                                File.Move((string)array.GetValue(i), NewNames[i]);
                                string param = "DataFileGuid='" + XSpaceFile.datafileGuids[i] + "'&" + "FileName='" +
                                    FileName + "'&" + "UserID='" + XSpaceFile.UserID + "'";
                                XSpaceFile.dataAccess.ExecuteProcedure("UpdateDataFile_SP", param);

                                }
                            else
                            {
                                status = "Failure";
                                
                            }
                        }

                    }
                }
            });
            JavaScriptSerializer jsonstatus = new JavaScriptSerializer();
            return jsonstatus.Serialize(status);
        }

        [WebMethod]
        public static string MoveFile(string Guid, string DataUploadGuid, string Folder, string FolderType)
        {
            DataFile XSpaceFile = new DataFile();
            XSpaceFile.Guids = Guid;
            QueryAllFileData(XSpaceFile);
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();
            List<string> NewNames = new List<string>();
            string directory = "";
            string NewDatabasePath = "";
            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {

                string FilePath;

                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                int index = XSpaceFile.path[i].LastIndexOf('\\');
                string FolderName = XSpaceFile.path[i].Substring(index + 1);

                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                directory = XSpaceFile.machine + FilePath.Replace(FolderName, Folder);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);
                FilePath = XSpaceFile.machine + FilePath;


                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);
                NewNames.Add(FilePath.Replace(FolderName, Folder));
                NewDatabasePath = "\\\\" + "WELLS" + "\\\\" + XSpaceFile.WellboreGuid[i] + "\\\\" + Folder;



            }
            string url = SPContext.Current.Web.Url.ToString();
            string status = "success";
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        for (int i = 0; i < XSpaceFile.path.Count(); i++)
                        {
                            if (File.Exists(NewNames[i]) == false)
                            {
                                if (Directory.Exists(directory) == false)
                                {
                                    Directory.CreateDirectory(directory);                                  
                                }                                
                                
                                File.Move((string)array.GetValue(i), NewNames[i]);
                                string param = "DataFileUploadGuid='" + DataUploadGuid + "'&" + "DestPath='" +
                                    NewDatabasePath + "'&" + "UserID='" + XSpaceFile.UserID + "'&" + "DataFileGuid='" + Guid + "'&FolderType='" + FolderType + "'";
                                XSpaceFile.dataAccess.ExecuteProcedure("UpdateDataFileUpload_SP", param);
                                
                            }
                            else
                            {
                                status = "Failure";

                            }
                        }

                    }
                }
            });
            JavaScriptSerializer jsonstatus = new JavaScriptSerializer();
            return jsonstatus.Serialize(status);
        }

        public struct FileDetails
        {
            public string FileGuid;
            public string FileName;
            public double Size;

        }

        [WebMethod]
        public static long CreateSubZipFile(string archiveFilenameIn, string outPathname, string zipFileName, string[] selectedFiles)
        {

            string outfileName = Path.Combine(outPathname, zipFileName);
            Directory.CreateDirectory(outPathname);
            FileStream fsOut = File.Create(outfileName);
            Ionic.Zip.ZipOutputStream zipOutStream = new Ionic.Zip.ZipOutputStream(fsOut);
            zipOutStream.EnableZip64 = Ionic.Zip.Zip64Option.AsNecessary;

            //zipOutStream.SetLevel(3); //0-9, 9 being the highest level of compression

            Ionic.Zip.ZipFile zf = null;
            long size = 0;
            try
            {
                //FileStream fs = File.OpenRead(archiveFilenameIn);
                zf = new Ionic.Zip.ZipFile(archiveFilenameIn);

                foreach (Ionic.Zip.ZipEntry zipEntry in zf)
                {
                    if (zipEntry.IsDirectory || selectedFiles.Contains(zipEntry.FileName)==false)
                    {
                        continue;           // Ignore directories
                    }
                    String entryFileName = zipEntry.FileName;
                    //ZipEntry newEntry = new ZipEntry(entryFileName);
                    //newEntry.DateTime = zipEntry.DateTime;
                    //newEntry.Size = zipEntry.Size;
                    if (zipOutStream.ContainsEntry(entryFileName) == false)
                    {
                        zipOutStream.PutNextEntry(entryFileName);
                    }
                    else
                        continue;
                    size = size + zipEntry.UncompressedSize;
                    
                    // to remove the folder from the entry:- entryFileName = Path.GetFileName(entryFileName);
                    // Optionally match entrynames against a selection list here to skip as desired.
                    // The unpacked length is available in the zipEntry.Size property.

                    byte[] buffer = new byte[4096];     // 4K is optimum
                    Stream zipStream = zipEntry.InputStream;

                    Int64 count = zipEntry.CompressedSize;
                    zipEntry.Extract(zipOutStream);

                }
            }
            finally
            {
                zf.Dispose();
            }


            zipOutStream.Close();
            return size;
        }

        [WebMethod]
        public static string InsertData(string FileName, string FilePath, double Size, DataFile XSpaceFile, int i)
        {
            var param = "DriveGuid=" + "'" + XSpaceFile.DriveGuid + "'&" + "FileName=" + "'" + FileName + "'&" + "FilePath=" + "'" + FilePath
             + "'&" + "Status=" + "'" + "FINAL" + "'&" + "Comment=" + "'" + "" + "'&" + "UserID='" + XSpaceFile.UserID + "'&" + "Size=" + Size;
            
            string datafileguid = "";
            DataService service = new DataService();

            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("InsertDataFile_SP", param);

            datafileguid = dataAccess.GetData("DATA_FILE_GUID");
            if (string.IsNullOrEmpty(XSpaceFile.WellboreGuid[i])== false)
            {
                if (XSpaceFile.WellboreGuid[i] != null)
                {
                    param = "WBJobGuid=" + "'" + XSpaceFile.WellboreGuid[i] + "'&" + "DataFileGuid=" + "'" + datafileguid + "'&" + "FolderType=" + "'" + XSpaceFile.FolderType[i] + "'&" + "UserID='" + XSpaceFile.UserID + "'";

                    dataAccess.ExecuteProcedure("InsertWBJobDataFile_SP", param);
                }

            }
            
            return datafileguid;
        }

        [WebMethod]
        public static string PackageSelectedFileForDistribution(string Guid, string FileNames)
        {
            DataFile XSpaceFile = new DataFile();
            XSpaceFile.Guids = Guid;
            QueryAllFileData(XSpaceFile);
            string[] selectedFiles = FileNames.Split(',');
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();
            string Foldername = "DistributedFile";
            string NewFolderPath = "";

            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;

                Foldername = XSpaceFile.path[i];
                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                NewFolderPath = XSpaceFile.path[i];
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);

                FilePath = XSpaceFile.machine + FilePath;

                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);


            }
            ArrayList myAL = new ArrayList();
            string url = SPContext.Current.Web.Url.ToString();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        for (int i = 0; i < XSpaceFile.path.Count(); i++)
                        {
                            try
                            {

                                string outfilePath = XSpaceFile.machine + NewFolderPath;
                                string strDate = DateTime.Now.ToString("yyyyMMddhhmmss");
                                string zipFileName = "XSpaceFiles" + strDate + ".zip";
                                string filePathFordatabase =  Foldername;
                                long size = CreateSubZipFile(((string)array.GetValue(i)), outfilePath,zipFileName, selectedFiles);
                                string DataGuid = InsertData(zipFileName, filePathFordatabase, ConvertSizeFromKBtoMB(size), XSpaceFile, i);
                                FileDetails details = new FileDetails();
                                details.FileGuid = DataGuid;
                                details.FileName = zipFileName;
                                details.Size = ConvertSizeFromKBtoMB(size);
                                myAL.Add(details);

                            }
                            catch (Exception ex)
                            {

                            }

                        }
                    }
                }
            });
            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize(myAL);

            return TheJsonEx;

        }

        public static double ConvertSizeFromKBtoMB(long size)
        {
            double Size = (size / 1024f) / 1024f;
            return Math.Round(Size, 2);

        }

        [WebMethod]
        public static string GetFileList(string Guid)
        {
            DataFile XSpaceFile = new DataFile();
            XSpaceFile.Guids = Guid;
            QueryAllFileData(XSpaceFile);
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();

            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;

                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);

                FilePath = XSpaceFile.machine + FilePath;

                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);


            }
            ArrayList myAL = new ArrayList();
            //string url =  "http://" + HttpContext.Current.Request.Url.Host + ":" + HttpContext.Current.Request.Url.Port.ToString();
            string url = SPContext.Current.Web.Url.ToString();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        for (int i = 0; i < XSpaceFile.path.Count(); i++)
                        {
                            Ionic.Zip.ZipFile zf = null;
                            try
                            {
                                //FileStream fs = File.OpenRead((string)array.GetValue(i));
                                zf = new Ionic.Zip.ZipFile((string)array.GetValue(i));
                                foreach (Ionic.Zip.ZipEntry zipEntry in zf)
                                {
                                    if (zipEntry.IsDirectory)
                                    {
                                        continue;           // Ignore directories
                                    }
                                    String entryFileName = zipEntry.FileName;
                                    FileDetails details = new FileDetails();

                                    {
                                        details.FileGuid = XSpaceFile.DataFileGuids[i];
                                        details.FileName = entryFileName;
                                        details.Size = ConvertSizeFromKBtoMB(zipEntry.CompressedSize);
                                        myAL.Add(details);
                                        
                                    }
                                }
                                //zf.IsStreamOwner = true; // Makes close also shut the underlying stream
                                //zf.Close(); // Ensure we release resources

                            }
                            catch (Exception ex)
                            {



                            }

                        }
                    }
                }
            });
            JavaScriptSerializer TheSerializerEx = new JavaScriptSerializer();

            //optional: you can create your own custom converter

            var TheJsonEx = TheSerializerEx.Serialize(myAL);

            return TheJsonEx;
        
        }
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
