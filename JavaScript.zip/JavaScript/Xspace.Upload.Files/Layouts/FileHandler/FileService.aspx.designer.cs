﻿namespace XSpace.Upload.Download.Files.Layouts.FileHandler
{
    public partial class FileService
    {
    }
}
