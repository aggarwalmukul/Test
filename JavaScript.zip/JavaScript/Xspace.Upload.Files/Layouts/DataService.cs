﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Runtime.InteropServices;
using System.Drawing;
using System.IO;
using System.Collections.Generic;
using System.Web;
using Westwind.plUpload;
using System.Text;
using System.Linq;
//using Newtonsoft.Json;
using System.Net;
//using Newtonsoft.Json.Linq;
using System.Data;
using System.Configuration;
using XSpace.Upload.Download.Files.Layouts.FileHandler;


namespace XSpace.Upload.Download.Files.Layouts
{
    public class DataService
    {
        //public string ExecuteProcedure(string procedure, string parameter, string serviceUrlConfig)
        //{
        //    //string serviceUrlConfig = FileService.GetDataServiceUrl();
        //    var param = "?parameter=" + parameter;
        //    string serviceUrl = serviceUrlConfig + procedure + param;
        //    WebClient client = new WebClient();
        //    client.UseDefaultCredentials = true;
        //    client.Headers["Content-type"] = "application/json";
        //    client.Encoding = Encoding.UTF8;
        //    string response = response = client.DownloadString(serviceUrl);
        //    return response;
        //}
        //class ExecuteData
        //{
        //    [JsonProperty(PropertyName = "ExecuteProcedureWithoutPropResult")]
        //    public string dataWithoutPropResult { get; set; }
        //    [JsonProperty(PropertyName = "ExecuteProcedureWithoutParamResult")]
        //    public string dataWithoutParamResult { get; set; }
        //    public string GetData(string data)
        //    {
        //        if (data != null)
        //        {
        //            var parent = JsonConvert.DeserializeObject<ExecuteData>(data);
        //            if (data.Contains("ExecuteProcedureWithoutPropResult") == true)
        //            {
        //                return parent.dataWithoutPropResult;

        //            }
        //            if (data.Contains("ExecuteProcedureWithoutParamResult") == true)
        //            {
        //                return parent.dataWithoutParamResult;

        //            }

        //        }
        //        return null;

        //    }
        //}

        //class ServiceData
        //{
        //    [JsonProperty(PropertyName = "data")]
        //    public System.Data.DataTable Items { get; set; }
        //}


        //public DataTable GetDatatable(string data)
        //{
        //    ExecuteData returnedData = new ExecuteData();
        //    var parent = returnedData.GetData(data);
        //    //var parent = JsonConvert.DeserializeObject<ExecuteWithoutPropServiceData>(data);
        //    if (parent != null)
        //    {
        //        var jsondata = JsonConvert.DeserializeObject<ServiceData>(parent);
        //        return jsondata.Items;
        //    }
        //    else
        //        return null;
        //}


        //public void GetData(DataTable table, List<string> dataArray, string columnName)
        //{
        //    foreach (DataRow row in table.Rows)
        //    {
        //        string line = string.Empty;

        //        foreach (DataColumn column in table.Columns)
        //        {
        //            if (column.ColumnName == columnName)
        //            {
        //                object value = row[column];
        //                if (value != DBNull.Value)
        //                {
        //                    string data = (string)row[column];
        //                    dataArray.Add(data);
        //                }
        //                else
        //                {
        //                    dataArray.Add("");
        //                }
        //            }

        //        }
        //    }
        //}

        //public string GetData(DataTable table, string columnName)
        //{
        //    foreach (DataRow row in table.Rows)
        //    {
        //        string line = string.Empty;

        //        foreach (DataColumn column in table.Columns)
        //        {
        //            if (column.ColumnName == columnName)
        //            {
        //                string data = (string)row[column];
        //                return data;
        //            }

        //        }
        //    }
        //    return "";
        //}

        public string GetCurrentUser()
        {
            string strUserContext = HttpContext.Current.User.Identity.Name.ToString();
            string strUserID = string.Empty;

            if (!strUserContext.Contains('\\'))
            {
                strUserID = strUserContext.Split('|')[2].ToString();
            }
            else
            {
                strUserID = strUserContext.Split('\\')[1].ToString();
            }

            return strUserID;
        }
    }
}
                    

            
          

