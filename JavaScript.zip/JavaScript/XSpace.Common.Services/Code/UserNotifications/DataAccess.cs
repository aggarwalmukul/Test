﻿using Microsoft.SharePoint;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace XSpace.Common.Services
{
    public class DataAccess
    {
        string data;
        //DataTable table;
        JToken token;
        

        class ExecuteData
        {
            [JsonProperty(PropertyName = "data")]
            public string dataWithoutPropResult { get; set; }
            JToken token;

            public JToken GetData(string data)
            {
                if (data != null)
                {
                    JObject obj = JObject.Parse(data);
                    token = obj["data"];
                    return token;
                }
                return null;

            }
        }

        class ServiceData
        {
            [JsonProperty(PropertyName = "data")]
            public System.Data.DataTable Items { get; set; }
        }

        public void ExecuteProcedure(string procedure, string param)
        {
            token = null;
            DataService service = new DataService();
            //param = param.Replace("#", "%23");
            data = service.ExecuteProcedure("XSPACE", procedure, param);
            GetDatatable(data);
        }

        //public static string GetSettingsKeyValue(string keyName)
        //{
            
        //    using (SPWeb mySite = SPContext.Current.Web)
        //    {
        //        SPList list = mySite.Lists["XSpaceSettings"];

        //        SPListItemCollection oSpListCln = list.Items;
        //        foreach (SPListItem item in oSpListCln)
        //        {
        //            if ((string)item["KeyName"] == keyName)
        //            {

        //                return (string)item["KeyValue"];
        //            }

        //        }



        //    }

        //    return "";
        //}


        private void GetDatatable(string data)
        {
            ExecuteData returnedData = new ExecuteData();
            token = returnedData.GetData(data);
            //var parent = JsonConvert.DeserializeObject<ExecuteWithoutPropServiceData>(data);

        }


        public void GetData( List<string> dataArray, string columnName)
        {

            for (int i = 0; i < token.Count(); i++ )
            {
                string line = string.Empty;

                //foreach (DataColumn column in table.Columns)
                {
                    //if (column.ColumnName == columnName)
                    {
                        //object value = row[column];
                        //if (value != DBNull.Value)
                        {

                            dataArray.Add((string)token[i][columnName]);
                        }
                        //else
                        //{
                        //    dataArray.Add("");
                        //}
                    }

                }
            }
        }

        public string GetData(string columnName)
        {
            return (string)token[0][columnName];
            //foreach (DataRow row in table.Rows)
            //{
            //    string line = string.Empty;

            //    foreach (DataColumn column in table.Columns)
            //    {
            //        if (column.ColumnName == columnName)
            //        {
            //            string data = (string)row[column];
            //            return data;
            //        }

            //    }
            //}
            //return "";
        }
    }
}
