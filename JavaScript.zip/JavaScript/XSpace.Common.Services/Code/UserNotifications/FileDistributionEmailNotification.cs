﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    class FileDistributionEmailNotification
    {
        protected static void QueryDistributeddataFiles(DataFile XSpaceFile)
        {
            //var qs = HttpUtility.ParseQueryString(HttpContext.Current.Request.Url.Query);
            string guids = XSpaceFile.Guids; // Folder Names.
            char[] delimitedChars = { ',' };
            XSpaceFile.datafileGuids = guids.Split(delimitedChars);

            for (int i = 0; i < XSpaceFile.datafileGuids.Count(); i++)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + XSpaceFile.datafileGuids[i] + "'");
                
                dataAccess.GetData( XSpaceFile.filenameArray, "DATA_FILE_LNM");
                dataAccess.GetData( XSpaceFile.path, "FILE_PATH");
                dataAccess.GetData( XSpaceFile.DataFileGuids, "DATA_FILE_GUID");
                dataAccess.GetData( XSpaceFile.UploadType, "UPL_TYP_CD");
                dataAccess.GetData( XSpaceFile.FolderName, "FLDR_TYP_NM");
                dataAccess.GetData( XSpaceFile.FolderType, "FLDR_TYP_ID");
                dataAccess.GetData( XSpaceFile.WellboreGuid, "WB_JOB_GUID");
                dataAccess.GetData( XSpaceFile.Comments, "DATA_FILE_CMNT");
                dataAccess.GetData( XSpaceFile.FileSize, "FILE_SZ_VAL");


            }
            List<string> filesize = new List<string>();
            for (int i = 0; i < XSpaceFile.FileSize.Count(); i++)
            {
                filesize.Add(Math.Round(Convert.ToDecimal(XSpaceFile.FileSize[i]), 2).ToString());

            }
            XSpaceFile.FileSize = filesize;

        }

        protected static void QueryDistributedWellData(DataFile XSpaceFile)
        {
            for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
            {
                if (XSpaceFile.WellboreGuid[i] != null && XSpaceFile.WellboreGuid[i] != "")
                {
                    DataAccess dataAccess = new DataAccess();
                    dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + XSpaceFile.WellboreGuid[i] + "'");
                    
                    dataAccess.GetData( XSpaceFile.WellName, "WELL_NM");
                    dataAccess.GetData( XSpaceFile.OperatorID, "CO_NM");
                    dataAccess.GetData( XSpaceFile.Fieldname, "FLD_NM");

                }
                else
                {
                    XSpaceFile.WellName.Add("");
                    XSpaceFile.OperatorID.Add("");
                    XSpaceFile.Fieldname.Add("");

                }

            }
        }


        protected static void QueryMachineDrive(DataFile XSpaceFile)
        {
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

            string drive = "";

            drive = dataAccess.GetData( "DRV_PATH");
            XSpaceFile.DriveGuid = dataAccess.GetData( "DRV_GUID");
            XSpaceFile.machine = drive;
        }

        protected static void QueryDistributedFileData(DataFile XSpaceFile)
        {
            QueryDistributeddataFiles(XSpaceFile);
            QueryDistributedWellData(XSpaceFile);
            QueryUserData(XSpaceFile);
            QueryMachineDrive(XSpaceFile);
            UserSettings settings = XSpaceFile.SenderSetting;
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserSettingByUserGuid_SP", "UserGuid='" + XSpaceFile.SenderGuid + "'");
            
            dataAccess.GetData( settings.Firstname, "USR_NM");
            dataAccess.GetData( settings.EmailAddress, "EMAIL_ADDR_DESC");
            

            dataAccess.GetData( settings.CellNumber, "CELL_PHONE_NUM");
            dataAccess.GetData( settings.CellPhoneProvider, "CELL_PHONE_PRVDR_CD");

            dataAccess.GetData( settings.WellEmailFlag, "WELL_NTFN_FLG");
            dataAccess.GetData( settings.DropBoxEmailFlag, "DROP_BOX_NTFN_FLG");

            dataAccess.GetData( settings.WellTextFlag, "WELL_TXT_NTFN_FLG");
            dataAccess.GetData( settings.DropBoxTextFlag, "DRPBX_TXT_NTFN_FLG");
        }





        public string GetFileDistributionHtmlTable(DataFile XSpaceFile)
        {
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();

            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;

                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);

                FilePath = XSpaceFile.machine + FilePath;

                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);


            }
            List<FileDetails> filedetail = new List<FileDetails>();
            for (int i = 0; i < XSpaceFile.filenameArray.Count(); i++)
            {
                if (XSpaceFile.filenameArray[i].Contains(".zip") == true)
                {
                    List<FileDetails> subfiledetail = GetFileList((string)array.GetValue(i));
                    for (int j = 0; j < subfiledetail.Count(); j++)
                    {
                        subfiledetail[j].WellName = XSpaceFile.WellName[i];
                        subfiledetail[j].FieldName = XSpaceFile.Fieldname[i];
                        subfiledetail[j].Operator = XSpaceFile.OperatorID[i];

                    }
                    filedetail.AddRange(subfiledetail);
                }
                else
                {
                    FileDetails detail = new FileDetails();
                    detail.FileName = XSpaceFile.filenameArray[i];
                    detail.WellName = XSpaceFile.WellName[i];
                    detail.FieldName = XSpaceFile.Fieldname[i];
                    detail.Operator = XSpaceFile.OperatorID[i];
                    double.TryParse(XSpaceFile.FileSize[i], out detail.Size);
                    filedetail.Add(detail);
                }
            }
            StringBuilder newbody = new StringBuilder();
            //if (XSpaceFile.UploadType.Count > 0)
            {
                newbody.Append("<tr>");
                newbody.Append("<td style=font-weight:bold>");
                newbody.Append("Document(s)");
                newbody.Append("</td>");
                newbody.Append("<td style=font-weight:bold>");
                newbody.Append("Size");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                for (int i = 0; i < filedetail.Count(); i++)
                {
                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append(filedetail[i].FileName);
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append(filedetail[i].Size.ToString() + "MB");
                    newbody.Append("</td>");
                    newbody.Append("</tr>");

                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("</tr>");
                }

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");
            }

            return newbody.ToString();
        }

        public string GetFileDistributionData(DataFile XSpaceFile, string receivername)
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "EmailAttachmentNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{Name}", receivername);
            body = body.Replace("{SName}", XSpaceFile.SenderSetting.Firstname[0]);

            string files = "<table width=600px border=0 cellspacing=2 cellpadding=2 bgcolor=White dir=ltr rules=all style=border-width: thin; border-style: solid; line-height: normal; vertical-align: baseline; text-align: center; font-family: Calibri; font-size: medium; font-weight: normal; font-style: normal; font-variant: normal; color: #000000; list-style-type: none;>";
            files = files + GetFileDistributionHtmlTable(XSpaceFile);
            files = files + "</table>";


            body = body.Replace("{Files}", files);
            body = body.Replace("{Comments}", XSpaceFile.Comments[0]);


            body = body.Replace("{SupportWirelineUrl}", ServiceData.GetWirelineSupportUrl());
            body = body.Replace("{SupportSperryUrl}", ServiceData.GetSperrySupportUrl());
            body = body.Replace("{SupportBaroidUrl}", ServiceData.GetBaroidSupportUrl());
            body = body.Replace("{ForgotPasswordUrl}", ServiceData.GetPasswordSupportUrl());
            return body;
        }

        public List<Attachment> CreateZipFileForEmail(DataFile XSpaceFile)
        {
            for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
            {
                if (string.IsNullOrEmpty(XSpaceFile.WellboreGuid[i]) == false)
                    XSpaceFile.UploadType[i] = "WELL";
                else
                    XSpaceFile.UploadType[i] = "USER";

            }

            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());


            List<string> ResultFileNameArray = new List<string>();
            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;
                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);
                FilePath = XSpaceFile.machine + FilePath;
                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);

            }

            List<Attachment> mailattachments = new List<Attachment>();
            // User to User File download or Already zipped well file download.
            //if (XSpaceFile.DataFileGuids.Count() == 1 && (string.Compare(XSpaceFile.UploadType[0], "User", true) == 0 || ResultFileNameArray[0].Contains(".zip")))
            //if (XSpaceFile.DataFileGuids.Count() == 1 )
            {
                for (int i = 0; i < XSpaceFile.DataFileGuids.Count(); i++)
                {
                    string filepath = (string)array.GetValue(i);

                    //WebClient req = new WebClient();
                    Stream myStream = null;
                    try
                    {
                        myStream = new FileStream((string)(array.GetValue(i)),
                          FileMode.Open,
                          FileAccess.Read);
                        //myStream = req.OpenRead((string)(array.GetValue(i)));
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }

                    if (myStream != null)
                    {
                        System.IO.MemoryStream ms = new System.IO.MemoryStream();
                        System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Octet);
                        ct.Name = ResultFileNameArray[i];

                        Int64 count = myStream.Length;

                        int bytesRead = 0;
                        while (count > 0)
                        {
                            byte[] buffer = new byte[4096];
                            bytesRead = myStream.Read(buffer, 0, 4096);
                            count = count - bytesRead;
                            ms.Write(buffer, 0, bytesRead);
                        }
                        myStream.Close();

                        ms.Position = 0;
                        System.Net.Mail.Attachment attach = new System.Net.Mail.Attachment(new System.IO.MemoryStream(ms.ToArray()), ct);
                        attach.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;
                        attach.ContentDisposition.FileName = ResultFileNameArray[i];
                        attach.ContentDisposition.Size = ms.ToArray().Length;

                        mailattachments.Add(attach);
                        XSpaceFile.msarray.Add(ms);
                    }

                    // Zip single well file download.
                }
            }

            return mailattachments;
        }

        //public Attachment CreateZipFileForEmail(DataFile XSpaceFile)
        //{
        //    for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
        //    {
        //        if (string.IsNullOrEmpty(XSpaceFile.WellboreGuid[i]) == false)
        //            XSpaceFile.UploadType[i] = "WELL";
        //        else
        //            XSpaceFile.UploadType[i] = "USER";

        //    }

        //    Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());


        //    List<string> ResultFileNameArray = new List<string>();
        //    for (int i = 0; i < XSpaceFile.path.Count(); i++)
        //    {
        //        string FilePath;
        //        XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
        //        FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
        //        FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);
        //        FilePath = XSpaceFile.machine + FilePath;
        //        array.SetValue(FilePath, i);
        //        ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);

        //    }

        //    // User to User File download or Already zipped well file download.
        //    if (XSpaceFile.DataFileGuids.Count() == 1 && (string.Compare(XSpaceFile.UploadType[0], "User", true) == 0 || ResultFileNameArray[0].Contains(".zip")))
        //    //if (XSpaceFile.DataFileGuids.Count() == 1 )
        //    {
        //        for (int i = 0; i < 1; i++)
        //        {
        //            string filepath = (string)array.GetValue(i);

        //            WebClient req = new WebClient();
        //            Stream myStream = null;
        //            try
        //            {
        //                myStream = req.OpenRead((string)(array.GetValue(i)));
        //            }
        //            catch (Exception ex)
        //            {
        //                continue;
        //            }

        //            if (myStream != null)
        //            {
        //                XSpaceFile.ms = new System.IO.MemoryStream();
        //                System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Octet);
        //                ct.Name = ResultFileNameArray[i];

        //                Int64 count = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));

        //                int bytesRead = 0;
        //                while (count > 0)
        //                {
        //                    byte[] buffer = new byte[4096];
        //                    bytesRead = myStream.Read(buffer, 0, 4096);
        //                    count = count - bytesRead;
        //                    XSpaceFile.ms.Write(buffer, 0, bytesRead);
        //                }
        //                myStream.Close();

        //                XSpaceFile.ms.Position = 0;
        //                System.Net.Mail.Attachment attach = new System.Net.Mail.Attachment(new System.IO.MemoryStream(XSpaceFile.ms.ToArray()), ct);
        //                attach.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;
        //                attach.ContentDisposition.FileName = ResultFileNameArray[i];
        //                attach.ContentDisposition.Size = XSpaceFile.ms.ToArray().Length;

        //                return attach;
        //            }

        //            // Zip single well file download.
        //        }
        //    }
        //    else
        //    {
        //        string zipFileName = "";
        //        if (XSpaceFile.DataFileGuids.Count() == 1)
        //        {
        //            int index = XSpaceFile.filenameArray[0].LastIndexOf(".");
        //            if (index >= 0)
        //            {
        //                zipFileName = XSpaceFile.filenameArray[0].Substring(0, index) + ".zip";
        //            }
        //            else
        //                zipFileName = "LogData.zip";
        //        }
        //        else
        //        {
        //            string strDate = DateTime.Now.ToString("yyyyMMddhhmmss");
        //            zipFileName = "XSpaceFiles" + strDate + ".zip";
        //        }

        //        byte[] buffer = new byte[4096];

        //        XSpaceFile.ms = new System.IO.MemoryStream();
        //        XSpaceFile.zipOutputStream = new ZipOutputStream(XSpaceFile.ms);
        //        ZipOutputStream zipOutputStream = XSpaceFile.zipOutputStream;
        //        System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.Zip);
        //        ct.Name = zipFileName;
        //        System.Net.Mail.Attachment attach = new System.Net.Mail.Attachment(XSpaceFile.ms, ct);
        //        attach.ContentDisposition.FileName = zipFileName;

        //        attach.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;
        //        zipOutputStream.SetLevel(3);

        //        try
        //        {
        //            {
        //                for (int i = 0; i < array.Length; i++)
        //                {

        //                    {
        //                        WebClient req = new WebClient();

        //                        ZipEntry zipEntry;
        //                        if (string.Compare(XSpaceFile.UploadType[i], "User", true) == 0)
        //                        {
        //                            zipEntry = new ZipEntry((string)(ResultFileNameArray[i]));
        //                        }
        //                        else if (string.IsNullOrEmpty(XSpaceFile.UploadType[i]) == true)
        //                        {
        //                            zipEntry = new ZipEntry((string)(ResultFileNameArray[i]));
        //                        }
        //                        else
        //                        {
        //                            string entry = "Wells" + "\\" + XSpaceFile.OperatorID[i] + XSpaceFile.Fieldname[i] + XSpaceFile.WellName[i] + "\\" + XSpaceFile.FolderName[i]
        //                                + "\\" + ResultFileNameArray[i];
        //                            zipEntry = new ZipEntry(ZipEntry.CleanName(entry));
        //                        }
        //                        Stream myStream = null;
        //                        string url = dataAccess.GetSiteUrl();

        //                        try
        //                        {
        //                            myStream = req.OpenRead((string)(array.GetValue(i)));
        //                        }
        //                        catch (Exception ex)
        //                        {
        //                            //continue;
        //                        }

        //                        if (myStream != null)
        //                        {
        //                            zipEntry.Size = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));
        //                            zipOutputStream.PutNextEntry(zipEntry);

        //                            Int64 count = zipEntry.Size;

        //                            while (count > 0)
        //                            {
        //                                int bytesRead = myStream.Read(buffer, 0, 4096);
        //                                count = count - bytesRead;

        //                                zipOutputStream.Write(buffer, 0, bytesRead);
        //                                zipOutputStream.Flush();

        //                            }
        //                            zipOutputStream.CloseEntry();
        //                            myStream.Close();
        //                        }
        //                    }

        //                }

        //            }
        //            zipOutputStream.Flush();
        //            zipOutputStream.IsStreamOwner = false;
        //            zipOutputStream.Close();
        //            XSpaceFile.ms.Position = 0;
        //            attach.ContentDisposition.Size = XSpaceFile.ms.ToArray().Length;

        //            return attach;

        //        }
        //        catch (Exception ex)
        //        {
        //            throw;
        //        }
        //    }
        //    return null;
        //}



       

        public static List<FileDetails> GetFileList(string filePath)
        {
            return ServiceData.GetFileList(filePath);
        }

        protected static void QueryUserData(DataFile XSpaceFile)
        {
            string user = ServiceData.GetCurrentUser();
            //string user = ServiceSecurityContext.Current.PrimaryIdentity.Name.Substring(ServiceSecurityContext.Current.PrimaryIdentity.Name.IndexOf(@"\") + 1);
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");
            XSpaceFile.UserID = user;

            XSpaceFile.userguid = "";
            
            XSpaceFile.userguid = dataAccess.GetData( "USR_GUID");
        }

        public void SendFileDistributionEmail(string parameter)
        {
            DataFile XSpaceFile = new DataFile();
            string[] param = parameter.Split(';');
            if (param.Length > 0)
            {
                var builder = new System.Data.Common.DbConnectionStringBuilder();
                builder.ConnectionString = param[0];
                var keys = builder.Keys;
                var values = builder.Values;
                XSpaceFile.Guids = (string)builder["DataFileGuid"];
                if (param.Length > 1)
                {
                    builder.ConnectionString = param[1];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.ExternalUserNames = ((string)builder["UserName"]).Split(',');

                }
                if (param.Length > 2)
                {
                    builder.ConnectionString = param[2];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.ExternalUserEmail = ((string)builder["Email"]).Split(',');

                }
                if (param.Length > 3)
                {
                    builder.ConnectionString = param[3];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.SenderGuid = ((string)builder["SenderGuid"]);

                }
            }
            QueryDistributedFileData(XSpaceFile);
            

            string url = ServiceData.GetSiteUrl();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        List<Attachment> items = CreateZipFileForEmail(XSpaceFile);
                        for (int i = 0; i < XSpaceFile.ExternalUserEmail.Count(); i++)
                        {
                            ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                                XSpaceFile.ExternalUserEmail[i],
                                "XSpace Email Attachment Delivery",
                                GetFileDistributionData(XSpaceFile, XSpaceFile.ExternalUserNames[i]),
                                true,
                                items);
                        }
                        for (int i = 0; i < items.Count(); i++)
                        {
                            items[i].Dispose();
                        }
                    }
                }
            });



        }

    }
}
