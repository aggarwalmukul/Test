﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    public class FileDetails
    {
        public string FileGuid;
        public string FileName;
        public double Size;
        public string WellName;
        public string FieldName;
        public string Operator;

    }

    public class DataFile
    {
        public UserSettings SenderSetting = new UserSettings();
        public UserSettings ReceiverSettings = new UserSettings();
        public Dictionary<string, UserSettings> UserToFolderMapping = new Dictionary<string, UserSettings>();
        public Dictionary<string, UploadedDataFiles> dictionary = new Dictionary<string, UploadedDataFiles>();
        public bool IsWellUpload = true;
        public int MaxFileSize = 0;
        public List<System.IO.MemoryStream> msarray = new List<System.IO.MemoryStream>();
        //public System.IO.MemoryStream ms;
        public System.IO.StreamWriter writer;
        //public ZipOutputStream zipOutputStream;
        public List<string> path = new List<string>();
        public List<string> filenameArray = new List<string>();
        public List<string> DataFileGuids = new List<string>();
        public List<string> UploadType = new List<string>();
        public List<string> FolderName = new List<string>();
        public List<string> WellboreGuid = new List<string>();
        public List<string> WellName = new List<string>();
        public List<string> OperatorID = new List<string>();
        public List<string> Fieldname = new List<string>();
        public List<string> FolderType = new List<string>();
        public List<string> FileSize = new List<string>();
        public List<string> FileStatus = new List<string>();
        public List<string> Comments = new List<string>();
        public string[] datafileGuids = null;
        public string userguid = "";
        public string machine = "";
        public string DriveGuid = "";
        public string Guids;
        public string UserID = "";
        public string UploadSessionGuid = "";
        public string[] UserUploadReceivedGuid;
        public string SenderGuid;
        public string[] ExternalUserNames;
        public string[] ExternalUserEmail;
        public DataFile()
        {
            ServiceData.GetDataServiceUrl();

        }


    }

    public class UserSettings
    {
        public List<string> Firstname = new List<string>();
        public List<string> LastName = new List<string>();
        public List<string> EmailAddress = new List<string>();
        public List<string> UserGuid = new List<string>();
        
        
        public List<string> FolderList = new List<string>();
        public List<string> CellNumber = new List<string>();
        public List<string> CellPhoneProvider = new List<string>();
        public List<string> HalFlag = new List<string>();
        public List<string> CustomerRole = new List<string>();
        public List<string> Wellbore = new List<string>();
        public List<string> DropBoxEmailFlag = new List<string>();
        public List<string> WellEmailFlag = new List<string>();
        public List<string> DropBoxTextFlag = new List<string>();
        public List<string> WellTextFlag = new List<string>();
    }
    public class UploadedDataFiles
    {
        public UserSettings folderUsers = new UserSettings();
        public List<string> FileNames = new List<string>();
        public List<string> Size = new List<string>();
        public List<string> WellName = new List<string>();
        public List<string> FieldName = new List<string>();
        public List<string> Company = new List<string>();

    }
}
