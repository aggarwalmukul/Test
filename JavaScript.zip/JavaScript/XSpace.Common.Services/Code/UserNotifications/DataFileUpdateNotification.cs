﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    public class DataFileUpdateNotification
    {
        protected static void ClearFields()
        {
        }

        protected static void QuerydataFiles(DataFile XSpaceFile)
        {
            string[] guid = XSpaceFile.Guids.Split(',');
            for (int i = 0; i < guid.Count(); i++)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + guid[i] + "'");
                //string Datafiledata = dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + guid[i] + "'");
                dataAccess.GetData( XSpaceFile.filenameArray, "DATA_FILE_LNM");
                dataAccess.GetData( XSpaceFile.path, "FILE_PATH");
                dataAccess.GetData( XSpaceFile.DataFileGuids, "DATA_FILE_GUID");
                dataAccess.GetData( XSpaceFile.UploadType, "UPL_TYP_CD");
                dataAccess.GetData( XSpaceFile.FolderName, "FLDR_TYP_NM");
                dataAccess.GetData( XSpaceFile.FolderType, "FLDR_TYP_ID");
                dataAccess.GetData( XSpaceFile.WellboreGuid, "WB_JOB_GUID");
                dataAccess.GetData( XSpaceFile.Comments, "DATA_FILE_CMNT");
                dataAccess.GetData( XSpaceFile.FileSize, "FILE_SZ_VAL");
                dataAccess.GetData( XSpaceFile.FileStatus, "FILE_STAT_CD");


            }
            List<string> filesize = new List<string>();
            for (int i = 0; i < XSpaceFile.FileSize.Count(); i++)
            {
                filesize.Add(Math.Round(Convert.ToDecimal(XSpaceFile.FileSize[i]), 2).ToString());

            }
            XSpaceFile.FileSize = filesize;

        }

        protected static void QueryWellData(DataFile XSpaceFile)
        {
            if (XSpaceFile.WellboreGuid.Count() > 0)
            {
                for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
                {
                    if (XSpaceFile.WellboreGuid[i] != null && XSpaceFile.WellboreGuid[i] != "")
                    {
                        DataAccess dataAccess = new DataAccess();
                        dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + XSpaceFile.WellboreGuid[i] + "'");
                        dataAccess.GetData( XSpaceFile.WellName, "WELL_NM");
                        dataAccess.GetData( XSpaceFile.OperatorID, "CO_NM");
                        dataAccess.GetData( XSpaceFile.Fieldname, "FLD_NM");

                    }
                    else
                    {
                        XSpaceFile.WellName.Add("");
                        XSpaceFile.OperatorID.Add("");
                        XSpaceFile.Fieldname.Add("");

                    }

                }
            }
        }

        protected static void QueryUserData(DataFile XSpaceFile)
        {
            string user = ServiceData.GetCurrentUser();
            //string user = ServiceSecurityContext.Current.PrimaryIdentity.Name.Substring(ServiceSecurityContext.Current.PrimaryIdentity.Name.IndexOf(@"\") + 1);
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");
            XSpaceFile.UserID = user;

            XSpaceFile.userguid = "";
            
            XSpaceFile.userguid = dataAccess.GetData( "USR_GUID");
            XSpaceFile.SenderSetting.Firstname.Add(dataAccess.GetData( "USR_FIR_NM"));
            XSpaceFile.SenderSetting.LastName.Add(dataAccess.GetData( "USR_LST_NM"));
        }

        public static Dictionary<string, UploadedDataFiles> GetFilteredFolders(DataFile XSpaceFile)
        {
            Dictionary<string, UploadedDataFiles> dictionary = XSpaceFile.dictionary;
            for (int i = 0; i < XSpaceFile.FolderName.Count(); i++)
            {
                if (XSpaceFile.filenameArray[i].Length > XSpaceFile.MaxFileSize)
                    XSpaceFile.MaxFileSize = XSpaceFile.filenameArray[i].Length;
                if (XSpaceFile.FolderName[i].Length > XSpaceFile.MaxFileSize)
                    XSpaceFile.MaxFileSize = XSpaceFile.FolderName[i].Length;

                if (dictionary.ContainsKey(XSpaceFile.FolderName[i]))
                {
                    UploadedDataFiles file = dictionary[XSpaceFile.FolderName[i]];
                    file.FileNames.Add(XSpaceFile.filenameArray[i]);
                    file.Size.Add(XSpaceFile.FileSize[i]);
                    file.WellName.Add(XSpaceFile.WellName[i]);
                    file.FieldName.Add(XSpaceFile.Fieldname[i]);
                    file.Company.Add(XSpaceFile.OperatorID[i]);
                }
                else
                {

                    UploadedDataFiles file = new UploadedDataFiles();
                    QueryFolderUsers(XSpaceFile.WellboreGuid[i], XSpaceFile.FolderType[i], XSpaceFile.FolderName[i], XSpaceFile);
                    file.FileNames.Add(XSpaceFile.filenameArray[i]);
                    file.Size.Add(XSpaceFile.FileSize[i]);
                    file.WellName.Add(XSpaceFile.WellName[i]);
                    file.FieldName.Add(XSpaceFile.Fieldname[i]);
                    file.Company.Add(XSpaceFile.OperatorID[i]);
                    dictionary.Add(XSpaceFile.FolderName[i], file);

                }
            }
            return dictionary;

        }


        public string GenerateHTMLtable(string folderName, UploadedDataFiles files, StringBuilder newbody)
        {
            //StringBuilder newbody = new StringBuilder();

            //newbody.Append("<tr>");
            //newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            //newbody.Append(folderName);
            //newbody.Append("</td>");
            //newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            //newbody.Append("Size");
            //newbody.Append("</td>");
            //newbody.Append("</tr>");

            for (int i = 0; i < files.FileNames.Count(); i++)
            {
                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append(files.FileNames[i]);
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append(files.Size[i] + "MB");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append(files.WellName[i]);
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append(files.FieldName[i]);
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append(files.Company[i]);
                newbody.Append("</td>");
                newbody.Append("</tr>");
            }

            return newbody.ToString();
        }


        public string GetWellUploadEmailData(DataFile XSpaceFile, UserSettings setting)
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "FileStatusNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{FirstName}", setting.Firstname[0]);
            body = body.Replace("{LastName}", setting.LastName[0]);
            body = body.Replace("{SName}", XSpaceFile.SenderSetting.Firstname[0] + " " + XSpaceFile.SenderSetting.LastName[0]);
            body = body.Replace("{FileStatus}", XSpaceFile.FileStatus[0]);

            Dictionary<string, UploadedDataFiles> dictionary = XSpaceFile.dictionary;

            string files = "<table width=600px border=1 cellspacing=2 cellpadding=2 bgcolor=White dir=ltr rules=all style=border-width: thin; border-style: solid; line-height: normal; vertical-align: baseline; text-align: center; font-family: Calibri; font-size: medium; font-weight: normal; font-style: normal; font-variant: normal; color: #000000; list-style-type: none;>";
            bool bFolderFound = false;
            StringBuilder newbody = new StringBuilder();
            newbody.Append("<tr>");
            newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            newbody.Append("Document(s)");
            newbody.Append("</td>");
            newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            newbody.Append("Size");
            newbody.Append("</td>");
            newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            newbody.Append("Well");
            newbody.Append("</td>");
            newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            newbody.Append("Field");
            newbody.Append("</td>");
            newbody.Append("<td style=background-color:#ECECEC;font-weight:bold>");
            newbody.Append("Company");
            newbody.Append("</td>");
            newbody.Append("</tr>");
            foreach (var item in dictionary)
            {

                string data = item.Key;
                if (setting.FolderList.Contains(item.Key))
                {
                    //folders = folders + "<b>" + item.Key + "</b>";
                    //folders = folders + ",";
                    bFolderFound = true;
                    GenerateHTMLtable(item.Key, item.Value, newbody);
                }
            }

            files = files + newbody.ToString() + "</table>";

            if (bFolderFound == true)
            {
                body = body.Replace("{Files}", files);
            }
            else
                body = body.Replace("{Files}", "");

            string homepage = ServiceData.GetHomePageUrl() + "download.aspx?operation=FILE&WBGuid=" +
    XSpaceFile.WellboreGuid[0];
            
            body = body.Replace("{Url}", homepage);

            body = body.Replace("{SupportWirelineUrl}", ServiceData.GetWirelineSupportUrl());
            body = body.Replace("{SupportSperryUrl}", ServiceData.GetSperrySupportUrl());
            body = body.Replace("{SupportBaroidUrl}", ServiceData.GetBaroidSupportUrl());
            body = body.Replace("{ForgotPasswordUrl}", ServiceData.GetPasswordSupportUrl());
            return body;
        }

        public void SendFileStatusChangeNotification(string parameter)
        {
            DataFile XSpaceFile = new DataFile();
            string[] param = parameter.Split(';');
            if (param.Length > 0)
            {
                var builder = new System.Data.Common.DbConnectionStringBuilder();
                builder.ConnectionString = param[0];
                var keys = builder.Keys;
                var values = builder.Values;
                XSpaceFile.Guids = ((string)builder["DataFileGuid"]);

            }
            QueryAllFileData(XSpaceFile);


            string url = ServiceData.GetSiteUrl();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        //if (XSpaceFile.IsWellUpload == true)
                        {
                            foreach (var item in XSpaceFile.UserToFolderMapping)
                            {
                                UserSettings setting = item.Value;
                                string body = GetWellUploadEmailData(XSpaceFile, setting);
                                if (setting.HalFlag[0] == "" || setting.HalFlag[0] == "0" || setting.CustomerRole[0] == "CUSTUSER" || setting.CustomerRole[0] == "CUSTADM")
                                {

                                    ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                                        setting.EmailAddress[0],
                                        "File Status Change Notification",
                                        body,
                                        true);



                                    if (setting.CellNumber.Count() > 0)
                                    {
                                        ServiceData.SendSMS(ServiceData.GetFromEmailAddress(),
                                            setting.CellNumber[0],
                                            setting.CellPhoneProvider[0],
                                            "File Status Change Notification",
                                            body,
                                            true);
                                    }



                                }
                            }
                        }


                        
                    }
                }
            });
        }



        
        protected static void QueryMachineDrive(DataFile XSpaceFile)
        {
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

            string drive = "";
            
            drive = dataAccess.GetData( "DRV_PATH");
            XSpaceFile.DriveGuid = dataAccess.GetData( "DRV_GUID");
            XSpaceFile.machine = drive;
        }

        protected static void QueryFolderUsers(string WellboreGuid, string folder, string foldername, DataFile XSpaceFile)
        {
            UserSettings settings = new UserSettings();
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetFolderUsers_SP", "FolderType='" + folder + "'");

            dataAccess.GetData( settings.Firstname, "USR_FIR_NM");
            dataAccess.GetData( settings.LastName, "USR_LST_NM");
            dataAccess.GetData( settings.EmailAddress, "EMAIL_ADDR_DESC");
            dataAccess.GetData( settings.UserGuid, "USR_GUID");
            dataAccess.GetData( settings.WellEmailFlag, "WELL_NTFN_FLG");
            dataAccess.GetData( settings.HalFlag, "HAL_FLG");
            dataAccess.GetData( settings.CustomerRole, "ROLE_CD");
            dataAccess.GetData( settings.WellTextFlag, "WELL_TXT_NTFN_FLG");
            dataAccess.GetData( settings.CellNumber, "CELL_PHONE_NUM");
            dataAccess.GetData( settings.Wellbore, "WB_JOB_GUID");
            dataAccess.GetData( settings.CellPhoneProvider, "CELL_PHONE_PRVDR_CD");
            if (settings.Wellbore.Count > 0 && settings.Wellbore.Contains(WellboreGuid) == true )
            {
                for (int i = 0; i < settings.UserGuid.Count(); i++)
                {
                    if (XSpaceFile.UserToFolderMapping.ContainsKey(settings.UserGuid[i]))
                    {
                        UserSettings newsettings = XSpaceFile.UserToFolderMapping[settings.UserGuid[i]];
                        newsettings.FolderList.Add(foldername);

                    }
                    else
                    {
                        UserSettings newsettings = new UserSettings();
                        newsettings.FolderList.Add(foldername);
                        newsettings.EmailAddress.Add(settings.EmailAddress[i]);
                        newsettings.Firstname.Add(settings.Firstname[i]);
                        newsettings.LastName.Add(settings.LastName[i]);
                        newsettings.UserGuid.Add(settings.UserGuid[i]);
                        newsettings.WellEmailFlag.Add(settings.WellEmailFlag[i]);
                        newsettings.WellTextFlag.Add(settings.WellTextFlag[i]);

                        newsettings.CellNumber.Add(settings.CellNumber[i]);
                        newsettings.CellPhoneProvider.Add(settings.CellPhoneProvider[i]);
                        newsettings.Wellbore.Add(settings.Wellbore[i]);
                        newsettings.HalFlag.Add(settings.HalFlag[i]);
                        newsettings.CustomerRole.Add(settings.CustomerRole[i]);
                        XSpaceFile.UserToFolderMapping.Add(settings.UserGuid[i], newsettings);

                    }


                }
            }

        }




        protected static void QueryAllFileData(DataFile XSpaceFile)
        {

            ClearFields();
            QuerydataFiles(XSpaceFile);
            QueryWellData(XSpaceFile);
            QueryUserData(XSpaceFile);
            QueryMachineDrive(XSpaceFile);
            GetFilteredFolders(XSpaceFile);

        }

    }
}
