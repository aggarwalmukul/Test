﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    class DropBoxNotification
    {
        int NumberOfFiles = 0;
        protected static void QueryDistributeddataFiles(DataFile XSpaceFile)
        {
            //var qs = HttpUtility.ParseQueryString(HttpContext.Current.Request.Url.Query);
            string guids = XSpaceFile.Guids; // Folder Names.
            char[] delimitedChars = { ',' };
            XSpaceFile.datafileGuids = guids.Split(delimitedChars);

            for (int i = 0; i < XSpaceFile.datafileGuids.Count(); i++)
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetDataFileByGuid_SP", "DataFileGuid='" + XSpaceFile.datafileGuids[i] + "'");
                
                dataAccess.GetData( XSpaceFile.filenameArray, "DATA_FILE_LNM");
                dataAccess.GetData( XSpaceFile.path, "FILE_PATH");
                dataAccess.GetData( XSpaceFile.DataFileGuids, "DATA_FILE_GUID");
                dataAccess.GetData( XSpaceFile.UploadType, "UPL_TYP_CD");
                dataAccess.GetData( XSpaceFile.FolderName, "FLDR_TYP_NM");
                dataAccess.GetData( XSpaceFile.FolderType, "FLDR_TYP_ID");
                dataAccess.GetData( XSpaceFile.WellboreGuid, "WB_JOB_GUID");
                dataAccess.GetData( XSpaceFile.Comments, "DATA_FILE_CMNT");
                dataAccess.GetData( XSpaceFile.FileSize, "FILE_SZ_VAL");


            }
            List<string> filesize = new List<string>();
            for (int i = 0; i < XSpaceFile.FileSize.Count(); i++)
            {
                filesize.Add(Math.Round(Convert.ToDecimal(XSpaceFile.FileSize[i]), 2).ToString());

            }
            XSpaceFile.FileSize = filesize;

        }

        protected static void QueryDistributedWellData(DataFile XSpaceFile)
        {
            for (int i = 0; i < XSpaceFile.WellboreGuid.Count(); i++)
            {
                if (XSpaceFile.WellboreGuid[i] != null && XSpaceFile.WellboreGuid[i] != "")
                {
                    DataAccess dataAccess = new DataAccess();
                    dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + XSpaceFile.WellboreGuid[i] + "'");

                    dataAccess.GetData( XSpaceFile.WellName, "WELL_NM");
                    dataAccess.GetData( XSpaceFile.OperatorID, "CO_NM");
                    dataAccess.GetData( XSpaceFile.Fieldname, "FLD_NM");

                }
                else
                {
                    XSpaceFile.WellName.Add("");
                    XSpaceFile.OperatorID.Add("");
                    XSpaceFile.Fieldname.Add("");

                }

            }
        }


        protected static void QueryMachineDrive(DataFile XSpaceFile)
        {
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

            string drive = "";
            
            drive = dataAccess.GetData( "DRV_PATH");
            XSpaceFile.DriveGuid = dataAccess.GetData( "DRV_GUID");
            XSpaceFile.machine = drive;
        }

        protected static void QueryDistributedFileData(DataFile XSpaceFile)
        {
            QueryDistributeddataFiles(XSpaceFile);
            QueryDistributedWellData(XSpaceFile);
            QueryUserData(XSpaceFile);
            QueryMachineDrive(XSpaceFile);
            ServiceData.QueryUserSettingsForUserUploadNotification(XSpaceFile);
        }





        public string GetFileDistributionHtmlTable(DataFile XSpaceFile)
        {
            Array array = Array.CreateInstance(typeof(string), XSpaceFile.datafileGuids.Count());
            List<string> ResultFileNameArray = new List<string>();

            for (int i = 0; i < XSpaceFile.path.Count(); i++)
            {
                string FilePath;

                XSpaceFile.path[i] = XSpaceFile.path[i].Replace("\\\\", "\\");
                FilePath = Path.Combine(XSpaceFile.machine, XSpaceFile.path[i]);
                FilePath = Path.Combine(FilePath, XSpaceFile.filenameArray[i]);

                FilePath = XSpaceFile.machine + FilePath;

                array.SetValue(FilePath, i);
                ResultFileNameArray.Add(XSpaceFile.filenameArray[i]);


            }
            List<FileDetails> filedetail = new List<FileDetails>();
            for (int i = 0; i < XSpaceFile.filenameArray.Count(); i++)
            {
                if (XSpaceFile.filenameArray[i].Contains(".zip") == true)
                {
                    List<FileDetails> subfiledetail = GetFileList((string)array.GetValue(i));
                    for (int j = 0; j < subfiledetail.Count(); j++ )
                    {
                        subfiledetail[j].WellName = XSpaceFile.WellName[i];
                        subfiledetail[j].FieldName = XSpaceFile.Fieldname[i];
                        subfiledetail[j].Operator = XSpaceFile.OperatorID[i];

                    }
                    filedetail.AddRange(subfiledetail);
                }
                else
                {
                    FileDetails detail = new FileDetails();
                    detail.FileName = XSpaceFile.filenameArray[i];
                    if (XSpaceFile.WellName.Count() > 0)
                    {
                        detail.WellName = XSpaceFile.WellName[i];
                        detail.FieldName = XSpaceFile.Fieldname[i];
                        detail.Operator = XSpaceFile.OperatorID[i];
                    }
                    double.TryParse(XSpaceFile.FileSize[i], out detail.Size);
                    filedetail.Add(detail);
                }
            }
            StringBuilder newbody = new StringBuilder();
            //if (XSpaceFile.UploadType.Count > 0)
            {
                newbody.Append("<tr>");
                newbody.Append("<td font-weight:bold>");
                newbody.Append("Document(s)");
                newbody.Append("</td>");
                newbody.Append("<td font-weight:bold>");
                newbody.Append("Size");
                newbody.Append("</td>");
                //newbody.Append("<td font-weight:bold>");
                //newbody.Append("Well");
                //newbody.Append("</td>");
                //newbody.Append("<td font-weight:bold>");
                //newbody.Append("Field");
                //newbody.Append("</td>");
                //newbody.Append("<td font-weight:bold>");
                //newbody.Append("Company");
                //newbody.Append("</td>");
                newbody.Append("</tr>");

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                for (int i = 0; i < filedetail.Count(); i++)
                {
                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append(filedetail[i].FileName);
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append(filedetail[i].Size.ToString() + "MB");
                    newbody.Append("</td>");
                    //newbody.Append("<td>");
                    //newbody.Append(filedetail[i].WellName);
                    //newbody.Append("</td>");
                    //newbody.Append("<td>");
                    //newbody.Append(filedetail[i].FieldName);
                    //newbody.Append("</td>");
                    //newbody.Append("<td>");
                    //newbody.Append(filedetail[i].Operator);
                    //newbody.Append("</td>");
                    newbody.Append("</tr>");

                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("</tr>");
                    NumberOfFiles = NumberOfFiles + 1;
                }
            }

            newbody.Append("<tr>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("</tr>");

            return newbody.ToString();
        }

        public string GetFileDistributionData(DataFile XSpaceFile, string receivername)
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "DropBoxNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{Name}", receivername);
            body = body.Replace("{SName}", XSpaceFile.SenderSetting.Firstname[0]);

            string files = "<table width=600px border=0 cellspacing=2 cellpadding=2 bgcolor=White dir=ltr rules=all style=border-width: thin; border-style: solid; line-height: normal; vertical-align: baseline; text-align: center; font-family: Calibri; font-size: medium; font-weight: normal; font-style: normal; font-variant: normal; color: #000000; list-style-type: none;>";
            files = files + GetFileDistributionHtmlTable(XSpaceFile);
            files = files + "</table>";


            body = body.Replace("{Files}", files);
            body = body.Replace("{Comments}", XSpaceFile.Comments[0]);
            body = body.Replace("{Url}", ServiceData.GetMyFilesUrl());

            //body = body.Replace("{SupportWirelineUrl}", dataAccess.GetWirelineSupportUrl());
            //body = body.Replace("{SupportSperryUrl}", dataAccess.GetSperrySupportUrl());
            //body = body.Replace("{SupportBaroidUrl}", dataAccess.GetBaroidSupportUrl());
            //body = body.Replace("{ForgotPasswordUrl}", dataAccess.GetPasswordSupportUrl());
            return body;
        }





        

        public static List<FileDetails> GetFileList(string filePath)
        {
            return ServiceData.GetFileList(filePath);

        }

        protected static void QueryUserData(DataFile XSpaceFile)
        {
            string user = ServiceData.GetCurrentUser();
           // string user = ServiceSecurityContext.Current.PrimaryIdentity.Name.Substring(ServiceSecurityContext.Current.PrimaryIdentity.Name.IndexOf(@"\") + 1);
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");
            XSpaceFile.UserID = user;

            XSpaceFile.userguid = "";
            
            XSpaceFile.userguid = dataAccess.GetData( "USR_GUID");
        }

        public void SendDropBoxFileDistributionEmail(string parameter)
        {
            DataFile XSpaceFile = new DataFile();
            string[] param = parameter.Split(';');
            if (param.Length > 0)
            {
                var builder = new System.Data.Common.DbConnectionStringBuilder();
                builder.ConnectionString = param[0];
                var keys = builder.Keys;
                var values = builder.Values;
                XSpaceFile.Guids = (string)builder["DataFileGuid"];
                if (param.Length > 1)
                {
                    builder.ConnectionString = param[1];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.ExternalUserNames = ((string)builder["UserName"]).Split(',');

                }
                if (param.Length > 2)
                {
                    builder.ConnectionString = param[2];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.ExternalUserEmail = ((string)builder["Email"]).Split(',');

                }
                if (param.Length > 3)
                {
                    builder.ConnectionString = param[3];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.UserUploadReceivedGuid = ((string)builder["Receipents"]).Split(',');

                }
                if (param.Length > 4)
                {
                    builder.ConnectionString = param[4];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.SenderGuid = ((string)builder["SenderGuid"]);

                }
                if (param.Length > 5)
                {
                    builder.ConnectionString = param[5];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.Comments.Add(((string)builder["Comments"]));

                }
            }
            QueryDistributedFileData(XSpaceFile);
            //Attachment item = CreateZipFileForEmail(XSpaceFile);

            string url = ServiceData.GetSiteUrl();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        for (int i = 0; i < XSpaceFile.ReceiverSettings.Firstname.Count(); i++)
                        {
                            if (XSpaceFile.ReceiverSettings.DropBoxEmailFlag[i] == "1" || XSpaceFile.ReceiverSettings.DropBoxTextFlag[i] == "1" )
                            {
                                NumberOfFiles = 0;
                                string body = GetFileDistributionData(XSpaceFile, XSpaceFile.ReceiverSettings.Firstname[i]);

                                if (XSpaceFile.ReceiverSettings.DropBoxEmailFlag[i] == "1")
                                {
                                    ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                                        XSpaceFile.ReceiverSettings.EmailAddress[i],
                                        "New Well Data Information Available in My Files",
                                        body,

                                        true);
                                }

                                if (XSpaceFile.ReceiverSettings.DropBoxTextFlag[i] == "1")//send sms too.
                                {
                                    if (XSpaceFile.ReceiverSettings.CellNumber.Count() > 0)
                                    {
                                        ServiceData.SendSMS(ServiceData.GetFromEmailAddress(),
                                            XSpaceFile.ReceiverSettings.CellNumber[0],
                                            XSpaceFile.ReceiverSettings.CellPhoneProvider[0],
                                            "New Well Data Information in My Files",
                                            "XSpace Notification: " + XSpaceFile.SenderSetting.Firstname[0] + " has sent you " + NumberOfFiles.ToString() + " files.",
                                            true);
                                    }

                                }
                            }


                        }
                        //item.Dispose();
                    }
                }
            });



        }

    }
}
