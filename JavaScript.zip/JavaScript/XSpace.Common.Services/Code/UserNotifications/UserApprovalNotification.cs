﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    class UserApprovalNotification
    {
        public class RegisteredUserData
        {
            public string FirstName;
            public string LastName;
            public string EmailAddress;
        }

        public static string GetUserApprovalData(RegisteredUserData userdata )
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "ApprovalNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{FirstName}", userdata.FirstName);
            body = body.Replace("{LastName}", userdata.LastName);
            body = body.Replace("{UserEmail}", userdata.EmailAddress);

            return body;
        }

        protected static RegisteredUserData QueryApprovedUserData(string UserID)
        {
            string user = ServiceData.GetCurrentUser();
           // string user = ServiceSecurityContext.Current.PrimaryIdentity.Name.Substring(ServiceSecurityContext.Current.PrimaryIdentity.Name.IndexOf(@"\") + 1);
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserRegistered_SP", "UserID='" + UserID + "'");
            RegisteredUserData userdata = new RegisteredUserData();

            
            userdata.FirstName = dataAccess.GetData( "USR_FIR_NM");
            userdata.LastName = dataAccess.GetData( "USR_LST_NM");
            userdata.EmailAddress = dataAccess.GetData( "EMAIL_ADDR_DESC");
            return userdata;
        }

        public void SendUserApprovedEmail(string parameter)
        {
            
            string[] param = parameter.Split(';');
            string UserID = "";
            if (param.Length > 0)
            {
                var builder = new System.Data.Common.DbConnectionStringBuilder();
                builder.ConnectionString = param[0];
                var keys = builder.Keys;
                var values = builder.Values;
                UserID = (string)builder["UserID"];
            }
            RegisteredUserData userdata = QueryApprovedUserData(UserID);
            string body = GetUserApprovalData(userdata);
            
            string url = ServiceData.GetSiteUrl();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {

                        ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                            userdata.EmailAddress,
                            "XSpace Registration Confirmation",
                            body,
                            true);

                    }
                }
            });


        }

    }
}
