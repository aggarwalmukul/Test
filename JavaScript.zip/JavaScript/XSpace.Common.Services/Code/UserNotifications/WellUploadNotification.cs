﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    public class WellUploadNotification
    {
        int NumberOfFiles = 0;
        string Well;
        string Field;
        string Company;

        protected static void ClearFields()
        {
        }

        protected static void QuerydataFiles(DataFile XSpaceFile)
        {
            string guids = XSpaceFile.UploadSessionGuid; // Folder Names.
            {
                DataAccess dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetWellUploadData_SP", "DataFileUploadSessionGuid='" + XSpaceFile.UploadSessionGuid + "'");
                
                dataAccess.GetData( XSpaceFile.filenameArray, "DATA_FILE_LNM");
                dataAccess.GetData( XSpaceFile.path, "FILE_PATH");
                dataAccess.GetData( XSpaceFile.DataFileGuids, "DATA_FILE_GUID");
                dataAccess.GetData( XSpaceFile.UploadType, "UPL_TYP_CD");
                dataAccess.GetData( XSpaceFile.FolderName, "FLDR_TYP_NM");
                dataAccess.GetData( XSpaceFile.FolderType, "FLDR_TYP_ID");
                dataAccess.GetData( XSpaceFile.WellboreGuid, "WB_JOB_GUID");
                dataAccess.GetData( XSpaceFile.Comments, "DATA_FILE_CMNT");
                dataAccess.GetData( XSpaceFile.FileSize, "FILE_SZ_VAL");


            }
            List<string> filesize = new List<string>();
            for (int i = 0; i < XSpaceFile.FileSize.Count(); i++)
            {
                filesize.Add(Math.Round(Convert.ToDecimal(XSpaceFile.FileSize[i]), 2).ToString());

            }
            XSpaceFile.FileSize = filesize;

        }

        protected static void QueryWellData(DataFile XSpaceFile)
        {
            if (XSpaceFile.WellboreGuid.Count() > 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    if (XSpaceFile.WellboreGuid[0] != null && XSpaceFile.WellboreGuid[0] != "")
                    {
                        DataAccess dataAccess = new DataAccess();
                        dataAccess.ExecuteProcedure("GetWellDataByWBJobGuid_SP", "WBJobGuid='" + XSpaceFile.WellboreGuid[i] + "'");
                        
                        dataAccess.GetData( XSpaceFile.WellName, "WELL_NM");
                        dataAccess.GetData( XSpaceFile.OperatorID, "CO_NM");
                        dataAccess.GetData( XSpaceFile.Fieldname, "FLD_NM");

                    }
                    else
                    {
                        XSpaceFile.WellName.Add("");
                        XSpaceFile.OperatorID.Add("");
                        XSpaceFile.Fieldname.Add("");

                    }

                }
            }
        }

        protected static void QueryUserData(DataFile XSpaceFile)
        {
           
           string user=ServiceData.GetCurrentUser();
             //= ServiceSecurityContext.Current.PrimaryIdentity.Name.Substring(ServiceSecurityContext.Current.PrimaryIdentity.Name.IndexOf(@"\") + 1);
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserDetailByUserID_SP", "UserID='" + user + "'");
            XSpaceFile.UserID = user;

            XSpaceFile.userguid = "";
            
            XSpaceFile.userguid = dataAccess.GetData( "USR_GUID");
        }

        public static Dictionary<string, UploadedDataFiles> GetFilteredFolders(DataFile XSpaceFile)
        {
            Dictionary<string, UploadedDataFiles> dictionary = XSpaceFile.dictionary;
            for (int i = 0; i < XSpaceFile.FolderName.Count(); i++)
            {
                if (XSpaceFile.filenameArray[i].Length > XSpaceFile.MaxFileSize)
                    XSpaceFile.MaxFileSize = XSpaceFile.filenameArray[i].Length;
                if (XSpaceFile.FolderName[i].Length > XSpaceFile.MaxFileSize)
                    XSpaceFile.MaxFileSize = XSpaceFile.FolderName[i].Length;

                if (dictionary.ContainsKey(XSpaceFile.FolderName[i]))
                {
                    UploadedDataFiles file = dictionary[XSpaceFile.FolderName[i]];
                    file.FileNames.Add(XSpaceFile.filenameArray[i]);
                    file.Size.Add(XSpaceFile.FileSize[i]);
                }
                else
                {

                    UploadedDataFiles file = new UploadedDataFiles();
                    QueryFolderUsers(XSpaceFile.WellboreGuid[0], XSpaceFile.FolderType[i], XSpaceFile.FolderName[i], XSpaceFile);
                    file.FileNames.Add(XSpaceFile.filenameArray[i]);
                    file.Size.Add(XSpaceFile.FileSize[i]);
                    dictionary.Add(XSpaceFile.FolderName[i], file);

                }
            }
            return dictionary;

        }

        public string GenerateUserUploadHTMLtable(DataFile XSpaceFile)
        {
            StringBuilder newbody = new StringBuilder();
            //if (XSpaceFile.UploadType.Count > 0)
            {
                newbody.Append("<tr>");
                newbody.Append("<td font-weight:bold>");
                newbody.Append("Document(s)");
                newbody.Append("</td>");
                newbody.Append("<td font-weight:bold>");
                newbody.Append("Size");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                for (int i = 0; i < XSpaceFile.filenameArray.Count(); i++)
                {
                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append(XSpaceFile.filenameArray[i]);
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append(XSpaceFile.FileSize[i] + "MB");
                    newbody.Append("</td>");
                    newbody.Append("</tr>");

                    newbody.Append("<tr>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("<td>");
                    newbody.Append("");
                    newbody.Append("</td>");
                    newbody.Append("</tr>");
                    NumberOfFiles = NumberOfFiles + 1;
                }

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");
            }

            return newbody.ToString();
        }
        public string GenerateHTMLtable(string folderName, UploadedDataFiles files)
        {
            StringBuilder newbody = new StringBuilder();

            newbody.Append("<tr>");
            newbody.Append("<td style=font-weight:bold>");
            newbody.Append(folderName);
            newbody.Append("</td>");
            newbody.Append("<td style=font-weight:bold>");
            newbody.Append("Size");
            newbody.Append("</td>");
            newbody.Append("</tr>");

            newbody.Append("<tr>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("</tr>");

            for (int i = 0; i < files.FileNames.Count(); i++)
            {
                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append(files.FileNames[i]);
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append(files.Size[i] + "MB");
                newbody.Append("</td>");
                newbody.Append("</tr>");

                newbody.Append("<tr>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("<td>");
                newbody.Append("");
                newbody.Append("</td>");
                newbody.Append("</tr>");
                NumberOfFiles = NumberOfFiles + 1;
            }
            newbody.Append("<tr>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("<td>");
            newbody.Append("");
            newbody.Append("</td>");
            newbody.Append("</tr>");

            return newbody.ToString();
        }

        public string GetUserUploadedData(DataFile XSpaceFile, string sendername, string receivername)
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "UserUploadNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{Name}", receivername);
            body = body.Replace("{SName}", sendername);

            string files = "<table width=600px border=0 cellspacing=2 cellpadding=2 bgcolor=White dir=ltr rules=all style=border-width: thin; border-style: solid; line-height: normal; vertical-align: baseline; text-align: center; font-family: Calibri; font-size: medium; font-weight: normal; font-style: normal; font-variant: normal; color: #000000; list-style-type: none;>";
            files = files + GenerateUserUploadHTMLtable(XSpaceFile);
            files = files + "</table>";


            body = body.Replace("{Files}", files);
            body = body.Replace("{Comments}", XSpaceFile.Comments[0]);
            body = body.Replace("{Url}", ServiceData.GetMyFilesUrl());

            //body = body.Replace("{SupportWirelineUrl}", dataAccess.GetWirelineSupportUrl());
            //body = body.Replace("{SupportSperryUrl}", dataAccess.GetSperrySupportUrl());
            //body = body.Replace("{SupportBaroidUrl}", dataAccess.GetBaroidSupportUrl());
            //body = body.Replace("{ForgotPasswordUrl}", dataAccess.GetPasswordSupportUrl());
            return body;
        }

        public static string ReplaceAt(string str, int index, int length, string replace)
        {
            return str.Remove(index, Math.Min(length, str.Length - index))
                    .Insert(index, replace);
        }

        public string GetWellUploadEmailData(DataFile XSpaceFile, UserSettings setting)
        {
            string ConfigFilePath = SPUtility.GetVersionedGenericSetupPath(@"TEMPLATE\LAYOUTS\XSP\Data", 15);
            string WellUploadEmailTemplatePath = Path.Combine(ConfigFilePath, "WellUploadNotification.html");
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(WellUploadEmailTemplatePath))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{FirstName}", setting.Firstname[0]);
            body = body.Replace("{LastName}", setting.LastName[0]);
            body = body.Replace("{Well}", XSpaceFile.WellName[0]);
            body = body.Replace("{Company}", XSpaceFile.OperatorID[0]);
            body = body.Replace("{Field}", XSpaceFile.Fieldname[0]);

            Well = XSpaceFile.WellName[0];
            Field = XSpaceFile.Fieldname[0];
            Company = XSpaceFile.OperatorID[0];
            string folders = "";
            Dictionary<string, UploadedDataFiles> dictionary = XSpaceFile.dictionary;

            string files = "<table width=600px border=0 cellspacing=2 cellpadding=2 bgcolor=White dir=ltr rules=all style=border-width: thin; border-style: solid; line-height: normal; vertical-align: baseline; text-align: center; font-family: Calibri; font-size: medium; font-weight: normal; font-style: normal; font-variant: normal; color: #000000; list-style-type: none;>";
            bool bFolderFound = false;
            foreach (var item in dictionary)
            {

                string data = item.Key;
                if (setting.FolderList.Contains(item.Key))
                {
                    folders = folders + "<b>" + item.Key + "</b>";
                    folders = folders + ",";
                    bFolderFound = true;
                    files = files + GenerateHTMLtable(item.Key, item.Value);
                }
            }


            folders = folders.Remove(folders.Length - 1);
            if ( folders.LastIndexOf(',') > 0 )
            {
                folders = ReplaceAt(folders,folders.LastIndexOf(','), 1, " and " );
            }
            files = files + "</table>";
            body = body.Replace("{Folders}", folders);
            if (bFolderFound == true)
            {
                body = body.Replace("{Files}", files);
            }
            else
                body = body.Replace("{Files}", "");
            body = body.Replace("{Comments}", XSpaceFile.Comments[0]);
            string homepage = ServiceData.GetHomePageUrl() + "download.aspx?operation=FILE&WBGuid=" +
                XSpaceFile.WellboreGuid[0];
            body = body.Replace("{Url}", homepage);

            //body = body.Replace("{SupportWirelineUrl}", dataAccess.GetWirelineSupportUrl());
            //body = body.Replace("{SupportSperryUrl}", dataAccess.GetSperrySupportUrl());
            //body = body.Replace("{SupportBaroidUrl}", dataAccess.GetBaroidSupportUrl());
            //body = body.Replace("{ForgotPasswordUrl}", dataAccess.GetPasswordSupportUrl());
            //dataAccess.UpdateCommonSectionInEmail(body);
            return body;
        }

        public void SendEmail(string parameter)
        {
            DataFile XSpaceFile = new DataFile();
            string[] param = parameter.Split(';');
            if (param.Length > 0)
            {
                var builder = new System.Data.Common.DbConnectionStringBuilder();
                builder.ConnectionString = param[0];
                var keys = builder.Keys;
                var values = builder.Values;
                XSpaceFile.UploadSessionGuid = (string)builder["UploadSessionGuid"];
                if (param.Length > 1)
                {
                    builder.ConnectionString = param[1];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.UserUploadReceivedGuid = ((string)builder["UserGuid"]).Split(',');

                }
                if (param.Length > 2)
                {
                    builder.ConnectionString = param[2];
                    keys = builder.Keys;
                    values = builder.Values;

                    XSpaceFile.SenderGuid = ((string)builder["SenderGuid"]);

                }
            }
            QueryAllFileData(XSpaceFile);


            string url = ServiceData.GetSiteUrl();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        if (XSpaceFile.IsWellUpload == true)
                        {
                            foreach (var item in XSpaceFile.UserToFolderMapping)
                            {
                                UserSettings setting = item.Value;
                                NumberOfFiles = 0;
                                string body = GetWellUploadEmailData(XSpaceFile, setting);
                                if (setting.WellEmailFlag[0] == "1" || setting.WellTextFlag[0] == "1")
                                {
                                    if (setting.WellEmailFlag[0] == "1")
                                    {
                                        ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                                            setting.EmailAddress[0],
                                            "New Well Information Uploaded",
                                            body,
                                            true);
                                    }
                                    if (setting.WellTextFlag[0] == "1")//send sms too.
                                    {
                                        if (setting.CellNumber.Count() > 0)
                                        {
                                            ServiceData.SendSMS(ServiceData.GetFromEmailAddress(),
                                                setting.CellNumber[0],
                                                setting.CellPhoneProvider[0],
                                                "New Well Information Uploaded",
                                                "XSpace Notification: " + Company + ":" +  Field + ":" + Well + " has received " + NumberOfFiles.ToString() + " new files.",
                                                true);
                                        }

                                    }

                                }
                            }
                        }
                        else
                        {
                            for (int i = 0; i < XSpaceFile.ReceiverSettings.Firstname.Count(); i++)
                            {
                                if (XSpaceFile.ReceiverSettings.WellEmailFlag[i] == "1" || XSpaceFile.ReceiverSettings.WellTextFlag[i] == "1")
                                {
                                    NumberOfFiles = 0;
                                    string body = GetUserUploadedData(XSpaceFile, XSpaceFile.SenderSetting.Firstname[0], XSpaceFile.ReceiverSettings.Firstname[i]);
                                    if (XSpaceFile.ReceiverSettings.WellEmailFlag[i] == "1")
                                    {
                                        ServiceData.SendEmail(ServiceData.GetFromEmailAddress(),
                                            XSpaceFile.ReceiverSettings.EmailAddress[i],
                                            "New Information Received from XSpace User",
                                            body,
                                            true);
                                    }

                                    if (XSpaceFile.ReceiverSettings.WellTextFlag[i] == "1")//send sms too.
                                    {
                                        if (XSpaceFile.ReceiverSettings.CellNumber.Count() > 0)
                                        {
                                            ServiceData.SendSMS(ServiceData.GetFromEmailAddress(),
                                                                                           XSpaceFile.ReceiverSettings.CellNumber[0],
                                                                                           XSpaceFile.ReceiverSettings.CellPhoneProvider[0],
                                                                                           "New Information Received from User",
                                                                                           XSpaceFile.SenderSetting.Firstname[0] + " has sent you " + NumberOfFiles.ToString() + " files.",
                                                                                           true);

                                        }

                                    }
                                }
                            }

                        }
                    }
                }
            });
        }



        
        protected static void QueryMachineDrive(DataFile XSpaceFile)
        {
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetStorageDrive_SP", "");

            string drive = "";
            
            drive = dataAccess.GetData( "DRV_PATH");
            XSpaceFile.DriveGuid = dataAccess.GetData( "DRV_GUID");
            XSpaceFile.machine = drive;
        }

        protected static void QueryFolderUsers(string WellboreGuid, string folder, string foldername, DataFile XSpaceFile)
        {
            UserSettings settings = new UserSettings();
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetFolderUsers_SP", "FolderType='" + folder + "'");
            
            dataAccess.GetData( settings.Firstname, "USR_FIR_NM");
            dataAccess.GetData( settings.LastName, "USR_LST_NM");
            dataAccess.GetData( settings.EmailAddress, "EMAIL_ADDR_DESC");
            dataAccess.GetData( settings.UserGuid, "USR_GUID");
            dataAccess.GetData( settings.WellEmailFlag, "WELL_NTFN_FLG");
            dataAccess.GetData( settings.WellTextFlag, "WELL_TXT_NTFN_FLG");
            dataAccess.GetData( settings.CellNumber, "CELL_PHONE_NUM");
            dataAccess.GetData( settings.Wellbore, "WB_JOB_GUID");
            dataAccess.GetData( settings.CellPhoneProvider, "CELL_PHONE_PRVDR_CD");
            if (settings.Wellbore.Count > 0 && settings.Wellbore.Contains(WellboreGuid) == true )
            {
                for (int i = 0; i < settings.UserGuid.Count(); i++)
                {
                    if (XSpaceFile.UserToFolderMapping.ContainsKey(settings.UserGuid[i]))
                    {
                        UserSettings newsettings = XSpaceFile.UserToFolderMapping[settings.UserGuid[i]];
                        newsettings.FolderList.Add(foldername);

                    }
                    else
                    {
                        UserSettings newsettings = new UserSettings();
                        newsettings.FolderList.Add(foldername);
                        newsettings.EmailAddress.Add(settings.EmailAddress[i]);
                        newsettings.Firstname.Add(settings.Firstname[i]);
                        newsettings.LastName.Add(settings.LastName[i]);
                        newsettings.UserGuid.Add(settings.UserGuid[i]);
                        newsettings.WellEmailFlag.Add(settings.WellEmailFlag[i]);
                        newsettings.WellTextFlag.Add(settings.WellTextFlag[i]);

                        newsettings.CellNumber.Add(settings.CellNumber[i]);
                        newsettings.CellPhoneProvider.Add(settings.CellPhoneProvider[i]);
                        newsettings.Wellbore.Add(settings.Wellbore[i]);
                        XSpaceFile.UserToFolderMapping.Add(settings.UserGuid[i], newsettings);

                    }


                }
            }

        }




        protected static void QueryAllFileData(DataFile XSpaceFile)
        {

            ClearFields();
            QuerydataFiles(XSpaceFile);
            QueryWellData(XSpaceFile);
            QueryUserData(XSpaceFile);
            QueryMachineDrive(XSpaceFile);
            XSpaceFile.IsWellUpload = false;
            if (XSpaceFile.UploadType.Count > 0 && string.Compare(XSpaceFile.UploadType[0], "User", true) != 0)
            {
                GetFilteredFolders(XSpaceFile);
                XSpaceFile.IsWellUpload = true;
            }
            else
            {
                ServiceData.QueryUserSettingsForUserUploadNotification(XSpaceFile);
            }
        }

    }
}
