﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace XSpace.Common.Services
{
    public class ServiceData
    {
        public static string serviceurl = "";
        public static string XSpaceHomeUrl = "";
        public static string XSpaceMyFilesUrl = "";
        public static string ImageUrl = "";
        public static string SiteUrl = "";
        public static string smtpserver = "";
        public static string FromAddress = "";
        public static string SMSCarrier = "";
        public static string ServiceUser = "";
        public static string ServiceUserPwd = "";
        public static string WirelineUrl = "";
        public static string SperryUrl = "";
        public static string BaroidUrl = "";
        public static string ForgotPasswordUrl = "";
        public static string LogNamingConventionUrl = "";
        public static string FileNamingConventionUrl = "";



        public static string GetSettingsKeyValue(string keyName)
        {
            String strKeyValue = string.Empty;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);

           
                    using (SPWeb mySite = SPContext.Current.Web)
                    {

                        SPList list = mySite.Lists["XSpaceSettings"];

                        SPQuery query = new SPQuery();
                        query.Query = "<Where><Eq><FieldRef Name='KeyName'/><Value Type='Text'>" + keyName + "</Value></Eq></Where>";

                        SPListItemCollection myItems = list.GetItems(query);
                        foreach (SPListItem item in myItems)
                        {
                            strKeyValue = item["KeyValue"].ToString();
                            break;
                        }
                    }
               
            return strKeyValue;
        }

        public static string GetConfigData(string key)
        {
            return GetSettingsKeyValue(key);
        }

        public static string GetDataServiceUrl()
        {
            if (string.IsNullOrEmpty(serviceurl) == true)
            {
                serviceurl = SPContext.Current.Web.Url.ToString()+ "/_vti_bin/XSpace.Common.Services/DataService.svc/ExecuteProcedure/XSPACE/";
                smtpserver = GetConfigData("SmtpServer");
                FromAddress = GetConfigData("FromEmailAddress");
                XSpaceMyFilesUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Pages/DropBox.aspx";

                SiteUrl = SPContext.Current.Web.Url.ToString();
                ImageUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Images/";
                XSpaceHomeUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Pages/";
                SperryUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Help/Sperry XSpace Support.pdf";
                WirelineUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Help/XSpace Support Wireline and Perforating Services.pdf";
                BaroidUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/Help/Baroid XSpace PSL Administrators.pdf";
                LogNamingConventionUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/References/Log naming conventions Sperry.pdf";
                FileNamingConventionUrl = SPContext.Current.Web.Url.ToString() + "/_layouts/15/XSP/References/WP Standardized File Naming Conventions.pdf";
                
            }
            return serviceurl;
        }
        public static string GetFromEmailAddress()
        {
            return FromAddress;
        }
        public static string GetSMSCarrier()
        {
            return SMSCarrier;
        }

        public static string QueryUserSMSUrl(string Provider)
        {
            DataAccess dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetCellPhoneProviderDetailByID_SP", "ProviderID='" + Provider + "'");

            return dataAccess.GetData( "SMS_URL");
        }
        public static void QueryUserSettingsForUserUploadNotification(DataFile XSpaceFile)
        {
            UserSettings settings = XSpaceFile.ReceiverSettings;
            string[] receiverguid = XSpaceFile.UserUploadReceivedGuid;
            DataAccess dataAccess = new DataAccess();
            foreach (var item in receiverguid)
            {
                dataAccess = new DataAccess();
                dataAccess.ExecuteProcedure("GetUserSettingByUserGuid_SP", "UserGuid='" + item + "'");
                
                dataAccess.GetData( settings.Firstname, "USR_NM");
                dataAccess.GetData( settings.EmailAddress, "EMAIL_ADDR_DESC");


                dataAccess.GetData( settings.CellNumber, "CELL_PHONE_NUM");
                dataAccess.GetData( settings.CellPhoneProvider, "CELL_PHONE_PRVDR_CD");
                dataAccess.GetData( settings.WellEmailFlag, "WELL_NTFN_FLG");
                dataAccess.GetData( settings.DropBoxEmailFlag, "DROP_BOX_NTFN_FLG");

                dataAccess.GetData( settings.WellTextFlag, "WELL_TXT_NTFN_FLG");
                dataAccess.GetData( settings.DropBoxTextFlag, "DRPBX_TXT_NTFN_FLG");

            }
            settings = XSpaceFile.SenderSetting;
            dataAccess = new DataAccess();
            dataAccess.ExecuteProcedure("GetUserSettingByUserGuid_SP", "UserGuid='" + XSpaceFile.SenderGuid + "'");
            
            dataAccess.GetData( settings.Firstname, "USR_NM");
            dataAccess.GetData( settings.EmailAddress, "EMAIL_ADDR_DESC");


            dataAccess.GetData( settings.CellNumber, "CELL_PHONE_NUM");
            dataAccess.GetData( settings.CellPhoneProvider, "CELL_PHONE_PRVDR_CD");
            dataAccess.GetData( settings.WellEmailFlag, "WELL_NTFN_FLG");
            dataAccess.GetData( settings.DropBoxEmailFlag, "DROP_BOX_NTFN_FLG");

            dataAccess.GetData( settings.WellTextFlag, "WELL_TXT_NTFN_FLG");
            dataAccess.GetData( settings.DropBoxTextFlag, "DRPBX_TXT_NTFN_FLG");

        }

        public static double ConvertSizeFromKBtoMB(long size)
        {
            double Size = (size / 1024f) / 1024f;
            return Math.Round(Size, 2);

        }

        public static List<FileDetails> GetFileList(string filePath)
        {
            string url = ServiceData.GetSiteUrl();
            List<FileDetails> filedetails = new List<FileDetails>();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        //for (int i = 0; i < XSpaceFile.path.Count(); i++)
                        {
                            //ZipFile zf = null;

                            Ionic.Zip.ZipFile zf = null;
                            try
                            {
                                //FileStream fs = File.OpenRead((string)array.GetValue(i));
                                zf = new Ionic.Zip.ZipFile((string)filePath);
                                foreach (Ionic.Zip.ZipEntry zipEntry in zf)
                                {
                                    if (zipEntry.IsDirectory)
                                    {
                                        continue;           // Ignore directories
                                    }
                                    String entryFileName = zipEntry.FileName;
                                    FileDetails details = new FileDetails();

                                    {

                                        details.FileName = entryFileName;
                                        details.Size = ConvertSizeFromKBtoMB(zipEntry.CompressedSize);
                                        filedetails.Add(details);

                                    }
                                }
                                zf.Dispose();
                                //zf.IsStreamOwner = true; // Makes close also shut the underlying stream
                                //zf.Close(); // Ensure we release resources

                            }
                            catch (Exception ex)
                            {



                            }


                        }
                    }
                }
            });


            return filedetails;

        }

        public static void SendSMS(string From, string cellnumber, string provider, string subject, 
            string body, bool IsHtml)
            
        {
            if (string.IsNullOrEmpty(cellnumber) == true)
                return;
            if (string.IsNullOrEmpty(provider) == true)
                return;
            string providerurl = QueryUserSMSUrl(provider);

            string provideraddress = cellnumber.Replace("-","")  + "@" + providerurl;
            SendEmail(From, provideraddress, subject, body, false);
        }

        public static void SendEmail(string From, string to, string subject, string body, bool IsHtml,
            List<Attachment> attachments=null)
        {
            MailMessage mailMsg = new MailMessage();
            body = UpdateCommonSectionInEmail(body);

            mailMsg.To.Add(to);
            if (attachments != null)
            {
                for (int i = 0; i < attachments.Count(); i++ )
                    mailMsg.Attachments.Add(attachments[i]);
            }
            MailAddress mailAddress = new MailAddress(From);
            mailMsg.From = mailAddress;
            mailMsg.Subject = subject;
            mailMsg.IsBodyHtml = IsHtml;
            mailMsg.Body = body;
            SmtpClient smtpClient = new SmtpClient(ServiceData.smtpserver);
            //smtpClient.Credentials = new System.Net.NetworkCredential(ServiceUser, ServiceUserPwd);
            smtpClient.UseDefaultCredentials = true;

            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Send(mailMsg);

        }

        public static string GetWirelineSupportUrl()
        {
            return WirelineUrl;
        }

        public static string GetSperrySupportUrl()
        {
            return SperryUrl;
        }

        public static string GetBaroidSupportUrl()
        {
            return BaroidUrl;
        }
        public static string GetLogNamingConventionsUrl()
        {
            return LogNamingConventionUrl;
        }
        public static string GetFileNamingConventionsUrl()
        {
            return FileNamingConventionUrl;
        }

        public static string GetPasswordSupportUrl()
        {
            return ForgotPasswordUrl;
        }

        public static string UpdateCommonSectionInEmail(string body)
        {
            body = body.Replace("{SupportWirelineUrl}", GetWirelineSupportUrl());
            body = body.Replace("{SupportSperryUrl}", GetSperrySupportUrl());
            body = body.Replace("{SupportBaroidUrl}", GetBaroidSupportUrl());
            body = body.Replace( "{LogonUrl}", GetHomePageUrl() + "Home.aspx");
            body = body.Replace("{HeaderImageUrl}", ImageUrl + "emailheader.png");
            body = body.Replace("{footerImageUrl}", ImageUrl + "emailfooter.png");
            return body;

        }

        public static string GetHomePageUrl()
        {
            if (string.IsNullOrEmpty(XSpaceHomeUrl) == true)
            {
              //  string Server = GetConfigData("DataServiceUrl");
              //  string port = GetConfigData("Port");
                //XSpaceHomeUrl = SPContext.Current.Web.Url.ToString()+"/_layouts/15/XSP/Pages/Home.aspx";
            }
            return XSpaceHomeUrl;
        }
        public static string GetMyFilesUrl()
        {
            if (string.IsNullOrEmpty(XSpaceMyFilesUrl) == true)
            {
               // string Server = GetConfigData("DataServiceUrl");
                //string port = GetConfigData("Port");
                //XSpaceMyFilesUrl = SPContext.Current.Web.Url.ToString() +"/_layouts/15/XSP/Pages/DropBox.aspx";
            }
            return XSpaceMyFilesUrl;
        }
        public static string GetSiteUrl()
        {
            if (string.IsNullOrEmpty(SiteUrl) == true)
            {
               // string Server = GetConfigData("DataServiceUrl");
               // string port = GetConfigData("Port");
                //SiteUrl = SPContext.Current.Web.Url.ToString();
            }
            return SiteUrl;
        }

        public static string GetCurrentUser()
        {
            string strUserContext = HttpContext.Current.User.Identity.Name.ToString();
            string strUserID = string.Empty;

            if (!strUserContext.Contains('\\'))
            {
                strUserID = strUserContext.Split('|')[2].ToString();
            }
            else
            {
                strUserID = strUserContext.Split('\\')[1].ToString();
            }

            return strUserID;
        }
        public static bool IsInternalSite()
        {
            string strUserContext = HttpContext.Current.User.Identity.Name.ToString();
            bool IsInternal = false;

            if (!strUserContext.Contains('\\'))
            {
                IsInternal = false;
            }
            else
            {
                IsInternal=true;
                
            }

            return IsInternal;
        }
    }
}
