﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using Microsoft.Office.Server.Social;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.Office.Server.Microfeed;
using Microsoft.SharePoint;
using Microsoft.Office.Server.ReputationModel;
using Microsoft.Office.Server.SocialData;

using System.Configuration;
using System.Security.Principal;
using System.Web;
using Microsoft.Web.Hosting.Administration;
using System.Net;
using System.IO;
using System.Net.Mail;
using Microsoft.SharePoint.Utilities;
using System.Data;
using Newtonsoft.Json;
using System.Web.UI.WebControls;

//using Newtonsoft.Json.Linq;

namespace XSpace.Common.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public sealed class EmailSmsService : IEmailSmsService
    {

        public void SendEmail(string parameter)
        {
            WellUploadNotification wellupload = new WellUploadNotification();
            wellupload.SendEmail(parameter);
        }

        public void SendFileDistributionEmail(string parameter)
        {
            FileDistributionEmailNotification fileDistribution = new FileDistributionEmailNotification();
            fileDistribution.SendFileDistributionEmail(parameter);
        }

        public void SendDropBoxFileDistributionEmail(string parameter)
        {
            DropBoxNotification dropboxnotification = new DropBoxNotification();
            dropboxnotification.SendDropBoxFileDistributionEmail(parameter);
        }

        public void SendUserApprovedEmail(string parameter)
        {
            UserApprovalNotification approvalnotification = new UserApprovalNotification();
            approvalnotification.SendUserApprovedEmail(parameter);
        }

        public void SendFileStatusChangeNotification(string parameter)
        {
            DataFileUpdateNotification updatenotification = new DataFileUpdateNotification();
            updatenotification.SendFileStatusChangeNotification(parameter);
        }
    }
}




           
