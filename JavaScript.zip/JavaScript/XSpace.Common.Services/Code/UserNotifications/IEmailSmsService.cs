﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace XSpace.Common.Services
{
    [ServiceContract]
    public interface IEmailSmsService
    {
        [OperationContract(Name = "SendEmail")]
        [WebInvoke(Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        void SendEmail(string parameter);

        [OperationContract(Name = "SendFileDistributionEmail")]
        [WebInvoke(Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        void SendFileDistributionEmail(string parameter);

        [OperationContract(Name = "SendDropBoxFileDistributionEmail")]
        [WebInvoke(Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        void SendDropBoxFileDistributionEmail(string parameter);

        [OperationContract(Name = "SendUserApprovedEmail")]
        [WebInvoke(Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        void SendUserApprovedEmail(string parameter);

        [OperationContract(Name = "SendFileStatusChangeNotification")]
        [WebInvoke(Method = "POST",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        void SendFileStatusChangeNotification(string parameter);

    }
}
