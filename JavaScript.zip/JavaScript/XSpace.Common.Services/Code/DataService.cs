﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using Microsoft.Office.Server.Social;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.Office.Server.Microfeed;
using Microsoft.SharePoint;
using Microsoft.Office.Server.ReputationModel;
using Microsoft.Office.Server.SocialData;
using DSP.SP.SDK;
using DSP.SP.Common;
using System.Configuration;
using System.Security.Principal;
using System.Web;
using Microsoft.Web.Hosting.Administration;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using Microsoft.SharePoint.Administration;

namespace XSpace.Common.Services
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public sealed class DataService : IDataService
    {

        /// <summary>
        /// ExecuteProcedure
        /// </summary>
        /// <param name="source"></param>
        /// <param name="procName"></param>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public string ExecuteProcedure(string source, string procName)
        {
            string jsonData = null;
            string properties = "";
            string parameter = "";

            try
            {
                jsonData = ExecuteProcedure(source, procName, parameter, properties);
            }
            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                throw ex;
            }
            return jsonData;
        }


        /// <summary>
        /// ExecuteProcedure
        /// </summary>
        /// <param name="source"></param>
        /// <param name="procName"></param>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public string ExecuteProcedure(string source, string procName, string parameter)
        {
            string jsonData = null;
            string properties = "";
            string strParam = "";
            try
            {
                if (!string.IsNullOrEmpty(parameter))
                {
                    var arrParam = parameter.Split('&');
                    for (int i = 0; i < arrParam.Length; i++)
                    {
                        var item = arrParam[i].Split('=');
                        if (!string.IsNullOrEmpty(item[0]))
                            strParam = strParam + item[0] + "=" + HttpUtility.UrlEncode(HttpUtility.UrlDecode(item[1])) + "&";
                    }
                }
                else
                    strParam = parameter;
                jsonData = ExecuteProcedure(source, procName, strParam, properties);
            }
            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON, "Data Query", 615, TraceSeverity.Medium);
                //throw ex;
            }
            return jsonData;
        }

        /// <summary>
        /// ExecuteProcedure
        /// </summary>
        /// <param name="source"></param>
        /// <param name="procName"></param>
        /// <param name="parameter"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        public string ExecuteProcedure(string source, string procName, string parameter, string properties)
        {
            string jsonData = null;
            bool userCheck = false;

            try
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                jsonData = GetDataFromProc(source, procName, properties, parameter, userCheck);
            }
            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                throw ex;
            }
            return jsonData;
        }

        private static DataModelSources GetDataServerUrl(string serviceName)
        {
            List<DataModelSources> lstDataModelSource = null;
            DataModelSources dataSource = null;
            DSP.SP.SDK.ServiceManager serviceManager = new DSP.SP.SDK.ServiceManager();
            try
            {
                lstDataModelSource = serviceManager.GetDataModelServices("Data Server");

                if (lstDataModelSource != null && lstDataModelSource.Count > 0)
                {

                    dataSource = lstDataModelSource.Where(d => d.ServiceName == serviceName).FirstOrDefault();

                }

            }

            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                throw ex;
            }

            return dataSource;
        }

        private static string GetEntitydata(string concatString, DataModelSources datasource)
        {

            string responseData = string.Empty;
            //try
            //{
            DSP.SP.SDK.ServiceManager sManager = new DSP.SP.SDK.ServiceManager();
            ICredentials credentials = sManager.GetCredentials(datasource);
            string dataServerUrl = datasource.ConnectionURL;

            string metadataurl = string.Empty;

            if (dataServerUrl.EndsWith("/"))
            {
                metadataurl = dataServerUrl + concatString;
            }
            else
            {
                metadataurl = dataServerUrl + "/" + concatString;
            }


            try
            {

                responseData = ODataHelper.GetODataResponseString(metadataurl, datasource.AuthenticationType, credentials);
            }
            catch (Exception exec)
            {
                // For DSIS 10.3 environment, the connection URL should include ALL_PROJECTS/ in the URL.
                try
                {
                    string cookies = ODataHelper.GetTokenFromCache(datasource);
                    if (cookies != null)
                    {
                        responseData = ODataHelper.GetODataResponseString(metadataurl, datasource.AuthenticationType, cookies);
                    }
                }
                catch (Exception exc)
                {
                    LogManager.TraceToDeveloper(exc, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                    throw exc;
                }

            }

            return responseData;

        }


        private static HttpWebResponse GetOdataResponse(string concatString, string dataServerUrl, ICredentials credentials)
        {

            HttpWebResponse response = null;
            string metadataurl = string.Empty;

            try
            {
                if (dataServerUrl.EndsWith("/"))
                {
                    metadataurl = dataServerUrl + concatString;
                }
                else
                {
                    metadataurl = dataServerUrl + "/" + concatString;
                }

                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(metadataurl);
                request.Credentials = credentials;

                request.Method = "GET";
                request.ContentType = "text/xml; encoding='utf-8'";
                request.PreAuthenticate = true;
                response = (HttpWebResponse)request.GetResponse();

            }
            catch (WebException ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                if (ex.Message.Contains("401"))
                {
                    throw (new Exception("Access is denied"));
                }
                else if (ex.Message.Contains("500"))
                {
                    throw (new Exception("The requested entity or property or filter or query option is not valid. Please check with your administrator"));
                }
                else if (ex.Message.Contains("400"))
                {
                    throw (new Exception("The requested entity or property or filter or query option is not valid. Please check with your administrator"));
                }
                else
                {
                    throw ex;
                }

            }
            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                throw ex;
            }

            return response;
        }


        internal static string GetDataFromProc(string source, string procName, string properties, string parameter, bool userCheck)
        {
            string concatString = null;
            StringBuilder jsonResponse = new StringBuilder();
            string format = "$format=json";
            string strProperties = "";
            object count = "";
            string uName = string.Empty;

            try
            {
                DataModelSources dataSource = GetDataServerUrl(Convert.ToString(source));
                if (string.IsNullOrEmpty(properties))
                {
                    strProperties = "";
                }
                else
                {
                    strProperties = "$select=" + properties;
                }

                if (string.IsNullOrEmpty(parameter))
                {
                    parameter = "";
                }

                //if (parameter.Contains("and") == true)
                //{
                //    parameter = parameter.Replace("and", "&");
                //}
                if (parameter.Contains("Login_id") == true)
                {

                    uName = SPUtil.ReturnLoginName(false);
                    parameter = parameter.Replace("Login_id", uName);
                }

                if (userCheck == true)
                {
                    uName = SPUtil.ReturnLoginName(false);
                    parameter = parameter.Trim() + "&UserName=" + uName;
                }

                concatString = procName + "?";

                if (!String.IsNullOrEmpty(parameter))
                {
                    concatString = concatString + parameter.Trim() + "&";
                    if (!String.IsNullOrEmpty(strProperties))
                    {
                        concatString = concatString + strProperties + "&";
                    }
                }
                else if (!String.IsNullOrEmpty(strProperties))
                {
                    concatString = concatString + strProperties + "&";
                }

                concatString = concatString + format;


                var paramList = new Dictionary<string, object>();

                JArray allJArrayData = new JArray();
                try
                {
                    //get element results 
                    string responseData = GetEntitydata(concatString, dataSource);
                    var objData = JObject.Parse(responseData);
                    JArray results = null;

                    if (objData["d"] != null)
                    {
                        if (objData["d"].GetType().ToString().Contains("JArray"))
                        {
                            results = JArray.Parse(objData["d"]["results"].ToString());
                        }
                        else if (objData["d"][procName] != null && objData["d"][procName].ToString() != "")
                        {
                            results = JArray.Parse(objData["d"][procName].ToString());
                        }
                        else if (objData["d"]["results"] != null && objData["d"]["results"].ToString() != "")
                        {
                            results = JArray.Parse(objData["d"]["results"].ToString());
                        }
                        else
                            results = null;


                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(objData["value"].ToString()))
                            results = JArray.Parse(objData["value"].ToString());

                        //foreach (var item in results)
                        //{
                        //    allJArrayData.Add(item);
                        //}

                    }
                    //  totalResults = totalResults + results.Count();
                    if (results != null)
                    {
                        int strLength = Convert.ToString(results).Length;
                        string strValue = Convert.ToString(results).Substring(1, (strLength - 2));
                        jsonResponse.Append((jsonResponse.Length > 0 ? "," : "") + strValue);
                    }


                }
                catch (Exception ex)
                {
                    LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                    throw ex;
                }

                if (jsonResponse.ToString() == "")
                {
                    //throw new Exception("There is no data or the fields are missing in the Catalog.");
                }
            }
            catch (Exception ex)
            {
                LogManager.TraceToDeveloper(ex, LogConstants.AREA_DSP + "/" + LogConstants.CATEGORY_COMMON);
                throw ex;
            }
            return "{\"data\":[" + jsonResponse + "]}";
        }

        public string GetSettingsKeyValue(string keyName)
        {
            String strKeyValue = string.Empty;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);

         
                    using (SPWeb mySite = SPContext.Current.Web)
                    {

                        SPList list = mySite.Lists["XSpaceSettings"];

                        SPQuery query = new SPQuery();
                        query.Query = "<Where><Eq><FieldRef Name='KeyName'/><Value Type='Text'>" + keyName + "</Value></Eq></Where>";

                        SPListItemCollection myItems = list.GetItems(query);
                        foreach (SPListItem item in myItems)
                        {
                            strKeyValue = item["KeyValue"].ToString();
                            break;
                        }
                    }
               

            return strKeyValue;
        }


    }
}
