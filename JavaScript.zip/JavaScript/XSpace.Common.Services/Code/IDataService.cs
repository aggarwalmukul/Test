﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace XSpace.Common.Services
{
    [ServiceContract]
    public interface IDataService
    {
        [OperationContract(Name = "ExecuteProcedureWithProp")]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "ExecuteProcedure?source={source}&procName={procName}&parameter={parameter}&properties={properties}")]
        string ExecuteProcedure(string source, string procName, string parameter, string properties);

        [OperationContract(Name = "ExecuteProcedureWithoutProp")]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "ExecuteProcedure/{source}/{procName}?parameter={parameter}")]
        string ExecuteProcedure(string source, string procName, string parameter);

        [OperationContract(Name = "ExecuteProcedureWithoutParam")]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "ExecuteProcedure/{source}/{procName}")]
        string ExecuteProcedure(string source, string procName);

        [OperationContract(Name = "GetSettingsKeyValue")]
        [WebInvoke(Method = "GET",
            ResponseFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Wrapped,
            UriTemplate = "GetSettingsKeyValue/{keyValue}")]
        string GetSettingsKeyValue(string keyValue);
    }
}
