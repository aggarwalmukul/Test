﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using XSpace.Common.Services;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class Home : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            userID.Value = ServiceData.GetCurrentUser();
        }
    }
}
