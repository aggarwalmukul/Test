﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;
using XSpace.Common.Services;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class Reference : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            XSpace.Common.Services.ServiceData.GetDataServiceUrl();
            hrefLogNaming.HRef = XSpace.Common.Services.ServiceData.GetLogNamingConventionsUrl();
            hrefFileNaming.HRef = XSpace.Common.Services.ServiceData.GetFileNamingConventionsUrl();        
        }
    }
}
