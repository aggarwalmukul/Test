﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class EmployeeRegistration : LayoutsPageBase
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            if (HttpContext.Current.Items["UID"] != null)
            {
                lblUserName.Text = HttpContext.Current.Items["FNAME"].ToString() + " " + HttpContext.Current.Items["LNAME"].ToString();

            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
