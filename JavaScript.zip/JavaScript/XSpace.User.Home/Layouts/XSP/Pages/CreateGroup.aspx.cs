﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class CreateGroup : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
