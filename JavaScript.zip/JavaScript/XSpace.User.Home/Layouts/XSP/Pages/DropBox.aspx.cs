﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;
using XSpace.Common.Services;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class DropBox : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            userID.Value = ServiceData.GetCurrentUser();        
        }
    }
}
