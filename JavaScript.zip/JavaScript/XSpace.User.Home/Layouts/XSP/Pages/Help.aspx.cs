﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web;
using XSpace.Common.Services;

namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class Help : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            XSpace.Common.Services.ServiceData.GetDataServiceUrl();
            hrefWireline.HRef = XSpace.Common.Services.ServiceData.GetWirelineSupportUrl();
            hrefSperry.HRef = XSpace.Common.Services.ServiceData.GetSperrySupportUrl();
            hrefBaroid.HRef = XSpace.Common.Services.ServiceData.GetBaroidSupportUrl();

        }
    }
}
