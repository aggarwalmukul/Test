﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;using System.Net;

namespace XSpace.User.Home.Layouts.XSP.Pages
{



    public partial class NewFiles : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }


    }
}
