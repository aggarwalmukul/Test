﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;


namespace XSpace.User.Home.Layouts.XSP.Pages
{
    public partial class Download : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
       
    
        }

        //[WebMethod]

        //public static void GetData()
        //{

        //    HttpResponse Response = HttpContext.Current.Response;
        //    Array array = Array.CreateInstance(typeof(string), 5);
        //    array.SetValue(@"\\hssan\test\Mukul\Test.png", 0);
        //    array.SetValue(@"\\hssan\test\Mukul\Test1.png", 1);
        //    array.SetValue(@"\\hssan\test\Nilesh\FileSystemScanner.cs", 2);
        //    array.SetValue(@"\\hssan\test\Mukul\Mukul.zip", 3);
        //    array.SetValue(@"\\hssan\test\Mukul\HTDM.mdb", 4);
        //    string zipFileName = "MyZipFiles.zip";
        //    Response.ContentType = "application/zip";
        //    Response.AddHeader("content-disposition", "fileName=" + zipFileName);
        //    byte[] buffer = new byte[4096];
        //    ZipOutputStream zipOutputStream = new ZipOutputStream(Response.OutputStream);
        //    zipOutputStream.SetLevel(3);


        //    try
        //    {
        //        //DirectoryInfo DI = new DirectoryInfo(Server.MapPath("~/DownloadFolder"));
        //        //foreach (var i in DI.GetFiles())
        //        {
        //            //Stream fs = File.OpenRead("//hssan/test/Mukul/Test.png");

        //            //int count = fs.Read(buffer, 0, buffer.Length);  
        //            //while (count > 0)
        //            for (int i = 0; i < array.Length; i++)
        //            {
        //                WebClient req = new WebClient();

        //                //byte[] data = req.DownloadData((string)(array.GetValue(i)));
        //                ZipEntry zipEntry = new ZipEntry(ZipEntry.CleanName((string)(array.GetValue(i))));
        //                Stream myStream = req.OpenRead((string)(array.GetValue(i)));
        //                zipEntry.Size = (Convert.ToInt64(req.ResponseHeaders["Content-Length"]));
        //                zipOutputStream.PutNextEntry(zipEntry);


        //                Int64 count = zipEntry.Size;

        //                while (count > 0)
        //                {
        //                    int bytesRead = myStream.Read(buffer, 0, 4096);
        //                    count = count - bytesRead;

        //                    zipOutputStream.Write(buffer, 0, bytesRead);
        //                    //count = fs.Read(buffer, 0, buffer.Length);
        //                    if (!Response.IsClientConnected)
        //                    {

        //                    }
        //                    Response.Flush();

        //                }
        //                myStream.Close();


        //            }
        //            //fs.Close();
        //        }
        //        zipOutputStream.Close();
        //        Response.Flush();
        //        Response.End();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }

        //    //using (ZipFile zip = new ZipFile())
        //    //{

        //    //    zip.AlternateEncodingUsage = ZipOption.AsNecessary;
        //    //    zip.AddDirectory(@"\\hssan\Test\Mukul\", "Mukul");
        //    //    zip.AddFile(@"\\hssan\Mukul\test.png");
        //    //    //zip.AddDirectoryByName("Files");
        //    //    //zip.AddFile(@"\\HALVHD41031\hssan\test.txt", "Files");
        //    //    //zip.AddFile(@"\\hssan\test\Test1.png", "Files");
        //    //    Response.Clear();
        //    //    Response.BufferOutput = false;
        //    //    string zipName = String.Format("Zip_{0}.zip", DateTime.Now.ToString("yyyy-MMM-dd-HHmmss"));
        //    //    Response.ContentType = "application/zip";
        //    //    Response.AddHeader("content-disposition", "attachment; filename=" + zipName);
        //    //    zip.Save(Response.OutputStream);
        //    //    Response.End();
        //    //}

        //    //try
        //    //{
        //    //    ZipFile zip
        //    //    string strURL = "//hssan/test/Mukul/Test.png";
        //    //    string strURL1 = "//hssan/test/Mukul/Test1.png";
        //    //    WebClient req = new WebClient();
        //    //    HttpResponse response = HttpContext.Current.Response;
        //    //    response.Clear();
        //    //    response.ClearContent();
        //    //    response.ClearHeaders();
        //    //    response.Buffer = true;
        //    //    //response.AddHeader("Content-Disposition", "attachment;filename=\"" + Server.MapPath(strURL) + "\"");
        //    //    response.AddHeader("Content-Disposition", "attachment;filename=\"" + strURL + "\"");
        //    //    response.AddHeader("Content-Disposition", "attachment;filename=\"" + strURL1 + "\"");
        //    //    byte[] data = req.DownloadData(strURL);
        //    //    response.BinaryWrite(data);
        //    //    response.End();
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //}
        //}




    }
}
