﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;

namespace XSpace.User.Home.CONTROLTEMPLATES.XSP
{
    public partial class Upload : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                createAccordianUsingRepeater();
            }
        }



        public void createAccordianUsingRepeater()
        {
            //repAccordian.DataSource = createDataTable();
            //repAccordian.DataBind();
        }
        //using System.Data;
        public DataTable createDataTable()
        {
            DataTable dt = new DataTable();
            //DataColumn dc = new DataColumn();
            //dc.ColumnName = "Name";
            //dc.DataType = typeof(string);
            //dt.Columns.Add(dc);

            //dc = new DataColumn();
            //dc.ColumnName = "Description";
            //dc.DataType = typeof(string);
            //dt.Columns.Add(dc);

            //dc = new DataColumn();
            //dc.ColumnName = "Email";
            //dc.DataType = typeof(string);
            //dt.Columns.Add(dc);

            //dc = new DataColumn();
            //dc.ColumnName = "Phone";
            //dc.DataType = typeof(string);

            //dt.Columns.Add(dc);


            //dt.Rows.Add(new object[] { "Artificail Lift(2)", "SDL-DSN-GR-Run5.las(22MB)", "SDL-DSN-GR-Run6.las(22MB)", "SDL-DSN-GR-Run7.las(22MB)" });
            //dt.Rows.Add(new object[] { "Borehole Seismic(2)", "SDL-DSN-GR-Run5.las(22MB)", "SDL-DSN-GR-Run6.las(22MB)", "SDL-DSN-GR-Run7.las(22MB)" });
            //dt.Rows.Add(new object[] { "Cementing(2)", "SDL-DSN-GR-Run5.las(22MB)", "SDL-DSN-GR-Run6.las(22MB)", "SDL-DSN-GR-Run7.las(22MB)" });
            //dt.Rows.Add(new object[] { "Completion Tools(0)", "SDL-DSN-GR-Run5.las(22MB)", "SDL-DSN-GR-Run6.las(22MB)", "SDL-DSN-GR-Run7.las(22MB)" });
            //dt.Rows.Add(new object[] { "Consulting and Project Management(0)", "SDL-DSN-GR-Run5.las(22MB)", "SDL-DSN-GR-Run6.las(22MB)", "SDL-DSN-GR-Run7.las(22MB)" });


            return dt;

        }
    }
}
