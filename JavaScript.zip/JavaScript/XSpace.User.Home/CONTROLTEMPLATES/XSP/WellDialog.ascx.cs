﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace XSpace.User.Home.CONTROLTEMPLATES.XSP
{
    public partial class WellDialog : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
