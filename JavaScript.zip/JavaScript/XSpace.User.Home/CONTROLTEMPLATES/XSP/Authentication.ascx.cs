﻿using Microsoft.SharePoint;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using XSpace.Common.Services;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint.Administration;
namespace XSpace.User.Home.CONTROLTEMPLATES.XSP
{
    public partial class Authentication : UserControl
    {
        bool isFirstTimeLogin = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            string userType = string.Empty;
            string userID = string.Empty;
            string userEmail = string.Empty;
            string userFName = string.Empty;
            string userLName = string.Empty;
            HttpCookie cUType = null;
            HttpCookie cUserID = null;
            HttpCookie cEmail = null;
            HttpCookie cFName = null;
            HttpCookie cLName = null;
            HttpCookie cLoggedIn = null;
            try
            {

                // if user ID is not null
                if (ServiceData.GetCurrentUser() != null)
                {
                    if (ServiceData.IsInternalSite())
                    {
                        HttpContext.Current.Items.Add("UType", "halliburton");//either customer or halliburton
                        HttpContext.Current.Items.Add("UID", ServiceData.GetCurrentUser());
                        if (string.IsNullOrEmpty(SPContext.Current.Web.CurrentUser.Email))
                        {
                            HttpContext.Current.Items.Add("EMAIL", "xspaceqa@halliburton.com");
                        }
                        else
                        {
                            HttpContext.Current.Items.Add("EMAIL", SPContext.Current.Web.CurrentUser.Email.ToString());
                        }


                        string[] UserName = GetUserFirstandLastName(SPContext.Current.Web.CurrentUser);
                        if (!string.IsNullOrEmpty(UserName[0]))
                        {
                            HttpContext.Current.Items.Add("FNAME", UserName[0]);
                            if (!string.IsNullOrEmpty(UserName[1]))
                            {
                                HttpContext.Current.Items.Add("LNAME", UserName[1]);
                            }
                            else
                            {
                                HttpContext.Current.Items.Add("LNAME", ".");

                            }
                        }
                        else
                        {
                            HttpContext.Current.Items.Add("FNAME", SPContext.Current.Web.CurrentUser.Name.ToString());
                            HttpContext.Current.Items.Add("LNAME", ".");
                        }

                    }

                    userType = HttpContext.Current.Items["UType"].ToString();
                    userID = HttpContext.Current.Items["UID"].ToString();
                    userEmail = HttpContext.Current.Items["EMAIL"].ToString();
                    userFName = HttpContext.Current.Items["FNAME"].ToString();
                    userLName = HttpContext.Current.Items["LNAME"].ToString();

                    if (HttpContext.Current.Request.Cookies["CUID"] == null)
                    {
                        isFirstTimeLogin = true;
                        cUType = new HttpCookie("CUTYPE");
                        cUType.Value = userType;
                        cUType.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cUType);

                        cUserID = new HttpCookie("CUID");
                        cUserID.Value = userID;
                        cUserID.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cUserID);

                        cEmail = new HttpCookie("CEMAIL");
                        cEmail.Value = userEmail;
                        cEmail.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cEmail);

                        cFName = new HttpCookie("CFNAME");
                        cFName.Value = userFName;
                        cFName.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cFName);

                        cLName = new HttpCookie("CLNAME");
                        cLName.Value = userLName;
                        cLName.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cLName);


                        cLoggedIn = new HttpCookie("CLoggedIn");
                        cLoggedIn.Value = "True";
                        cLoggedIn.Expires = DateTime.Now.AddMinutes(20d);
                        Response.Cookies.Add(cLoggedIn);
                    }



                    if ((!isXSpaceUser(userID)) || (!isUserApproved(userID)))
                    {
                        if (!string.IsNullOrEmpty(userType) && userType.ToString() == "customer")
                        {
                            if (!HttpContext.Current.Request.Url.ToString().Contains("CustomerRegistration.aspx"))
                                Response.Redirect("CustomerRegistration.aspx");
                        }
                        else
                        {
                            if (!HttpContext.Current.Request.Url.ToString().Contains("EmployeeRegistration.aspx"))
                            {
                                Response.Redirect("EmployeeRegistration.aspx");
                            }
                        }
                    }
                }
                else
                {
                    // if user ID is null
                    //Response.Redirect("_layouts/15/XSP/Pages/Home.aspx");
                }
            }
            catch (Exception ex)
            {

                ShowXspaceLog(ex.Message.ToString());
            }


        }
        public string[] GetUserFirstandLastName(SPUser user)
        {
            string[] tmpuserName = new string[2];


            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                using (SPSite site = new SPSite(SPContext.Current.Web.Url.ToString()))
                {
                    try
                    {
                        SPServiceContext serverContext = SPServiceContext.GetContext(site);
                        UserProfileManager profileManager = new UserProfileManager(serverContext);

                        UserProfile profile = profileManager.GetUserProfile(user.LoginName);
                        tmpuserName[0] = profile["FirstName"].Value.ToString();
                        tmpuserName[1] = profile["LastName"].Value.ToString();


                    }
                    catch (Exception ex)
                    {
                        ShowXspaceLog(ex.Message.ToString());
                    }
                }
            });


            return tmpuserName;

        }
        private bool isXSpaceUser(string UID)
        {
            bool isExist = false;
            string param = "UserID='" + UID + "'";
            DataService dataService = new DataService();
            string jsonString = dataService.ExecuteProcedure("XSPACE", "GetUserDetailByUserID_SP", param);
            var userArray = JArray.Parse(JObject.Parse(jsonString)["data"].ToString());
            if (userArray.Count > 0)
            {
                isExist = true;

            }
            return isExist;
        }
        private bool isUserApproved(string UID)
        {

            bool isApproved = false;

            string param = "UserID='" + UID + "'";
            DataService dataService = new DataService();
            string jsonString = dataService.ExecuteProcedure("XSPACE", "GetUserApprovalStatus_SP", param);

            if (jsonString.Contains("\"APRVD\""))
            {
                isApproved = true;
                if (isFirstTimeLogin)
                {
                    //dataService.ExecuteProcedure("XSPACE", "UpdateUserLogout_SP", param);
                    isFirstTimeLogin = false;
                }



            }


            return isApproved;
        }
        public void ShowXspaceLog(string sEvent)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
                    diagSvc.WriteTrace(123456, new SPDiagnosticsCategory("xSpace", TraceSeverity.Monitorable, EventSeverity.Error), TraceSeverity.Monitorable, "{0}:{1}", new object[] { "XSpace Method_Name", sEvent });
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }


}
