﻿using System;
using System.Configuration;
using System.Web;
using Microsoft.SharePoint;
using System.Collections.Generic;
using System.Xml;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Net;
using System.Text.RegularExpressions;
using System.Security.Principal;
using Microsoft.SharePoint.IdentityModel;
using System.Text;
using Microsoft.SharePoint.Administration;
using System.IdentityModel.Tokens;
using System.Diagnostics;
namespace XSpace.Common.HttpModule
{


    public class XSpaceLoginModule : IHttpModule
    {
        private static string externalUrl = string.Empty;

        public void Init(HttpApplication application)
        {
            //ShowXLog("XSpace Init Starts");

            if (SPSecurity.AuthenticationMode == System.Web.Configuration.AuthenticationMode.Forms)
            {

                application.AuthenticateRequest += OnAuthenticateRequest;

            }
            // ShowXLog("XSpace Init End");
        }
        public static void ShowXLog(string sEvent)
        {
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    SPDiagnosticsService diagSvc = SPDiagnosticsService.Local;
                    diagSvc.WriteTrace(123456, new SPDiagnosticsCategory("xSpace", TraceSeverity.Monitorable, EventSeverity.Error), TraceSeverity.Monitorable, "{0}:{1}", new object[] { "XSpace Method_Name", sEvent });
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private void OnAuthenticateRequest(object sender, EventArgs e)
        {
            //ShowXLog("XSpace On Auth");
            var context = new HttpContextWrapper(((HttpApplication)sender).Context);
            try
            {
                HttpApplication application = (HttpApplication)sender;
                string requestUrl = application.Request.AppRelativeCurrentExecutionFilePath.ToString().Trim();

                if (requestUrl.ToLower().Contains(".aspx"))
                {
                    //ShowXLog("XSpace Authenticate for aspx pages");
                    if (context.Request.Headers["UID"] != null)
                    {
                        //ShowXLog("XSpace UID" + context.Request.Headers["UID"].ToString());
                        //ShowXLog("XSpace UID" + context.Request.Headers["usertype"].ToString());
                        //ShowXLog("XSpace UID" + context.Request.Headers["EMAIL"].ToString());
                        //ShowXLog("XSpace UID" + context.Request.Headers["FNAME"].ToString());
                        //ShowXLog("XSpace UID" + context.Request.Headers["LNAME"].ToString());

                        HttpContext.Current.Items.Add("UType", context.Request.Headers["usertype"].ToString());
                        HttpContext.Current.Items.Add("UID", context.Request.Headers["UID"].ToString());
                        HttpContext.Current.Items.Add("EMAIL", context.Request.Headers["EMAIL"].ToString());
                        HttpContext.Current.Items.Add("FNAME", context.Request.Headers["FNAME"].ToString());
                        HttpContext.Current.Items.Add("LNAME", context.Request.Headers["LNAME"].ToString());


                        // ShowXLog(" XSpace before validation");
                        ValidateUser(application);
                        // ShowXLog(" XSpace after validation");

                    }
                    else
                    {
                        // ShowXLog("XSpace else aspx");                      

                    }
                }
            }
            catch (Exception ex)
            {
                ShowXLog("XSpace OnAuth error" + ex.Message.ToString());

            }


        }

        public void ValidateUser(HttpApplication httpApp)
        {
            //ShowXLog("XSpace Validate User");
            string userId = string.Empty;

            try
            {
                userId = httpApp.Context.Request.Headers["UID"].ToString();
                if (!String.IsNullOrEmpty(userId))
                {
                    // ShowXLog("XSpace Valid  User ID");
                    HttpCookie spCookie = null;
                    try
                    {
                        spCookie = httpApp.Context.Request.Cookies["FedAuth"];
                        if (spCookie != null)
                        {
                            //ShowXLog("XSpace Valid FedAuth Cookie");
                            try
                            {
                                if (!isSPCookieValid(spCookie.Value, userId))
                                {
                                    //ShowXLog("XSpace Before FedAuth cookie Generation");
                                    SPClaimsUtility.AuthenticateFormsUser(httpApp.Request.Url, userId, "password");
                                    ShowXLog("XSpace After FedAuth cookie Generation sucessfully");
                                }

                            }
                            catch (Exception ex)
                            {

                                ShowXLog("XSpace " + ex.Message.ToString());
                            }
                        }
                        else if (!String.IsNullOrEmpty(userId))
                        {
                            // ShowXLog("XSpace Before FedAuth cookie Generation First time");
                            SPClaimsUtility.AuthenticateFormsUser(httpApp.Request.Url, userId, "password");
                            ShowXLog("XSpace After FedAuth cookie Generation First time sucessfully");
                        }

                    }
                    catch (Exception ex)
                    {
                        ShowXLog("XSpace " + ex.Message.ToString());

                    }

                }
            }
            catch (Exception ex)
            {
                ShowXLog("XSpace " + ex.Message.ToString());

            }

        }

        public void Dispose()
        {
        }
        private bool isSPCookieValid(string cookie, string userId)
        {
            byte[] cookieBytes = Convert.FromBase64String(cookie);
            if ((cookieBytes != null) && (cookieBytes.Length > 0))
            {
                string cookieStr = Encoding.UTF8.GetString(cookieBytes);
                if (!String.IsNullOrEmpty(cookieStr))
                {
                    String[] cVals = cookieStr.Split(new char[] { ',' });
                    if ((cVals != null) && (cVals.Length > 1))
                    {
                        String[] clVals = cVals[0].Split(new char[] { '|' });
                        if ((clVals != null) && (clVals.Length > 2))
                        {
                            if (clVals[2].ToLower().Trim().Equals(userId.ToLower()))
                            {
                                //UserIds are equal ...
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }




    }

}
