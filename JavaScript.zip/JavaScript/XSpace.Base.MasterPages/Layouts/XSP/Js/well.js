﻿var myVM;
var isCancel = false;
var isGridLoaded=false;
$(document).ready(function () {
    $("#contract").css("display", "none");
    $('#ddlFilter').on('change', function () {
        
        // when game select changes, filter the character list to the selected game
       
        $("#contract").css("display", "none");

        var list = document.getElementById('ddlFilter');

        // Get the index of selected item, first item 0, second item 1 etc ...
        var INDEX = list.selectedIndex;

        // Viola you're done
        if (list[INDEX].text != "Custom") {
            GetXSpaceData("UserWellFilterGuid='" + list[INDEX].value + "'", "GetUserWellFilterByGuid_SP", UpdateSearchCreteria);
        }
    })

    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                if (isCancel) {
                    isCancel = false;
                    $(this).dialog('close');
                    $("#dWellDetails").dialog('close');
                }
                else {
                    GetXSpaceData(filterParam, "UpdateUserWellFilter_SP", UpdateFilterUI);
                    $(this).dialog('close');
                }
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#editconfirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                GetXSpaceData("UserWellFilterGuid='" + $("#filterId").val() + "'", "DeleteUserWellFilter_SP", undefined);
                GetXSpaceData(filterParam, "UpdateUserWellFilter_SP", UpdateFilterUI);
                var table = $("#" + filterGridSettings.GridId).DataTable();
                var oTable = $("#" + filterGridSettings.GridId).dataTable();
                $("#" + filterGridSettings.GridId + "tbody").html("");
                oTable.dataTable().fnDestroy();
                UpdateFilterGrid();
                $(this).dialog('close');              
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    loadCompanies();
    loadCoutries()
    $("#dCreateWellSelCompanyCountry").dialog({
        autoOpen: false,
        modal: true,
        title: "Create Well",
        height: 250,
        width: 550,
        open: function () {
            $("#ddlCountry").val("");
            $("#ddlCompany").val("");
        },
        buttons: {
            "OK": function () {
                if ($("#ddlCountry").val() == "") {
                    $("#alert").html("Please select a country.").dialog('open');
                    return false;
                }
                if ($("#ddlCompany").val() == "") {
                    $("#alert").html("Please select a company.").dialog('open');
                    return false;
                }
               // $("#dWellDetails").dialog('open');
                OpenCreateWellDialog(RetrieveSelectedWell);
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dWellDetails").dialog({
        autoOpen: false,
        modal: true,
        title: "Create Well",
        height: 400,
        width: 800,
        open: function () {
            $(".wDetails").val("");
            $("#wCompany").val($("#ddlCompany").val());
            $("#wCountry").val($("#ddlCountry").val());
            loadWellDetails();
        },
        buttons: {
            "Create Well": function () {
                if (ValidateWellDetails() && ValidateWellNameOrAPI()) {
                GetXSpaceData(getInsertParams(), "UpdateWellDetails_SP", function (data) {
                    sessionStorage.setItem('well-tab-index', null);
                    window.location.href = "/_layouts/XSP/Pages/download.aspx?operation=0&WBGuid=" +  data[0].WB_JOB_GUID ;
                    //$(this).dialog('close');
                });               
                }
            },
            "Cancel": function () {
                isCancel = true;
                $("#confirm").html("Are you sure to cancel?").dialog('open');
                return;
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#deleteFilter").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                //write code to delete filter
                var table = $("#" + filterGridSettings.GridId).DataTable();
                var data = table.row(".selected").data();
                var param = "UserWellFilterGuid='" + data.USR_WELL_FLTR_GUID + "'";
                var oTable = $("#" + filterGridSettings.GridId).dataTable();
                $("#" + filterGridSettings.GridId + "tbody").html("");
                oTable.dataTable().fnDestroy();
                GetXSpaceData(param, "DeleteUserWellFilter_SP", UpdateFilterUI);
                UpdateFilterGrid();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#divSaveFilter").dialog({
        autoOpen: false,
        modal: true,
        title: "Save Filter",
        height: 140,
        width: 326,
        open: function () {
            $("#txtFilter").val("");
        },
        buttons: {
            
            "Save": function () {                
                if ($.trim($("#txtFilter").val().toLowerCase()) == "custom")
                {
                    $("#alert").html("Custom can not be filter name.").dialog('open');
                }
                else if ($.trim($("#txtFilter").val()) == "") {
                    $("#alert").html("Please enter filter name.").dialog('open');
                    return;
                }
                else {
                    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", InsertFilterDB);
                    //save
                    $(this).dialog('close');
                }
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#FilterEdit").dialog({
        autoOpen: false,
        modal: true,
        title: "Filters",
        height: 400,
        width: 600,
        open: function () {
            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, "GetUserWellFilterList_SP", populateFilterGrid);
            //populateFilterGrid();
        },
        close: function () {
            var oTable = $("#" + filterGridSettings.GridId).dataTable();
            $("#" + filterGridSettings.GridId + "tbody").html("");
            oTable.dataTable().fnDestroy();
        },
        buttons: {
            "Close": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#divRename").dialog({
        autoOpen: false,
        modal: true,
        title: "Rename filter",
        height: 150,
        width: 320,       
        buttons: {
            "Save": function () {
                //write code to save               
                if ($.trim($("#filterName").val().toLowerCase()) == "custom") {
                    $("#alert").html("Custom can not be filter name.").dialog('open');
                }
                else if($.trim($("#filterName").val())=="")
                {
                    $("#alert").html("Please enter filter name.").dialog('open');
                    return;
                }
                else {
                    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", UpdateFilterDB);                    
                   $(this).dialog('close');
                }
            },
            "Close": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#collapse").on("click", function () {
        $("#tblFilter").css("display", "none");
        //$("#contract").css("display", "");
    });
     
    GetUserGuid(GetUserGUIDDetails);
    // var param = "UserID='" + document.getElementById('userID').value + "'";
   
    if (getPageName() == "Well") {
    GetXSpaceData("UserID='" + USERID + "'", wellGridSettings.DataSource, PopulateWellData);
    }
    if ($("#AddWell").length > 0)
        $("#AddWell")[0].onclick = null;
    $(document).on("click", "#AddWell", function () { AddWell(); });
    $("#wellGridtoolbar").width("500px");
    // debugger
    myVM = { viewModel: new VMMain(new vmSearch(null, null, null, null, null, null, null, null, null, null, null, null)) };
    ko.applyBindings(myVM.viewModel, document.getElementById('tblFilter'));
    if ($("#FilterManager").length>0) {
        $("#FilterManager")[0].onclick = null;
    }
    $("#FilterManager").on("click", function () {
        FilterManager();
    });
    if ($("#clearWFilter").length>0) {
        $("#clearWFilter")[0].onclick = null;
    }
    $("#clearWFilter").on("click", function () {
        ClearFilter();
    });
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.InternalUser)
        $("#AddWell").hide();
});

function RenameWell() {
    var table = $("#" + filterGridSettings.GridId).DataTable();
    var data = table.row(".selected").data();
    if (table.row(".selected").length > 0) {
        $("#filterId").val(data.USR_WELL_FLTR_GUID);
        $("#filterName").val(data.FLTR_NM);
        $("#divRename").dialog('open');
    }
    else {
        $("#alert").html("Please select a filter.").dialog('open');
        return;
    }
}



function DeleteWell() {
    var table = $("#" + filterGridSettings.GridId).DataTable();
    if (table.row(".selected").length > 0) {
        $("#deleteFilter").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#alert").html("Please select a filter.").dialog('open');
        return;
    }
}
function renderMultipleActions(data, type, full, meta) {
    if (data.split('.').pop() != "las")
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + data + "</td><td width='20%'><img class='zipinfo' src='../images/file_info_16x16.png' height='16' width='16' style='cursor:pointer;' onclick='openZipDialog(this);'/></td></tr></table>";
    else
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + data + "</td><td></td></tr></table>";
}
 
function PopulateWellData(data) {
	if(isGridLoaded)
	   destroyGrid();
	var list = document.getElementById('ddlFilter');
	if (list.selectedIndex!=-1&&list[list.selectedIndex].text != "Custom") 
	  $("#tblFilter").css("display", "");
	  
    $("#" + wellGridSettings.GridId).renderGrid(wellGridSettings, data);
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
	isGridLoaded=true;
}


function FilterManager(gridId) {
    $("#FilterEdit").dialog('open');
}
function ExpandFilter(gridId) {
    
    $("#tblFilter").css("display", "");
    //$("#contract").css("display", "none");
			
$("#tblFilter input:text").keypress(function (e) {

    if (e.keyCode == 13) {

       myVM.viewModel.Apply();	
        return false;
    }
});
}
var filterParam;
function InsertFilterDB(data)
{
    var param = "UserID='" + USERID + Sep() + "TypeCode='" + "Well" + Sep() +
        "Name='" + $("#txtFilter").val() + Sep() + "FilterString='" + GetWellSearchDBString() + "'";
    var Updated = false;

    var filterstring = "";
    for (var i = 0 ; i < data.length; i++) {
        if ($("#txtFilter").val() == data[i].FLTR_NM) {
            Updated = true;
            filterParam="UserWellFilterGuid='" + data[i].USR_WELL_FLTR_GUID + Sep() + "Name='" + $("#txtFilter").val() + Sep() + "FilterString='" +
                GetWellSearchDBString() + "'";
            $("#confirm").html("Filter name already exists.Do you want to overwrite?").dialog('open');          
            break;
        }
    }
    if (Updated == false) {
        GetXSpaceData(param, "InsertUserWellFilter_SP", UpdateFilterUI);
    }

}
function UpdateFilterDB(data)
{
    var Updated = false;
    var filtername = $("#filterName").val();
    var filterstring = "";
    for (var i = 0 ; i < data.length; i++) {
        if ($("#filterId").val() == data[i].USR_WELL_FLTR_GUID) {
            filterstring = data[i].FLTR_STR;
            break;
        }
    }
    for (var i = 0 ; i < data.length; i++) {       
        if (filtername == data[i].FLTR_NM && $("#filterId").val() != data[i].USR_WELL_FLTR_GUID)
        {
            Updated = true;
            filterParam="UserWellFilterGuid='" + data[i].USR_WELL_FLTR_GUID + Sep() + "Name='" + filtername + Sep() + "FilterString='" +
                filterstring + "'";
            $("#editconfirm").html("Filter name already exists.Do you want to overwrite?").dialog('open');
            break;
        }
    }
    if( Updated == false )
    {
        GetXSpaceData("UserWellFilterGuid='" + $("#filterId").val() + Sep() + "Name='" + filtername + Sep() + "FilterString='" +
            filterstring + "'", "UpdateUserWellFilter_SP", UpdateFilterUI);
        var table = $("#" + filterGridSettings.GridId).DataTable();
        var oTable = $("#" + filterGridSettings.GridId).dataTable();
        $("#" + filterGridSettings.GridId + "tbody").html("");
        oTable.dataTable().fnDestroy();
        UpdateFilterGrid();

    }

}

function UpdateFilterList(data) {
    //debugger
    var UpdateFilterDisplay = false;
    var list = document.getElementById("ddlFilter");
    var INDEX = list.selectedIndex;
    var guid = "";
    if (list.selectedIndex >= 0) {

        guid = list[list.selectedIndex].value;
    }
    removeOptions(document.getElementById("ddlFilter"));
    var select = document.getElementById('ddlFilter');
    for (var i = 0; i < data.length; i++) {
        var opt = document.createElement('option');
        opt.value = data[i].USR_WELL_FLTR_GUID;
        if (guid == opt.value)
        {
            UpdateFilterDisplay = true;
        }
        opt.text = data[i].FLTR_NM;
        select.appendChild(opt);

    }
    var opt = document.createElement('option');
    opt.value = "Custom";
    opt.text = "Custom";
    select.appendChild(opt);
    if (UpdateFilterDisplay == true) {
        $('#ddlFilter').val(guid).change();
    }
    else if ( guid == "Custom" )
    {
        $('#ddlFilter').val("Custom");
    }
    else if (myVM != null) {
        myVM.viewModel.Fields.Clear();
    }
    if (INDEX == -1)
        select.selectedIndex = -1;
}

function removeOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}
function UpdateSearchCreteria(data)
{
    var filterdata = GetFilterString(data[0].FLTR_STR);

    myVM.viewModel.Fields.Clear();
    if (ValidateEmptyData(filterdata[0]))
        myVM.viewModel.Fields.WellName(filterdata[0]);
    if (ValidateEmptyData(filterdata[1]))
        myVM.viewModel.Fields.Company(filterdata[1]);
    if (ValidateEmptyData(filterdata[2]))
        myVM.viewModel.Fields.SO(filterdata[2]);
    if (ValidateEmptyData(filterdata[3]))
        myVM.viewModel.Fields.Country(filterdata[3]);
    if (ValidateEmptyData(filterdata[4]))
        myVM.viewModel.Fields.State(filterdata[4]);
    if (ValidateEmptyData(filterdata[5]))
        myVM.viewModel.Fields.County(filterdata[5]);
    if (ValidateEmptyData(filterdata[6]))
        myVM.viewModel.Fields.Field(filterdata[6]);
    if (ValidateEmptyData(filterdata[7]))
        myVM.viewModel.Fields.Block(filterdata[7]);
    if (ValidateEmptyData(filterdata[8]))
        myVM.viewModel.Fields.Range(filterdata[8]);
    if (ValidateEmptyData(filterdata[9]))
        myVM.viewModel.Fields.Section(filterdata[9]);
    if (ValidateEmptyData(filterdata[10]))
        myVM.viewModel.Fields.Township(filterdata[10]);
    if (ValidateEmptyData(filterdata[11]))
        myVM.viewModel.Fields.UWI(filterdata[11]);
	myVM.viewModel.Apply()	
}
function UpdateFilterGrid(data)
{
    var param = "UserID='" + USERID + "'";
    GetXSpaceData(param, "GetUserWellFilterList_SP", populateFilterGrid);
}
function populateFilterGrid(data) {
//    var data = [{ "DT_RowId": "1", "FilterName": "Filter 1" }, { "DT_RowId": "2", "FilterName": "Filter 2" } ];
    $("#" + filterGridSettings.GridId).renderGrid(filterGridSettings, data);
}
var vmFilter = function(value, text) {
    this.value =ko.observable(value);
    this.text = ko.observable(text); 
};

var vmSearch = function(WellName, Company,SO,Country,State,County,Field,Block,Range,Section,Township,UWI) {
    this.WellName = ko.observable(WellName);
    this.Company = ko.observable(Company);
    this.SO = ko.observable(SO);
    this.Country = ko.observable(Country);
    this.State = ko.observable(State);
    this.County = ko.observable(County);
    this.Field = ko.observable(Field);
    this.Block = ko.observable(Block);
    this.Range = ko.observable(Range);
    this.Section = ko.observable(Section);
    this.Township = ko.observable(Township);
    this.UWI = ko.observable(UWI);
    this.Clear=function()
    {
        this.WellName(null);
        this.Company(null);
        this.SO(null);
        this.Country(null);
        this.State(null);
        this.County(null);
        this.Field(null);
        this.Block(null);
        this.Range(null);
        this.Section(null);
        this.Township(null);
        this.UWI(null);
    }
};

function UpdateFilterUI()
{

    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", UpdateFilterList);

}



function GetWellSearchDBString()
{
    return SetFilterString(
        myVM.viewModel.Fields.WellName(),
        myVM.viewModel.Fields.Company(),
        myVM.viewModel.Fields.SO(),
        myVM.viewModel.Fields.Country(),
        myVM.viewModel.Fields.State(),
        myVM.viewModel.Fields.County(),
        myVM.viewModel.Fields.Field(),
        myVM.viewModel.Fields.Block(),
        myVM.viewModel.Fields.Range(),
        myVM.viewModel.Fields.Section(),
        myVM.viewModel.Fields.Township(),
        myVM.viewModel.Fields.UWI()


        );
}
function GetWellSearchParamString()
{
    var param = "";
    if (ValidateEmptyData(myVM.viewModel.Fields.WellName()))
    {
        param = param + "WellName=" + "'" + myVM.viewModel.Fields.WellName() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Company())) {
        param = param + "Company=" + "'" + myVM.viewModel.Fields.Company() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.SO())) {
        param = param + "SONumber=" + "'" + myVM.viewModel.Fields.SO() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Country())) {
        param = param + "Country=" + "'" + myVM.viewModel.Fields.Country() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.State())) {
        param = param + "State=" + "'" + myVM.viewModel.Fields.State() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.County())) {
        param = param + "County=" + "'" + myVM.viewModel.Fields.County() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Field())) {
        param = param + "Field=" + "'" + myVM.viewModel.Fields.Field() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Block())) {
        param = param + "Block=" + "'" + myVM.viewModel.Fields.Block() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Range())) {
        param = param + "WellRange=" + "'" + myVM.viewModel.Fields.Range() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Section())) {
        param = param + "Section=" + "'" + myVM.viewModel.Fields.Section() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.Township())) {
        param = param + "Township=" + "'" + myVM.viewModel.Fields.Township() + Sep();
    }
    if (ValidateEmptyData(myVM.viewModel.Fields.UWI())) {
        param = param + "UWI=" + "'" + myVM.viewModel.Fields.UWI() + "'";
    }

    return param;

    //var param = "SendUserGuid=" + "'" + UserGUID + "'%26" + "TypeCode=" + "'INPRL'%26" + "StatusCode=" + "'CMPLT'%26" + "Comment=" + "'" + $("#comments").val() + "'";

}
VMMain=function(Fields)
{
    this.Apply=function() {
        //alert(this.Fields.WellName());
        $("#clearWFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
        GetXSpaceData("UserID='" + USERID + Sep() + GetWellSearchParamString(), wellGridSettings.DataSource, PopulateWellData);
    }
    this.Save=function() {
        $("#divSaveFilter").dialog('open');
    }
    this.Clear=function() {
        //this.Fields(new vmSearch(null, null, null, null, null, null, null, null, null, null, null, null));
        this.Fields.Clear();
        $('#ddlFilter').val("Custom");            
    }
    this.Fields = Fields;
    this.Change = function (data, event) {
        $('#ddlFilter').val("Custom");
        return true;
    }

    UpdateFilterUI();
    $('#ddlFilter').val("");
    
    //this.FilterCollection = ko.observableArray([new vmFilter("Custom", "Custom")]);
    this.SelectedFilter = ko.observable();
    this.SelectedFilter.subscribe(function (newValue) {
        
        $("#tblFilter").css("display", "");
        $("#contract").css("display", "none");

        if (newValue != "Custom") {
            GetXSpaceData("UserWellFilterGuid='" + newValue + "'", "GetUserWellFilterByGuid_SP", UpdateSearchCreteria);
        }
    });
    this.ClearFilter = function () {
        $("#tblFilter").css("display", "none");
        GetXSpaceData("UserID='" +USERID + "'", wellGridSettings.DataSource, PopulateWellData);
    }
    
}
function ClearFilter() {
    GetXSpaceData("UserID='" +USERID + "'", wellGridSettings.DataSource, PopulateWellData);
    $("#clearWFilter").attr("src", "../images/clear_filter_32x32.png");
	var list = document.getElementById('ddlFilter');
	list.selectedIndex=-1;
	$("#tblFilter").css("display", "none");
	myVM.viewModel.Clear();
}

function destroyGrid(){
	
    var oTable = $("#" + wellGridSettings.GridId).dataTable();
    $("#" + wellGridSettings.GridId + "tbody").html("");
    oTable.dataTable().fnDestroy();
	 $("#" + wellGridSettings.GridId).empty();
}
function AddWell() {
    $("#dCreateWellSelCompanyCountry").dialog('open');
}
function loadCompanies() {
    if ($("#ddlCompany").length == 0)
        return;
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        var select = $("#ddlCompany")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CO_ID;
            option.text = data[i].CO_NM;
            select.options.add(option);
        }
    });
}
function loadCoutries() {
    if ($("#ddlCountry").length == 0)
        return;
    GetXSpaceData("", "GetCountryList_SP", function (data) {
        var select = $("#ddlCountry")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CNTRY_ID;
            option.text = data[i].CNTRY_NM;
            select.options.add(option);
        }
        
    });
}

function SetSelectedWell(arrWells){
    $("#dWellDetails").dialog('open');
}