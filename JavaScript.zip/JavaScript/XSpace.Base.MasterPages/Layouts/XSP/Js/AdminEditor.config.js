﻿var AvailableCountriesGridSettings = {
    GridId: "AvailableCountriesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetAdminCountryAvailable_SP",
    ColumnCollection: [
                    {
                        Name: "Available Countries",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};

var SelectedCountriesGridSettings = {
    GridId: "SelectedCountriesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetAdminCountryOperating_SP",
    ColumnCollection: [

                    {
                        Name: "Selected Countries",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};

var AvailablePSLsGridSettings = {
    GridId: "AvailablePSLsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetAdminPslAvailable_SP",
    ColumnCollection: [
                    {
                        Name: "Available PSLs",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var SelectedPSLsGridSettings = {
    GridId: "SelectedPSLsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetAdminPslAssociated_SP",
    ColumnCollection: [

                    {
                        Name: "Selected PSLs",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};

var AvailableFolderGridSettings = {
    GridId: "AvailableFolderGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetFolderType_SP",
    ColumnCollection: [
                    {
                        Name: "Available Folder",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_TYP_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var SelectedFolderGridSettings = {
    GridId: "SelectedFolderGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
	DataSource: "GetAdminFolderAssociated_SP",
    ColumnCollection: [

                    {
                        Name: "Selected Folder",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_TYP_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};