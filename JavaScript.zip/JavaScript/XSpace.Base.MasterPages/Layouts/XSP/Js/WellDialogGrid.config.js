﻿var wellUserControlGridSettings = {
    GridId: "wellUserControlGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: true,
    PagingCount: 20,
    DataSource: "GetWellSearch_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [{
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        renderAction: "GenerateRenderWellName",
                        DataIndex: 1,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    //{
                    //    Name: "New",
                    //    Visible: true,
                    //    Enabled: true,
                    //    DataType: "string",
                    //    Style: "Text", // Text,Image,Action,URL
                    //    CssClass: "cHeader rText",
                    //    HeaderVisible: true,
                    //    data: "FILE_COUNT",
                    //    DataIndex: 2,
                    //    renderAction: "RenderNewFileActions",
                    //    Width: "5%",
                    //    IsFilterable: true,
                    //    IsSortable: true
                    //},
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLD_NM",
                        DataIndex: 4,
                        Width: "5%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Country",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 5,
                        Width: "6%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "State/Province",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL1_NM",
                         DataIndex: 6,
                         Width: "10%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "County",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL2_NM",
                         DataIndex: 7,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "UWI/API",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GOVT_ID_NUM",
                         DataIndex: 8,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "Updated",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 9,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "UCExpand",
            Action: "UCExpandFilter",
            Icon: "magnifying_glass_32x32.png",
            Text: "Expand Well Search",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "UCFilterManager",
            Action: "UCFilterManager",
            Icon: "filter_manager_24x24.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
        Name: "UCclearWFilter",
        Action: "UCClearFilter",
        Icon: "clear_filter_32x32.png",
        Text: "Clear Well Filter",
        Appearance: "Icon", // (Text or Icon)
        Visible: true,
        Enabled: true
    }//,
        //{
        //    Name: "Delete",
        //    Action: "RemoveFile",
        //    Icon: "delete_32x32.png",
        //    Text: "Delete",
        //    Appearance: "Icon", // (Text or Icon)
        //    Visible: true,
        //    Enabled: true
        //}
        ]
    }]
};
var wellUserControlfilterGridSettings = {
    GridId: "wellUserControlfilterGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    ColumnCollection: [{
        Name: "Filter Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "FLTR_NM",
        DataIndex: 0,
        Width: "100%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Rename",
            Action: "UCRename",
            Icon: "edit.png",
            Text: "Rename",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "UCDelete",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};