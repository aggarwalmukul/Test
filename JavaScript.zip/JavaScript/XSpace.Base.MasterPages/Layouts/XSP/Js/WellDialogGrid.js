﻿
var ucVM;

$(document).ready(function () {
    $("#uc_contract").css("display", "none");
    $('#uc_ddlFilter').on('change', function () {

        // when game select changes, filter the character list to the selected game
        $("#uc_tblFilter").css("display", "");
        $("#uc_contract").css("display", "none");

        var list = document.getElementById('uc_ddlFilter');

        // Get the index of selected item, first item 0, second item 1 etc ...
        var INDEX = list.selectedIndex;

        // Viola you're done
        if (list[INDEX].text != "Custom") {
            GetXSpaceData("UserWellFilterGuid='" + list[INDEX].value + "'", "GetUserWellFilterByGuid_SP", UCUpdateSearchCreteria);
        }
    })

    $("#uc_confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                GetXSpaceData("UserWellFilterGuid='" + $("#uc_filterId").val() + "'", "DeleteUserWellFilter_SP", undefined);
                GetXSpaceData(overwriteParam, "UpdateUserWellFilter_SP", UCUpdateFilterUI);
                var table = $("#" + wellUserControlfilterGridSettings.GridId).DataTable();
                var oTable = $("#" + wellUserControlfilterGridSettings.GridId).dataTable();
                $("#" + wellUserControlfilterGridSettings.GridId + "tbody").html("");
                oTable.dataTable().fnDestroy();
                UCUpdateFilterGrid();
                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_confirmOverwrite").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                GetXSpaceData(overwriteParam, "UpdateUserWellFilter_SP", UCUpdateFilterUI);
                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_deleteFilter").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                //write code to delete filter
                var table = $("#" + wellUserControlfilterGridSettings.GridId).DataTable();
                var data = table.row(".selected").data();
                var param = "UserWellFilterGuid='" + data.USR_WELL_FLTR_GUID + "'";
                var oTable = $("#" + wellUserControlfilterGridSettings.GridId).dataTable();
                $("#" + wellUserControlfilterGridSettings.GridId + "tbody").html("");
                oTable.dataTable().fnDestroy();
                GetXSpaceData(param, "DeleteUserWellFilter_SP", UCUpdateFilterUI);
                UCUpdateFilterGrid();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_divSaveFilter").dialog({
        autoOpen: false,
        modal: true,
        title: "Save Filter",
        height: 150,
        width: 300,
        open: function () {
            $("#uc_txtFilter").val("");
        },
        buttons: {

            "Save": function () {
                if ($.trim($("#uc_txtFilter").val()) == "")
                {
                    $("#uc_alert").html("Please enter filter name.").dialog('open');
                }
                else if ($.trim($("#uc_txtFilter").val().toLowerCase()) == "custom") {
                    $("#uc_alert").html("Custom can not be filter name.").dialog('open');
                }
                else {
                    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", UCInsertFilterDB);
                    //save
                    $(this).dialog('close');
                }
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_FilterEdit").dialog({
        autoOpen: false,
        modal: true,
        title: "Filters",
        height: 400,
        width: 600,
        open: function () {
            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, "GetUserWellFilterList_SP", UCpopulateFilterGrid);
            //populateFilterGrid();
        },
        close: function () {
            var oTable = $("#" + wellUserControlfilterGridSettings.GridId).dataTable();
            $("#" + wellUserControlfilterGridSettings.GridId + "tbody").html("");
            oTable.dataTable().fnDestroy();
        },
        buttons: {
            "Close": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_divRename").dialog({
        autoOpen: false,
        modal: true,
        title: "Rename filter",
        height: 150,
        width: 300,       
        buttons: {
            "Save": function () {
                //write code to save             
                if ($.trim($("#uc_filterName").val().toLowerCase()) == "custom") {
                    $("#uc_alert").html("Custom can not be filter name.").dialog('open');
                }
                else if ($.trim($("#uc_filterName").val()) == "")
                {
                    $("#uc_alert").html("Please enter filter name.").dialog('open');
                    return;
                }
                else {
                    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", UCUpdateFilterDB);
                    var table = $("#" + wellUserControlfilterGridSettings.GridId).DataTable();
                    var oTable = $("#" + wellUserControlfilterGridSettings.GridId).dataTable();
                    $("#" + wellUserControlfilterGridSettings.GridId + "tbody").html("");
                    oTable.dataTable().fnDestroy();
                    UCUpdateFilterGrid();
                    $(this).dialog('close');
                }
            },
            "Close": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#uc_collapse").on("click", function () {
        $("#uc_tblFilter").css("display", "none");
        //$("#contract").css("display", "");
    });

    GetUserGuid(GetUserGUIDDetails);
       $("#wellUserControlGridtoolbar").width("500px");

      
    if ($("#UCclearWFilter").length > 0) {
        $("#UCclearWFilter")[0].onclick = null;
    }
    $("#UCclearWFilter").on("click", function () {
        UCClearFilter();
    });
});
function bindFilterManager()
{
    if ($("#UCFilterManager").length > 0) {
        $("#UCFilterManager")[0].onclick = null;
    }
    $("#UCFilterManager").on("click", function () {
        UCFilterManager();
    });
}
function applyWellBindings() {
    ko.cleanNode($('#uc_tblFilter')[0]);
    ucVM = { viewModel: new ucVMMain(new ucvmSearch(null, null, null, null, null, null, null, null, null, null, null, null)) };
    ko.applyBindings(ucVM.viewModel, document.getElementById("uc_tblFilter"));
    $("#uc_tblFilter").css("display", "none");
}
function UCRename() {
    var table = $("#" + wellUserControlfilterGridSettings.GridId).DataTable();
    var data = table.row(".selected").data();
    if (table.row(".selected").length > 0) {
        $("#uc_filterId").val(data.USR_WELL_FLTR_GUID);
        $("#uc_filterName").val(data.FLTR_NM);
        $("#uc_divRename").dialog('open');
    }
    else {
        $("#uc_alert").html("Please select a filter.").dialog('open');
        return;
    }
}
function UCDelete() {
    var table = $("#" + wellUserControlfilterGridSettings.GridId).DataTable();
    if (table.row(".selected").length > 0) {
        $("#uc_deleteFilter").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#uc_alert").html("Please select a filter.").dialog('open');
        return;
    }
}
function renderMultipleActions(data, type, full, meta) {
    if (data.split('.').pop() != "las")
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + data + "</td><td width='20%'><img class='zipinfo' src='../images/file_info_16x16.png' height='16' width='16' style='cursor:pointer;' onclick='openZipDialog(this);'/></td></tr></table>";
    else
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + data + "</td><td></td></tr></table>";
}

function UCPopulateWellData(data) {
    $("#" + wellUserControlGridSettings.GridId).renderGrid(wellUserControlGridSettings, data);
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
}


function UCFilterManager(gridId) {
    $("#uc_FilterEdit").dialog('open');
}
function UCExpandFilter(gridId) {

    $("#uc_tblFilter").css("display", "");
    $(document).on("keypress", "#uc_tblFilter input:text", function (e) {
        if (e.keyCode == 13) {

            ucVM.viewModel.Apply();
            return false;
        }
    });
}
var overwriteParam;
function UCInsertFilterDB(data) {
    var param = "UserID='" + USERID + Sep() + "TypeCode='" + "Well" + Sep() +
        "Name='" + $("#uc_txtFilter").val() + Sep() + "FilterString='" + UCGetWellSearchDBString() + "'";
    var Updated = false;

    var filterstring = "";
    for (var i = 0 ; i < data.length; i++) {
        if ($("#uc_txtFilter").val() == data[i].FLTR_NM) {
            Updated = true;
            overwriteParam="UserWellFilterGuid='" + data[i].USR_WELL_FLTR_GUID + Sep() + "Name='" + $("#uc_txtFilter").val() + Sep() + "FilterString='" +
                UCGetWellSearchDBString() + "'";
            $("#uc_confirmOverwrite").html("Filter name already exists. Do you want to overwrite?").dialog('open');
           
            break;

        }
    }
    if (Updated == false) {
        GetXSpaceData(param, "InsertUserWellFilter_SP", UCUpdateFilterUI);
    }

}
function UCUpdateFilterDB(data) {
    var Updated = false;
    var filtername = $("#uc_filterName").val();
    var filterstring = "";
    for (var i = 0 ; i < data.length; i++) {
        if ($("#uc_filterId").val() == data[i].USR_WELL_FLTR_GUID) {
            filterstring = data[i].FLTR_STR;
            break;
        }
    }
    for (var i = 0 ; i < data.length; i++) {      
        if (filtername == data[i].FLTR_NM && $("#uc_filterId").val() != data[i].USR_WELL_FLTR_GUID) {
            Updated = true;
            $("#uc_confirm").html("Filter name already exists.Do you want to overwrite?").dialog('open');
            overwriteParam="UserWellFilterGuid='" + data[i].USR_WELL_FLTR_GUID + Sep() + "Name='" + filtername + Sep() + "FilterString='" +
                data[i].FLTR_STR + "'";
            break;
        }
    }
    if (Updated == false) {
        GetXSpaceData("UserWellFilterGuid='" + $("#uc_filterId").val() + Sep() + "Name='" + filtername + Sep() + "FilterString='" +
            filterstring + "'", "UpdateUserWellFilter_SP", UCUpdateFilterUI);

    }

}

function UCUpdateFilterList(data) {

    var UCUpdateFilterDisplay = false;
    var list = document.getElementById("uc_ddlFilter");
    var INDEX = list.selectedIndex;
    var guid = "";
    if (list.selectedIndex >= 0) {

        guid = list[list.selectedIndex].value;
    }
    ucremoveOptions(document.getElementById("uc_ddlFilter"));
    var select = document.getElementById('uc_ddlFilter');
    for (var i = 0; i < data.length; i++) {
        var opt = document.createElement('option');
        opt.value = data[i].USR_WELL_FLTR_GUID;
        if (guid == opt.value) {
            UCUpdateFilterDisplay = true;
        }
        opt.text = data[i].FLTR_NM;
        select.appendChild(opt);

    }
    var opt = document.createElement('option');
    opt.value = "Custom";
    opt.text = "Custom";
    select.appendChild(opt);
    if (UCUpdateFilterDisplay == true) {
        $('#uc_ddlFilter').val(guid).change();
    }
    else if (guid == "Custom") {
        $('#uc_ddlFilter').val("Custom");
    }
    else if (ucVM != null) {
        ucVM.viewModel.Fields.Clear();
    }
    if (INDEX == -1)
        select.selectedIndex = -1;
}

function ucremoveOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1; i >= 0; i--) {
        selectbox.remove(i);
    }
}
function UCUpdateSearchCreteria(data) {
    var filterdata = GetFilterString(data[0].FLTR_STR);

    ucVM.viewModel.Fields.Clear();
    if (ValidateEmptyData(filterdata[0]))
        ucVM.viewModel.Fields.ucWellName(filterdata[0]);
    if (ValidateEmptyData(filterdata[1]))
        ucVM.viewModel.Fields.ucCompany(filterdata[1]);
    if (ValidateEmptyData(filterdata[2]))
        ucVM.viewModel.Fields.ucSO(filterdata[2]);
    if (ValidateEmptyData(filterdata[3]))
        ucVM.viewModel.Fields.ucCountry(filterdata[3]);
    if (ValidateEmptyData(filterdata[4]))
        ucVM.viewModel.Fields.ucState(filterdata[4]);
    if (ValidateEmptyData(filterdata[5]))
        ucVM.viewModel.Fields.ucCounty(filterdata[5]);
    if (ValidateEmptyData(filterdata[6]))
        ucVM.viewModel.Fields.ucField(filterdata[6]);
    if (ValidateEmptyData(filterdata[7]))
        ucVM.viewModel.Fields.ucBlock(filterdata[7]);
    if (ValidateEmptyData(filterdata[8]))
        ucVM.viewModel.Fields.ucRange(filterdata[8]);
    if (ValidateEmptyData(filterdata[9]))
        ucVM.viewModel.Fields.ucSection(filterdata[9]);
    if (ValidateEmptyData(filterdata[10]))
        ucVM.viewModel.Fields.ucTownship(filterdata[10]);
    if (ValidateEmptyData(filterdata[11]))
        ucVM.viewModel.Fields.ucUWI(filterdata[11]);
    ucVM.viewModel.Apply()
}
function UCUpdateFilterGrid(data) {
    var param = "UserID='" + USERID + "'";
    GetXSpaceData(param, "GetUserWellFilterList_SP", UCpopulateFilterGrid);
}
function UCpopulateFilterGrid(data) {   
    $("#" + wellUserControlfilterGridSettings.GridId).renderGrid(wellUserControlfilterGridSettings, data);
}
var vmFilter = function (value, text) {
    this.value = ko.observable(value);
    this.text = ko.observable(text);
};

var ucvmSearch = function (ucWellName, ucCompany, ucSO, ucCountry, ucState, ucCounty, ucField, ucBlock, ucRange, ucSection, ucTownship, ucUWI) {
    this.ucWellName = ko.observable(ucWellName);
    this.ucCompany = ko.observable(ucCompany);
    this.ucSO = ko.observable(ucSO);
    this.ucCountry = ko.observable(ucCountry);
    this.ucState = ko.observable(ucState);
    this.ucCounty = ko.observable(ucCounty);
    this.ucField = ko.observable(ucField);
    this.ucBlock = ko.observable(ucBlock);
    this.ucRange = ko.observable(ucRange);
    this.ucSection = ko.observable(ucSection);
    this.ucTownship = ko.observable(ucTownship);
    this.ucUWI = ko.observable(ucUWI);
    this.Clear = function () {
        this.ucWellName(null);
        if (typeof ($("#uc_txtCompany").attr("disabled")) == "undefined") {
            this.ucCompany(null);
        }
        this.ucSO(null);
        this.ucCountry(null);
        this.ucState(null);
        this.ucCounty(null);
        this.ucField(null);
        this.ucBlock(null);
        this.ucRange(null);
        this.ucSection(null);
        this.ucTownship(null);
        this.ucUWI(null);
    }
};

function UCUpdateFilterUI() {

    GetXSpaceData("UserID='" + USERID + "'", "GetUserWellFilterList_SP", UCUpdateFilterList);

}

function UCGetWellSearchDBString() {
    return SetFilterString(
        ucVM.viewModel.Fields.ucWellName(),
        ucVM.viewModel.Fields.ucCompany(),
        ucVM.viewModel.Fields.ucSO(),
        ucVM.viewModel.Fields.ucCountry(),
        ucVM.viewModel.Fields.ucState(),
        ucVM.viewModel.Fields.ucCounty(),
        ucVM.viewModel.Fields.ucField(),
        ucVM.viewModel.Fields.ucBlock(),
        ucVM.viewModel.Fields.ucRange(),
        ucVM.viewModel.Fields.ucSection(),
        ucVM.viewModel.Fields.ucTownship(),
        ucVM.viewModel.Fields.ucUWI()


        );
}

function UCGetWellSearchParamString() {
    var param = "";
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucWellName())) {
        param = param + "WellName=" + "'" + ucVM.viewModel.Fields.ucWellName() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucCompany())) {
        if (param != "")
            param = param + Sep();
        param = param + "Company=" + "'" + ucVM.viewModel.Fields.ucCompany() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucSO())) {
        if (param != "")
            param = param + Sep();
        param = param + "SONumber=" + "'" + ucVM.viewModel.Fields.ucSO() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucCountry())) {
        if (param != "")
            param = param + Sep();
        param = param + "Country=" + "'" + ucVM.viewModel.Fields.ucCountry() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucState())) {
        if (param != "")
            param = param + Sep();
        param = param + "State=" + "'" + ucVM.viewModel.Fields.ucState() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucCounty())) {
        if (param != "")
            param = param + Sep();
        param = param + "County=" + "'" + ucVM.viewModel.Fields.ucCounty() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucField())) {
        if (param != "")
            param = param + Sep();
        param = param + "Field=" + "'" + ucVM.viewModel.Fields.ucField() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucBlock())) {
        if (param != "")
            param = param + Sep();
        param = param + "Block=" + "'" + ucVM.viewModel.Fields.ucBlock() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucRange())) {
        if (param != "")
            param = param + Sep();
        param = param + "WellRange=" + "'" + ucVM.viewModel.Fields.ucRange() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucSection())) {
        if (param != "")
            param = param + Sep();
        param = param + "Section=" + "'" + ucVM.viewModel.Fields.ucSection() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucTownship())) {
        if (param != "")
            param = param + Sep();
        param = param + "Township=" + "'" + ucVM.viewModel.Fields.ucTownship() ;
    }
    if (ValidateEmptyData(ucVM.viewModel.Fields.ucUWI())) {
        if (param != "")
            param = param + Sep();
        param = param + "UWI=" + "'" + ucVM.viewModel.Fields.ucUWI() ;
    }
    if (param != "")
        param = param + Sep();
    param = param + "UserID='" + USERID
  
    if (param != "")
        param = param + "'";

    return param;

    //var param = "SendUserGuid=" + "'" + UserGUID + "'%26" + "TypeCode=" + "'INPRL'%26" + "StatusCode=" + "'CMPLT'%26" + "Comment=" + "'" + $("#comments").val() + "'";

}
ucVMMain = function (Fields) {
    this.Apply = function () {       
        $("#UCclearWFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
        var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
        $("#" + wellUserControlGridSettings.GridId + "tbody").html("");
        oTable.dataTable().fnDestroy();
        GetXSpaceData(UCGetWellSearchParamString(), wellUserControlGridSettings.DataSource, UCPopulateWellData);
       if($("#dialog-createWell").hasClass('ui-dialog-content')){
            ApplyScrollValidation();
        }
    }
    this.Save = function () {
        $("#uc_divSaveFilter").dialog('open');
    }
    this.Clear = function () {       
        this.Fields.Clear();
        $('#ddlFilter').val("Custom");        
    }
    this.Fields = Fields;
    this.Change = function (data, event) {
        $('#uc_ddlFilter').val("Custom");
        return true;
    }

    UCUpdateFilterUI();
    $('#uc_ddlFilter').val("");
    this.SelectedFilter = ko.observable();
    this.SelectedFilter.subscribe(function (newValue) {

        $("#uc_tblFilter").css("display", "");
        $("#uc_contract").css("display", "none");

        if (newValue != "Custom") {
            GetXSpaceData("UserWellFilterGuid='" + newValue + "'", "GetUserWellFilterByGuid_SP", UCUpdateSearchCreteria);
        }
    });
    this.ClearFilter = function () {       
        $("#uc_tblFilter").css("display", "none");          
        var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
        $("#" + wellUserControlGridSettings.GridId + "tbody").html("");
        oTable.dataTable().fnDestroy();
        var param = "UserID='" + USERID + "'";
        GetXSpaceData(param, wellUserControlGridSettings.DataSource, UCPopulateWellData);
    }

}
function UCClearFilter() {
    $("#uc_tblFilter").css("display", "none");
    // $("#contract").css("display", "");        
    var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
    $("#" + wellUserControlGridSettings.GridId + "tbody").html("");
    oTable.dataTable().fnDestroy();
    //var param = "UserID='" + USERID + "'";
    //GetXSpaceData(param, wellUserControlGridSettings.DataSource, UCPopulateWellData);
    ucVM.viewModel.Clear();
    GetXSpaceData(UCGetWellSearchParamString(), wellUserControlGridSettings.DataSource, UCPopulateWellData);
    $("#UCclearWFilter").attr("src", "../images/clear_filter_32x32.png");
    var list = document.getElementById('uc_ddlFilter');
    list.selectedIndex = -1;    
}





function OpenWellDialog(callback) {

    $("#dialog-well").dialog({
        autoOpen: false,
        height: 550,
        width: 1100,
        modal: true,
        resizable: false,
        draggable: false,
        close: function (event, ui) {
            var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
            $("#" + wellUserControlGridSettings.GridId + "tbody").html("");
            oTable.dataTable().fnDestroy();
            $("#wellDialogtabs").tabs("destroy");
        },
        open: function (event, ui) {
            $("#wellDialogtabs").tabs({ active: 0 });
            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, wellUserControlGridSettings.DataSource, UCPopulateWellData);
            applyWellBindings();
            bindFilterManager();
        },
        buttons: {
            "OK": function () {
                var oTableSource = $("#" + wellUserControlGridSettings.GridId).DataTable();
                var oData = oTableSource.rows('.selected').data();
                if (oData.length == 0) {
                    ShowCustomAlert("No item selected.");
                    return;
                }

                $(this).dialog("close");
                callback(oData);
            },
            "Cancel": function () {
                $(this).dialog("close");
            }
        }
    });

    $("#dialog-well").dialog("open");

}


function OpenCreateWellDialog(callbackfunction) {

    $("#dialog-createWell").dialog({
        autoOpen: false,
        height: 550,
        width: 1100,
        modal: true,
        resizable: false,
        draggable: false,      
        open: function (event, ui) {
            DestroyWellDataTable();
            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, wellUserControlGridSettings.DataSource, UCPopulateWellData);
            $("#dialog-createWell").off("scroll.sc");
            FilterWellsData();
            bindFilterManager();
        },      
        beforeClose: function(event, ui) {
            $("body").css({ overflow: 'inherit' })
        },
        buttons: {           
            "Cancel": function () {
                $(this).dialog("close");
            }
        },
        create: function () {          
            $("body").css({ overflow: 'hidden' })
        }
    });

    $("#dialog-createWell").dialog("open");

}


function DestroyWellDataTable() {
    if ($.fn.dataTable.isDataTable("#" + wellUserControlGridSettings.GridId)) {
        var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
        $("#" + wellUserControlGridSettings.GridId + "tbody").html("");
        oTable.dataTable().fnDestroy();
    }
}

function FilterWellsData() {   
    applyWellBindings();
    ucVM.viewModel.Fields.ucCompany($("#ddlCompany option:selected").text());
    ucVM.viewModel.Fields.ucCountry($("#ddlCountry option:selected").text());
    ucVM.viewModel.Apply();   
}
function FilterWellsByCompany(cmpyName) {
    applyWellBindings();
    ucVM.viewModel.Fields.ucCompany(cmpyName);   
    ucVM.viewModel.Apply();
    $("#uc_txtCompany").attr("disabled", "disabled");
    $("#uc_txtCompany").attr("title", cmpyName)
}
function RetrieveSelectedWell(arrWells) {

    var oTableSource = $("#" + wellUserControlGridSettings.GridId).DataTable();
    var oData = oTableSource.rows('.selected').data();
    if (oData.length == 0) {
        ShowCustomAlert("Please select a Well first.");
        return;
    }

    $("#dialog-createWell").dialog("close");
    $("#dWellDetails").dialog('open');
}

function ValidateButtonState() {
    if ($("#" + wellUserControlGridSettings.GridId).DataTable().rows().data().length >= 0 && !isScrollVisible()) {
        $("#NewWell").removeAttr("disabled");
        $("#NewWell").attr("title", "Click to create a new Well");
        $("#NewWell").css('opacity', '1');
        $("#scrollMsg").hide();
    }
    else {
        $("#NewWell").css('opacity', '.5');
        $("#NewWell").attr("disabled", "disabled");
        $("#NewWell").attr("title", "User must scroll to the bottom of the well list to enable.");
        $("#scrollMsg").show();
    }

    $("#CopyWell").css('opacity', '.5');
    $("#CopyWell").attr("title", "User must scroll to the bottom of the well list to enable.");
    $("#CopyWell").attr("disabled", "disabled");
    var wellCount = $("#" + wellUserControlGridSettings.GridId).DataTable().rows().data().length;
    if (wellCount > 0 && !isScrollVisible()) {
        $("#CopyWell").css('opacity', '1');
        $("#CopyWell").attr("title", "Click to Copy a Well");
        $("#CopyWell").removeAttr("disabled");
        $("#scrollMsg").hide();
    }
}

function ApplyScrollValidation() {
    ValidateButtonState();

    $(document).ready(function () {
        //document.getElementById("dialog-createWell").addEventListener("scroll", checkScrollHeight, false);
        $('#uc_ddlFilter').val("Custom");

        if ($("#NewWell").length > 0)
            $("#NewWell")[0].onclick = null;
        if ($("#CopyWell").length > 0)
            $("#CopyWell")[0].onclick = null;  
        $("#NewWell").on("click", function () {
            if (typeof ($("#NewWell").attr("disabled")) == "undefined") {
                $("#dialog-createWell").dialog("close");
                $("#dWellDetails").dialog('open');
            }
        });
        $("#CopyWell").on("click", function () {
            if (typeof ($("#CopyWell").attr("disabled")) == "undefined") {               
                RetrieveSelectedWell();                
            }         
        });

        //// scroll validation 
        $("#dialog-createWell").on("scroll.sc", function () {         
            if ($(this).scrollTop() + $(this).innerHeight() + 2 >= $(this)[0].scrollHeight) {
                $("#NewWell").css('opacity', '1');
                $("#NewWell").attr("title", "Click to create a new Well");
                $("#NewWell").removeAttr("disabled");

                $("#CopyWell").removeAttr("disabled");
                $("#CopyWell").css('opacity', '1');
                $("#CopyWell").attr("title", "Click to Copy a Well");
                $("#scrollMsg").hide();
            }
        });
       
    });

}

function isScrollVisible()
{
    return $("#dialog-createWell")[0].scrollHeight > $("#dialog-createWell").innerHeight();
}



