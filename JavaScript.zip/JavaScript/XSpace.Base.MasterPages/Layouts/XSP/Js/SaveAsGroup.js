﻿$(document).ready(function () {
    $("#dAlertSaveAsGroup").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 130,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    var groups = [];
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        groups = data;
    });
    $("#dialog-saveasgroup").dialog({
        autoOpen: false,
        height: 200,
        width: 450,
        modal: true,
        resizable: false,
        draggable: false,
        close: function (event, ui) {

        },
        open: function (event, ui) {
            // write code to populate affiliated company select.#dSelectAffiliatedCompany  
            $(document).on("blur", "#dtxtGroupName", function () {
                removeSpecialChar($(this));
            });
			$("#dtxtGroupName").val("");
			var isSaveAs = $('#dialog-saveasgroup').data('param');
			var selectedIndex=-1;	 			
			if (groups.length > 0) {
			    $("#dSelectAffiliatedCompany").find('option').remove();
                var select = document.getElementById("dSelectAffiliatedCompany");
                for (var i = 0; i < groups.length; i++) {
                    var option = document.createElement('option');
                    option.text = groups[i].CO_NM;
                    option.value = groups[i].CO_ID;
                    if (isSaveAs == "saveAsGroup" && $.trim(groups[i].CO_NM) == $.trim($("#txtAffiliatedCompanyName").val()))
						option.selected =true;
					 select.add(option);
				
                }	
				if(isSaveAs=="saveAsGroup"){
					$("#dtxtGroupName").val(window.parent.dbGroupName);
					selectedIndex=$("#dSelectAffiliatedCompany option:selected").index();						
					 $("#dSelectAffiliatedCompany").attr("disabled", "disabled");
				}		
				select.selectedIndex =selectedIndex;					
							
            }
        },
        buttons: {
            "OK": function () {
                var groupName = $.trim($("#dtxtGroupName").val());
                var affiliatedCompany = $.trim($("#dSelectAffiliatedCompany").val());
				var isSaveAs = $('#dialog-saveasgroup').data('param');
                if (groupName == "") {
                    $("#dAlertSaveAsGroup").html("Please enter group name.").dialog('open');
                    return false;
                }
                if (affiliatedCompany == "") {
                    $("#dAlertSaveAsGroup").html("Please select affiliated company.").dialog('open');
                    return false;
                }
				isGroupNameAlreadyExist(groupName,undefined,function(data){
					if(data)
					{
						$("#dAlertSaveAsGroup").html("Group name already exist please choose another name.").dialog('open');
						return false;
					}
					
					var param = "Name='" + groupName + Sep() + "CompanyID='" + affiliatedCompany + Sep() + "UserID='" + USERID + Sep();
					var data = GetXSpaceData(param, "InsertUserGroup_SP", UpdateExternalReciepent);
					function UpdateExternalReciepent(data) {
						//write code to save data 
						var groupId = data[0].USR_GRP_GUID;// groupid is the id of saved group name and affiliated company                   
						$(document).trigger("saveAsEvent", [groupId, groupName, affiliatedCompany, isSaveAs]);
						//$(this).dialog("close");
					}
					
				} );
              
            },
            "Cancel": function () {
                $(this).dialog("close");
            }
        }
    });

});

function qs(key) {
    return GetUrlParameter(key);    
}
