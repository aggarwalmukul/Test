﻿var recipientsGridSettings = {
    GridId: "UserToUserTransferGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "120px",
    Paging: false,
    ColumnCollection: [{
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 0,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "Company",
                         Visible: true,
                         Enabled: true,
                         DataType: "string",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CO_NM",
                         DataIndex: 1,
                         Width: "30%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        DataIndex: 2,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Phone",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "PHONE_NUM",
                        renderAction: "formatPhoneNumber",
                        DataIndex: 3,
                        Width: "18%",
                        IsFilterable: false,
                        IsSortable: false
                    }
],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        Title: "Recipients",
        ButtonCollection: [{
            Name: "Add",
            Action: "AddRecipients",
            Icon: "create_32x32.png",
            Text: "Add recipients registered users",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveRecipients",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
    ]
    }]
};

var UserToUserTransferFilesGridSettings = {
    GridId: "UserToUserTransferFilesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "100px",
    Paging: false,
    ColumnCollection: [                           
                    {
                        Name: "File Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FileName",
                        DataIndex: 0,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Size (MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "Size",
                        DataIndex: 1,
                        renderAction: "RoundOffSize",
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                    Name: "Progress",
                    Visible: true,
                    Enabled: true,
                    DataType: "string",
                    Style: "Text", // Text,Image,Action,URL
                    CssClass: "cHeader rText",
                    HeaderVisible: true,
                    data: "Percent",
                    DataIndex: 1,
                    //renderAction: "RoundOffSize",
                    Width: "15%",
                    IsFilterable: true,
                    IsSortable: true
                }
],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter2",
        Visible: true,
        Enabled: true,
        Title: "Files",
        ButtonCollection: [{
            Name: "Add",
            Action: "AddFiles",
            Icon: "create_32x32.png",
            Text: "Add Files",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveFile",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
    ]
    }]
};


