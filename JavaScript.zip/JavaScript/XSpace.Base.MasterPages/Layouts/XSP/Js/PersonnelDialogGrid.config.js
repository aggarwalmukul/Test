﻿var personnelsGridSettings = {
    GridId: "PersonnelsGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single   
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    DataSource: "GetRecentDistributionRecpnt_SP",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 1,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "Company",
                         Visible: true,
                         Enabled: true,
                         DataType: "string",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CO_NM",
                         DataIndex: 2,
                         Width: "29%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "URL", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        DataIndex: 3,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Phone",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "PHONE_NUM",
                        renderAction: "formatPhoneNumber",
                        DataIndex: 4,
                        Width: "20%",
                        IsFilterable: false,
                        IsSortable: false
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },

    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearRecentFilter",
            Action: "clearRecentFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};


var allPersonnelsGridSettings = {
    GridId: "AllPersonnelsGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single   
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    DataSource: "GetUsers_SP",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 1,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                         {
                             Name: "Company",
                             Visible: true,
                             Enabled: true,
                             DataType: "string",
                             Style: "Text", // Text,Image,Action,URL
                             CssClass: "cHeader lText",
                             HeaderVisible: true,
                             data: "CO_NM",
                             DataIndex: 2,
                             Width: "29%",
                             IsFilterable: true,
                             IsSortable: true
                         },
                        {
                            Name: "Email Address ",
                            Visible: true,
                            Enabled: true,
                            DataType: "string",
                            Style: "URL", // Text,Image,Action,URL
                            CssClass: "cHeader lText",
                            HeaderVisible: true,
                            data: "EMAIL_ADDR_DESC",
                            DataIndex: 3,
                            Width: "20%",
                            IsFilterable: true,
                            IsSortable: true
                        },
                        {
                            Name: "Phone",
                            Visible: true,
                            Enabled: true,
                            DataType: "string",
                            Style: "Text", // Text,Image,Action,URL
                            CssClass: "cHeader rText",
                            HeaderVisible: true,
                            data: "PHONE_NUM",
                            renderAction: "formatPhoneNumber",
                            DataIndex: 4,
                            Width: "20%",
                            IsFilterable: false,
                            IsSortable: false
                        }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },

    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearAllFilter",
            Action: "clearAllFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};
