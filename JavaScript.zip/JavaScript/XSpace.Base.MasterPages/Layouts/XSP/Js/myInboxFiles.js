﻿var fileGuid = "";

$(document).ready(function () {
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                var table = $("#" + inboxGridSettings.GridId).DataTable();              
               
                var data = table.rows(".selected").data();
                if (data.length > 0) {
                    for (var i = 0 ; i < data.length; i++) {
                        var param = "DistributeRecGuid='" + data[i].DSTBN_RCPT_GUID + Sep() + "UserID='" + document.getElementById('userID').value + "'";
                        GetXSpaceData(param, "DeleteDistributeRecipient_SP", undefined);                           
                    }
                    table.row('.selected').remove().draw(false);
                }
                $(this).dialog('close');
                
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#fileInfo").dialog({
        autoOpen: false,
        modal: true,
        title: "File Info",
        height: 320,
        width: 500,
        open: function () {
            var o = { Guid: fileGuid };         
            var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetFileList";

            $.ajax({
                url: urlstring,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(o),             
                contentType: "application/json; charset=utf-8",
                error: function (errorThrown) {
                },
                success: function (dataFile) {
                    var temp = JSON.parse(dataFile.d);
                    $("#" + fileListGridSettings.GridId).renderGrid(fileListGridSettings, JSON.parse(dataFile.d));
                },
            });
        },
        close: function () {
            var oTable = $("#" + fileListGridSettings.GridId).dataTable();
            $("#" + fileListGridSettings.GridId + "tbody").html("");
            oTable.dataTable().fnDestroy();
        },
        buttons: {
            "Download": function () {
                DownloadZipSelectedFiles();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
   
    $("#tabsActionButtons").tabs();      
    var param = "UserID='";
    if(qs("UserID")!=undefined && qs("UserID")!=null && qs("UserID")!=""){
        param += qs("UserID");
        DisplayUserDetail(qs("UserID"))
        }
    else
        param +=  document.getElementById('userID').value;
    param+= "'";
    
    GetXSpaceData(param, inboxGridSettings.DataSource, PopulateInboxFiles);
    GetUserGuid(GetUserGUIDDetails);

});

function DownloadFiles() {
    var table = $("#" + inboxGridSettings.GridId).DataTable();
    if (table.row('.selected').length > 0) {
        DownloadSelectedFiles();
    }
    else {
        $("#alert").html("Please select file(s) to download.").dialog("open");
    }
}

function renderMultipleActions(data, type, full, meta) {
    var FileName = full.DATA_FILE_GUID;
    var folder = "";

    if (data.split('.').pop() != "las")
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + GetFileDownloadlink(full.DATA_FILE_GUID, data) + "</td><td width='20%'><img class='zipinfo' src='../images/file_info_16x16.png' height='16' width='16' style='cursor:pointer;' onclick='openZipDialog(\"" + FileName + "\"" + ',' + "\"" + folder + "\", \"" + full.FILE_PATH + "\");'/></td></tr></table>";
    else
        return "<table width='100%'><tr style='background-color:transparent;'><td width='80%'>" + GetFileDownloadlink(full.DATA_FILE_GUID, data) + "</td><td></td></tr></table>";
}

function openZipDialog(fileName, folder,full) {
    fileGuid = fileName;
    selectedFilePath = full;
   
    $("#fileInfo").dialog("open");
}
function RemoveFile() {
    var table = $("#" + inboxGridSettings.GridId).DataTable();
    if (table.row('.selected').length > 0) {
        $("#confirm").html("Are you sure to delete selected file(s)?").dialog("open");
    }
    else {
        $("#alert").html("Please select file(s) to delete.").dialog("open");
    }
}
function DistributeFile() {
    var data = $("#" + inboxGridSettings.GridId).DataTable().rows(".selected").data();
    if (data.length == 0) {
        $("#alert").html("Please select file to distribute.").dialog("open");
    }
    else {
        DistributeData(data);       
    }
}


function DownloadSelectedFiles() {
    var jasondata = null;
    var guids = "";// = "Guid1,Guid2,Guid3";
    var fileid = [];
    var folderid = "";
    var fileName = "";
    var FileNames = "";
    var data = $("#" + inboxGridSettings.GridId).DataTable().rows(".selected").data();

    for (var i = 0; i < data.length; i++) {
        FileNames = FileNames + data[i].FILE_PATH + "\\" + data[i].DATA_FILE_LNM + ",";       
        fileid.push(data[i].DATA_FILE_GUID);
    }

    FileNames = FileNames.substring(0, FileNames.lastIndexOf(","));
    
    DownloadAndLogAuditDropBox(fileid, FileNames);
    return false;
}
var selectedFilePath;

function DownloadZipSelectedFiles() {
    var table = $("#" + fileListGridSettings.GridId).DataTable();
    if (table.row('.selected').length > 0) {
        DownloadZipfiles();
    }
    else {
        $("#alert").html("Please select file(s) to download.").dialog("open");
    }
}

function DownloadZipfiles() {   
   
    var fileid;
    var FileNames = "";
    var data = $("#" + fileListGridSettings.GridId).DataTable().rows(".selected").data();
    for (var i = 0; i < data.length; i++) {
        FileNames = FileNames + data[i].FileName + ",";
        fileid = data[i].FileGuid;
    }

    FileNames = FileNames.substring(0, FileNames.lastIndexOf(","));
    DownloadFile(fileid, false, FileNames);   
    return false;
}

function PopulateInboxFiles(data){
    $("#" + inboxGridSettings.GridId).renderGrid(inboxGridSettings, data);
}

function reloadMyFiles() {
   window.location.reload();
}

function DisplayUserDetail(uid){
    var param="UserID='"+uid + Sep();
    GetXSpaceData(param, "GetUserDetailByUserID_SP", function(data){
        var formatedText=data[0].USR_NM +" , "+data[0].CO_NM;
        $("#idUserDetails").css("display","block");
        $("#userLabel")[0].innerHTML=formatedText;
        
    });
}