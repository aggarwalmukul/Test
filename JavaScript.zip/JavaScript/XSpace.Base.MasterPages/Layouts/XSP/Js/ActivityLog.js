﻿$(document).ready(function () {
    GetUserGuid(function (data) {
        var GetUserGUID = data;
        var userRole = GetUserGUID[0].ROLE_CD;
        if (userRole == USERROLE_TYPE.CustomerUser || userRole == USERROLE_TYPE.CustomerAdministrator || userRole == USERROLE_TYPE.InternalUser) {
            window.location.href = "/_layouts/15/XSP/Pages/Home.aspx";
        }
        else {
            $(document).on("keyup", "input", function () {
                $("#clearFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
            });
            $("#folderList").dialog({
                autoOpen: false,
                modal: true,
                title: "Folders",
                height: 240,
                width: 350,
                open: function () { bindFoldersList(selectedRow.DATA_UPL_GUID); },
                buttons: {
                    "OK": function () {
                        $(this).dialog('close');
                    }
                }
            });
            $("#fileList").dialog({
                autoOpen: false,
                modal: true,
                title: "Files",
                height: 240,
                width: 450,
                open: function () { bindFilesList(selectedRow.DATA_UPL_GUID); },
                buttons: {
                    "OK": function () {
                        $(this).dialog('close');
                    }
                }
            });
            loadActivityLog();
            if ($("#clearFilter").length > 0)
                $("#clearFilter")[0].onclick = null;
            $(document).on("click", "#clearFilter", function () {
                clearFilter();
            });
            window.setInterval(function () {
                clearFilter();
            }, (1000 * 60 * 5));
        }
    });

	$(window).keypress(function (e) {
	    if (e.keyCode == 13) {
	        searchFilter();
	        return false;
	    }
	});
});
    var selectedRow;
    function linkFolders(data, type, full, meta) {
        return "<a class='edithref' href='#' onclick='openFolders(event)'>" + full.FLDR_CNT + "</a>";
    }
function linkFiles(data, type, full, meta) {
    return "<a class='edithref' href='#' onclick='openFiles(event)'>" + full.FILE_CNT + "</a>";
}
function openFolders(event) {
    event = event || window.event;

    if (typeof (event.target) == "undefined")
        selectedRow = $("#" + ActivityLogGridSettings.GridId).DataTable().row($(event.srcElement).closest("tr")).data();
    else
        selectedRow = $("#" + ActivityLogGridSettings.GridId).DataTable().row($(event.target).closest("tr")).data();
    $("#folderList").dialog('open');
}
function openFiles(event) {
    event = event || window.event;
    if (typeof (event.target) == "undefined")
        selectedRow = $("#" + ActivityLogGridSettings.GridId).DataTable().row($(event.srcElement).closest("tr")).data();
    else
        selectedRow = $("#" + ActivityLogGridSettings.GridId).DataTable().row($(event.target).closest("tr")).data();
    $("#fileList").dialog('open');
}
function loadActivityLog() {
    GetXSpaceData("", ActivityLogGridSettings.DataSource, function (data)
    {
        $("#" + ActivityLogGridSettings.GridId).renderGrid(ActivityLogGridSettings, data);
    });
}
function clearFilter() {
    $("input").val("");
    var oTable = $("#" + ActivityLogGridSettings.GridId).dataTable();
    $("#" + ActivityLogGridSettings.GridId + "tbody").html("");
    oTable.dataTable().fnDestroy();

    loadActivityLog();
    $("#clearFilter").attr("src", "../images/clear_filter_32x32.png");
}
function editCompany(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?CompanyID=" + full.CO_ID + "\">" + full.CO_NM + "</a>";
}
function editUser(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/Settings.aspx?type=activity&UserID=" + full.USR_AD_NM + "'>" + full.UPLOADED_BY + "</a>";
}
function renderActivityComment(data, type, full, meta) {
    var gid = meta.settings.sTableId;
    gridSettings = globalGridSettings[gid];

    return "<div class='ellipsis' style='width: 50px; padding-left:5px;' title=' " + data + "'>" + data + "</div><img src='../images/comment_32x32.png' style='cursor:pointer; float:right;width:16px;height:16px;' onclick='openActivityCommentDialog(event, this,\"" + gridSettings.GridId + "\");'/>";
}
function openActivityCommentDialog(event, me, sourceGridID) {
    var sourcetr;
    event = event || window.event;

    if (typeof (event.target) == "undefined") {
        sourcetr = $(event.srcElement).closest("tr");
    }
    else {
        sourcetr = $(event.target).closest("tr");
    }

    var data = $("#" + sourceGridID).DataTable().row(sourcetr).data();
    //alert("to do: show comment in dialog" + data);
    if (data.DATA_FILE_CMNT != "") {
        $("#txtarea_comments").val(data.DATA_UPL_CMNT);
        $("#dialog-comments").dialog("open");
    }
}
function bindFoldersList(sessionGUID) {
    GetXSpaceData("DataSessGuid='" + sessionGUID + "'", "GetFoldersByDataSessGuid_SP", function (data) {
        var html = '';
        if (typeof (data) != "undefined" && data.length > 0)
        {
            for (var i = 0; i < data.length; i++) {
                html = html + "<tr><td>" + data[i].FLDR_TYP_NM + "</td></tr>";
            }
            $("#tblFolders").html(html);
        }
    });
}
function bindFilesList(sessionGUID) {
    GetXSpaceData("DataSessGuid='" + sessionGUID + "'", "GetDataFileByDataSessGuid_SP", function (data) {
        var html = '';
        if (typeof (data) != "undefined" && data.length > 0) {
            for (var i = 0; i < data.length; i++) {
                html = html + "<tr><td>" + data[i].DATA_FILE_LNM + "</td></tr>";
            }
            $("#tblFiles").html(html);
        }
    });
}