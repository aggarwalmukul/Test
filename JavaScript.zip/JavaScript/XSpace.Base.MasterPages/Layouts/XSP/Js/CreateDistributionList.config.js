﻿var wellGridSettings = {
    GridId: "wellGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: true,
    IsScrollY: true,
    DataSource: "GetActiveWells_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [{
                        Name: "Actions",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WB_JOB_GUID",
                        DataIndex: 0,
                        renderAction: "GenerateRenderAction",
                        Width: "6%",
                        IsFilterable: true,
                        IsSortable: false
                    },
                    {
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        DataIndex: 1,
                        
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "New Files",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "FILE_COUNT",
                        DataIndex: 2,
                        renderAction: "RenderNewFileActions",
                        Width: "8%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Comapany",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLD_NM",
                        DataIndex: 4,
                        Width: "5%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Country",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 5,                        
                        Width: "6%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "State/Province",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL1_NM",
                         DataIndex: 6,
                         Width: "10%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "County",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL2_NM",
                         DataIndex: 7,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "UWI/API",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GOVT_ID_NUM",
                         DataIndex: 8,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "Updated",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 9,
                         Width: "5%",
                         IsFilterable: true,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Expand",
            Action: "ExpandFilter",
            Icon: "magnifying_glass_32x32.png",
            Text: "Expand",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Filter Manager",
            Action: "FilterManager",
            Icon: "filter_manager_24x24.png",
            Text: "Distribute",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var filterGridSettings = {
    GridId: "filterGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    ColumnCollection: [{
        Name: "Filter Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "FilterName",
        DataIndex: 0,
        Width: "100%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Rename",
            Action: "Rename",
            Icon: "edit.png",
            Text: "Rename",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "Delete",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};

var dropBoxRecipientsGridSettings = {
    GridId: "dropBoxRecipientsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,   
    Paging: false,
    DataSource: "GetDistributionListUsers_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 0,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
						renderAction: "mailTo",
                        DataIndex: 1,
                        Width: "35%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Company Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 2,
                        Width: "35%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Add",
            Action: "AddDropboxRecipients",
            Icon: "add_32x32.png",
            Text: "Add recipients registered users",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveRecipients",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var emailRecipientsGridSettings = {
    GridId: "emailRecipientsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,   
    Paging: false,
    DataSource: "GetDistributionListExternRecpnt_SP",
    DataSourceParam: "USERID",
    ColumnCollection: [
            {
                Name: "Name",
                Visible: true,
                Enabled: true,
                DataType: "string",
                Style: "Text", // Text,Image,Action,URL
                CssClass: "cHeader lText",
                HeaderVisible: true,
                data: "USR_LST_NM",
                DataIndex: 1,
                Width: "20%",
                IsFilterable: true,
                IsSortable: true,
                renderAction: "GenerateFullName",
            },        
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
						renderAction: "mailTo",
                        DataIndex: 2,
                        Width: "30%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Company Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "20%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Add",
            Action: "AddBlankRow",
            Icon: "add_32x32.png",
            Text: "Add Email Recipients un- registered users",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveRecipients",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
    ]
    }
    ]
};
