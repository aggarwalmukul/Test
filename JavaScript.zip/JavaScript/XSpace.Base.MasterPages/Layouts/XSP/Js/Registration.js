﻿
var AUTH_USR_FNAME = "";
var AUTH_USR_LNAME = "";
var AUTH_USR_ID = "";
var AUTH_USR_EMAIL = "";
var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
var regExphone = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
var userReg;
var REG_TYPE = { CUS: "CUSTOMER", EMP: "EMPLOYEE" };
function getCookie(name) {
    var value = "; " + document.cookie;
    var parts = value.split("; " + name + "=");
    if (parts.length == 2) return parts.pop().split(";").shift();
}
$(document).ready(function () {
   
    AUTH_USR_ID = getCookie('CUID');
    AUTH_USR_EMAIL = getCookie('CEMAIL');
    AUTH_USR_FNAME = getCookie('CFNAME');
    AUTH_USR_LNAME = getCookie('CLNAME');

    ValidateUser();
    if (getPageName() == "CustomerRegistration") {
        userReg = REG_TYPE.CUS;
        bindCompaniesDropDown();
    }
    else if (getPageName() == "EmployeeRegistration") {
        userReg = REG_TYPE.EMP;
        GetAllDistricts(bindDistrictsDropDown);
    }   

    GetXSpaceData("", "GetPSL_SP", bindPslDropDown);
    GetXSpaceData("", "GetCellPhoneProviderList_SP", bindProviderDropDown);

    $("#empRequestAccess").on("click", function () {
        if (validateRegisterEmployeeData()) {
            registerEmployee();
        }
    });

    $("#cusRequestAccess").on("click", function () {
        if (validateRegisterCustomerData()) {
            registerCustomer();
        }
    });

    $('#officePhone').mask("000-000-0000", { placeholder: "___-___-____" });
    $('#CellPhoneNumber').mask("000-000-0000", { placeholder: "___-___-____" });
    $("#CellPhoneNumber").prop("disabled", true);
    $("#cellProvider").prop("disabled", true);
    $('#Notifications').change(function () {
        $("#CellPhoneNumber").prop("disabled", !$(this).is(':checked'));
        $("#cellProvider").prop("disabled", !$(this).is(':checked'));
    });

});

function bindCompaniesDropDown() {
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        var select = $("#ddlCCompany")[0];
        var option = new Option();      
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CO_ID;
            option.text = data[i].CO_NM;
            select.options.add(option);
        }
    });
}

function bindProviderDropDown(data) {
    var select = document.getElementById("cellProvider");
    var option = document.createElement('option');
    select.add(option);
    for (var i = 0; i < data.length; i++) {
        option = document.createElement('option');
        option.text = data[i].CELL_PHONE_PRVDR_NM;
        option.value = data[i].CELL_PHONE_PRVDR_CD;
        select.add(option);
    }
    select.selectedIndex = 0;   
}

function bindPslDropDown(data) {
    var PSLs = data;
    var select = document.getElementById("ddl_PSL");
    for (var i = 0; i < PSLs.length; i++) {
        var option = document.createElement('option');
        option.text = PSLs[i].PSL_NM;
        option.value = PSLs[i].PSL_ID;
        select.add(option, 0);
    }
    SortOptions("#ddl_PSL");
    select.selectedIndex = 0;
}

function bindDistrictsDropDown(data) {
    //var districts = JSON.parse(data.GetDistrict_SP);
    var districts = data;
    var select = document.getElementById("ddl_District");
    for (var i = 0; i < districts.length; i++) {
        var option = document.createElement('option');
        option.text = districts[i].DIST_NM;
        option.value = districts[i].DIST_GUID;
        select.add(option, 0);
    }
    SortOptions("#ddl_District");
    select.selectedIndex = 0;
}

function validateRegisterEmployeeData() {
   /* if ($("#alternateEmail").val() == "") {
        ShowCustomAlert("Please enter Alternate Email ID.", "Error:", 250);
        return false;
    }*/
   
    if ($("#alternateEmail").val() != "" && !regex.test($("#alternateEmail").val())) {       
        ShowCustomAlert("Please enter correct Email ID.", "Error:", 200);
        return false;
    }

    if ($("#officePhone").val() == "") {
        ShowCustomAlert("Please enter Office Phone Number.", "Error:", 250);
        return false;
    }
    var phone = $.trim($("#officePhone").val());
    if (phone != "") {
        if (!regExphone.test(phone)) {
            ShowCustomAlert("Invalid office phone number.", "Error:", 250);
            return false;
        }
    }

    if ($("#ddl_PSL").val() == null) {
        ShowCustomAlert("Select Primary HAL PSL from List.", "Error:", 250);
        return false;
    }
    if ($("#ddl_District").val() == null) {
        ShowCustomAlert("Select District from List.", "Error:", 250);
        return false;
    }

    return true;
}

function registerEmployee() {
    GetXSpaceData(getInsertParams(), "InsertUserHal_SP", function (data) {
        //window.location.href = "/_layouts/XSP/Pages/Home.aspx";
        $("#userValidationMsg").html("Welcome <span> " + AUTH_USR_FNAME + "</span><br /><br />Your application for XSpace is still being reviewed.  You should receive a message in your work email when your application has been processed.");
        $("#registrationBox").hide();
    });
}

function getInsertParams() {    

    var param = "FName='" + AUTH_USR_FNAME + "'%26LName='" + AUTH_USR_LNAME + "'%26UserID='" + AUTH_USR_ID + "'%26Email='" + AUTH_USR_EMAIL +
    "'%26AltEmail='" + $("#alternateEmail").val() + "'%26OfficePhone='" + $("#officePhone").val() + "'%26PslID='" + $("#ddl_PSL").val() + "'%26DistrictID='" + $("#ddl_District").val() + "'";

    if ($.trim($("#CellPhoneNumber").val()) != "")
        param = param + "%26CellPhone='" + $("#CellPhoneNumber").val() + "'";
    else
        param = param + "%26CellPhone=' '";

    if ($.trim($("#cellProvider").val()) != null && $.trim($("#cellProvider").val()) != "")
        param = param + "%26CellProviderType='" + $("#cellProvider").val() + "'";
    else
        param = param + "%26CellProviderType=null";

    if ($("#Notifications")[0].checked)
        param = param + "%26TxtNotifyFlg='1'";
    else
        param = param + "%26TxtNotifyFlg='0'";

    return param;
}

function validateRegisterCustomerData() {
    
    if ($("#ddlCCompany").val() == "") {
        ShowCustomAlert("Select Customer Company from List.", "Error:", 250);
        return false;
    }   
    if ($("#officePhone").val() == "") {
        ShowCustomAlert("Please enter Office Phone Number.", "Error:", 250);
        return false;
    }
    var phone = $.trim($("#officePhone").val());
    if (phone != "") {
        if (!regExphone.test(phone)) {
            ShowCustomAlert("Invalid office phone number.", "Error:", 250);
            return false;
        }
    }

    if ($("#ddl_PSL").val() == null) {
        ShowCustomAlert("Select Primary HAL PSL from List.", "Error:", 250);
        return false;
    }
    if ($("#HalSalesAgent").val() == "") {
        ShowCustomAlert("Please enter Primary HAL Sales Agent.", "Error:", 250);
        return false;
    }

    return true;
}

function registerCustomer() {
    GetXSpaceData(getCustomerInsertParams(), "InsertUserExternal_SP", function (data) {
        //window.location.href = "/_layouts/XSP/Pages/home.aspx";
        $("#userValidationMsg").html("Welcome <span> " + AUTH_USR_FNAME + "</span><br /><br />Your application for XSpace is still being reviewed.  You should receive a message in your work email when your application has been processed.");
        $("#registrationBox").hide();
    });
}

function getCustomerInsertParams() {

    var param = "FName='" + AUTH_USR_FNAME + "'%26LName='" + AUTH_USR_LNAME + "'%26UserID='" + AUTH_USR_ID + "'%26Email='" + AUTH_USR_EMAIL +
    "'%26CompanyID='" + $("#ddlCCompany").val() + "'%26OfficePhone='" + $("#officePhone").val() + "'%26PslID='" + $("#ddl_PSL").val() + "'%26HalSalesAgnt='" + $("#HalSalesAgent").val() + "'";

    if ($.trim($("#alternateEmail").val()) != "")
        param = param + "%26AltEmail='" + $("#alternateEmail").val() + "'";
    else
        param = param + "%26AltEmail=''";

    if ($.trim($("#CellPhoneNumber").val()) != "")
        param = param + "%26CellPhone='" + $("#CellPhoneNumber").val() + "'";
    else
        param = param + "%26CellPhone=' '";
    
    if ($.trim($("#cellProvider").val()) != null && $.trim($("#cellProvider").val()) != "")
        param = param + "%26CellProviderType='" + $("#cellProvider").val() + "'";
    else
        param = param + "%26CellProviderType=null";   
   
    if ($.trim($("#comments").val()) != "")
        param = param + "%26Comment='" + $("#comments").val() + "'";
    else
        param = param + "%26Comment=''";
    
    if ($("#Notifications")[0].checked)
        param = param + "%26TxtNotifyFlg='1'"; 
    else
        param = param + "%26TxtNotifyFlg='0'";

    return param;
}


function ValidateUser() {
    var param = "UserID='" + AUTH_USR_ID + "'";
    GetXSpaceData(param, "GetUserApprovalStatus_SP", function (data) {
        if (data != null && data[0] != undefined) {
            var status = data[0].APRVL_STAT_CD;           
            if (status == "PNDG") {
                $("#userValidationMsg").html("Welcome <span> " + AUTH_USR_FNAME + "</span><br /><br />Your application for XSpace is still being reviewed.  You should receive a message in your work email when your application has been processed.");
                $("#registrationBox").hide();                
            }
            else if (status == "RJCT") {
                GetXSpaceData(param, "GetUserRegistered_SP", function (data) {                     

                    $("#userValidationMsg").html("Welcome <span> " + AUTH_USR_FNAME + "</span><br /><br />Your application for XSpace has was not accepted.  The reason given was: " + (data[0].APRVL_CMNT==null?'':data[0].APRVL_CMNT) + ". If you feel this was in error, please reapply and add additional comments explaining why.<a style='color:blue;' href='#' id='applyLink'>Apply again</a>");
                    $("#registrationBox").hide();
                    $("#applyLink").on("click", function () {
                        $("#userValidationMsg").html("");
                        $("#registrationBox").show();                        
                        ////Prepopulates fields with data from previous application
                        loadRegistrationDetails(data);                      
                    });
                });
            }
            else if (status == "APRVD") {
                //redirect user into application landing page...
                window.location.href = "/_layouts/XSP/Pages/home.aspx";
            }
        }
       
    });
}

function loadRegistrationDetails(data) {
    if (data.length > 0) {

        $("#alternateEmail").val(data[0].ALT_EMAIL_ADDR_DESC);
        $("#officePhone").val(maskValue(data[0].PHONE_NUM));
        $("#ddl_PSL").val(data[0].PSL_ID);

        if (data[0].TXT_NTFN_FLG == "1") {
            $('#Notifications').prop('checked', true);
            $("#CellPhoneNumber").prop("disabled", false);
            $("#cellProvider").prop("disabled", false);
        }
        else
            $('#Notifications').prop('checked', false);
        $("#CellPhoneNumber").val(maskValue(data[0].CELL_PHONE_NUM));
        $("#cellProvider").val(data[0].CELL_PHONE_PRVDR_CD);

        if (userReg == REG_TYPE.EMP) {
            $("#ddl_District").val(data[0].DIST_GUID);
        }
        else if (userReg == REG_TYPE.CUS) {
            $("#ddlCCompany").val(data[0].CO_ID);
            $("#HalSalesAgent").val(data[0].HAL_SLS_AGNT_NM);
            $("#comments").val(data[0].RGSTR_CMNT);
        }

    }   
}





