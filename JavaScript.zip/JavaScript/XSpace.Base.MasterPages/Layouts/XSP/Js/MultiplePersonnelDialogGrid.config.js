﻿var personnelsGridSettings = {
    GridId: "PersonnelsGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single   
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    DataSource: "GetRecentDistributionRecpnt_SP",
    ColumnCollection: [
                    {
                        Name: "Dropbox",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "DROPBOX",
                        renderAction: "renderDropBoxCheckbox",
                        DataIndex: 0,
                        Width: "9%",
                        IsFilterable: false,
                        IsSortable: false
                    },
                    {
                        Name: "Email",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "EMAIL",
                        renderAction: "renderEmailCheckbox",
                        DataIndex: 1,
                        Width: "9%",
                        IsFilterable: false,
                        IsSortable: false
                    },
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 2,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "Company",
                         Visible: true,
                         Enabled: true,
                         DataType: "string",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CO_NM",
                         DataIndex: 3,
                         Width: "20%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "URL", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        DataIndex: 4,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Phone",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "PHONE_NUM",
                        renderAction: "formatPhoneNumber",
                        DataIndex: 5,
                        Width: "20%",
                        IsFilterable: false,
                        IsSortable: false
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },

    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearRecentFilter",
            Action: "clearRecentFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};


var allPersonnelsGridSettings = {
    GridId: "AllPersonnelsGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single   
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    DataSource: "GetUsers_SP",
    ColumnCollection: [
                    {
                        Name: "Dropbox",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "DROPBOX",
                        renderAction: "renderDropBoxCheckbox",
                        DataIndex: 0,
                        Width: "9%",
                        IsFilterable: false,
                        IsSortable: false
                    },
                    {
                        Name: "Email",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "EMAIL",
                        renderAction: "renderEmailCheckbox",
                        DataIndex: 1,
                        Width: "9%",
                        IsFilterable: false,
                        IsSortable: false
                    },
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 2,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },                      
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "URL", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        DataIndex: 4,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Phone",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "PHONE_NUM",
                        renderAction: "formatPhoneNumber",
                        DataIndex: 5,
                        Width: "20%",
                        IsFilterable: false,
                        IsSortable: false
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },

    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearAllFilter",
            Action: "clearAllFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};
