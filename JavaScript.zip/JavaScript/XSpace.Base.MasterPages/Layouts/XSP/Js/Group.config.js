﻿var groupGridSettings = {
    GridId: "groupGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetUserGroups_SP ",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "USR_GRP_NM",
        renderAction: "editGroup",
        DataIndex: 1,
        Width: "15%",
        IsFilterable: true,
        IsSortable: true
    },

                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 2,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "# of Users",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "USR_CNT",
                        renderAction: "editUser",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "# of Entitlements",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "ENTLMNT_CNT",
                        renderAction: "editEnt",
                        DataIndex: 4,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Created By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CREAT_BY_USRID",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Last Edited By",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "LST_UPDT_USRID",
                        DataIndex: 6,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "Create Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CREAT_TMSTMP",
                         DataIndex: 7,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Last Edited Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 8,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddGroup",
            Action: "AddGroup",
            Icon: "create_32x32.png",
            Text: "New Group",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteGroup",
            Action: "DeleteGroup",
            Icon: "delete_32x32.png",
            Text: "Delete Group",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearFilter",
            Action: "clearFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};