﻿var filesContainer = [];
var TempStorageDrive, TempDriveID;
var FileStorageDrive, FileStorageID;
var Comments;
var status;
var WellGUID;
var WellorUserUpload = true;
var UploadSessionGuid;
var drives;
var machine;
var folderpath;
var driveGuid;
var selectdistrictGuid;
var FileStatus = "FINAL";
var UploadGUID;
var FolderID;
var destinationPath;
var userid;
var userguid;
var DataFileGuid;
var zipfileflag;
var iTotalFileCount = 0;
var UpdatePreviousFileStatus = "";
var uploader;
var dataUpdateAtServer = true;
var isComplete = true;
var USERROLE="";
$(document).ready(function () {
    $("#s4-ribbonrow").hide();
    //$('#txtJobTicketNumber').val(GetUrlParameter("SO"));
    initializeUploader();
    GetStorageDrive(UpdateDrives);
    WellGUID = GetUrlParameter("WBGuid");
    uploader.disableBrowse(true);

    var control = document.getElementById("menuXSpace");
    control.style.display = 'none';
    control = document.getElementById("logoutlink");
    control.style.display = 'none';


    //GetAllDistricts(UpdateDistricts);
    GetWellFolders(UpdateWellFolders);
    GetUserGuid(GetUserData);
    var wellname = GetUrlAndParameter("WellName");
    wellname = unescape(wellname);
    document.getElementById("WellLabel").innerHTML = wellname;
    document.title = "Well Upload-" + wellname;

    $(document).on("click", "a.remove", function () {
        if (uploader.state == plupload.STARTED) {
            return;
        }
        var row = $(this).closest("tr");
        var id = $(row).attr("id");
        if (typeof (id) != "undefined") {
            $("#files tr[id='" + id + "']").remove();
            $("#files tr[child-id='" + id + "']").remove();
            var arrfiles = filesContainer[id];

            for (var i = arrfiles.length - 1; i >= 0; i--) {
                uploader.removeFile(arrfiles[i].FileId);
            }
            delete filesContainer[id];
        }
        else {
            id = $(row).attr("child-id");
            fileid = $(row).attr("file-id");
            $("#files tr[child-id='" + id + "'][file-id='" + fileid + "']").remove();
            var arrfiles = filesContainer[id];
            for (var i = 0; i < arrfiles.length; i++) {
                if (arrfiles[i].FileId == fileid) {
                    uploader.removeFile(fileid);
                    arrfiles.splice(i, 1);
                    break;
                }
            }
			if($("#files tr[child-id='" + id + "']").length==0){
				 $("#files tr[id='" + id + "']").remove();
				delete filesContainer[id];
				}
        }
        calculateFolderCount();
        var folderId = $("#folders").val();
        var folder = "";
        var dropdownObject = document.getElementById("folders");
        var dropdown = document.getElementById("folders").options.length;

        if (dropdown) {
            for (var k = 1; k < dropdown; k++) {
                if (dropdownObject.options[k].value == id) {
                    folder = dropdownObject.options[k].text;
                }
            }
        }
        if (filesContainer[id] != undefined) {
            var table = $("#files");
            var htmlString = $(table).find("tr[id='" + id + "']").html();
            var index1 = htmlString.indexOf("(");
            var index2 = htmlString.indexOf(")");
            var res = htmlString.substring(index1, index2 + 1);
            var stringreplace = "(" + filesContainer[id].length + ")";
            htmlString = htmlString.replace(res, stringreplace);
            $(table).find("tr[id='" + id + "']").html(htmlString);
        }

    });
    $(document).on("click", "a.collapseupload", function () {
        var id = $(this).closest("tr").attr("id");
        if (typeof ($(this).attr("state")) == "undefined" || $(this).attr("state") == "collapse") {
            $(this).html("<img src='/_layouts/15/XSP/images/toggle-expand.png' width=16px height=16px style='border:0'/>");
            $("#files tr[child-id='" + id + "']").css("display", "none");
            $(this).attr("state", "expand");
        }
        else {
            $(this).html("<img src='/_layouts/15/XSP/images/toggle.png' width=16px height=16px style='border:0'/>");
            $("#files tr[child-id='" + id + "']").css("display", "");
            $(this).attr("state", "collapse");
        }
    });
    $(document).on("change", "#folders", function () {
        if ($(this).val() == "") {
            uploader.disableBrowse(true);
            $("#pickfiles").css("color", "grey");
        }
        else {
            uploader.disableBrowse(false);
            $("#pickfiles").css("color", "black");
        }
    });

    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 150,
        width: 300,
        buttons: {
            "OK": function () {
                if (isComplete) {
					if(window.opener.reloadFiles!=undefined)
						window.opener.reloadFiles();
					else
                    window.opener.location.reload();
                    self.close();
                }
                $(this).dialog('close');
            }
        }
    });
   
});
plupload.addFileFilter('cust_Ext_Val', function (maxSize, file, cb) {
    var undef;
    var ext = ".exe,.dll,.asp,.aspx.cs,.aspx.vb,.vbe,.wsf,.wsc,.wsh,.bat,.vb,.vbs,.js,.com,.htm,.html,.shtml,.hta";
    var arr = ext.split(",");
    var filext = file.name.split(".")[1];
    var flag = false;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == ("." + filext))
        {
            flag = true;
            break;
        }
    }
    // Invalid file size
    if (flag) {
        this.trigger('Error', {
            code: plupload.FILE_SIZE_ERROR,
            message: plupload.translate('Selected file type not allowed.'),
            file: file
        });
        cb(false);
    } else {
        cb(true);
    }
});

function initializeUploader() {
      uploader = new plupload.Uploader({
        runtimes: 'html5,browserplus,silverlight,gears,html4',
        browse_button: 'pickfiles', // you can pass in id...
        container: document.getElementById('AddFileButton'), // ... or DOM Element itself
        url: getAppURL() + "/_layouts/15/upload/uploadhandler.ashx",
        flash_swf_url: '/_layouts/15/XSP/JS/Moxie.swf',
        silverlight_xap_url: '/_layouts/15/XSP/JS/Moxie.xap',
        chunk_size: '500kb',
        unique_names: false,
        multipart_params: {
            "name1": "value1",
            "name2": "value2"
        },
        filters: {
            max_file_size: '10000mb',
            prevent_duplicates: true,
            cust_Ext_Val:"validate",
            mime_types: [
        //{ title: "Vedio files", extensions: "mkv" },
        //{ title: "Text files", extensions: "pdf,txt,docx,xlsx" },
        //{ title: "Image files", extensions: "jpg,gif,png" },
        //{ title: "Zip files", extensions: "zip" }
            ]
        },

        init: {
            PostInit: function () {
                document.getElementById('filelist').innerHTML = '';
                document.getElementById('name').innerHTML = name;
                document.getElementById('Upload').onclick = function () {
                    if (iTotalFileCount <= 0) {
                        isComplete = false;
                        $("#alert").html("Please select file(s).").dialog('open');
                        return false;
                    }
                    Comments = document.getElementById('TextComments').value;
                    status = document.querySelector('input[name="status"]:checked').value;
                    if (Comments == "")
                    {
                        isComplete = false;
                        $("#alert").html("Please enter comments.").dialog('open');
                        return false;
                    }
					else if ($.trim(Comments).length<10)
                    {
                        isComplete = false;
                        $("#alert").html("Please enter comments at least 10 characters").dialog('open');
                        return false;
                    }

                    CheckStorageDrivePermission();
                    if (StorageDriveStatus == "false") {
                        isComplete = false;
                        $("#alert").html("Permission Denied.").dialog("open");
                        return;
                    }
                    if ($('#chkKeepZipfilesAsZip').is(':checked') == true)
                        zipfileflag = "1";
                    else
                        zipfileflag = "0";

                    FileStatus = document.querySelector('input[name="status"]:checked').value;
                    if (FileStatus == "Preliminary")
                        FileStatus = "PRELM";
                    else if (FileStatus == "Final")
                        FileStatus = "FINAL";
                    else
                        FileStatus = "INTRNL";

                    // Create a file upload session here.
                    UploadSessionGuid = null;

                    InsertUploadSession(WellGUID, "WELL", "INPROG", Comments,
                        userguid, zipfileflag,
                        "InsertUploadSession_SP", KickUploadSession);

                    return false;
                };
                uploader.disableBrowse(true);
                $("#pickfiles").css("color", "grey");
            },
            
            BeforeUpload: function (up, file) {
                var wellflag = true;
                if (UpdatePreviousFileStatus != "") {
                    document.getElementById(UpdatePreviousFileStatus).getElementsByTagName('b')[0].innerHTML = '<span>' + 100 + "%</span>";
                }
                
                var status = document.querySelector('input[name="status"]:checked').value;
                params = uploader.settings.multipart_params;
              
                params.Comments = Comments;
                params.UploadSessionGuid = UploadSessionGuid;
                params.WellGUID = WellGUID;
                params.driveGuid = driveGuid;
                params.Status = FileStatus;
                params.zipflag = zipfileflag;
                params.UserID = USERID;
                if (dataUpdateAtServer == true) {
                    params.DataUpdate = "true";
                }
                params.distGuid = selectdistrictGuid;
                params.UploadStorageDrive = machine;

                var dropdownObject = document.getElementById("folders");
                var dropdown = document.getElementById("folders").options.length;
                var folder;

                if (dropdown) {
                    for (var k = 1; k < dropdown; k++) {

                        if (typeof (filesContainer[dropdownObject.options[k].value]) != "undefined") {

                            fileArr = filesContainer[dropdownObject.options[k].value]
                            for (var i = 0; i < fileArr.length; i++) {
                                if (file.id == fileArr[i].FileId) {
                                    params.Folder = dropdownObject.options[k].text;
                                    FolderID = dropdownObject.options[k].value;
                                    params.folderPath = "\\WELLS\\" + WellGUID + "\\" + dropdownObject.options[k].text;
                                    params.folderID = FolderID;
                                    break;
                                }

                            }
                        }

                    }
                }

                var size = file.size / 1048576;
                var roundoffsize = round(size, 2);
                params.Size = roundoffsize;
                
                destinationPath = GetDestinationPath(WellGUID, machine, params.Folder);
                params.destinationPath = destinationPath;
                if (dataUpdateAtServer == false) {
                    InsertDataFile(driveGuid, file.name, destinationPath, roundoffsize, FileStatus, selectdistrictGuid, Comments, "InsertDataFile_SP", KickFileUploadForDataEntry);
                }
            },
            FilesAdded: function (up, files) {
                $("#console").html("");
                var fileArr = [];
                var folderId = $("#folders").val();
                var folder = $("#folders option:selected").text();
                if (typeof (filesContainer[folderId]) == "undefined") {
                    plupload.each(files, function (file) {
                        var obj = new Object();
                        obj.FileId = file.id;
                        obj.FileName = file.name;
                        obj.Size = plupload.formatSize(file.size);
                        obj.TotalFileSizeInBytes = file.size;
                        obj.folderId = folderId;
                        file.folderId = folderId;
                        fileArr.push(obj);
                        filesContainer[folderId] = fileArr;
                    });
                    //plupload.DUPLICATEMESSAGE = false;
                }
                else {
                    fileArr = filesContainer[folderId]
                    plupload.each(files, function (file) {
                        for (var i = fileArr.length - 1; i >= 0; i--) {
                            if (fileArr[i].FileName != file.name) {
                                var obj = new Object();
                                obj.FileId = file.id;
                                obj.FileName = file.name;
                                obj.Size = plupload.formatSize(file.size);
                                obj.TotalFileSizeInBytes = file.size;
                                obj.folderId = folderId;
                                file.folderId = folderId;
                                fileArr.push(obj);
                                break;
                            }
                            else {
                                fileArr.slice(i, 1);
                                uploader.removeFile(file);
                            }
                        }
                    });

                }
                updateList(folderId, folder);
                //plupload.DUPLICATEMESSAGE = false;
            },

            UploadProgress: function (up, file) {
                UpdatePreviousFileStatus = "";
                if (document.getElementById(file.id) != null) {
                    if (document.getElementById(file.id).getElementsByTagName('b') != null) {
                        var percent = 0;
                        percent = file.percent;
                        if (file.percent > 95 && file.percent <= 100)
                            percent = "finalizing";
                        if (file.percent == 100)
                            UpdatePreviousFileStatus = file.id;
                        document.getElementById(file.id).getElementsByTagName('b')[0].innerHTML = '<span>' + percent + "%</span>";
						
						// move scroll
						var container = $('#accordion1'),scrollTo = $('#'+file.id);
						container.scrollTop(
						scrollTo.offset().top - container.offset().top + container.scrollTop()
						);
						
                        if (UploadGUID != undefined) {
                            if (dataUpdateAtServer == false) {
                                UpdateUploadProgress(UploadGUID, file.percent, "UpdateFileUploadPercent_SP", null);
                            }
                        }
                        else {

                        }
                    }
                    }
            },
            UploadComplete: function (up, file) {
                if (UpdatePreviousFileStatus != "") {
                    document.getElementById(UpdatePreviousFileStatus).getElementsByTagName('b')[0].innerHTML = '<span>' + 100 + "%</span>";
                }

                isComplete = true;
                $("#alert").html("Files Uploaded Successfully.").dialog("open");
                var param = "DataSessGuid='" + UploadSessionGuid + Sep() + "Status='" + "CMPLTD" + "'";
                GetXSpaceData(param, "UpdateDataFileSession_SP", undefined);
                WellUploadNotification(UploadSessionGuid);
            },
            Error: function (up, err) {
                ShowCustomAlert("Error: " + err.message, "Alert", 350);
            }
        }
    });

    uploader.init();
}
function GetUserData(UserData, FilterData) {
    userguid = UserData[0].USR_GUID;
	USERROLE =UserData[0].ROLE_CD;
	 if(USERROLE == USERROLE_TYPE.CustomerUser ||USERROLE == USERROLE_TYPE.CustomerAdministrator){
		$("input[value='Internal']").hide()
		$("#lblInternal").hide();
		$("input[value='Preliminary']").prop("checked","true");
	}
}

function UpdateWellFolders(data) {
    var wellfoldersdata = data;
    var selectwellfolders = document.getElementById("folders");
    for (var i = wellfoldersdata.length - 1; i >= 0; i--) {
        var option = document.createElement('option');

        option.text = wellfoldersdata[i].FLDR_TYP_NM;
        option.value = wellfoldersdata[i].FLDR_TYP_ID;
        selectwellfolders.add(option, 0);
    }
    var option = document.createElement('option');

    option.text = "Select Folder...";
    option.value = "0";
    selectwellfolders.add(option, 0);
    selectwellfolders.selectedIndex = 0;
}
function UpdateDistricts(data) {
    var districts = data;
    var select = document.getElementById("select");
    for (var i = 0; i < districts.length; i++) {
        var option = document.createElement('option');
        option.text = districts[i].DIST_NM;
        option.value = districts[i].DIST_GUID;
        select.add(option, 0);
    }
    select.selectedIndex = 0;
}
function calculateFolderCount() {
    iTotalFileCount = 0;
    var iTotalFileSize = 0;
    var iTotalFolderCount = 0;
    var isFolder = false;
    var dropdownObject = document.getElementById("folders");
    var dropdown = document.getElementById("folders").options.length;

    if (dropdown) {
        for (var k = 1; k < dropdown; k++) {

            if (typeof (filesContainer[dropdownObject.options[k].value]) != "undefined") {
                iTotalFolderCount = iTotalFolderCount + 1;
                fileArr = filesContainer[dropdownObject.options[k].value]
                for (var i = 0; i < fileArr.length; i++) {
                    iTotalFileCount = iTotalFileCount + 1;
                    iTotalFileSize = iTotalFileSize + fileArr[i].TotalFileSizeInBytes;
                }
                isFolder = true;
            }

        }
    }

    if (isFolder)
        $("#TotalFileCount").text("Total :" + iTotalFileCount + " files in " + iTotalFolderCount + " folders " + "(" + CalculateFileSize(iTotalFileSize) + ")");
    else
        $("#TotalFileCount").text('');
}

function round(num, precision) {
    return Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision);
}

function CalculateFileSize(size) {
    var fileSize;
    fileSize = size / 1048576;
    return round(fileSize, 2) + " " + plupload.translate('MB');
}

function getHeaderRow(folderId, folder, filecount) {
    var html = "<tr class='headerItem' style=\"background-color: #efefef;\" +  id='" + folderId + "' + folderName='" + folder + "' ><td colspan='4'><a class='collapseupload' id=toggle'" + folderId + "' href='#'><img src='/_layouts/15/XSP/images/toggle.png' width=16px height=16px style='border:0'/></a>"
                     + "<img src='/_layouts/15/XSP/images/folder.jpg'/>" + folder + "(" + filecount + "                      )</td>";

    html = html + "<td width=\"80px\"><a style=\"color:blue;\" +  href='#' class='remove'>Remove All</a></td></tr>";
    return html;
}
function getFileRow(folderId, filename, fileId, size) {
    var html = "<tr style=\"background-color: #efefef;\" + child-id='" + folderId + "' file-id='" + fileId + "'>";
    html = html + "<td width=\"30px\"></td>";
    html = html + "<td colspan='3'>" + filename + "(" + size + ")<div id='" + fileId + "'><b></div></td>";
    html = html + "<td><a style=\"color:blue;\" + href='#' class='remove'>Remove</a></td>";
    html = html + "</tr>";
    return html;
}


function updateList(folderId, folder) {
    var table = $("#files");
    var row = $(table).find("tr[id='" + folderId + "']");
    if (row.length == 0) {
        if (filesContainer[folderId].length > 0) {
            $(table).append(getHeaderRow(folderId, folder, filesContainer[folderId].length));
            for (var i = 0; i < filesContainer[folderId].length; i++) {
                $(table).append(getFileRow(folderId, filesContainer[folderId][i].FileName, filesContainer[folderId][i].FileId, filesContainer[folderId][i].Size));
            }
        }
    }
    else {
        if (filesContainer[folderId].length != 0) {

            var rows = $(table).find("tr[class=headerItem]");
            var ColumnValue = "";
            var folderArray = [];
            var folderNameArray = [];
            for (var k = 0; k < rows.length; k++) {
                ColumnValue = $(rows[k]).attr("id");
                folderArray.push(ColumnValue);
                folderNameArray.push($(rows[k]).attr("folderName"));
            }


            if (folderArray[folderArray.length - 1] != folderId) {
                $(table).empty();
                for (var k = 0; k < folderArray.length; k++) {
                    updateList(folderArray[k], folderNameArray[k]);

                }
                return;
            }

            $(table).find("tr[child-id='" + folderId + "']").remove();
            var htmlString = $(table).find("tr[id='" + folderId + "']").html();
            var index1 = htmlString.indexOf("(");
            var index2 = htmlString.indexOf(")");
            var res = htmlString.substring(index1, index2 + 1);
            var stringreplace = "(" + filesContainer[folderId].length + ")";
            htmlString = htmlString.replace(res, stringreplace);
            $(table).find("tr[id='" + folderId + "']").html(htmlString);
            for (var i = 0; i < filesContainer[folderId].length; i++) {
                $(table).append(getFileRow(folderId, filesContainer[folderId][i].FileName, filesContainer[folderId][i].FileId, filesContainer[folderId][i].Size));
            }

            //for (var i = 0; i < filesContainer[folderId].length; i++) {
            //    $(table).find("tr[id='" + folderId + "']").append(getFileRow(folderId, filesContainer[folderId][i].FileName, filesContainer[folderId][i].FileId, filesContainer[folderId][i].Size));
            //}
        }
        else {
            $(table).find("tr[id='" + folderId + "']").remove();
            delete filesContainer[folderId];
        }

    }
    calculateFolderCount();
}


function updateParent() {
    //window.opener.updateStatus(guid, "complete");
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function qs(key) {
    return GetUrlParameter(key);
}

var guid = getParameterByName("q");
var name = getParameterByName("name");
var i = 0;
function KickUploadSession(data) {    
    var session = data;
    UploadSessionGuid = session[0].DATA_UPL_GUID;  
    uploader.start();
    return false;
}

function KickUploadSessionfromSoNumber(data) {
    var wellguid = data;
    WellGUID = wellguid[0].WB_JOB_GUID;
    InsertUploadSession(WellGUID, "WELL", "INPROG", Comments,
        userguid, zipfileflag,
        "InsertUploadSession_SP", KickUploadSession);
    // Create a file upload session here.
    return false;

}

function KickFileUpload(data) {
    var dataFile = data;
    var dataUploadGuid = dataFile[0].DATA_FILE_UPL_GUID;
    UploadGUID = dataUploadGuid;

}
function KickFileUploadForDataEntry(data) {
    var dataFile = data;
    var dataFileGuid = dataFile[0].DATA_FILE_GUID;
    DataFileGuid = dataFileGuid;
    InsertWBJobDataFile(WellGUID, dataFileGuid, FolderID, "InsertWBJobDataFile_SP", undefined);
    InsertUploadFile(UploadSessionGuid, dataFileGuid, driveGuid, destinationPath, "InsertFileUpload_SP", KickFileUpload);
}
function GetFolderID(id) {
    var dropdownObject = document.getElementById("folders");
    var dropdown = document.getElementById("folders").options.length;
    var folder;

    if (dropdown) {
        for (var k = 0; k < dropdown; k++) {

            if (typeof (filesContainer[dropdownObject.options[k].value]) != "undefined") {

                fileArr = filesContainer[dropdownObject.options[k].value];
                for (var i = 0; i < fileArr.length; i++) {
                    if (id == fileArr[i].FileId) {
                        folder = filesContainer[dropdownObject.options[k].value];
                        break;
                    }
                }
            }

        }
    }
}
function UploadFunction() {
    $("#uploadfiles").click();
}
function UploadCancel() {
    if (uploader != null && uploader != undefined) {
        if (uploader.state == plupload.STARTED) {
            uploader.stop();
            if (UploadSessionGuid != null && UploadSessionGuid != "") {
                var param = "DataSessGuid='" + UploadSessionGuid + Sep() + "Status='" + "CNCLD" + "'";
                GetXSpaceData(param, "UpdateDataFileSession_SP", undefined);
                window.close();
            }
        }
        else
            window.close();
    }
    else
        window.close();

}

function UpdateDrives(data) {
    machine = data[0].DRV_PATH;
    folderpath = "";
    driveGuid = data[0].DRV_GUID;
}

function GetUrlAndParameter(keyName){
	var href = window.location.href;
    href = href.replace('#', '');
   var well= href.substring(href.indexOf(keyName),href.length)
   var splitedWell=well.split("=");
   if(splitedWell.length>0)
	   return $.trim(splitedWell[1]);
   return "";
}