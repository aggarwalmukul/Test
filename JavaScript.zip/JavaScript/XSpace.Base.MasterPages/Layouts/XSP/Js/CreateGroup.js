﻿var IsDirty = false;
var IsEditEntitlements = false;
var WellName;
var GroupName;
var AffiliatedCompany;
var IsEntitledGrid = false;
var groupId = "";
var wellJobID = "";
var folderfullList;
var folderAvailableList;
var folderSelectedList;
var selectedfolder;
var entitlementRow = new Object();
var deletelistforUser = [];
var deletelistforEntitlement = [];
var dbGroupName = "";
$(document).ready(function () {
    $(document).on("keypress blur", "input", function () {
        removeSpecialChar($(this));
    });
    GetUserGuid(GetUserGUIDDetails);
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                IsDirty = true;
                if (IsEntitledGrid) {
                    var data = $("#" + EntitlementsGridSettings.GridId).DataTable().rows(".selected").data();
                    for (var i = 0; i < data.length; i++)
                        deletelistforEntitlement.push(data[i]);
                    var table = $("#" + EntitlementsGridSettings.GridId).DataTable();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                }
                else {
                    var data = $("#" + UsersGridSettings.GridId).DataTable().rows(".selected").data();
                    for (var i = 0; i < data.length; i++)
                        deletelistforUser.push(data[i]);
                    var table = $("#" + UsersGridSettings.GridId).DataTable();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                }
                $("#save").attr("src", "../images/save_dirty_24x24.png");
                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });

    $("#dEditEntitlements").dialog({
        autoOpen: false,
        modal: true,
        title: "Edit Group Entitlements",
        height: 600,
        width: 750,
        close: function () {
            DestoryEntitlementsGrid();
        },
        open: function () {

            $("#dGroupName").val(GroupName);
            $("#dAffiliatedCompany").val(AffiliatedCompany);
            $("#dWellName").val("");

            if (IsEditEntitlements) {
                $("#imgSearchWell").css("display", "none");
            }
            else {
                $("#imgSearchWell").css("display", "");
            }
            populateEmptyAvailableSelectedEntitlements();
            $("#AvailableEntitlementsGrid_info").hide();
            $("#SelectedEntitlementsGrid_info").hide();
            $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
            $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
        },
        buttons: {
            "OK": function () {
                var selectedEntTable = $("#" + SelectedEntitlementsGridettings.GridId).DataTable().rows().data();
                if (selectedEntTable.length > 0) {
                    if(!IsEditEntitlements && isWellExist(entitlementRow.WELL_NM)){
                        $("#alert").html("Well name already exist.Please choose another").dialog('open');
                    }
                    else{
                    AddNewEntitlement();
                    $(this).dialog('close');
                    }
                }
                else
                    $("#alert").html("Please select atleast one folder").dialog('open');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 140,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
                $("#txtGroupName").focus();
            }
        }
    });
    SetControlVisibility();

    $("#save").on("click", function () {
        var groupName = $.trim($("#txtGroupName").val());
        if (groupName == "") {
            $("#alert").html("Please enter group name.").dialog('open');
            return false;
        }
        isGroupNameAlreadyExist(groupName, qs("GroupID"), function (data) {
            if (data) {
                $("#alert").html("Group name already exist please choose another name.").dialog('open');
                return false;
            }

            InsertItemsGroup();
            //redirecttoSourcePage();  
            ClearDirty();
        });
    });

    $("input.edit").on("keyup", function () {
        IsDirty = true;
        if (typeof ($(this).attr("readonly")) == 'undefined')
            $("#save").attr("src", "../images/save_dirty_24x24.png");
    });

    $("#saveaspersonal").on("click", function () {
        $("#dSaveAsPersonal").dialog('open');
    });

    initUI();
    populateUsers();
    populateEntitlements();

    $("#grouptabs").tabs({
        activate: function (event, ui) {
            if (ui.newPanel.is("#Usertab")) {
                IsEntitledGrid = false;
            }
            else {
                if ($("#openAddEntitlement").length > 0)
                    $("#openAddEntitlement")[0].onclick = null;
                if ($("#RemoveEntitlements").length > 0)
                    $("#RemoveEntitlements")[0].onclick = null;
                $("#openAddEntitlement").on("click", function () {
                    openAddEntitlements();
                });
                $("#RemoveEntitlements").on("click", function () {
                    RemoveEntitlements();
                });
                IsEntitledGrid = true;
            }
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });
    $("#openAddEntitlements").on("click", function () {
        openAddEntitlements();
    });
    var tabIndex = 0;
    if (typeof (qs("tab")) != 'undefined') {
        if (qs("tab") == "U")
            tabIndex = 0
        else
            tabIndex = 1;
    }
    $("#grouptabs").tabs("option", "active", tabIndex);
    $("#SaveAs").on("click", function () {
        $("#dialog-saveasgroup").data('param', "saveAsGroup").dialog('open');
    });
    $(document).on("saveAsEvent", {}, function (event, groupId, groupName, affiliatedCompany, isSaveAs) {
        //save entitlements and users and than redirect to groups page.
        InsertItemsGroup(groupId, affiliatedCompany, isSaveAs);
        //redirecttoSourcePage();
        ClearDirty();
    });
    $(document).on("click", "#back", function () {
        redirecttoSourcePage();
    });
    $("#MoveLeft").on("click", function () {
        var availableEntTable = $("#" + AvailableEntitlementsGridettings.GridId).DataTable();
        var rows = availableEntTable.rows(".selected");
        if (rows.length == 0) {
            $("#alert").html("Please select entitlements to move.").dialog('open');
            return false;
        }
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + SelectedEntitlementsGridettings.GridId).DataTable().row.add(item).draw(false);
        }
        availableEntTable.row('.selected').remove().draw(false);
        if (availableEntTable.rows().data().length == 0) {
            $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#SelectedEntitlementsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#SelectedEntitlementsGrid_wrapper").find("tr").removeClass("selected");
    });
    $("#MoveRight").on("click", function () {
        var selectedEntTable = $("#" + SelectedEntitlementsGridettings.GridId).DataTable()
        var rows = selectedEntTable.rows(".selected");
        if (rows.length == 0) {
            $("#alert").html("Please select entitlements to move.").dialog('open');
            return false;
        }
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + AvailableEntitlementsGridettings.GridId).DataTable().row.add(item).draw(false);
        }
        selectedEntTable.row('.selected').remove().draw(false);
        if (selectedEntTable.rows().data().length == 0) {
            $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $('#' +AvailableEntitlementsGridettings.GridId).DataTable().order([1, 'asc']).draw();
        $("#AvailableEntitlementsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#AvailableEntitlementsGrid_wrapper").find("tr").removeClass("selected");
    });
    GetAllFolders();
    $("#imgSearchWell").on("click", function () {
        OpenWellDialog(SetSelectedWell);
    });
    window.onbeforeunload = function () {
        if (IsDirty == true) {
          /*  if (confirm("You have unsaved changes.Do you want to save?")) {
                //write save logic  and redirect to groups page
                InsertItemsGroup();
                return;
            }
            else {
                return;
            }*/
            return 'You have unsaved changes!';
        }
       // return;
    };

    $("#txtGroupName").on("keyup", function () {
        SetDirtyFilter();
    });
    PerformAdminActions();

});
function ClearDirty() {
    IsDirty = false;
    $("#save").attr("src", "../images/save_32x32.png");
}
function editCompany(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?GroupID=" + qs("GroupID") + "&CompanyID=" + full.CO_ID + "&Page=EditGroup\">" + full.CO_NM + "</a>";
}
function PerformAdminActions()
{
    if (USERROLE == USERROLE_TYPE.InternalUser) {
        $("#AddUsers").hide();
        $("#RemoveUsers").hide();
        $("#openAddEntitlement").hide();
        $("#RemoveEntitlements").hide();
        $("#save").hide();
        $("#SaveAs").hide();
    }
}

function SetSelectedWell(arrWells) {
    entitlementRow = new Object();

    $("#dWellName").val(arrWells[0].WELL_NM);
    if (!IsEditEntitlements) {
        selectedfolder = "";
        wellJobID = arrWells[0].WB_JOB_GUID;
        entitlementRow.WB_JOB_GUID = arrWells[0].WB_JOB_GUID;
    }
    else {
        entitlementRow.WB_JOB_GUID = wellJobID;
    }

    //Add New items	
    entitlementRow.WELL_NM = arrWells[0].WELL_NM;
    entitlementRow.CO_NM = arrWells[0].CO_NM;
    entitlementRow.FLD_NM = arrWells[0].FLD_NM;
    entitlementRow.GOVT_ID_NUM = arrWells[0].GOVT_ID_NUM;
    entitlementRow.FLDR_TYP_NM = "";
    entitlementRow.FLDR_TYP_ID = selectedfolder;

    populateAvailableEntitlements();   
}

function openAddEntitlements() {
    AffiliatedCompany = $("#txtAffiliatedCompanyName").val();
    GroupName = $("#txtGroupName").val();
    IsEditEntitlements = false;
    $("#dEditEntitlements").dialog('option', 'title', 'Add Group Entitlements');
    $("#dEditEntitlements").dialog('open');
}
function editEntitelements(data, type, full, meta) {
    if (USERROLE == USERROLE_TYPE.InternalUser)
        return data;
    else {
        return "<a class='edithref' onclick=\"openEditEntitlements('" + full.WB_JOB_GUID + "','" + full.WELL_NM + "','" + full.CO_NM + "','" + full.FLDR_TYP_ID + "')\">" + data + "</a>";
    }
}
function openEditEntitlements(wJobID, wellName, company, selectedEntity) {
    IsEditEntitlements = true;
    WellName = wellName;
    AffiliatedCompany = company;
    GroupName = $("#txtGroupName").val();

    selectedfolder = selectedEntity;
    $("#dEditEntitlements").dialog('option', 'title', 'Edit Group Entitlements');
    $("#dEditEntitlements").dialog('open');
    wellJobID = wJobID;
    var param = "WBJobGuid='" + wJobID + Sep();
    GetXSpaceData(param, "GetWellDataByWBJobGuid_SP", SetSelectedWell);
}
function RemoveEntitlements() {
    IsEntitledGrid = true;

    if ($("#" + EntitlementsGridSettings.GridId).DataTable().row(".selected").length == 0) {
        $("#alert").html("Please select entitlement(s).").dialog('open');
    }
    else {
        $("#confirm").html("Are you sure to delete?").dialog('open');
    }
}
function initUI() {
    var param = "GroupGuid='" + qs("GroupID") + Sep();
    GetXSpaceData(param, "GetUserGroupByGuid_SP", function (data) {
        dbGroupName = data[0].USR_GRP_NM;
        $("#txtGroupName").val(data[0].USR_GRP_NM);
        $("#txtAffiliatedCompanyName").val(data[0].CO_NM);
    });
}

function populateUsers() {
    var param = "GroupGuid='" + qs("GroupID") + Sep();
    GetXSpaceData(param, UsersGridSettings.DataSource, populateUserGrid);
}
function populateUserGrid(data) {
    userGroupList = data;
    $("#" + UsersGridSettings.GridId).renderGrid(UsersGridSettings, data);
}
function populateEntitlements() {
    var param = "GroupGuid='" + qs("GroupID") + Sep();
    GetXSpaceData(param, EntitlementsGridSettings.DataSource, populateEntitlementsGrid);
}

function populateEntitlementsGrid(data) {
    for (var index = 0; index < data.length; index++)
        data[index].RecordStatus = "nochange";
    $("#" + EntitlementsGridSettings.GridId).renderGrid(EntitlementsGridSettings, data);
}
function DestoryDataTableIfExists(tabname) {
    if (tabname != undefined && tabname != "" && tabname == "usergroup") {
        if ($.fn.dataTable.isDataTable("#" + UsersGridSettings.GridId)) {
            var oTable1 = $("#" + UsersGridSettings.GridId).dataTable();
            $("#" + UsersGridSettings.GridId + "tbody").html("");
            oTable1.dataTable().fnDestroy();
        }
        IsEntitledGrid = false;
    }
    else {
        if ($.fn.dataTable.isDataTable("#" + EntitlementsGridSettings.GridId)) {
            var oTable2 = $("#" + EntitlementsGridSettings.GridId).dataTable();
            $("#" + EntitlementsGridSettings.GridId + "tbody").html("");
            oTable2.dataTable().fnDestroy();
        }
    }
}
function DestoryEntitlementsGrid() {
    if ($.fn.dataTable.isDataTable("#" + AvailableEntitlementsGridettings.GridId)) {
        var oTable1 = $("#" + AvailableEntitlementsGridettings.GridId).dataTable();
        $("#" + AvailableEntitlementsGridettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }

    if ($.fn.dataTable.isDataTable("#" + SelectedEntitlementsGridettings.GridId)) {
        var oTable2 = $("#" + SelectedEntitlementsGridettings.GridId).dataTable();
        $("#" + SelectedEntitlementsGridettings.GridId + "tbody").html("");
        oTable2.dataTable().fnDestroy();
    }
}
function SetControlVisibility() {
    $("#saveasdistrict").css("display", "none");
    $("#saveaswell").css("display", "none");
    $("#saveaspersonal").css("display", "none");
    if (qs("type") == "W") {
        $("#divWellName").css("display", "");
        $("#txtWellName").css("display", "");
        $("#imgSearchWell").css("display", "");
    }
    if (qs("type") == "D") {
        $("#dvDistrict").css("display", "");
        $("#ddlDistrict").css("display", "");
    }
    if (typeof (qs("DLID")) != 'undefined') {
        $("#saveasdistrict").css("display", "");
        $("#saveaswell").css("display", "");
        $("#saveaspersonal").css("display", "");
        $("#txtdlName").css("background-color", "#f0f0f0");
        $("#txtdlName").attr("readonly", "readonly");

        $("#ddlDistrict").css("background-color", "#f0f0f0");
        $("#ddlDistrict").attr("disabled", "disabled");

        $("#txtWellName").css("background-color", "#f0f0f0");
        $("#txtWellName").attr("readonly", "readonly");

        $("#ddlPSL").css("background-color", "#f0f0f0");
        $("#ddlPSL").attr("disabled", "disabled");
    }
}
function AddGroupUser(sourceGridID) {
    personnelsGridSettings.RowSelectionStyle = "Checkbox";
    personnelsGridSettings.RowSelectionType = "Multiple";
    allPersonnelsGridSettings.RowSelectionStyle = "Checkbox";
    allPersonnelsGridSettings.RowSelectionType = "Multiple";
    PopulateRecipients(sourceGridID, null, false, qs("CompanyID"));
    
    var currentLength= $("#" + UsersGridSettings.GridId).DataTable().rows().data().length;
    $("#dialog-personnel").dialog("open");
    $('#dialog-personnel').unbind('dialogclose');
    $('#dialog-personnel').bind('dialogclose', function(event) {
     var newLength=$("#" + UsersGridSettings.GridId).DataTable().rows().data().length;
     if(newLength>currentLength)
     {
          IsDirty = true;
          $("#save").attr("src", "../images/save_dirty_24x24.png");
     }
 });
}

var gridId;
function RemoveGroupUsers(sourceGridID) {
    gridId = sourceGridID;
    var table = $("#" + sourceGridID).DataTable();
    if (table.row('.selected').length > 0) {
        $("#confirm").html("Are you sure to delete selected user(s)?").dialog("open");
    }
    else {
        $("#alert").html("Please select user(s) to delete.").dialog("open");
    }
}

function populateEmptyAvailableSelectedEntitlements() {
    $("#" + AvailableEntitlementsGridettings.GridId).renderGrid(AvailableEntitlementsGridettings, []);
    $("#" + SelectedEntitlementsGridettings.GridId).renderGrid(SelectedEntitlementsGridettings, []);
}
var availableEntitlements = [];
var allFolders=[];
function GetAllFolders()
{
    GetXSpaceData("", "GetFolderType_SP", function (data) {
        allFolders = data;
    });
}
function deleteFolderFromAvailable(folderAvailableList,folder) {
    for (var i = 0; i < folderAvailableList.length; i++)
    {
        if (folderAvailableList[i].FLDR_TYP_ID == $.trim(folder)) {
            folderAvailableList.splice(i, 1);
            break;
        }
    }
    return folderAvailableList;
}
function populateAvailableEntitlements() {
    var param="";
    var proc="GetFolderType_SP";
    if (USERROLE == USERROLE_TYPE.PSLAdministrator)
    {
        param = "UserID='" + USERID + "'";
        proc="GetAdminFolderAssociated_SP";
    }
    
    GetXSpaceData(param, proc, function (data) {
        availableEntitlements =$.extend( {}, data) ;
        folderfullList = data;
        folderAvailableList = data
        folderSelectedList = [];
        if (selectedfolder != null && selectedfolder != "") {
            var selectedfolderList = selectedfolder.split(",");
            for (var selectedListCount = 0; selectedListCount < selectedfolderList.length; selectedListCount++) {
                if (allFolders.length > 0) {
                    for (var i = 0; i < allFolders.length; i++) {
                        if (allFolders[i].FLDR_TYP_ID == $.trim(selectedfolderList[selectedListCount])) {
                            var item = new Object();
                            item.FLDR_TYP_ID = allFolders[i].FLDR_TYP_ID;
                            item.FLDR_TYP_NM = allFolders[i].FLDR_TYP_NM;
                            folderSelectedList.push(item);
                        }
                    }
                }
                folderAvailableList = deleteFolderFromAvailable(folderAvailableList, selectedfolderList[selectedListCount]);
                
            }
        }

        DestoryEntitlementsGrid();
        $("#" + AvailableEntitlementsGridettings.GridId).renderGrid(AvailableEntitlementsGridettings, folderAvailableList);
        $("#" + SelectedEntitlementsGridettings.GridId).renderGrid(SelectedEntitlementsGridettings, folderSelectedList);
        if (selectedfolder != null && selectedfolder != "" && USERROLE == USERROLE_TYPE.PSLAdministrator) {
            $("#" + SelectedEntitlementsGridettings.GridId).DataTable().rows().iterator('row', function (context, index) {
                if (!IsEntitelementExists(folderSelectedList[index].FLDR_TYP_ID)) {
                    $(this.row(index).node()).find("input[type=checkbox]").remove();
                }
            });
        }
         $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
         $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
    });
}
function IsEntitelementExists(folder)
{
    var flag = false;
    $.each(availableEntitlements, function (key, value) {
        if (value.FLDR_TYP_ID == folder) {
            flag = true;
            return false;
        }
    });    
    return flag;
}
function DeleteUserGroupData(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var param = "GroupGuid='" + qs("GroupID") + Sep() + "GroupUserGuid='" + data[i].USR_GUID + Sep() + "UserID='" + USERID + Sep();
            GetXSpaceData(param, "DeleteUserGroupUser_SP", undefined);
        }
    }
}

function DeleteEntitlementGroupData(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var folderTypeIDs = data[i].FLDR_TYP_ID.split(",");
            for (var index = 0; index < folderTypeIDs.length; index++) {
                var param = "GroupGuid='" + qs("GroupID") + Sep() + "WBJobGuid='" + data[i].WB_JOB_GUID + Sep() + "FolderID='" + $.trim(folderTypeIDs[index]) + Sep() + "UserID='" + USERID + Sep();
                GetXSpaceData(param, "DeleteUserGroupEntitlements_SP", undefined);
            }
        }
    }
}

function InsertItemsGroup(groupId, affiliatedCompany, isSaveAs) {
    var isSaveAs = false;
    var saveGroupGUI = "";

    if (groupId != undefined && groupId != "") {	//Save as logic
        isSaveAs = true;
        saveGroupGUI = groupId;
    }
    else {
        saveGroupGUI = qs("GroupID");
        //delete user group item
        DeleteUserGroupData(deletelistforUser);
        //delete entitlement items
        DeleteEntitlementGroupData(deletelistforEntitlement)
        deletelistforUser = [];
        deletelistforEntitlement = [];

        // if groupName changed then update
        if ($.trim($("#txtGroupName").val()) != $.trim(dbGroupName))
            UpdateUserGroupName(saveGroupGUI, $.trim($("#txtGroupName").val()), USERID);
    }
    //insert group items
    var groupUsers = $("#" + UsersGridSettings.GridId).DataTable().rows().data();
    if (typeof (groupUsers) != 'undefined' && groupUsers.length > 0) {
        for (var i = 0; i < groupUsers.length; i++) {
            Reciepentitem = groupUsers[i];
            if (isSaveAs || (groupId != Reciepentitem.USR_GRP_ASGMNT_GUID == undefined || Reciepentitem.USR_GRP_ASGMNT_GUID == "")) {
                var param = "GroupGuid=" + "'" + saveGroupGUI + "'%26" + "GroupUserGuid=" + "'" + groupUsers[i].USR_GUID + "'%26" + "UserID='" + USERID + Sep();
                var data = GetXSpaceData(param, "InsertUserGroupUser_SP", UpdateUserReciepent);
            }
        }
    }

    // insert entitlement items
    var groupentitlement = $("#" + EntitlementsGridSettings.GridId).DataTable().rows().data();
    if (typeof (groupentitlement) != 'undefined' && groupentitlement.length > 0) {
        for (var i = 0; i < groupentitlement.length; i++) {
            EntitleItem = groupentitlement[i];
            if (isSaveAs || (EntitleItem.RecordStatus == undefined || EntitleItem.RecordStatus == "new")) {
                var folderTypeIDs = EntitleItem.FLDR_TYP_ID.split(",");
                for (var index = 0; index < folderTypeIDs.length; index++)
                    InsertUserGroupEntitlements(saveGroupGUI, EntitleItem.WB_JOB_GUID, folderTypeIDs[index], USERID)
            }
            else if (!isSaveAs && EntitleItem.RecordStatus != "nochange") {
                checkUpatedEntitlement(EntitleItem, saveGroupGUI);
            }
        }
    }
    IsDirty=false;
}

function checkUpatedEntitlement(entitleItem, saveGroupGUI) {
    var dbEntitlementList = entitleItem.RecordStatus.split(",");
    var newEntitlement = entitleItem.FLDR_TYP_ID.split(",");
    // delete existing items
    for (var index = 0; index < dbEntitlementList.length; index++) {
        var param = "GroupGuid='" + qs("GroupID") + Sep() + "WBJobGuid='" + entitleItem.WB_JOB_GUID + Sep() + "FolderID='" + $.trim(dbEntitlementList[index]) + Sep() + "UserID='" + USERID + Sep();
        GetXSpaceData(param, "DeleteUserGroupEntitlements_SP", undefined);
    }

    // insert new items
    for (var index = 0; index < newEntitlement.length; index++) {
        InsertUserGroupEntitlements(saveGroupGUI, entitleItem.WB_JOB_GUID, newEntitlement[index], USERID);
    }
}
function UpdateUserGroupName(GroupGuidID, newName, saveUserID) {
    var param = "GroupGuid=" + "'" + GroupGuidID + "'%26" + "Name=" + "'" + newName + "'%26" + "UserID='" + saveUserID + Sep();
    GetXSpaceData(param, "UpdateUserGroup_SP", undefined);
}

function InsertUserGroupEntitlements(GroupGuid, WBJobGuid, FolderID, UserID) {
    var param = "GroupGuid='" + GroupGuid + "'%26" + "WBJobGuid='" + WBJobGuid + "'%26" + "FolderID='" + $.trim(FolderID) + "'%26" + "UserID='" + UserID + Sep();
    GetXSpaceData(param, "InsertUserGroupEntitlements_SP", UpdateEntitleReciepent);
}

function UpdateUserReciepent(data) {
    if (data.length > 0) {
        Reciepentitem.USR_GRP_ASGMNT_GUID = data.EXTNL_RCPT_GUID;
    }
}

function UpdateEntitleReciepent(data) {
    if (data.length > 0) {
        EntitleItem.RecordStatus = "nochange";
    }
}

function AddNewEntitlement() {
     IsDirty = true;
     $("#save").attr("src", "../images/save_dirty_24x24.png");
    var selectedEntitlementFolder = "";
    var selectedEntitlementFolderID = "";
    var selectedEntTable = $("#" + SelectedEntitlementsGridettings.GridId).DataTable();
    var rows = selectedEntTable.rows();
    var data = rows.data();
    var dbFolderTypeID = entitlementRow.FLDR_TYP_ID;
    for (var i = 0; i < data.length; i++) {
        selectedEntitlementFolder += data[i].FLDR_TYP_NM + ",";
        selectedEntitlementFolderID += data[i].FLDR_TYP_ID + ",";        
    }
    if (selectedEntitlementFolder != "") {
        entitlementRow.FLDR_TYP_NM = selectedEntitlementFolder.substr(0, selectedEntitlementFolder.length - 1);
        entitlementRow.FLDR_TYP_ID = selectedEntitlementFolderID.substr(0, selectedEntitlementFolderID.length - 1);
        if (!IsEditEntitlements) {
            entitlementRow.RecordStatus = "new";
            $('#' + EntitlementsGridSettings.GridId).DataTable().row.add(entitlementRow).draw(false);
        } else {
            var data = $("#" + EntitlementsGridSettings.GridId).DataTable().rows().data();
            for (var i = 0; i < data.length; i++) {
                if (data[i].WB_JOB_GUID == entitlementRow.WB_JOB_GUID) {
                    if (data[i].RecordStatus == "nochange")
                        data[i].RecordStatus = dbFolderTypeID;

                    data[i].FLDR_TYP_NM = entitlementRow.FLDR_TYP_NM;
                    data[i].FLDR_TYP_ID = entitlementRow.FLDR_TYP_ID;
                    break;
                }
            }
            DestoryDataTableIfExists("entitlement");
            $("#" + EntitlementsGridSettings.GridId).renderGrid(EntitlementsGridSettings, data);
        }

    }
}

function SetDirtyFilter()
{
    IsDirty = true;
    $("#save").attr("src", "../images/save_dirty_24x24.png");  
}

function redirecttoSourcePage() {
    if (typeof (qs("WBGuid")) != "undefined") {
        sessionStorage.setItem('well-tab-index', null);
        window.location.href = "/_layouts/15/XSP/Pages/download.aspx?operation=2&WBGuid=" + qs("WBGuid");
    }	
    else if (typeof (qs("CompanyID")) != "undefined" && typeof(qs("GroupID"))!="undefined" && ((typeof(qs("Page"))!="undefined") && qs("Page")=="EditCompany")) {
        sessionStorage.setItem('well-tab-index', null);
        window.location.href = "/_layouts/15/XSP/Pages/EditCompany.aspx?tab=G&CompanyID=" + qs("CompanyID");
    }
        else if(typeof(qs("editUser"))!="undefined" && qs("editUser")!=null && qs("editUser") != "")
                window.location.href = "/_layouts/15/XSP/Pages/Settings.aspx?UserID=" + qs("editUser") + "&tab=g";
    else
        window.location.href = "/_layouts/15/XSP/Pages/Groups.aspx";
}

function isWellExist(wellName){
    var isExist=false;	
     var data = $("#" + EntitlementsGridSettings.GridId).DataTable().rows().data();
            for (var i = 0; i < data.length; i++) {
                if (data[i].WELL_NM == wellName) { 
                    isExist=true;				
                    break;
                }
            }
    return isExist;
}