﻿var companyGridSettings = {
    GridId: "companiesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    PagingCount: 20,  
    DataSource: "GetCompanyList_SP",
    DataSourceParam: "",
    ColumnCollection: [{
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        renderAction: "editCompany",
                        DataIndex: 1,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Location",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "ADDR_1",
                        DataIndex: 2,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Type",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_TYP_NM",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Operating Countries",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_LIST",
                        DataIndex: 4,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "PSLs",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "PSL_CNT",
                        renderAction: "editPSL",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Users",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "USR_CNT",
                        renderAction: "editUsers",
                        DataIndex: 6,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Groups",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "GRP_CNT",
                        renderAction: "editGroups",
                        DataIndex: 7,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Wells",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "WELL_CNT",
                        renderAction: "editWells",
                        DataIndex: 8,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddCompany",
            Action: "AddCompany",
            Icon: "create_32x32.png",
            Text: "AddCompany",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteCompany",
            Action: "DeleteCompany",
            Icon: "delete_32x32.png",
            Text: "DeleteCompany",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearFilter",
            Action: "clearFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};