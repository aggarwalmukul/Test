﻿
var globalGridSettings = [];

(function ($) {
    $.fn.renderGrid = function (gridSettings, data) {

        $.fn.gridSettings = gridSettings;
        globalGridSettings[gridSettings.GridId] = gridSettings;
        var columns = getColumns(gridSettings);
        this.DataTable({
            //"bDeferRender":true,
            "bFilter": true,
            "bPaginate": gridSettings.Paging,
            "bSort": true,
            "bLengthChange": false,
            "iDisplayLength": gridSettings.PagingCount,
            "scrollY": gridSettings.ScrollYHeight,
            "scrollX": false,
            "order": getDefaultColumnSort(gridSettings),
            data: data,
            columns: columns,
            "createdRow": function (row, data, index) {
                if (typeof (gridSettings.GreyRowDataProperty) != "undefined" && gridSettings.GreyRowDataProperty != null) {
                    if (typeof (data[gridSettings.GreyRowDataProperty]) != "undefined" && data[gridSettings.GreyRowDataProperty] == true) {
                        $(row).attr("disabled", true);
                        if (typeof (gridSettings.GreyRowCss) != "undefined") {
                            $(row).addClass(gridSettings.GreyRowCss);
                        }
                    }
                }                
            },
            "fnDrawCallback": function (oSettings) {              
                if ($("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead tr[id='_filterRow']").length == 0) {
                    if (gridSettings.FilterRow.Visible == true) {
                        addFilterRow(gridSettings, this.find("thead tr").clone());
                    }
                }
            
                //// set toolbar width according to datatable header
                //$("#" + gridSettings.GridId + "toolbar").width($("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollHeadInner").width() + "px");
                //// set row hover on datattable
                $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollBody").find("table td").bind('mouseenter', function () { $(this).parent().children().each(function () { $(this).addClass('datatablerowhighlight'); }); });
                $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollBody").find("table td").bind('mouseleave', function () { $(this).parent().children().each(function () { $(this).removeClass('datatablerowhighlight'); }); });
            },
            "fnInitComplete": function (oSettings) {
                if (gridSettings.RowSelectionStyle == "Checkbox") {
                    var sel = gridSettings.RowSelectionStyle == "Checkbox" ? " <input type=\"checkbox\" class=\"selectall\">" : "";                    
                    $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead tr:last").find("th:first").html(sel).addClass("cHeader");
                }
                //// show ellipsis on long text when column name contains comments
                var colWidth = $("#" + gridSettings.GridId).find("thead tr:last").find("th:contains('Comments')").width();
                if (gridSettings.GridId.indexOf("_grid") != -1 || gridSettings.GridId == "recyclebinGrid")
                {
                    colWidth = $("#" + gridSettings.GridId).find("thead tr:last").find("th:contains('Comments')").width();
                    colWidth = colWidth - 6;
                    if (colWidth <= 10)
                        colWidth = 81;

                }
                if (colWidth == null) {
                    colWidth = $("#" + gridSettings.GridId).find("thead tr:last").find("th:contains('Description')").width();
                    colWidth = colWidth - 6;
                    if (colWidth <= 10)
                        colWidth = 81;
                }
                $("#" + gridSettings.GridId).find("tbody tr").find("div.ellipsis").width((colWidth - 16) + "px");
            },
            "error": function (xhr, textStatus, thrownError) {
                alert("An error occurred on the server while trying to complete the action. The error has been sent to the maintenance team. Please try again later.");
                var reqParams = new Hashtable();
                reqParams.put('Parameters', 'Parameter not available.');
                LoggingException(xhr, "GetWellData", reqParams);
            }
        });

        //to check uncheck all input box
        $('.selectall').click(function (event) {  //on click            
            // var gridid = $(this).closest("table").attr("id");
            var gridid = $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollBody").find("table").attr("id");
            var aData = '';
            var data = '';
            var hdnfieldvalue = '';
            var selectedFileIDList = $('#hdn' + gridSettings.GridId + 'SelectedIDList').val();

            if (this.checked) { // check select status
                $('.rowselect', "#" + gridid).each(function () { //loop through each checkbox                  
                    aData = $('#' + gridSettings.GridId).dataTable().fnGetData(this.parentNode.parentNode);
                    hdnfieldvalue = $('#hdn' + gridSettings.GridId + 'Field').val();
                    if (hdnfieldvalue != null && hdnfieldvalue != "") {
                        data = aData[hdnfieldvalue];
                        if ($(this).is(':checked')) {
                        }
                        else {
                           
                                $(this).attr("checked", "checked");
                                selectedFileIDList = $('#hdn' + gridSettings.GridId + 'SelectedIDList').val();
                                selectedFileIDList = selectedFileIDList + data + "$";
                                $('#hdn' + gridSettings.GridId + 'SelectedIDList').val(selectedFileIDList);                           
                        }
                    }
                    if (!$(this).closest("tr").is(":disabled")) {
                        if ($(this).prop("disabled") == false) {
                            this.checked = true;  //select all checkboxes with class "rowselect"   
                            $(this).closest("tr").addClass("selected");
                        }
                    }
                });
            } else {
                $('.rowselect', "#" + gridid).each(function () { //loop through each checkbox
                    aData = $('#' + gridSettings.GridId).dataTable().fnGetData(this.parentNode.parentNode)
                    hdnfieldvalue = $('#hdn' + gridSettings.GridId + 'Field').val();
                    if (hdnfieldvalue != null && hdnfieldvalue != "") {
                        data = aData[hdnfieldvalue];
                        if ($(this).is(':checked')) {
                            $(this).removeAttr("checked", "checked");
                            selectedFileIDList = $('#hdn' + gridSettings.GridId + 'SelectedIDList').val();
                            selectedFileIDList = selectedFileIDList.replace(data + "$", "");
                            $('#hdn' + gridSettings.GridId + 'SelectedIDList').val(selectedFileIDList);
                        }
                    }
                    if (!$(this).closest("tr").is(":disabled")) {
                        this.checked = false; //deselect all checkboxes with class "rowselect"
                        $(this).closest("tr").removeClass("selected");
                    }
                });
            }
            event.stopImmediatePropagation();

        });

        if (gridSettings.RowSelectionStyle == "Checkbox" || gridSettings.RowSelectionStyle == "RadioButton") {
            $('#' + gridSettings.GridId).on("click", " input.rowselect", function () {
                if (gridSettings.RowSelectionStyle == "RadioButton") {
                    $("#" + gridSettings.GridId).find("tbody tr").removeClass("selected");
                    $(this).closest("tr").addClass("selected");
                }
                if (gridSettings.RowSelectionStyle == "Checkbox") {
                    var aData = $('#' + gridSettings.GridId).dataTable().fnGetData(this.parentNode.parentNode);
                    var hdnfieldvalue = $('#hdn' + gridSettings.GridId + 'Field').val();
                    if (hdnfieldvalue != null && hdnfieldvalue != "") {
                        var Data = aData[hdnfieldvalue];
                        //Create a hidden field and save the value....
                        var selectedFileIDList = $('#hdn' + gridSettings.GridId + 'SelectedIDList').val();
                        if ($(this).is(':checked')) {
                            if (selectedFileIDList == '') {
                                selectedFileIDList = Data + "$";
                                $('#hdn' + gridSettings.GridId + 'SelectedIDList').val(selectedFileIDList);
                            }
                            else {

                                selectedFileIDList = $('#hdn' + gridSettings.GridId + 'SelectedIDList').val();
                                selectedFileIDList = selectedFileIDList + Data + "$";
                                $('#hdn' + gridSettings.GridId + 'SelectedIDList').val(selectedFileIDList);
                            }
                        }
                        else {
                            //Write Uncheck code....
                            selectedFileIDList = selectedFileIDList.replace(Data + "$", "");
                            $('#hdn' + gridSettings.GridId + 'SelectedIDList').val(selectedFileIDList);
                        }

                    }
                    if (gridSettings.RowSelectionType == "Single") {
                        $("#" + gridSettings.GridId).find("tbody tr").removeClass("selected");
                        var checkstate = $(this)[0].checked
                        $("#" + gridSettings.GridId).find("tbody tr input.rowselect").attr("checked", false);
                        $(this)[0].checked = checkstate;
                        $(this).closest("tr").addClass("selected");
                    }
                    if (gridSettings.RowSelectionType == "Multiple") {
                        $(this).closest("tr").addClass("selected");
                    }
                    if ($(this)[0].checked == false) {
                        $(this).closest("tr").removeClass("selected");
                    }
                }
                if (gridSettings.RowSelectionStyle == "Row") {
                    if (gridSettings.RowSelectionType == "Single") {
                        $("#" + gridSettings.GridId).find("tbody tr").removeClass("selected");
                        $(this).closest("tr").addClass("selected");
                    }
                    else {
                        $(this).closest("tr").addClass("selected");
                    }

                }

                if ($(".rowselect", "#" + gridSettings.GridId + "_wrapper").length == $(".rowselect:checked", "#" + gridSettings.GridId + "_wrapper").length) {
                    $(".selectall", "#" + gridSettings.GridId + "_wrapper").prop("checked", true);
                } else {
                    $(".selectall", "#" + gridSettings.GridId + "_wrapper").removeAttr("checked");
                }
            });
        }
        else {
            $("#" + gridSettings.GridId).on("click", "tbody tr", function () {
                if (gridSettings.RowSelectionStyle == "Row") {
                    if (gridSettings.RowSelectionType == "Single") {
                        $("#" + gridSettings.GridId).find("tbody tr").removeClass("selected");
                        $(this).closest("tr").addClass("selected");
                    }
                    else {
                        $(this).toggleClass('selected');
                    }

                }
            });
        }

        renderToolbar(gridSettings);

        $(".dataTables_filter").hide();

        appendCommentsDialog();
        $(".dataTables_scrollBody").css("overflow-x", "hidden");
        return this;
    };

    function addFilterRow(gridSettings, row) {
        $(row).attr("id", "_filterRow");
        $(row).find("th").html("&nbsp;").attr("class", "");
        for (var i = 0; i < gridSettings.ColumnCollection.length; i++) {
            if (gridSettings.ColumnCollection[i].IsFilterable) {
                var index;
                index = gridSettings.ColumnCollection[i].DataIndex + 1;
                $(row).find("th").eq(index - 1).html("<input type='text' id='txt" + gridSettings.ColumnCollection[i].data + "' index='" + (index - 1) + "'/>");
            }
        }
        if (typeof (gridSettings.IsScrollY) != "undefined" && gridSettings.IsScrollY == true) {
            $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead").prepend(row);
        }
        else {
            $("#" + gridSettings.GridId).find("thead").prepend(row);
        }
    }

    function getColumns(gridSettings) {
        var columns = [];

        if (typeof (gridSettings.ColumnCollection) !== undefined) {
            if (gridSettings.ColumnCollection.length > 0) {
                for (var i = 0; i < gridSettings.ColumnCollection.length; i++) {
                    var column = new Object();
                    column.sTitle = gridSettings.ColumnCollection[i].Name;
                    column.targets = i;
                    column.DataIndex = gridSettings.ColumnCollection[i].DataIndex;
                    column.data = gridSettings.ColumnCollection[i].data;
                    column.searchable = gridSettings.ColumnCollection[i].IsFilterable;
                    column.sortable = gridSettings.ColumnCollection[i].IsSortable;
                    column.width = gridSettings.ColumnCollection[i].Width;
                    if (typeof (gridSettings.ColumnCollection[i].CssClass) != "undefined") {
                        column.sClass = gridSettings.ColumnCollection[i].CssClass;
                    }

                    if (typeof (gridSettings.ColumnCollection[i].renderAction) != "undefined") {
                        var fn = window[gridSettings.ColumnCollection[i].renderAction];
                        column.render = fn;
                    }
                    columns.push(column);
                }

                if (gridSettings.RowSelectionStyle == "Checkbox" || gridSettings.RowSelectionStyle == "RadioButton") {
                    var column = new Object();
                    column.sTitle = "";
                    //column.targets = 0;
                    column.DataIndex = 0;
                    column.searchable = false;
                    column.sortable = false;
                    column.width = "3%";
                    column.sClass = "cText";
                    var fn = window["renderRowCheckbox"];
                    column.render = fn;
                    columns.unshift(column);
                }

            }
        }

        return columns.sort(comparator);
    }
    function getDefaultColumnSort(gridSettings) {
        if (gridSettings.DefaultColumnSort >= 0) {
            var a = [];
            var b = [];
            b.push(gridSettings.DefaultColumnSort)
            b.push(gridSettings.DefaultColumnSortOrder)
            a.push(b)
            return a;
        }
        return [];
    }
    function comparator(a, b) {
        return parseInt(a["DataIndex"]) - parseInt(b["DataIndex"]);
    }
    function checkboxColumn(data, type, full) {
        return '<input type="checkbox" class="editor-active">';
    }


    function renderToolbar(gridSettings) {
        var ele;
        if (typeof (gridSettings.ToolbarCollection) !== undefined) {
            if (gridSettings.ToolbarCollection.length > 0) {
                for (var i = 0; i < gridSettings.ToolbarCollection.length; i++) {
                    var toolbar = gridSettings.ToolbarCollection[i];
                    if (toolbar.Visible == true) {
                        for (var j = 0; j < toolbar.ButtonCollection.length; j++) {
                            var button = toolbar.ButtonCollection[j];
                            if (button.Visible == true) {
                                if (button.Appearance == "Icon") {
                                    ele = "<img id='" + button.Name + "' src='../images/" + button.Icon + "' title='" + button.Text + "' style='cursor:pointer;height:24px; width:24px;' onclick='" + button.Action + "(\"" + gridSettings.GridId + "\");return false;'/>";
                                }
                                else {
                                    ele = "<button id='" + button.Name + "' value='" + button.Text + "' style='cursor:pointer;' onclick='" + button.Action + "();return false;'>" + button.Text + "</button>";
                                }
                            }

                            if ($("#" + gridSettings.GridId + "toolbar").find("#" + button.Name).length == 0) {
                                $("#" + gridSettings.GridId + "toolbar").append(ele);
                            }
                        }

                        if (toolbar.Title !== undefined) {
                            ele = "<div class='toolbarTitle'>" + toolbar.Title + "</div>";
                            $("#" + gridSettings.GridId + "toolbar").append(ele);
                        }

                    }
                }
            }
        }
    }


}(jQuery));



function searchFilter() {
    gridSettings = $.fn.gridSettings;

    var table = $("#" + gridSettings.GridId).DataTable();
    $("#" + gridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead  tr[id='_filterRow']").find("th").find("input").each(function () {
        table.column($(this).attr("index")).search($(this).val());
    });
    table.draw();
}
function go() {
    alert("go clicked");
}

function round(num, precision) {
    return Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision);
}

function RenderNewFileActions(data, type, full, meta) {
    var hreflink = "/_layouts/XSP/pages/NewFiles.aspx" + "?WBJobGuid=" + full.WB_JOB_GUID + "&" +
        "WBGuid=" + full.WB_JOB_GUID;
    return "<a href=" + hreflink + " style='color:red;text-decoration:none;' >" + data + "</a>";
}

function GenerateFormattedSize(data, type, full, meta) {
    return round(full.FILE_SZ_VAL, 2);
}

function RoundOffSize(data, type, full, meta) {
    return round(full.Size, 2);
}

function renderComment(data, type, full, meta) {
    var gid = meta.settings.sTableId;
    gridSettings = globalGridSettings[gid];

    //return "<div class='ellipsis' style='width: 50px; padding-left:5px;' title=' " + data + "'>" + data + "</div><img src='../images/comment_32x32.png' style='cursor:pointer; float:right;width:16px;height:16px;' onclick='openCommentDialog(\"" + event + "\"" + ',' + "\"" + this + "\", \"" + gridSettings.GridId + "\");'/>";
    

    return "<div class='ellipsis' style='width: 50px; padding-left:5px;' title=' " + data + "'>" + data + "</div><img src='../images/comment_32x32.png' style='cursor:pointer; float:right;width:16px;height:16px;' onclick='openCommentDialog(event, this,\"" + gridSettings.GridId + "\");'/>";
}

function renderEdit(data, type, full, meta) {
    return "<img src='../images/edit.png' height='14' width='14' style='cursor:pointer;' onclick='OpenEditDialog(\"" + meta.row + "\");'/>";
}
function renderCheckbox(data, type, full, meta) {
    if (data == true)
        return "<input type='checkbox' checked/>";
    return "<input type='checkbox' />";
}

function renderDSDropBoxCheckbox(data, type, full, meta) {
    return "<input type='checkbox' class='d_rowselect'/>";
}

function renderDSEmailCheckbox(data, type, full, meta) {
    return "<input type='checkbox' class='e_rowselect'/>";
}

function appendCommentsDialog() {
    var dlgHTML = "<div id='dialog-comments' title='Comments' style='display: none;'><textarea readonly  rows='8' cols='60' style='vertical-align: top;' class='text ui-widget-content ui-corner-all' id='txtarea_comments'></textarea></div>";
    $("form:first").append(dlgHTML);

    $("#dialog-comments").dialog({
        modal: false,
        resizable: false,
        autoOpen: false,
        width: "auto",
        //dialogClass: "dlg-no-title",
        buttons: {
            "OK": function () {
                $(this).dialog("close");
            }
        }
    });
}


function openCommentDialog(event, me, sourceGridID) {
    var sourcetr;
    event = event || window.event;

    if (typeof (event.target) == "undefined") {
        sourcetr = $(event.srcElement).closest("tr");
    }
    else {
        sourcetr = $(event.target).closest("tr");
    }

    var data = $("#" + sourceGridID).DataTable().row(sourcetr).data();
    //alert("to do: show comment in dialog" + data);
    if (data.DATA_FILE_CMNT != "") {
        $("#txtarea_comments").val(data.DATA_FILE_CMNT);
        $("#dialog-comments").dialog("open");
    }
}

function formatPhoneNumber(data, type, full, meta) {
    return !data ?
        '' :
        typeof data === 'string' ?
             data.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3") :
            data;
}

function renderRowCheckbox(data, type, full, meta) {
    var gid = meta.settings.sTableId;
    gridSettings = globalGridSettings[gid];

    //gridSettings = $.fn.gridSettings;
    return (gridSettings.RowSelectionStyle == 'Checkbox' ? "<input type='checkbox' class='rowselect'/>" : "<input type='radio' name='rowselect' class='rowselect'>");

}

function GenerateRenderAction(data, type, full, meta) {

    return "<img src='/_layouts/15/xsp/Images/down_24x24.png' title='Download Files From Well' style='height:24px;width:24px;cursor:pointer; padding-right:7px;' onclick='RedirectToAnotherPage(\"" + data + "\");'/>" +
            "<img src='/_layouts/15/xsp/Images/up_24x24.png' title='Upload Files to Well' style='height:24px;width:24px;cursor:pointer; padding-right:2px;' onclick='RedirectToAnotherPageUpload( \"" + full.WB_JOB_GUID + "\"" + ',' + "\"" + full.WELL_NM + "\"" + ',' + "\"" + full.CO_NM + "\"" + ',' + "\"" + full.FLD_NM + "\");' />";
}

function GenerateNewFileColumn(data, type, full, meta) {
    return "New File";
}

function GenerateNullColumn(data, type, full, meta) {

    return "";
}

function GenerateRenderWellName(data, type, full, meta) {
    var redirect = "/_layouts/XSP/Pages/download.aspx?operation=4&WBGuid=" + full.WB_JOB_GUID;
    return "<a href=" + redirect + " style='color:blue;text-decoration:underline' onclick='RedirectToAnotherPage(\"" + full.WB_JOB_GUID + "\");' >" + data + "</a>";
}
function GenerateRenderWellDetails(data, type, full, meta) {
    var redirect = "/_layouts/XSP/Pages/download.aspx?operation=DETAIL&WBGuid=" + full.WB_JOB_GUID;
    return "<a href=" + redirect + " style='color:blue;text-decoration:underline' onclick='RedirectToWellDetail(\"" + full.WB_JOB_GUID + "\");' >" + data + "</a>";
}

function RedirectToAnotherPageUpload(WellGuid, WellName, Operator, FieldName) {
    var customWellName = Operator + " " + FieldName + " " + WellName;
    var w = PopupCenter("/_layouts/XSP/Pages/Upload.aspx?operation=1&WBGuid=" + WellGuid + "&WellName="
        + customWellName, '_blank', 1200, 450);

    w.document.title = "Well Upload - " + customWellName;
    //window.location.href = "/_layouts/XSP/Pages/Upload.aspx?operation=1&well=" + id;
    //window.location.href = "/_layouts/XSP/Pages/Upload.aspx?operation=1&well=" + id + "&" + "target=" + '"_new"';
}
function RedirectToAnotherPage(id) {
    sessionStorage.setItem('well-tab-index', null);
    window.location.href = "/_layouts/XSP/Pages/download.aspx?operation=4&WBGuid=" + id;
}
function RedirectToWellDetail(id) {
    sessionStorage.setItem('well-tab-index', null);
    window.location.href = "/_layouts/XSP/Pages/download.aspx?operation=0&WBGuid=" + id;
}
function deleteFile() {
    alert("delete");
}
function moveToFolder() {
    alert("moveToFolder");
}

function RenderDropBoxFileInfo(data, type, full, meta) {
    return "<img src='/_layouts/15/xsp/Images/file_info_16x16.png' height='16' width='16' style='cursor:pointer; padding-right:2px;' onclick='openZipDialog(this);'/>";
}


function RenderNewFileInfo(data, type, full, meta) {
    if (full.DATA_FILE_LNM.split('.').pop() == "zip") {
        var FileName = full.DATA_FILE_GUID;
        var folder = full.FLDR_TYP_NM;
        return "<img title='Zip File Contents' src='/_layouts/15/xsp/Images/file_info_16x16.png' height='16' width='16' style='cursor:pointer; padding-right:2px;' onclick='openZipDialog(\"" + FileName + "\"" + ',' + "\"" + folder + "\", \"" + full.FILE_PATH + "\");'/>";
    }
    else
        return "";
}

function RenderNewFilesDownloadLink(data, type, full, meta) {
    return GetFileDownloadlink(full.DATA_FILE_GUID, data);
}




