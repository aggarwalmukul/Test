﻿var IsDirty = false;
$(document).ready(function () {
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 300,
        buttons: {
            "Yes": function () {             			
                var data = $("#" + groupGridSettings.GridId).DataTable().rows(".selected").data();
                DeleteGroupData(data);
                var table = $("#" + groupGridSettings.GridId).DataTable();
                if (table.row('.selected').length > 0) {
                    table.row('.selected').remove().draw(false);
                }

                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 150,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    GetUserGuid(GetUserGUIDDetails);
    populateGroup();
    
    if ($("#clearFilter").length > 0)
        $("#clearFilter")[0].onclick = null;
    if ($("#AddGroup").length > 0)
        $("#AddGroup")[0].onclick = null;
    if ($("#DeleteGroup").length > 0)
        $("#DeleteGroup")[0].onclick = null;
    $("input").on("keyup", function () {
        if (!$(this).hasClass("edit")) {
            IsDirty = true;
            $("#clearFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
            if ($("#clearFilter").length > 0)
                $("#clearFilter")[0].onclick = null;
        }
        return false;
    });
    $("#clearFilter").on("click", function () {
        clearFilter();
    });
    $("#AddGroup").on("click", function () {
        AddGroup();
    });
    $("#DeleteGroup").on("click", function () {
        DeleteGroup();
    });
    $(document).on("saveAsEvent", {}, function (event, groupId, groupName, affiliatedCompany) {
        window.location.href = "/_layouts/15/XSP/Pages/CreateGroup.aspx?GroupID=" + groupId + "&CompanyID=" + affiliatedCompany;
    });
    $("input").val("");
});
function clearFilter() {
    IsDirty = false;
    $("#clearFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryDataTableIfExists();
    populateGroup();
}
function DestoryDataTableIfExists() {
    $("input").val("");
    if ($.fn.dataTable.isDataTable("#" + groupGridSettings.GridId)) {
        var oTable1 = $("#" + groupGridSettings.GridId).dataTable();
        $("#" + groupGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}
function populateGroup() {
     GetXSpaceData("", groupGridSettings.DataSource, function(data){
			 $("#" + groupGridSettings.GridId).renderGrid(groupGridSettings, data);
	  });   
}

function editGroup(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?GroupID=" + full.USR_GRP_GUID + "&CompanyID="+ full.CUST_ID + "'>" + full.USR_GRP_NM + "</a>";
}
function editUser(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=U&GroupID=" + full.USR_GRP_GUID + "&CompanyID=" + full.CUST_ID + "'>" + full.USR_CNT + "</a>";
}
function editEnt(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=E&GroupID=" + full.USR_GRP_GUID + "&CompanyID=" + full.CUST_ID + "'>" + full.ENTLMNT_CNT + "</a>";
}

function AddGroup() {
    $("#dialog-saveasgroup").data('param', "saveGroup").dialog('open');  
}

function DeleteGroup() {
    if ($("#" + groupGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#confirm").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#alert").html("Please select group to delete.").dialog('open');
    }
}

function DeleteGroupData(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var param = "GroupGuid='" + data[i].USR_GRP_GUID + Sep() + "UserID='" + USERID + Sep();
            GetXSpaceData(param, "DeleteUserGroup_SP", undefined);
        }
    }
}
$(window).keypress(function (e) {
    if (e.keyCode == 13) {
        searchFilter();
        return false;
    }
});