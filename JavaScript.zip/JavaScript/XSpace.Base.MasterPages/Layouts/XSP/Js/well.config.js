﻿var wellGridSettings = {
    GridId: "wellGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: true,
    PagingCount: 50,
    DataSource: "GetWellSearch_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [{
                        Name: "Actions",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WB_JOB_GUID",
                        DataIndex: 0,
                        renderAction: "GenerateRenderAction",
                        Width: "6%",
                        IsFilterable: true,
                        IsSortable: false
                    },
                    {
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        DataIndex: 1,
                        renderAction:"GenerateRenderWellName",
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    //{
                    //    Name: "New",
                    //    Visible: true,
                    //    Enabled: true,
                    //    DataType: "string",
                    //    Style: "Text", // Text,Image,Action,URL
                    //    CssClass: "cHeader cText",
                    //    HeaderVisible: true,
                    //    data: "FILE_COUNT",
                    //    DataIndex: 2,
                    //    renderAction: "RenderNewFileActions",
                    //    Width: "5%",
                    //    IsFilterable: true,
                    //    IsSortable: true
                    //},
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLD_NM",
                        DataIndex: 4,
                        Width: "5%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Country",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 5,                        
                        Width: "6%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "State/Province",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL1_NM",
                         DataIndex: 6,
                         Width: "10%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "County",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GEO_LVL2_NM",
                         DataIndex: 7,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "UWI/API",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "GOVT_ID_NUM",
                         DataIndex: 8,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "Updated",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 9,
                         Width: "8%",
                         IsFilterable: true,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddWell",
            Action: "AddWell",
            Icon: "create_32x32.png",
            Text: "AddWell",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Expand",
            Action: "ExpandFilter",
            Icon: "magnifying_glass_32x32.png",
            Text: "Expand Well Search",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "FilterManager",
            Action: "FilterManager",
            Icon: "filter_manager_24x24.png",
            Text: "Filter Manager",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearWFilter",
            Action: "ClearFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Well Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }//,
        //{
        //    Name: "Delete",
        //    Action: "RemoveFile",
        //    Icon: "delete_32x32.png",
        //    Text: "Delete",
        //    Appearance: "Icon", // (Text or Icon)
        //    Visible: true,
        //    Enabled: true
        //}
        ]
    }]
};
var filterGridSettings = {
    GridId: "filterGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    ColumnCollection: [{
        Name: "Filter Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "FLTR_NM",
        DataIndex: 0,
        Width: "100%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Rename",
            Action: "RenameWell",
            Icon: "edit.png",
            Text: "Rename",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "DeleteWell",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }]
    }]
};