﻿
 var fileListGridSettings = {
            GridId: "fileListGrid",
            RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
            RowSelectionType: "Multiple", // Multiple , Single
            DefaultColumnSort: -1, // positive column index, if no sort -1
            DefaultColumnSortOrder: "asc", // asc/desc
            IsScrollY: true,
            ScrollYHeight: "150px",
            ColumnCollection: [{
                Name: "File Name",
                Visible: true,
                Enabled: true,
                DataType: "string",
                Style: "Text", // Text,Image,Action,URL
                CssClass: "cHeader lText",
                HeaderVisible: true,
                data: "FileName",
                DataIndex: 0,
                Width: "60%",
                IsFilterable: true,
                IsSortable: true
            },
            {
                Name: "Size(MB)",
                Visible: true,
                Enabled: true,
                DataType: "string",
                Style: "Text", // Text,Image,Action,URL
                CssClass: "cHeader rText",
                HeaderVisible: true,
                data: "Size",
                DataIndex: 1,
                Width: "30%",
                IsFilterable: true,
                IsSortable: true
            }],
            FilterRow: {
                Visible: false,
                Enabled: true
            },
            ToolbarCollection: []
        };

        var machine;
        var folderpath;
        var driveGuid;
        var WellGuid;
        var FilePath;
        var foldername;

$(document).ready(function () {
    GetUserGuid(GetUserGUIDDetails);	
	var drives = GetStorageDrive(UpdateDrives);
            WellGuid = GetUrlParameter("WBGuid");            
            $("#fileInfo").dialog({
                autoOpen: false,
                modal: true,
                title: "File Info",
                height: 320,
                width: 500,
                open: function () {
                    var o = { Guid: FilePath };                 
                    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetFileList";
                      $.ajax({
                        url: urlstring,
                        type: "POST",
                        dataType: "json",
                        data: JSON.stringify(o),                       
                        contentType: "application/json; charset=utf-8",
                        error: function (errorThrown) {
                        },
                        success: function (dataFile) {
                            var temp = JSON.parse(dataFile.d);
                            $("#" + fileListGridSettings.GridId).renderGrid(fileListGridSettings, JSON.parse(dataFile.d));
                            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
                        },
                    });
                },
                close: function () {
                    var oTable = $("#" + fileListGridSettings.GridId).dataTable();
                    $("#" + fileListGridSettings.GridId + "tbody").html("");
                    oTable.dataTable().fnDestroy();
                },
                buttons: {
                    "Download": function () {
                        DownloadZipSelectedFiles();
                        $(this).dialog('close');
                    },
                    "Cancel": function () {
                        $(this).dialog('close');
                    }
                }
            });
			
	populateNewFileGrid();
});

function DestoryDataTableIfExists() {   
    if ($.fn.dataTable.isDataTable("#" + newFileGridSettings.GridId)) {
        var oTable1 = $("#" + newFileGridSettings.GridId).dataTable();
        $("#" + newFileGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}

function populateNewFileGrid() {
    var param = "WBJobGuid='" + WellGuid + Sep() + "UserID='" + USERID + Sep();
    GetXSpaceData(param, newFileGridSettings.DataSource, function (data) {
        $("#" + newFileGridSettings.GridId).renderGrid(newFileGridSettings, data);
        $("#" + newFileGridSettings.GridId).DataTable().rows().iterator('row', function ( context, index ) {
            if (data[index].FLDR_INDX == null)
            {
                $(this.row(index).node()).find("input[type=checkbox]").prop("disabled", true);
            }           
        });
    });
    
}       
        function UpdateDrives(data) {
            var drives = data;
             machine = drives[0].DRV_PATH;
            folderpath = "";
            driveGuid = drives[0].DRV_GUID;

        }	
		  
        function openZipDialog(fileName, folder) {
            FilePath = fileName;
            foldername = folder;
            $("#fileInfo").dialog("open");
        }

        function DownloadZipSelectedFiles() {
            var table = $("#" + fileListGridSettings.GridId).DataTable();
            if (table.row('.selected').length > 0) {
                var fileid;
                var FileNames = "";
                var data = $("#" + fileListGridSettings.GridId).DataTable().rows(".selected").data();
                for (var i = 0; i < data.length; i++) {
                    FileNames = FileNames + data[i].FileName + ",";
                    if (i == 0) {
                        fileid = data[i].FileGuid;
                    }
                }
                FileNames = FileNames.substring(0, FileNames.lastIndexOf(","));
                DownloadFile(fileid, false, FileNames);
                return false;
            }
            else {
                ShowCustomAlert("Please select file(s) to download." , "Alert", 300);               
            }
        }
        function DistributeSelectedFiles() {
            var data = $("#" + newFileGridSettings.GridId).DataTable().rows(".selected").data();
            if (data.length > 0) {
                DistributeData(data);
            }
            else {
                ShowCustomAlert("Please select file(s) to distribute.", "Alert", 300);                
                return;
            }
        }

        function DistributeSelectedFilesCallback(data)
        {
            var data = $("#" + newFileGridSettings.GridId).DataTable().rows(".selected").data();
        }

        function DownloadSelectedFiles(data) {
            var dataFiles = data;
            var GuidVal = $("#hdnGridViewNewFilesSelectedIDList").val();
            var SelectedGuidArray = GuidVal.split("$")
            var FileGuids = [];		
            var guids = "";// = "Guid1,Guid2,Guid3";
            var fileid = "";
            var folderid = "";
            var fileName = "";
            var FileNames = "";
			var data=$("#" + newFileGridSettings.GridId).DataTable().rows(".selected").data();
			

            for (var i = 0 ; i < dataFiles.length; i++) {
                for (var j = 0; j < SelectedGuidArray.length; j++) {
                    if (SelectedGuidArray[j] == dataFiles[i].DATA_FILE_GUID) {
                        fileid = dataFiles[i].DATA_FILE_GUID;
                        folderid = dataFiles[i].FLDR_TYP_NM;
                        fileName = dataFiles[i].DATA_FILE_LNM;
                        FileGuids.push(fileid);

                        if (guids != "") {
                            guids = guids + ",";
                            FileNames = FileNames + ",";
                        }
                        guids = guids + folderid;
                        FileNames = FileNames + fileName;
                        break;

                    }

                }

            }

            DownloadAndLogAudit(guids, WellGuid, FileGuids, machine, FileNames, "Well");
        }        
        function DownloadDropBoxSelectedFiles()
        {
		   var hdnGuid="";
		   var data = $("#" + newFileGridSettings.GridId).DataTable().rows(".selected").data();
		   if (data.length > 0) {
		       for (var i = 0; i < data.length; i++)
		           hdnGuid = hdnGuid + data[i].DATA_FILE_GUID + "$";
		       if (hdnGuid != "" && hdnGuid.length > 0)
		           hdnGuid = hdnGuid.substr(0, hdnGuid.length - 1);
		       $("#hdnGridViewNewFilesSelectedIDList").val(hdnGuid);
		       var GuidVal = $("#hdnGridViewNewFilesSelectedIDList").val();
		       var SelectedGuidArray = GuidVal.split("$")
		       GetWellFiles(WellGuid, "GetDataFilesNewByWBJob_SP", DownloadSelectedFiles);
		   }
		   else {
		       ShowCustomAlert("Please select file(s) to download.", "Alert", 300);
		       return;
		   }
        }