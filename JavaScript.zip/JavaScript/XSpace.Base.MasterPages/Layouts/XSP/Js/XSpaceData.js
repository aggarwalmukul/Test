var WebServiceURL = getAppURL() + "/_vti_bin/XSpace/XSpaceLogging.svc";

var DSTGUID;
var fileGUID;
var UserGUID;
var USERID;
var WellDetails;
var DataServiceUrl = "";
var TextNotificationServiceUrl = "";
var dirtyActiveWellData = false;
var USERROLE;
var USERROLE_TYPE = {
    "CustomerAdministrator": "CUSTADM", "CustomerUser": "CUSTUSER",
    "InternalUser": "INTUSER", "PSLAdministrator": "PSLADM",
    "RegionAdministrator": "REGADM", "SystemAdministrator": "SYSADM", "QA Tester": "TST"
};
var StorageDriveStatus = "true";
/*Logging Exception Functionality*/


function GetDataServieUrl()
{  
    if (DataServiceUrl == "")
        GetDataService();
    return DataServiceUrl;
    }

function GetTextServiceUrl()
    {
    if (TextNotificationServiceUrl == "")
        GetTextService();
    return TextNotificationServiceUrl;
}
function IsValidAuthCookies()
{
    var ck = readCookie("CUID");
    if (ck == null)
        window.location.href = getAppURL() + "/_layouts/xsp/pages/home.aspx";
}

function LoggingException(xhr, methodName, reqParams) {
    
    
    var div = document.createElement('div');
    div.innerHTML = xhr.responseText;
    var responseText = div.innerText;
    var keys = reqParams.keys();
    var parameters = '';
    $.each(keys, function (index, value) {
        var temp = reqParams.get(value);
        temp = temp.replace(/{/gi, "").replace(/}/gi, "").replace(/\[/gi, "").replace(/]/gi, "").replace(/\"/gi, "");
        parameters += value + " = " + temp + ' |$| ';
    });
    responseText = responseText.replace(/(\r\n|\n|\r)/gm, " ");
    reqParams.put('xhrStatus', xhr.status);
    reqParams.put('xhrResponseText', xhr.statusText);
    reqParams.put('methodName', methodName);
    reqParams.put('errorLocation', window.location.href);
    reqParams.put('methodParameters', parameters);
    var jsonParams = constructJsonRequestParameters(reqParams);

    var serviceUri = WebServiceURL + "/LogException";

    $.ajax({
        type: "POST",
        contentType: "application/json charset=utf-8",
        dataType: "json",
        url: serviceUri,
        data: jsonParams,
        success: function (data, textStatus, xhr) { },
        error: function (xhr, textStatus, thrownError) {
        }
    });
};
function groupBy(items, propertyName) {
    var result = [];
    $.each(items, function (index, item) {
        if ($.inArray(item[propertyName], result) == -1) {
            result.push(item[propertyName]);
        }
    });
    return result;
}
function constructJsonRequestParameters(hashTable) {
    var returnStr = '{'
    hashTable.each(function (key, value) {
        if (typeof value == "object") {
            var innerStr = '{';
            value.each(function (innerKey, innerValue) {
                innerStr = innerStr + '"' + innerKey + '"' + ':' + '"' + innerValue + '"' + ',';
            });
            if (innerStr.charAt(innerStr.length - 1) == ',') {
                innerStr = innerStr.substring(0, innerStr.length - 1);
            };
            innerStr = innerStr + '}';
            returnStr = returnStr + '"' + key + '"' + ':' + '[' + innerStr + ']' + ',';
        }
        else {
            var strValue = '' + value;
            if (strValue.indexOf('[') >= 0) {
                returnStr = returnStr + '"' + key + '"' + ':' + value + ',';
            }
            else if (strValue.indexOf('{') >= 0) {
                returnStr = returnStr + '"' + key + '"' + ':' + value.replace('{', '').replace('}', '') + ',';
            }
            else {
                returnStr = returnStr + '"' + key + '"' + ':' + '"' + value + '"' + ',';
            }
        }
    });
    if (returnStr.charAt(returnStr.length - 1) == ',') {
        returnStr = returnStr.substring(0, returnStr.length - 1);
    };
    returnStr = returnStr + '}';

    return returnStr;
};


function GetTextService() {
    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetTextService";

    $.ajax({
        url: urlstring,
        type: "POST",
        dataType: "json",
        async: false,
        //data: { PathUrl : "Test" },
        contentType: "application/json; charset=utf-8",
        error: function (errorThrown) {
        },
        success: function (servicedata) {
            var service = JSON.parse(servicedata.d);
            TextNotificationServiceUrl = service;
        }
    });
}
function GetDataService() {
    IsValidAuthCookies();   
    
    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetDataService";

    $.ajax({
        url: urlstring,
        type: "POST",
        dataType: "json",
        async: false,
        //data: { PathUrl : "Test" },
        contentType: "application/json; charset=utf-8",
        error: function (errorThrown) {
        },
        success: function (servicedata) {
            var service = JSON.parse(servicedata.d);
            DataServiceUrl = service;
        }
    });
}


function CheckStorageDrivePermission(callback) {


    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/CheckIfStorageDrivePermissionExists";

    $.ajax({
        url: urlstring,
        type: "POST",
        dataType: "json",
        async: false,
        //data: { PathUrl : "Test" },
        contentType: "application/json; charset=utf-8",
        error: function (errorThrown) {
        },
        success: function (servicedata) {
            var status = JSON.parse(servicedata.d);
            StorageDriveStatus = status;
            if (callback != undefined)
                callback(status);
            
        }
    });
}


// JavaScript source code
function GetXSpaceData(param, procedure, callback) {
    
    var XSpaceurl = GetDataServieUrl();
    if (param != "" && param != null) {

        if (param.indexOf("UserID") == -1) {
            if (USERID == undefined || USERID == "") {
                GetUserGuid(undefined);
            }
            param = param + "%26" + "UserID='" + USERID + "'";
        }
        var arrParam = param.split("%26");
        param = "";
        for (var i = 0; i < arrParam.length; i++) {
            var item = arrParam[i].split("=");
            if (item[0] != "")
            {
                param = param + item[0] + "=" + escape(item[1]) + "%26";
            }
        }
        //param = "?parameter=" + param;
    }
        param = "?parameter=" + param;
    
    XSpaceurl = XSpaceurl + procedure + param;
    $.ajax({
        type: "GET",
        url: XSpaceurl,
        dataType: "json",
        async: false,
        contentType: "application/json; charset=utf-8",
        //data: param,
        success: function (results) {
            if (callback != undefined) {
                var returndata = results.ExecuteProcedureWithoutParamResult;
                if (returndata == undefined)
                    returndata = results.ExecuteProcedureWithoutPropResult;
                var dataResult = JSON.parse(returndata);
                callback(dataResult.data);
                //jasondata = results;
                return results;
            }

        },
        error: function (errorThrown) {
            
            alert(XSpaceurl);
            alert(errorThrown.responseText + "and" + errorThrown.statusText);
            //alert(errorThrown.statusText);
            var reqParams = new Hashtable();
            reqParams.put('dataUrl', XSpaceurl);
            LoggingException(errorThrown, procedure, reqParams);
        }

    });

}


function GetXSpaceDataTestUrl(param, procedure, callback) {
    var XSpaceurl = "http://vc1cgr01xs01002:8080/dsdataserver/dsl.svc/XSPACEview/1/XSPACETviewVDB-XSPACET/";
    XSpaceurl = XSpaceurl + procedure + param;
    $.ajax({
        type: "GET",
        url: XSpaceurl,
        dataType: "json",
        data: param,
        success: function (results) {
            if (callback != undefined) {
                callback(results.d);
                //jasondata = results;
                return results;
            }

        },
        error: function (errorThrown) {
            
            alert("An error occurred on the server while trying to complete the action. The error has been sent to the maintenance team. Please try again later.");
            var reqParams = new Hashtable();
            reqParams.put('dataUrl', XSpaceurl);
            LoggingException(errorThrown, procedure, reqParams);
        }

    });

}


function GetStorageDrive(callback) {
    GetXSpaceData("", "GetStorageDrive_SP", callback);
}
function GetAllDistricts(callback) {
     var data = GetXSpaceData("", "GetDistrict_SP", callback);
}

function GetWellheaderData(wellguid, callback) {
    var param = "WBJobGuid='" + wellguid + "'";
    GetXSpaceData(param, "GetWellDataByWBJobGuid_SP", callback);
}



//Distribute Files * Chithrai* End


function GetWellFolders(callback) {
    var data = GetXSpaceData("", "GetFolderType_SP", callback);
}

function GetWellFoldersByUserID(wbJobGuid,USERID,callback) {
	var param = "WBJobGuid='" + wbJobGuid + Sep() + "UserID='" + USERID + Sep(); 
    var data = GetXSpaceData(param, "GetWellFolderByUserID_SP", callback);
}

function GetNewFileGuid(WellGuid) {


}



function InsertUploadSession(Wellboreguid, type, status, Comment, userid, zipflag, procedure, callback) {
    if (Wellboreguid != null)
        Wellboreguid = "'" + Wellboreguid + "'";
    if (userid != null)
        userid = "'" + userid + "'";
    if (Comment != null)
        Comment = "'" + Comment + "'";

    var param = "WellboreJobGuid="  + Wellboreguid + "%26" + "Type=" + "'" + type + "'%26" + "Status=" + "'" + status
    + "'%26" + "Comment="  + Comment + "%26" + "UserGuid=" + userid + "%26" + "ZipFlag=" + "'" + zipflag + "'";

    GetXSpaceData(param, procedure, callback);
}

function InsertUploadFile(UploadSessionGuid, DataFileGuid, DestinationDriveGuid, DestPath, procedure, callback) {
    
    var param = "UploadSessGuid=" + "'" + UploadSessionGuid + "'%26" + "FileUploadGuid=" + "'" + UploadSessionGuid + "'%26" + "DataFileGuid=" + "'" +
        DataFileGuid + "'%26" + "TempDriveGuid=" + "'" + DestinationDriveGuid + "'%26" + "TempPath=" + "'" + DestPath + "'%26" + "DestDriveGuid=" + "'"
        + DestinationDriveGuid + "'%26" + "DestPath=" + "'" + DestPath + "'";

    GetXSpaceData(param, procedure, callback);


}

function InsertDataFile(DriveGuid, FileName, FilePath, Size, Status, DistGuid, Comment, procedure, callback) {
    var param = "DriveGuid=" + "'" + DriveGuid + "'%26" + "FileName=" + "'" + FileName + "'%26" + "FilePath=" + "'" + FilePath
     + "'%26" + "Status=" + "'" + Status + "'%26" + "DistrictGuid=" + "'" + DistGuid
    + "'%26" + "Comment=" + "'" + Comment + "'%26" + "Size=" + Size;

    GetXSpaceData(param, procedure, callback);


}

function GetDestinationPath(WellGUID, machine, FolderID) {
    return "\\\\" + "WELLS" + "\\\\" + WellGUID + "\\\\" + FolderID;

}

function GetFileStatus(procedure, callback) {
    GetXSpaceData("", procedure, callback);

}

function StartUploadFromSOTicket(SoNumber, procedure, callback) {
    var param = "SONumber=" + "'" + SoNumber + "'";
    GetXSpaceData(param, procedure, callback);

}

function UpdateUploadProgress(datafileGuid, UploadPercentage, procedure, callback) {
    var param = "FileUploadGuid=" + "'" + datafileGuid + "'%26" + "Percent=" + UploadPercentage;
    GetXSpaceData(param, procedure, undefined)

}

function InsertWBJobDataFile(WBGuid, datafileGuid, FolderID, procedure, callback) {
    var param = "WBJobGuid=" + "'" + WBGuid + "'%26" + "DataFileGuid=" + "'" + datafileGuid + "'%26" + "FolderType=" + "'" + FolderID + "'";
    GetXSpaceData(param, procedure, undefined)

}

function GetWellFiles(WBGuid, procedure, callback) {
    var param = "WBJobGuid=" + "'" + WBGuid + "'";
    GetXSpaceData(param, procedure, callback)

}

function GetUrlParameter(key) {
    var href = window.location.href;
    href = href.replace('#', '');
    var vars = [], hash;
    var hashes = href.slice(href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars[key];
}

function GetFilterXSpaceData(param, procedure, callback, filterdata) {
    var XSpaceurl = GetDataServieUrl();
    if (param != "") {
        param = "?parameter=" + param;
    }
    XSpaceurl = XSpaceurl + procedure + param;
    $.ajax({
        type: "GET",
        url: XSpaceurl,
        dataType: "json",
        async: false,
        //data: param,
        success: function (results) {
            if (callback != undefined) {
                var returndata = results.ExecuteProcedureWithoutParamResult;
                if (returndata == undefined)
                    returndata = results.ExecuteProcedureWithoutPropResult;
                var dataResult = JSON.parse(returndata);
                callback(dataResult.data, filterdata);
            }
        },
        error: function (errorThrown) {

            alert("An error occurred on the server while trying to complete the action. The error has been sent to the maintenance team. Please try again later.");
            var reqParams = new Hashtable();
            reqParams.put('dataUrl', XSpaceurl);
            LoggingException(errorThrown, procedure, reqParams);
        }

    });

}

function GetApplicationRelativePath() {
    return getAppURL() + "/_layouts/15";
}
function GetUserGuid(callback) {
    //var FilePath = $("#fileInfo").data('File')
    
    var urlstring = GetApplicationRelativePath() + "/Download/DownloadFile.aspx/GetCurrentUser";

    $.ajax({
        url: urlstring,
        type: "POST",
        dataType: "json",
        async: false,
        contentType: "application/json; charset=utf-8",
        error: function (errorThrown) {
        },
        success: function (Userid) {
           
            var userdetail = Userid.d; //JSON.parse(Userid.d);
           
            USERID = userdetail;
            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, "GetUserDetailByUserID_SP", callback);

            var param = "UserID='" + USERID + "'";
            GetXSpaceData(param, "GetUsersPendingApproval_SP", function (data) {
                $("#pandingApprovalUserCount").html("[" + data.length + "]");
            });
        },
    });

}

function InsertUser() {
    var urlstring = GetApplicationRelativePath() + "/Download/DownloadFile.aspx/GetCurrentUser";

    $.ajax({
        url: urlstring,
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        error: function (errorThrown) {
        },
        success: function (Userid) {
            var userdetail = Userid.d; //JSON.parse(Userid.d);
            var param = "UserID='" + userdetail + "'";
            GetXSpaceData(param, "InsertUser_SP", undefined);

        },
    });

}

function DownloadAllDataFile(data) {
    //var drives = drive;
    //if (drive.GetStorageDrive_SP != "")
    //    drives = JSON.parse(drive.GetStorageDrive_SP);


    var folderpath = "";

    var dataFiles = data;

    var guids = "";// = "Guid1,Guid2,Guid3";
    var fileid = "";
    var folderid = "";
    var fileName = "";
    var FileNames = "";

    var FileGuid = [];
    for (var i = 0; i < dataFiles.length; i++) {
        fileid = dataFiles[i].DATA_FILE_GUID;
        folderid = dataFiles[i].FLDR_TYP_NM;
        fileName = dataFiles[i].DATA_FILE_LNM;

                if (guids != "") {
                    guids = guids + ",";
                    FileNames = FileNames + ",";
                }
                guids = guids + folderid;
                FileNames = FileNames + fileName;
				if(dataFiles[i].FLDR_INDX!=null && dataFiles[i].FLDR_INDX!="")
                FileGuid.push(fileid);

    }



    var WBGuid = GetUrlParameter("WBGuid");
    var WellorDropBox = "Well";
    DownloadAndLogAudit(guids, WBGuid, FileGuid, "", FileNames, WellorDropBox);

    return false;

}

function DownloadAndLogAudit(folderNames, WellGuid, DataFileGuids, machine, FileNames, WellorDropBox) {
    DownloadData(DataFileGuids);
    ////var parameters;
    ////var userguid = "68FA0666-5FB2-4ED8-868E-8893E0AA5278";
    ////var url = "http://" + window.location.hostname + ":" + window.location.port + "/_layouts/15/Download/DownloadFile.aspx";
    ////parameters = "FLAG=" + "Well" + "&Files=" + FileNames + "&machinename=" + machine + "&WBGuid=" + WellGuid + "&FolderPath=" + "";
    ////window.open(url + "?GUID=" + folderNames + "&" + parameters);
    ////for (var i = 0; i < DataFileGuids.length; i++) {
    ////    var param = "UserGuid='" + UserGUID + "'%26DataFileGuid='" + DataFileGuids[i] + "'" + "%26TypeCode='"
    ////    + "USER'" + "%26RepeatFlag='" + "0'";
    ////    GetXSpaceData(param, "InsertFileDownload_SP", undefined);
    ////}
    }
function DownloadSelectedAndLogAudit(folderNames, WellGuid, DataFileGuids, machine, FileNames, Operator, Field, WellName) {
    DownloadData(DataFileGuids);
    //var parameters;
    //var userguid = "68FA0666-5FB2-4ED8-868E-8893E0AA5278";
    //var url = "http://" + window.location.hostname + ":" + window.location.port + "/_layouts/15/Download/DownloadFile.aspx";
    //parameters = "FLAG=" + "Well" + "&Files=" + FileNames + "&machinename=" + machine + "&WBGuid=" + WellGuid + "&FolderPath=" + "&Operator=" + Operator + "&Field=" + Field + "&WellName=" + WellName;
    //window.open(url + "?GUID=" + folderNames + "&" + parameters);
    //for (var i = 0; i < DataFileGuids.length; i++) {
    //    var param = "UserGuid='" + UserGUID + "'%26DataFileGuid='" + DataFileGuids[i] + "'" + "%26TypeCode='"
    //    + "USER'" + "%26RepeatFlag='" + "0'";
    //    GetXSpaceData(param, "InsertFileDownload_SP", undefined);
    //}
}


function DownloadAllFiles() {
    var WBGuid = GetUrlParameter("WBGuid");
    var param = "WBJobGuid='" + WBGuid +  Sep()+"UserID='" + USERID + Sep(); 
    GetXSpaceData(param, "GetDataFilesByWBJob_SP", DownloadAllDataFile);

}

function CancelUpload(DataFileGuid, procedure, callback) {
    var parameterList = "DataFileGuid='" + DataFileGuid + "'";
    GetXSpaceData(parameterList, procedure, callback);

}

function update_query_string(uri, key, value) {

    // Use window URL if no query string is provided
    if (!uri) { uri = window.location.href; }

    // Create a dummy element to parse the URI with
    var a = document.createElement('a'),

        // match the key, optional square bracktes, an equals sign or end of string, the optional value
        reg_ex = new RegExp(key + '((?:\\[[^\\]]*\\])?)(=|$)(.*)'),

        // Setup some additional variables
        qs,
        qs_len,
        key_found = false;

    // Use the JS API to parse the URI 
    a.href = uri;

    // If the URI doesn't have a query string, add it and return
    if (!a.search) {

        a.search = '?' + key + '=' + value;

        return a.href;
    }

    // Split the query string by ampersands
    qs = a.search.replace(/^\?/, '').split(/&(?:amp;)?/);
    qs_len = qs.length;

    // Loop through each query string part
    while (qs_len > 0) {

        qs_len--;

        // Check if the current part matches our key
        if (reg_ex.test(qs[qs_len])) {

            // Replace the current value
            qs[qs_len] = qs[qs_len].replace(reg_ex, key + '$1') + '=' + value;

            key_found = true;
        }
    }

    // If we haven't replaced any occurences above, add the new parameter and value
    if (!key_found) { qs.push(key + '=' + value); }

    // Set the new query string
    a.search = '?' + qs.join('&');

    return a.href;
}


function DistributeFilesData(data) {
    var path = GetApplicationRelativePath() + "/XSP/Pages/distribute.aspx";
    localStorage.setItem("SelectedFiles", JSON.stringify(data));
    PopupCenter(path, "_blank", "1200", "570");
    
    
}

function Sep() {
    return "'%26";
}

function SetFilterString(WellName, Company, SO, Country, State,
    County, Field, Block, Range, Section, Township, UWI) {
    return WellName + "@"
    + Company + "@"
    + SO + "@"
    + Country + "@"
    + State + "@"
    + County + "@"
    + Field + "@"
    + Block + "@"
    + Range + "@"
    + Section + "@"
    + Township + "@"
    + UWI + "@";

}

function GetFilterString(filter) {
    return filter.split("@");
}

function ValidateEmptyData(data) {
    if (data == "null" || data == "undefined" || data == "" || data == null || data == undefined)
        return false;
    else
        return true;

}

function GetUsers(procedure, callback) {
    GetXSpaceData('', procedure, callback);
}

function InsertDistributionList(callback) {
    var param = "SendUserGuid=" + "'" + UserGUID + "'%26" + "TypeCode=" + "'INPRL'%26" + "StatusCode=" + "'CMPLT'%26" + "Comment=" + "'" + $("#comments").val() + "'";
    var data = GetXSpaceData(param, "InsertDistribution_SP", callback);
}

function InsertDistributionListUser(comment, callback) {
    var param = "SendUserGuid=" + "'" + UserGUID + "'%26" + "TypeCode=" + "'INPRL'%26" + "StatusCode=" + "'CMPLT'%26" + "Comment=" + "'" + $("#UserToUserTransferComments").val() + "'";
    var data = GetXSpaceData(param, "InsertDistribution_SP", callback);
}

function InsertDistributionFile(DSTGUID, DFileGUID, callback) {
    var param = "DistributionGuid=" + "'" + DSTGUID + "'%26" + "DataFileGuid=" + "'" + DFileGUID + "'";
    var data = GetXSpaceData(param, "InsertDistributionFile_SP", callback);
}
function GetUserGUIDDetails(data) {
    var GetUserGUID = data;
    if (data.length != 0) {
        UserGUID = GetUserGUID[0].USR_GUID;
        USERROLE = GetUserGUID[0].ROLE_CD;
        if (USERROLE == USERROLE_TYPE.InternalUser) {
            $("#nav").find("li.nav_well").hide();          
        }
        if (USERROLE == USERROLE_TYPE.InternalUser || USERROLE == USERROLE_TYPE.CustomerUser) {
            $("#home_nav").find("li.home_nav_imgActivityLog").hide();
            $("#nav_rootMenu").find("li.rootMenu_activityLog").hide();
        }
    }
}

function GetDownloadUrl() {
    return getAppURL() + "/_layouts/15/Download/DownloadService.aspx";
}

function GetFileDownloadlink( guid, filename,full)
{
    var hreflink  = "void(0)";
	var link="";
	if(full==undefined ||(full.FLDR_INDX!=undefined && full.FLDR_INDX!=null && full.FLDR_INDX!=""))
		link= "<a style='color:blue;text-decoration:none;cursor:pointer'  onclick='DownloadFile(\"" + guid + "\");'>" + filename + "</a>";		
	else
		link= filename;
    return link;
}
function DownloadData(DataFileGuids, FileNames) {
    var guids = DataFileGuids.toString();
    
    DownloadFile(guids, false, FileNames);


}

function DownloadFile(guids, fileclick, FileNames) {
    if (fileclick == undefined)
        fileclick = "true";
    else
        fileclick = "false";

    if (FileNames == undefined)
        FileNames = "";

    var url = GetDownloadUrl();
    //window.open(url + "?GUID=" + guids + "&link=" + fileclick + "&FileNames=" + FileNames);
    $.fileDownload(url , {
        preparingMessageHtml: "Download in progress, please wait...",
        failMessageHtml: "There was a problem generating your report, please try again."
    }, "GUID=" + guids + "&link=" + fileclick + "&FileNames=" + FileNames);
    return false;
    }

function DownloadAndLogAuditDropBox(DataFileGuids, FileNames) {
    DownloadData(DataFileGuids);
    //var guids = DataFileGuids.toString();
    //window.open()
    //var parameters;  
    //var drives = GetStorageDrive(UpdateDrives);
    //var url = "http://" + window.location.hostname + ":" + window.location.port + "/_layouts/15/Download/DownloadDropBoxFile.aspx";

    //parameters = "FLAG=" + "DropBox" + "&Files=" + FileNames + "&machinename=" + machine + "&WBGuid=" + "" + "&FolderPath=" + "";
    //window.open(url + "?" + parameters);

    //for (var i = 0; i < DataFileGuids.length; i++) {
    //    var param = "UserGuid='" + UserGUID + "'%26DataFileGuid='" + DataFileGuids[i] + "'" + "%26TypeCode='"
    //    + "USER'" + "%26RepeatFlag='" + "0'";
    //    GetXSpaceData(param, "InsertFileDownload_SP", undefined);
    //}
}

var machine;
var folderpath;
var driveGuid;
function UpdateDrives(data) {
    var drives = data;
    //if (data.GetStorageDrive_SP != "")
    //    drives = JSON.parse(data.GetStorageDrive_SP);

    machine = drives[0].DRV_PATH;
    folderpath = "";
    driveGuid = drives[0].DRV_GUID;

}

function DistributeData(data)
{
    
    var distributedData = [];
    var zipfiledata = [];


    if (data.length == 0) {
        $("#alert").html("Please select file to distribute.").dialog("open");
    }
    else {
        //var stringdata = JSON.stringify(data);
        for (var i = 0; i < data.length; i++) {
            if (data[i].DATA_FILE_LNM != undefined) {
                if (data[i].DATA_FILE_LNM.indexOf(".zip") == -1) {
                    data[i].FILE_TYPE = "";
                    distributedData.push(data[i]);
                }
                else {
                    zipfiledata.push(data[i]);
                }
            }

        }
        if (zipfiledata.length > 0) {
            var guids = "";
            for (var i = 0; i < zipfiledata.length - 1; i++) {
                guids = zipfiledata[i].DATA_FILE_GUID + ",";

            }
            guids = guids + zipfiledata[zipfiledata.length - 1].DATA_FILE_GUID;
            var o = { Guid: guids };
            //var FilePath = $("#fileInfo").data('File')
            //var urlstring = "http://" + window.location.hostname + ":" + window.location.port + "/_layouts/15/FileHandler/FileService.aspx/GetFileList";
            var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetFileList";

            $.ajax({
                url: urlstring,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(o),
                //data: { PathUrl : "Test" },
                contentType: "application/json; charset=utf-8",
                error: function (errorThrown) {
                },
                success: function (dataFile) {
                    var temp = JSON.parse(dataFile.d);
                    for (var i = 0; i < temp.length; i++) {
                        for (var j = 0; j < zipfiledata.length; j++) {
                            if (temp[i].FileGuid == zipfiledata[j].DATA_FILE_GUID) {
                                var object = new Object();

                                object.DATA_FILE_LNM = temp[i].FileName;
                                object.DATA_FILE_GUID = temp[i].FileGuid;
                                object.DT_RowId = zipfiledata[j].DT_RowId;
                                object.DATA_FILE_CMNT = zipfiledata[j].DATA_FILE_CMNT;
                                object.FILE_SZ_VAL = temp[i].Size;
                                object.FILE_STAT_CD = zipfiledata[j].FILE_STAT_CD;
                                object.NEW_FILE = zipfiledata[j].NEW_FILE;
                                object.UPLOAD_DATE = zipfiledata[j].UPLOAD_DATE;
                                object.UPLOADED_BY = zipfiledata[j].UPLOADED_BY;
                                object.FILE_TYPE = ".zip";
                                distributedData.push(object);

                            }
                        }
                    }
                    localStorage.setItem("SelectedFiles", JSON.stringify(distributedData));
                    //window.location = "distribute.aspx";
                    var WBGuid = GetUrlParameter("WBGuid");
                    if (WBGuid != undefined && WBGuid != "")
                        PopupCenter("distribute.aspx?WBGuid=" + WBGuid, "_blank", "1200", "570");
                    else
                        PopupCenter("distribute.aspx", "_blank", "1200", "570");

                },
            });

        }
        else {
            localStorage.setItem("SelectedFiles", JSON.stringify(distributedData));
            //window.location = "distribute.aspx";
            var WBGuid = GetUrlParameter("WBGuid");
            if (WBGuid != undefined && WBGuid != "")
                PopupCenter("distribute.aspx?WBGuid=" + WBGuid, "_blank", "1200", "570");
            else
                PopupCenter("distribute.aspx", "_blank", "1200", "570");
        }
    }

    //DistributeFilesData(data);
    return false;

}


function OpenUploadFiles() {

    var customWellName = WellDetails[0].CO_NM + " " + WellDetails[0].FLD_NM + " " + WellDetails[0].WELL_NM;
    var WBGuids = GetUrlParameter("WBGuid");

    //var uploadQS = "?operation=1&" + WBGuids + "&WellName=";
    PopupCenter("/_layouts/XSP/Pages/Upload.aspx?operation=1&WBGuid=" + WBGuids + "&WellName="
        + customWellName, '_blank', 1200, 450);
    //PopupCenter("Upload.aspx" + uploadQS, "_blank", "1200", "500");
    return true;
}

function SortOptions(id) {
    var prePrepend = "#";
    if (id.match("^#") == "#") prePrepend = "";
    $(prePrepend + id).html($(prePrepend + id + " option").sort(
        function (a, b) { return a.text == b.text ? 0 : a.text < b.text ? -1 : 1 })
    );
}

function isGroupNameAlreadyExist (newGroupName,existGroupID,callback){
	GetXSpaceData("", "GetUserGroups_SP", function(data){
		var isExist=false;
		 for (var i = 0; i < data.length; i++){					
			  if(data[i].USR_GRP_NM.toLowerCase()==newGroupName.toLowerCase() && ( existGroupID==undefined || (existGroupID!=undefined && existGroupID!=data[i].USR_GRP_GUID))){
				  isExist=true;
				  break;
			  }
				  
		  }
		callback(isExist);
	  }); 
}

function SendNotification(Procedure, data )
{
    var XSpaceurl = GetTextServiceUrl() + Procedure;


    $.ajax({
        type: "POST",
        url: XSpaceurl,
        data: JSON.stringify(data),
        dataType: "json",
        async: true,
        contentType: "application/json; charset=utf-8",
        success: function (results) {
        },
        error: function (errorThrown) {
        }

    });

}
function FileStatusChangeNotification(DataFileGuids) {

    var data = { parameter:"DataFileGuid=" + DataFileGuids };

    SendNotification("SendFileStatusChangeNotification", data);

}

function UserApprovedNotification(UserID) {

    var data = { parameter: "UserID='" + UserID + "'" };

    SendNotification("SendUserApprovedEmail", data);
}

function WellUploadNotification(UploadSessionGuid) {

    var data = { parameter: "UploadSessionGuid='" + UploadSessionGuid + "';UserGuid='';SenderGuid='" + UserGUID + "'" };
    SendNotification("SendEmail", data);
}


function UserUploadNotification(UploadSessionGuid, UserGuid, SenderGuid) {

    var data = { parameter: "UploadSessionGuid='" + UploadSessionGuid + "';UserGuid='" + UserGuid + "';SenderGuid='" + SenderGuid + "'" };
    SendNotification("SendEmail", data);
}

function DistributeDropBoxFileNotification(DataFileGuid, UserName, EmailAddress, ReceipentGuids, UserGuid,
    Comments) {

    var data = {
        parameter: "DataFileGuid='" + DataFileGuid + "';UserName='" +
            UserName + "';Email='" + EmailAddress + "';Receipents='" + ReceipentGuids +
            "';SenderGuid='" + UserGuid + "';Comments='" + Comments + "'"
    };

    SendNotification("SendDropBoxFileDistributionEmail", data);
}
function DistributeFileNotification(DataFileGuid, UserName, EmailAddress, UserGuid) {

    var data = {
        parameter: "DataFileGuid='" + DataFileGuid + "';UserName='" +
        UserName + "';Email='" + EmailAddress + "';SenderGuid='" + UserGuid + "'"
    };

    SendNotification("SendFileDistributionEmail", data);

}
function removeSpecialChar(me) {
    var yourInput = $(me).val();
    re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
    var isSplChar = re.test(yourInput);
    if (isSplChar) {
        var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
        $(me).val(no_spl_char);
    }
}
function removeAmp(event) {  
    var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
    if (key=="&") {
        if (event.preventDefault == undefined)
            event.returnValue = false;
        else
            event.preventDefault();
        return false;
    }
}
function validateSpecialChar(event){
			  var regex = new RegExp("^[A-Za-z0-9 ]+$");
             var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
             if (!regex.test(key)) {
				 if(event.preventDefault == undefined)
					 event.returnValue=false;
				 else
					event.preventDefault();
                 return false;
             }
		 };
		 
function validateCharOnly(event){
			  var regex = new RegExp("^[A-Za-z ]+$");
             var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
             if (!regex.test(key)) {
				 if(event.preventDefault == undefined)
					 event.returnValue=false;
				 else
					event.preventDefault();
                 return false;
             }
		 };	 

function isDistributionListNameAlreadyExist(distType,newListName,existListID,callback){
	var spName;
	var param = "";
	
	if(distType=="W"){
		spName="GetWellDistributionList_SP"
	}
	else if(distType=="D"){
		spName="GetDistrictDistributionList_SP"
	}
	else if(distType=="P"){		
		param = "UserID='" + USERID + "'";
		spName="GetPersonalDistributionList_SP"
	}
	GetXSpaceData(param, spName, function(data){
		var isExist=false;
		 for (var i = 0; i < data.length; i++){					
		     if (distType=="P" && data[i].DSTBN_LIST_NM.toLowerCase() == newListName.toLowerCase() && (typeof (existListID) == "undefined" || (existListID != undefined && existListID != data[i].DSTBN_LIST_GUID))) {
				  isExist=true;
				  break;
			  }
				  
		 }
		 for (var i = 0; i < data.length; i++) {
		     if (data[i].DSTBN_LIST_NM.toLowerCase() == newListName.toLowerCase() && (typeof (existListID) != "undefined") && distType == "D" && data[i].DIST_GUID==existListID) {
		         isExist = true;
		         break;
		     }
		 }
		 for (var i = 0; i < data.length; i++) {
		     if (data[i].DSTBN_LIST_NM.toLowerCase() == newListName.toLowerCase() && (typeof (existListID) != "undefined") && distType == "W" && data[i].WB_JOB_GUID == existListID) {
		         isExist = true;
		         break;
		     }
		 }
		callback(isExist);
	  }); 
}

function getSettingsKeyValue(keyValue, callback) {
    var XSpaceurl = GetDataServieUrl();
    var procedure = "GetSettingsKeyValue";
    var param = "/" + keyValue;

    XSpaceurl = XSpaceurl.substr(0, XSpaceurl.indexOf(".svc")) + ".svc/";

    XSpaceurl = XSpaceurl + procedure + param;
    $.ajax({
        type: "GET",
        url: XSpaceurl,
        dataType: "json",
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (results) {
            if (callback != undefined) {
                callback(results.GetSettingsKeyValueResult);
                return results.GetSettingsKeyValueResult;
            }

        },
        error: function (errorThrown) {

            alert(XSpaceurl);
            alert(errorThrown.responseText + "and" + errorThrown.statusText);
            var reqParams = new Hashtable();
            reqParams.put('dataUrl', XSpaceurl);
            LoggingException(errorThrown, procedure, reqParams);
        }

    });
}