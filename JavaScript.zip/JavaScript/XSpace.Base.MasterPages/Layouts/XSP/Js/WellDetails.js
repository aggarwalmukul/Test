﻿var wellDetails = function ()
{
    function loadData(data,countryId,companyId) {

    }
    function validateData() {


    }
    function getData() {

    }
}
$(document).ready(function () {   
    bindCompanies();
    bindCoutries();
    //$(document).on("keypress blur", "input", function () {
    //    if (!$(this).hasClass("exclude"))
    //        removeSpecialChar($(this));
    //});
    bindStates();
    bindCounties();
    $(document).on("change", "#wCountry", function () {
        if ($(this).val() != "")
            bindStates();
        else
            $("#wState").find('option').remove();
    });
    $(document).on("change", "#wState", function () {
        if ($(this).val() != "")
            bindCounties();
        else
            $("#wCounty").find('option').remove();
    });
   
});
function bindCompanies() {
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        var select = $("#wCompany")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CO_ID;
            option.text = data[i].CO_NM;
            select.options.add(option);
        }
    });
}
function bindCoutries() {
    GetXSpaceData("", "GetCountryList_SP", function (data) {
        var select = $("#wCountry")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CNTRY_ID;
            option.text = data[i].CNTRY_NM;
            select.options.add(option);
        }

    });
}

function bindStates() {
    var param = "CntryID='" + $("#wCountry").val() + "'";
    GetXSpaceData(param, "GetStateList_SP", function (data) {
        $("#wState").find('option').remove();
        if (data.length > 0) {
            var select = $("#wState")[0];
            var option = new Option();
            option.value = "";
            option.text = "";
            select.options.add(option);
            for (var i = 0; i < data.length; i++) {
                option = new Option();
                option.value = data[i].GEO_LVL1_ID;
                option.text = data[i].GEO_LVL1_NM;
                select.options.add(option);
            }
        }
    });
}
function bindCounties() {
    var param = "CountryID='" + $("#wCountry").val() + Sep() + "StateID='" + $("#wState").val() + "'";
    GetXSpaceData(param, "GetCountyList_SP", function (data) {
        $("#wCounty").find('option').remove();
        if (data.length > 0) {
            var select = $("#wCounty")[0];
            var option = new Option();
            option.value = "";
            option.text = "";
            select.options.add(option);
            for (var i = 0; i < data.length; i++) {
                option = new Option();
                option.value = data[i].GEO_LVL2_ID;
                option.text = data[i].GEO_LVL2_NM; 
                select.options.add(option);
            }
        }
    });
}

////load well details  data
function loadWellDetails() {    
    if (typeof (wellUserControlGridSettings) != "undefined" && $("#" + wellUserControlGridSettings.GridId).DataTable().rows(".selected").data().length > 0) {
        var data = $("#" + wellUserControlGridSettings.GridId).DataTable().rows(".selected").data();
        var param = "WBJobGuid='" + data[0].WB_JOB_GUID + "'";      
    }
    else {
        var param = "WBJobGuid='" + qs("WBGuid") + "'";       
    }

    GetXSpaceData(param, "GetWellDetails_SP", function (data) {
        setFieldsData(data);
    });
}
function setFieldsData(data) {
    bindStates();
    bindCounties();
    if (data.length > 0) {
        $("#wWellName").val(data[0].WELL_NM);
        $("#wAPI").val(data[0].GOVT_ID_NUM);
        $("#wCompany").val(data[0].CO_ID);
        $("#wField").val(data[0].FLD_NM);
        $("#wSection").val(data[0].SECT_NUM);
        $("#wBlock").val(data[0].BLK_NUM);
        $("#wCountry").val(data[0].CNTRY_ID);
        if (data[0].CNTRY_ID != "")
            bindStates();
        $("#wState").val(data[0].GEO_LVL1_ID);
        if (data[0].CNTRY_ID != "" && data[0].GEO_LVL1_ID != "")
            bindCounties();
        $("#wCounty").val(data[0].GEO_LVL2_ID);

        $("#wTownship").val(data[0].TWP_NUM);
		if(data[0].LAT_VAL!="" && parseFloat(data[0].LAT_VAL)!=0)
			$("#wLatitude").val(data[0].LAT_VAL);
		else
			$("#wLatitude").val("");
        $("#wRange").val(data[0].RNG_NUM);
		if(data[0].LON_VAL!="" && parseFloat(data[0].LON_VAL)!=0)
			$("#wLongitude").val(data[0].LON_VAL);
		else
			$("#wLongitude").val("");
       
        if (data[0].TGHT_FLG == "1")
            $('#wTightHole').prop('checked', true);
        else
            $('#wTightHole').prop('checked', false);
        $("#wRigName").val(data[0].RIG_NM);

    }
}

var WellExists = false;
function ValidateWellNameOrAPI() {
    WellExists = false;
    var param = "WellName='" + $("#wWellName").val() + "'";
    
    GetXSpaceData(param, "GetWellByName_SP", function (data) {
        if (data != null && data.length > 0) {
            if (data != null && data[0].WELL_GUID != null && data[0].WELL_GUID.length > 0) {

                WellExists = false;
            }
            else {
                WellExists =  true;
            }
        }
        else {
            WellExists = true;
        }
    });
    if( WellExists == false )
    {
        ShowCustomAlert("Well with same name or API/UWI already exists.Please enter new value.", "Error:", 300);

    }
    return WellExists;
}

function ValidateWellDetails() {

    if ($("#wWellName").val() == "") {
        ShowCustomAlert("Please enter well name.", "Error:", 250);
        return false;
    }
       
    if ($("#wAPI").val() == "") {
        ShowCustomAlert("Please enter API/UWI.", "Error:", 250);
        return false;
    }
       
    if ($("#wCompany").val() == null) {
        ShowCustomAlert("Please select company.", "Error:", 250);
        return false;
    }
       
    if ($("#wField").val() == "") {
        ShowCustomAlert("Please enter field.", "Error:", 250);
        return false;
    }
       
    if ($("#wCountry").val() == null) {
        ShowCustomAlert("Please select country.", "Error:", 250);
        return false;
       
    }
   /* if ($("#wState").val() == null) {
        ShowCustomAlert("Please select state.", "Error:", 250);
        return false;
    }
    if ($("#wCounty").val() == null) {
        ShowCustomAlert("Please select county.", "Error:", 250);
        return false;
    }
*/
    return true;   

}
function getInsertParams() {   
    var param = "WBJobGuid=''%26WellName='" + $("#wWellName").val() + "'%26CompanyID='" + $("#wCompany").val() +"'%26CountryID='" + $("#wCountry").val()  + "'" ;
    if ($("#wState").val() == "" || $("#wState").val() == null)
    {

    }
        //param += "'NULL'";
    else {
        param = param  + "%26StateID="
        param += "'" + $("#wState").val() + "'";
    }
			
			
    if ($("#wCounty").val() == "" || $("#wCounty").val() == null) {
    }
        //param += "'NULL'";
    else {
        param += "%26CountyID="
        param += "'" + $("#wCounty").val() + "'";
    }
				
    if ($.trim($("#wLatitude").val()) != "")
        param = param + "%26Lat=" + $("#wLatitude").val();
    else
        param = param + "%26Lat=0";
    if ($.trim($("#wLongitude").val()) != "")
        param = param + "%26Lng=" + $("#wLongitude").val();
    else
        param = param + "%26Lng=0";
    if ($.trim($("#wRigName").val()) != "")
        param = param + "%26RigName='" + $("#wRigName").val() + "'";
    else
        param = param + "%26RigName=''";

    param = param + "%26UWI='" + $("#wAPI").val() + "'%26Field='" + $("#wField").val() + "'";
    if ($.trim($("#wTownship").val()) != "")
        param = param + "%26Township='" + $("#wTownship").val() + "'";
    else
        param = param + "%26Township=''" ;
    if ($.trim($("#wRange").val()) != "")
        param = param + "%26WellRange='" + $("#wRange").val() +"'";
    else
        param = param + "%26WellRange=''" ;
    if ($.trim($("#wSection").val()) != "")
        param = param + "%26Section='" + $("#wSection").val()+"'";
    else
        param = param + "%26Section=''";
    if ($.trim($("#wBlock").val()) != "")
        param = param + "%26Block='" + $("#wBlock").val() + "'";
    else
        param = param + "%26Block=''";
    if ($("#wTightHole")[0].checked)
        param = param + "%26TightHoleFlg=1";//+ $("#wTightHole").val();
    else
        param = param + "%26TightHoleFlg=0"
    return param;
}
function getUpdateParams() {
    var param = "WBJobGuid='" + qs("WBGuid") + "'%26WellName='" + $("#wWellName").val() + "'%26CompanyID='" + $("#wCompany").val() +
        "'%26CountryID='" + $("#wCountry").val() + "'%26StateID=";
    //+ $("#wState").val() + "'%26CountyID='" + $("#wCounty").val() + "'";
    if ($("#wState").val() == "")
        param += "''";
    else
        param += "'" + $("#wState").val() + "'";

    param += "%26CountyID="
    if ($("#wCounty").val() == "" || $("#wCounty").val() == null)
        param += "''";
    else
        param += "'" + $("#wCounty").val() + "'";

    if ($.trim($("#wLatitude").val()) != "")
        param = param + "%26Lat=" + $("#wLatitude").val();
    else
        param = param + "%26Lat=0";
    if ($.trim($("#wLongitude").val()) != "")
        param = param + "%26Lng=" + $("#wLongitude").val();
    else
        param = param + "%26Lng=0";
    if ($.trim($("#wRigName").val()) != "")
        param = param + "%26RigName='" + $("#wRigName").val() + "'";
    else
        param = param + "%26RigName=''";

    param = param + "%26UWI='" + $("#wAPI").val() + "'%26Field='" + $("#wField").val() + "'";
    if ($.trim($("#wTownship").val()) != "")
        param = param + "%26Township='" + $("#wTownship").val() + "'";
    else
        param = param + "%26Township=''";
    if ($.trim($("#wRange").val()) != "")
        param = param + "%26WellRange='" + $("#wRange").val() + "'";
    else
        param = param + "%26WellRange=''";
    if ($.trim($("#wSection").val()) != "")
        param = param + "%26Section='" + $("#wSection").val() + "'";
    else
        param = param + "%26Section=''";
    if ($.trim($("#wBlock").val()) != "")
        param = param + "%26Block='" + $("#wBlock").val() + "'";
    else
        param = param + "%26Block=''";
    if ($("#wTightHole")[0].checked)
        param = param + "%26TightHoleFlg=1";//+ $("#wTightHole").val();
    else
        param = param + "%26TightHoleFlg=0"
    return param;
}