﻿var ActivityLogGridSettings = {
    GridId: "ActivityLogGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: 9, // positive column index, if no sort -1
    DefaultColumnSortOrder: "desc", // asc/desc
    IsScrollY: true,
    //ScrollYHeight: "350px",
    Paging: false,
    DataSource: "GetActivityLog_SP",
    ColumnCollection: [
                    {
                        Name: "Country",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 0,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "District",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DIST_NM",                       
                        DataIndex: 1,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLD_NM",                       
                        DataIndex: 2,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        renderAction:"editCompany",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        renderAction: "GenerateRenderWellDetails",
                        DataIndex: 4,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Uploader",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "UPLOADED_BY",
                        renderAction:"editUser",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Folders",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_CNT",
                        renderAction: "linkFolders",
                        DataIndex: 6,
                        Width: "5%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Files",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FILE_CNT",
                        renderAction: "linkFiles",
                        DataIndex: 7,
                        Width: "5%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Comments",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DATA_UPL_CMNT",
                        renderAction: "renderActivityComment",
                        DataIndex: 8,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Started",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "STRT_TMSTMP",                        
                        DataIndex: 9,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Status",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "UPL_STAT_CD",
                        DataIndex: 10,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
        {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearFilter",
            Action: "clearFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};