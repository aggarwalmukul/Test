﻿var filesGridSettings = {
    GridId: "FilesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc    
   
    ColumnCollection: [{
                        Name: "File Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DATA_FILE_LNM",
                        DataIndex: 0,
                        renderAction: "renderDownloadNewFile",
                        Width: "25%",
                        IsFilterable: false,
                        IsSortable: true
                    },                   
                    {
                        Name: "Size (MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FILE_SZ_VAL",
                        DataIndex: 1,
                        renderAction: "GenerateWellDownloadFormattedSize",
                        Width: "8%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Status",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "FILE_STAT_CD",
                        DataIndex: 2,
                        renderAction: "renderFileColom",
                        Width: "8%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Comments",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "DATA_FILE_CMNT",
                         renderAction: "renderComment",
                         DataIndex: 3,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Uploaded By",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "UPLOADED_BY",
                         renderAction: "renderFileColom",
                         DataIndex: 4,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Upload Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "UPLOAD_DATE",
                         renderAction: "renderFileColom",
                         DataIndex: 5,
                         Width: "14%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Company Name",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CO_NM",
                         renderAction: "renderFileColom",
                         DataIndex: 6,
                         Width: "20%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var soGridSettings = {
    GridId: "soGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    PagingCount: 20,
    IsScrollY: true,
    DataSource: "GetWellSONumbers_SP",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Sales Order Number",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "SLORD_NUM",
        DataIndex: 1,
        Width: "15%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
            {
                Name: "AddSo",
                Action: "AddSo",
                Icon: "create_32x32.png",
                Text: "AddSo",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            }, {
            Name: "DeleteSo",
            Action: "DeleteSo",
            Icon: "delete_32x32.png",
            Text: "DeleteSo",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearSoFilter",
            Action: "clearSoFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearSoFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var groupsGridSettings = {
    GridId: "groupsGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    PagingCount: 20,
    IsScrollY: true,
    DataSource: "GetWellUserGroupEntitlements_SP",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Group Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "USR_GRP_NM",
        renderAction:"editGroup",
        DataIndex: 0,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    },
    {
        Name: "Entitled Folders",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "FLDR_TYP_NM",
        renderAction:"editEntitelements",
        DataIndex: 1,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
            {
                Name: "AddGroup",
                Action: "AddGroup",
                Icon: "create_32x32.png",
                Text: "AddGroup",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            }, {
                Name: "Filter",
                Action: "searchFilter",
                Icon: "filter_32x32.png",
                Text: "Filter",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            },
        {
            Name: "clearGroupFilter",
            Action: "clearGroupFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearGroupFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var dlGridSettings = {
    GridId: "dlGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    PagingCount: 20,
    IsScrollY: true,
    DataSource: "GetWellDistributionListByWBJob_SP",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "DSTBN_LIST_NM",
        renderAction:"editWellDL",
        DataIndex: 0,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    },
    {
        Name: "PSL",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "PSL_NM",
        DataIndex: 1,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
            {
                Name: "AddDL",
                Action: "AddDL",
                Icon: "create_32x32.png",
                Text: "AddDL",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            }, {
                Name: "Filter",
                Action: "searchFilter",
                Icon: "filter_32x32.png",
                Text: "Filter",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            },
        {
            Name: "clearDLFilter",
            Action: "clearDLFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearDLFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var recyclebinGridSettings = {
    GridId: "recyclebinGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc    
    DataSource: "GetWellBinFiles_SP",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "File Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "DATA_FILE_LNM",
        DataIndex: 0,
        renderAction: "renderNewFile",
        Width: "25%",
        IsFilterable: true,
        IsSortable: true
    },
                    {
                        Name: "Size (MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FILE_SZ_VAL",
                        DataIndex: 1,
                        renderAction: "GenerateFormattedSize",
                        Width: "8%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "Status",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "FILE_STATUS",
                        DataIndex: 2,
                        Width: "8%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                     {
                         Name: "Comments",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "DATA_FILE_CMNT",
                         renderAction: "renderComment",
                         DataIndex: 3,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Uploaded By",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "UPLOADED_BY",
                         DataIndex: 4,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Upload Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "UPLOAD_DATE",
                         DataIndex: 5,
                         Width: "14%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Company Name",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CO_NM",
                         DataIndex: 6,
                         Width: "20%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Folder",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "FLDR_TYP_NM",
                         DataIndex: 7,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
            {
                Name: "Restore",
                Action: "Restore",
                Icon: "create_32x32.png",
                Text: "Restore",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            }, {
                Name: "Filter",
                Action: "searchFilter",
                Icon: "filter_32x32.png",
                Text: "Filter",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            },
        {
            Name: "clearRBFilter",
            Action: "clearRBFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearRBFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var dGroupGridSettings = {
    GridId: "dGroupGrid",
    RowSelectionStyle: "RadioButton",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Single", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    PagingCount: 20,
    IsScrollY: true,
    DataSource: "GetUserGroupNotInWell_SP",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Group Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "USR_GRP_NM",
        DataIndex: 1,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    },
    {
        Name: "Company",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "CO_NM",
        DataIndex: 2,
        Width: "40%",
        IsFilterable: true,
        IsSortable: true
    }],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [
             {
                Name: "Filter",
                Action: "searchFilter",
                Icon: "filter_32x32.png",
                Text: "Filter",
                Appearance: "Icon", // (Text or Icon)
                Visible: true,
                Enabled: true
            },
        {
            Name: "clearDGroupFilter",
            Action: "clearDGroupFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearDGroupFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};