﻿var rID;
var UploadSessionGuid;
var DataFileGuid;
var destinationPath;
var UploadGUID;
var DrivePath;
var DriveGuid;
$(document).ready(function () {

    $("#titleAreaRow").hide();
    $("#mainContent").hide();
    
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {                
                    self.close();                
                    $(this).dialog('close');
            }
        }
    });
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
                var table = $("#" + rID).DataTable();
                table.row('.selected').remove().draw(false);
                $(this).dialog('close');
                $(".selectall", "#" + rID + "_wrapper").removeAttr("checked");
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#cancel").on("click", function () {
        self.close();
    });
    var recipientsGridData = [];
    $("#" + recipientsGridSettings.GridId).renderGrid(recipientsGridSettings, recipientsGridData);

    var RecipientsFilesGridData = [];
    $("#" + UserToUserTransferFilesGridSettings.GridId).renderGrid(UserToUserTransferFilesGridSettings, RecipientsFilesGridData);
   
    $("#UserToUserTransferFilesGridtoolbar").find("img[id='Add']").attr("id", "addFiles");
    GetUserGuid(GetUserGUIDDetails);
    GetStorageDrive(UpdateDrives);

    plupload.addFileFilter('cust_Ext_Val', function (maxSize, file, cb) {
        var undef;
        var ext = ".exe,.dll,.asp,.aspx.cs,.aspx.vb,.vbe,.wsf,.wsc,.wsh,.bat,.vb,.vbs,.js,.com,.htm,.html,.shtml,.hta";
        var arr = ext.split(",");
        var filext = file.name.split(".")[1];
        var flag = false;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == ("." + filext)) {
                flag = true;
                break;
            }
        }
        // Invalid file size
        if (flag) {
            this.trigger('Error', {
                code: plupload.FILE_SIZE_ERROR,
                message: plupload.translate('Selected file type not allowed.'),
                file: file
            });
            cb(false);
        } else {
            cb(true);
        }
    });

    var uploader = new plupload.Uploader({
        runtimes: 'html5,silverlight,flash,html4',
        browse_button: 'addFiles', // you can pass in id...
        container: document.getElementById('UserToUserTransferFilesGridtoolbar'), // ... or DOM Element itself
        url: "http://" + window.location.hostname + ":" + window.location.port + "/_layouts/15/upload/uploadhandler.ashx",
        flash_swf_url: '/_layouts/15/XSP/JS/Moxie.swf',
        silverlight_xap_url: '/_layouts/15/XSP/JS/Moxie.xap',
        chunk_size: '500kb',
        unique_names: false,
        multipart_params: {
            "name1": "value1",
            "name2": "value2"
        },
        filters: {
            max_file_size: '10000mb',
            prevent_duplicates: true,
            cust_Ext_Val: "validate",
            mime_types: [
            //{ title: "Image files", extensions: "jpg,gif,png" },
            //{ title: "Vedio files", extensions: "mkv" },
            //{ title: "Text files", extensions: "pdf,txt,docx,xlsx" },			
			//{ title: "Zip files", extensions: "zip" }
		]
        },

        init: {
            PostInit: function () {
                document.getElementById('Submit').onclick = function () {                    
                    InsertUploadSession(null, "USER", "INPROG", $("#UserToUserTransferComments").val(),
                                            UserGUID, 0,
                                            "InsertUploadSession_SP", KickUploadSession);
                }
            },
            BeforeUpload: function (up, file) {
                               params = uploader.settings.multipart_params;
                               params.UploadStorageDrive = DrivePath;
                ///Users/[User Guid]/Uploads/[Date in YYYYMMDD format]/[Upload Session Guid]
                               destinationPath = "\\\\Users\\" + UserGUID + "\\Uploads\\" + yyyymmdd(new Date()) + "\\" + UploadSessionGuid ;

                               params.folderPath = destinationPath;// cretae folder structure
                               var size = file.size / 1048576;
                               var roundoffsize = round(size, 2);
                               InsertDataFile(DriveGuid, file.name, destinationPath, roundoffsize, "FINAL", null, $("#UserToUserTransferComments").val(), "InsertDataFile_SP", KickFileUploadForDataEntry);
            },
            FilesAdded: function (up, files) {
            $("#console").html("");
            var table=$("#" + UserToUserTransferFilesGridSettings.GridId).DataTable();
              plupload.each(files, function (file) {
                    var obj = new Object();
                    obj.FileName = file.name;
                    obj.DT_RowId = file.id;
                    obj.Size = file.size / (1024 * 1024);
                    RecipientsFilesGridData.push(obj);
                    table.row.add(obj).draw(false);
                });
                table.draw();                
            },

            FileUploaded: function (up, file)
            {
                InsertDistributionListUser('comment', GetDistributionGUID);
            },

            UploadProgress: function (up, file) {
                var table = $("#" + UserToUserTransferFilesGridSettings.GridId).DataTable();
                var rows = table.rows(file.name).data();                
                for (var i = 0; i < rows.length; i++) {
                    console.dir(rows[i]);
                }

               // var data = table.rows([file.Name]).data;
               // data[1] = data[1] + data[0];

                UpdateUploadProgress(UploadGUID, file.percent, "UpdateFileUploadPercent_SP", null);
            },
            UploadComplete: function (up, file) {
                $("#alert").html("User to user file transfer complete.").dialog("open");
            },
            Error: function (up, err) {
                ShowCustomAlert("Error: " + err.message,"Alert",350);               
                //               document.getElementById('console').innerHTML += "\nError #" + err.code + ": " + err.message;
            }
        }
    });

    uploader.init();
    function UpdateDrives(data) {       
        DrivePath = data[0].DRV_PATH;
        DriveGuid = data[0].DRV_GUID;
    }

    function KickUploadSession(data) {
        var session = data;
        UploadSessionGuid = session[0].DATA_UPL_GUID;
        uploader.start();
        return false;
    }
    function KickFileUploadForDataEntry(data) {       
        DataFileGuid = data[0].DATA_FILE_GUID;
        //InsertWBJobDataFile(WellGUID, dataFileGuid, FolderID, "InsertWBJobDataFile_SP", undefined);
        InsertUploadFile(UploadSessionGuid, DataFileGuid, DriveGuid, destinationPath, "InsertFileUpload_SP", KickFileUpload);
    }
    function KickFileUpload(data) {       
        UploadGUID = data[0].DATA_FILE_UPL_GUID;
    }
});

function AddRecipients(sourceGridID) {
   // alert(sourceGridID);
    PopulateRecipients(sourceGridID);
    $("#dialog-personnel").dialog("open");
}

function AddFiles() {
}
function yyyymmdd(dateIn) {
    var yyyy = dateIn.getFullYear();
    var mm = dateIn.getMonth() + 1; // getMonth() is zero-based
    var dd = dateIn.getDate();
    return String(10000 * yyyy + 100 * mm + dd); // Leading zeros for mm and dd
}
function RemoveRecipients() {
    rID = recipientsGridSettings.GridId;
    var table = $("#" + recipientsGridSettings.GridId).DataTable();
    if (table.row('.selected')[0].length > 0) {
        var a = table.row('.selected')[0];
        $("#confirm").html("Are you sure to delete selected user(s)?").dialog("open");;
    }
    else {
        ShowCustomAlert("No item selected.");
    }
}
function RemoveFile() {
    rID = UserToUserTransferFilesGridSettings.GridId;
    var table = $("#" + UserToUserTransferFilesGridSettings.GridId).DataTable();
    if (table.row('.selected')[0].length > 0) {
        var a = table.row('.selected')[0];
        $("#confirm").html("Are you sure to delete selected file(s)?").dialog("open");
    }
    else {
        ShowCustomAlert("No item selected.");
    }
}

function GetDistributionGUID(data) {
    var GetDist = data;
    DSTGUID = GetDist[0].DSTBN_GUID;   
    InsertDistributionFile(DSTGUID, DataFileGuid, GetDistributionFileGUID)           
}

function GetDistributionFileGUID(data) {
    var GetDistFile = data;
    var DSTFileGUID = GetDistFile[0].DSTBN_FILE_GUID;
    if (typeof (DSTGUID) != 'undefined' && DSTGUID.length > 0) {
        if (typeof (DataFileGuid) != 'undefined' && DataFileGuid.length > 0) {
            InsertDistributionRecipient(DSTGUID, DataFileGuid, GetDistributionRecptGUID)
        }
    }
}
function GetDistributionRecptGUID(data) {
    var GetDistRecpFile = data;
    var DSTFileRecptGUID = GetDistRecpFile[0].DSTBN_RCPT_GUID;
}
function InsertDistributionRecipient(DSTGUID, DFileGUID, callback) {
    var dropboxUsers = $("#" + recipientsGridSettings.GridId).DataTable().rows().data();
    if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
        for (var i = 0; i < dropboxUsers.length; i++) {
            var param = "DataFileGuid=" + "'" + DataFileGuid + "'%26" + "DistributionGuid=" + "'" + DSTGUID + "'%26" + "RecUserGuid=" + "'" + dropboxUsers[i].USR_GUID + "'%26" + "Email=" + "'NULL'";
            var data = GetXSpaceData(param, "InsertDistributionRecipient_SP", callback);
        }
    }    
}
