﻿var currentStatus="";
var currentComment="";
var fileExtension="";
$(document).ready(function () {

    $("#divFileStatus").dialog({
        autoOpen: false,
        modal: true,
        title: "Edit File Status",
        height: 250,
        width: 400,
        open: function () {
            var select = document.getElementById("FileSelectList");
            var selValue = "";
            if (currentStatus == "Internal")
                selValue = "INTRNL";
            else if (currentStatus == "Preliminary")
                selValue = "PRELM";
            else if (currentStatus == "Final")
                selValue = "FINAL";

            $("#FileSelectList").val(selValue);
            selectedIndex = $("#FileSelectList option:selected").index();
            select.selectedIndex = selectedIndex;
            if (USERROLE == USERROLE_TYPE.CustomerUser) {
                $("#FileSelectList option[value='INTRNL']").remove();
            }
        },
        buttons: {
            "OK": function () {
                selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
                var guids = "";
                for (var index = 0; index < selectedFiles.length; index++) {
                    var param = "DataFileGuid='" + selectedFiles[index].DATA_FILE_GUID + "'%26" + "StatusCode='" + $("#FileSelectList").val() + "'";
                    currentStatus = "";
                    guids = guids + selectedFiles[index].DATA_FILE_GUID + ",";
                    GetXSpaceData(param, "UpdateDataFile_SP", undefined);
                    if (index == selectedFiles.length - 1) {
                        var oTable = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
                        $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
                        oTable.dataTable().fnDestroy();
                        var param = "UserID='" + USERID + "'";
                        GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);
                        {
                            $(this).dialog('close');
                        }
                    }
                }
                guids = guids.substring(0, guids.length - 1);
                FileStatusChangeNotification(guids);
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });

    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 150,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });

    $("#divComments").dialog({
        autoOpen: false,
        modal: true,
        title: "Comments",
        height: 250,
        width: 400,
        resizable: false,
        open: function () {
            $("#TextComments").val(currentComment);
            var maxLength = parseInt($('textarea[maxlength]').attr('maxlength'));
            var currentLengthInTextarea = $("#TextComments").val().length;
            $("#remainingLengthTempId").text(parseInt(maxLength) - parseInt(currentLengthInTextarea));
        },       
        buttons: {
            "OK": function () {
                var param = "DataFileGuid='" + $("#fileGuid").val() + "'%26" + "Comments='" + $("#TextComments").val() + "'";
                GetXSpaceData(param, "UpdateDataFile_SP", undefined);
                var oTable = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
                $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
                oTable.dataTable().fnDestroy();
                var param = "UserID='" + USERID + "'";
                GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);
                {
                    $(this).dialog('close');
                }
            },
            "Cancel": function () {
				currentComment="";
                $(this).dialog('close');
            }
        }
    });

    $("#divDelete").dialog({
        autoOpen: false,
        modal: true,
        title: "Delete File",
        height: 250,
        width: 400,
        buttons: {
            "OK": function () {
                var guids = $("#fileidlist").val().split(",");
                for (var i = 0; i < guids.length; i++) {
                    var param = "DataFileUploadGuid='" + guids[i] + "'";
                    GetXSpaceData(param, "DeleteDataFileUpload_SP", undefined);

                }
                {
                    var oTable = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
                    $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
                    oTable.dataTable().fnDestroy();
                    var param = "UserID='" + USERID + "'";
                    GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);
                    dirtyActiveWellData = true;
                    $(this).dialog('close');
                }

            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });

    
    $("#divRename").dialog({
        autoOpen: false,
        modal: true,
        title: "Rename File",
        height: 200,
        width: 500,        
        buttons: {
            "OK": function () {
				if($.trim($("#fileName").val())==""){
					 $("#alert").html("Please enter File Name.").dialog('open');
					 return false;
				}
				var fileNameWithExtension=$.trim($.trim($("#fileName").val())+fileExtension);
                var o = { Guid: $("#fileid").val(), FileName: fileNameWithExtension };
                var closedialog = false;
                //var FilePath = $("#fileInfo").data('File')
                var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/RenameFile";

                $.ajax({
                    url: urlstring,
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify(o),
                    async:false,
                    //data: { PathUrl : "Test" },
                    contentType: "application/json; charset=utf-8",
                    error: function (errorThrown) {
                    },
                    success: function (status) {
                        var stat = JSON.parse(status.d);
                        if (stat == "success") {
                            closedialog = true;
                            var oTable = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
                            $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
                            oTable.dataTable().fnDestroy();
                            var param = "UserID='" + USERID + "'";
                            GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);
                            
                        }
                        else {
                            $("#alert").html("File with entered Name already exists. Please enter different Name.").dialog('open');

                        }
                        

                    },
                });
                if (closedialog == true) {
                    $(this).dialog('close');
                }
                
             },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("keypress blur", "textarea", function () {
        if (!$(this).hasClass("exclude"))
            removeSpecialChar($(this));
    });

    $("#divFileMove").dialog({
        autoOpen: false,
        modal: true,
        title: "Move File",
        height: 200,
        width: 400,
        open: function () {
            GetWellFolders(UpdateWellFolders);
        },        
        buttons: {
            "OK": function () {
               
                for (var i = 0; i < selectedFiles.length; i++) {
                    var o = { Guid: selectedFiles[i].DATA_FILE_GUID, DataUploadGuid: selectedFiles[i].DATA_FILE_UPL_GUID, Folder: $("#FileFolderList :selected").text(), FolderType: $("#FileFolderList").val() };
                    var closedialog = false;                  
                    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/MoveFile";

                    $.ajax({
                        url: urlstring,
                        type: "POST",
                        dataType: "json",
                        data: JSON.stringify(o),
                        async: false,
                        //data: { PathUrl : "Test" },
                        contentType: "application/json; charset=utf-8",
                        error: function (errorThrown) {
                        },
                        success: function (status) {
                            var stat = JSON.parse(status.d);
                            if (stat == "success") {
                                closedialog = true;
                                var oTable = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
                                $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
                                oTable.dataTable().fnDestroy();
                                var param = "UserID='" + USERID + "'";
                                GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);

                            }
                            else {
                                $("#alert").html("File with entered Name already exists. Please enter different Name.").dialog('open');
                            }
                        },
                    });
                    if (closedialog == true) {
                        $(this).dialog('close');
                    }
                }

            },
            "Cancel": function () {
                $(this).dialog('close');
                }
            }
        
    });

    $("#fileInfo").dialog({
        autoOpen: false,
        modal: true,
        title: "File Info",
        height: 320,
        width: 500,
        open: function () {
            var o = { Guid: fileGuid };
            //var FilePath = $("#fileInfo").data('File')
            var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/GetFileList";

            $.ajax({
                url: urlstring,
                type: "POST",
                dataType: "json",
                data: JSON.stringify(o),
                //data: { PathUrl : "Test" },
                contentType: "application/json; charset=utf-8",
                error: function (errorThrown) {
                },
                success: function (dataFile) {
                    var temp = JSON.parse(dataFile.d);
                    $("#" + fileListGridSettings.GridId).renderGrid(fileListGridSettings, JSON.parse(dataFile.d));
                    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
                },
            });

        },
        close: function () {
            var oTable = $("#" + fileListGridSettings.GridId).dataTable();
            $("#" + fileListGridSettings.GridId + "tbody").html("");
            oTable.dataTable().fnDestroy();
        },
        buttons: {
            "Download": function () {
                DownloadZipSelectedFiles();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });


    $("#UserUploadedDataGridtoolbar").width("500px");
    $('#UserUploadedDataGridtoolbar').css('display', '');

    //GetUserGuid(GetUserGUIDDetails);
    
    
    $(window).keypress(function (e) {
        if (e.keyCode == 13) {
            searchFilter();
            return false;
        }
    });
});
function loadMyUploadedWellData() {
    if ($.fn.dataTable.isDataTable("#" + UserUploadedDataGridSettings.GridId)) {
        var oTable1 = $("#" + UserUploadedDataGridSettings.GridId).dataTable();
        $("#" + UserUploadedDataGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    var param = "UserID='" + USERID + "'";
    GetXSpaceData(param, UserUploadedDataGridSettings.DataSource, bindMyUploadedData);
}
function UpdateWellFolders(data) {
    //var wellfoldersdata = JSON.parse(data.GetFolderType_SP);
    $("#FileFolderList").empty();
    var wellfoldersdata = data;

    var selectwellfolders = document.getElementById("FileFolderList");
    for (var i = wellfoldersdata.length - 1; i >= 0; i--) {
        var option = document.createElement('option');

        option.text = wellfoldersdata[i].FLDR_TYP_NM;
        option.value = wellfoldersdata[i].FLDR_TYP_ID;
        selectwellfolders.add(option, 0);
    }
    selectwellfolders.selectedIndex = 0;
}   

function renderDownloadFile(data, type, full, meta) {
    //return "<img title='Zip File Contents' src='/_layouts/15/xsp/Images/file_info_16x16.png' height='20' width='30' style='cursor:pointer; padding-right:2px;' onclick='openZipDialog(\"" + FileName + "\"" + ',' + "\"" + folder + "\");'/>";
    return GetFileDownloadlink(full.DATA_FILE_GUID, data);
}
function RenameFile(gridid) {
    var data = $("#" + UserUploadedDataGridSettings.GridId).DataTable().rows(".selected").data();

    if (data.length == 1) {
        $("#fileid").val(data[0].DATA_FILE_GUID);
        var files = $.trim(data[0].DATA_FILE_LNM);
        if (data[0].DATA_FILE_LNM.lastIndexOf('.') > 0) {
            files = $.trim(data[0].DATA_FILE_LNM.substring(0, data[0].DATA_FILE_LNM.lastIndexOf('.')));
            fileExtension = $.trim(data[0].DATA_FILE_LNM.substring(data[0].DATA_FILE_LNM.lastIndexOf('.'), data[0].DATA_FILE_LNM.length));
        }
        else
            fileExtension = "";
        $("#fileName").val(files);
        $("#divRename").dialog('open');
    }
    else if (data.length > 1) {
        ShowMultipleFileMessage();
    }
    else {
        $("#alert").html("Please select a file to rename.").dialog('open');
        return;
    }
}


var selectedFiles = [];
function MoveFile(gridid) {
    var data = $("#" + UserUploadedDataGridSettings.GridId).DataTable().rows(".selected").data();
    if (data.length > 1) {
        var WellGuids = groupBy(data, 'WB_JOB_GUID');
        if (WellGuids.length > 1) {
            $("#alert").html("Action is allowed for same well only.").dialog('open');
            return;
        }       
    }
    selectedFiles = data;
    if (data.length >= 1) {
        $("#Movefileid").val(data[0].DATA_FILE_GUID);
        $("#WellName").val(data[0].WELL_NM);
        $("#MoveUploadfileid").val(data[0].DATA_FILE_UPL_GUID);        
        
        $("#divFileMove").dialog('open');
    }
    else{
        $("#alert").html("Please select file(s) to move.").dialog('open');
        return;
    }
}

function DeleteFile(gridid) {
    var data = $("#" + UserUploadedDataGridSettings.GridId).DataTable().rows(".selected").data();
    var Filenames = "<br>";
    var FileGuids = "";

    if (data.length > 0) {
        for (var i = 0 ; i < data.length; i++) {
            Filenames = Filenames + data[i].DATA_FILE_LNM + "<br>";
            if (i == data.length - 1) {
                FileGuids = FileGuids + data[i].DATA_FILE_UPL_GUID;
            }
            else {
                FileGuids = FileGuids + data[i].DATA_FILE_UPL_GUID + ",";
            }

        }
        $("#fileidlist").val(FileGuids);

        var y = document.getElementById("fileNamelist");
        y.innerHTML = Filenames;
        $("#divDelete").dialog('open');
    }
    else {
        $("#alert").html("Please select file(s) to delete.").dialog('open');
        return;
    }    
}

function ShowMultipleFileMessage()
{
    $("#alert").html("Action is allowed for single file selection only. Please select single file and try again.").dialog('open');
}
function EditComments(sourceGridID) {
    var data = $("#" + UserUploadedDataGridSettings.GridId).DataTable().rows(".selected").data();

    if (data.length == 1) {
        $("#fileGuid").val(data[0].DATA_FILE_GUID);
		currentComment=data[0].DATA_FILE_CMNT;
        $("#divComments").dialog('open');
    }
    else if (data.length > 1) {
        ShowMultipleFileMessage();
    }
    else {
        $("#alert").html("Please select a file.").dialog('open');
        return;
    }
}
function EditStatusDialog(sourceGridID) {
    var data = $("#" + UserUploadedDataGridSettings.GridId).DataTable().rows(".selected").data();

    if (data.length == 1) {
        $("#fileStatusGuid").val(data[0].DATA_FILE_GUID);
		currentStatus=data[0].FILE_STATUS;
        $("#divFileStatus").dialog('open');
    }
    else if (data.length > 1) {
        //ShowMultipleFileMessage();
		currentStatus="";
        $("#divFileStatus").dialog('open');
    }
    else if (data.length == 0) {
        $("#alert").html("Please select a file.").dialog('open');
        return;
    }

}
function bindMyUploadedData(data) {

    if (USERROLE == USERROLE_TYPE.CustomerUser) {
        var statusType = "INTERNAL";      
        var results = $.grep(data, function (element, index) {
            return element.FILE_STATUS.toUpperCase().indexOf(statusType) == -1;
        });

        $("#" + UserUploadedDataGridSettings.GridId).renderGrid(UserUploadedDataGridSettings, results);
    }
    else {
        $("#" + UserUploadedDataGridSettings.GridId).renderGrid(UserUploadedDataGridSettings, data);
    }

    $("#UserUploadedDataGridtoolbar").width("490px");
    $('#UserUploadedDataGridtoolbar').css('display', '');
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
}

function qs(key) {
    return GetUrlParameter(key);
}

function reloadMyFiles() {
   window.location.reload();
}

var selectedFilePath;

function openZipDialog(fileName, folder, filePath) {
    fileGuid = fileName;
    selectedFilePath = filePath;

    $("#fileInfo").dialog("open");
}

function DownloadZipSelectedFiles() {
    var table = $("#" + fileListGridSettings.GridId).DataTable();
    if (table.row('.selected').length > 0) {
        DownloadZipfiles();
    }
    else {
        $("#alert").html("Please select file(s) to download.").dialog("open");
    }
}

function DownloadZipfiles() {

    var fileid = [];
    var FileNames = "";
    var data = $("#" + fileListGridSettings.GridId).DataTable().rows(".selected").data();

    for (var i = 0; i < data.length; i++) {
        FileNames = FileNames + data[i].FileName + ",";
        fileid.push(data[i].FileGuid);
    }

    FileNames = FileNames.substring(0, FileNames.lastIndexOf(","));
    DownloadFile(fileid, false, FileNames);
   // DownloadAndLogAuditDropBox(fileid, FileNames);
    return false;
}