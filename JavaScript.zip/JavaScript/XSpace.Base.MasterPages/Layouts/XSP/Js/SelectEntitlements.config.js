﻿var AvailableEntitlementsGridettings = {
    GridId: "AvailableEntitlementsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "120px",
    Paging: false,
    ColumnCollection: [
                    {
                        Name: "Available Entitlements",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_TYP_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var SelectedEntitlementsGridettings = {
    GridId: "SelectedEntitlementsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "120px",
    Paging: false,
    ColumnCollection: [

                    {
                        Name: "Selected Entitlements",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_TYP_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};