﻿var IsDirty = false;
var IsEditEntitlements = false;
var WellName;
var GroupName;
var AffiliatedCompany;
var IsEntitledGrid = false;
$(document).ready(function () {
    $(document).on("keypress blur", "input", function () {
        if (!$(this).hasClass("exclude"))
             removeSpecialChar($(this));
    });
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm Delete",
        height: 140,
        width: 350,
        buttons: {
            "Yes": function () {
               
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $('#officePhone').mask("000-000-0000", { placeholder: "___-___-____" });
    $('#cellPhone').mask("000-000-0000", { placeholder: "___-___-____" });
	$("#cellPhone").focusout(function (e) {	
		textNotificationValidation();
	});
	$("#provider").change(function(e){
		textNotificationValidation();
	})
   
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#activeWell").on("keypress", function () {
        evt = event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    });
    $("input").each(function () {
        if ($.trim($(this).val()) == "")
            $(this).val("");
    });
      

    $("#save").on("click", function () {
        //write save logic  and redirect to groups page
        if (IsDirty && validate())
        {
            saveData();
        }
    });

    $(document).on("click", "#back", function () {
        if (typeof(qs("CompanyID")) != "undefined")
            window.location.href = "/_layouts/15/XSP/Pages/EditCompany.aspx?tab=U&CompanyID=" + qs("CompanyID");
        else {
			 window.location.href = "/_layouts/15/XSP/Pages/DropBox.aspx?UserID="+qs('UserID');
		}
           
    });

    $("select,input").on("change", function () {
            IsDirty = true;
            if (typeof ($(this).attr("readonly")) == 'undefined')
                $("#save").attr("src", "../images/save_dirty_24x24.png");
    });

    $("input").on("keyup", function () {
        IsDirty = true;
        if (typeof ($(this).attr("readonly")) == 'undefined')
            $("#save").attr("src", "../images/save_dirty_24x24.png");
    });

   
    $("#settingtabs").tabs({
        activate: function (event, ui) {            
            if (ui.newPanel.is("#Setting")) {
                ////
            }
            else if (ui.newPanel.is("#Groups")) {
                clearGroupTabFilter();

                $("input").on("keyup", function () {
                    IsDirty = true;
                    $("#clearGroupFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                    if ($("#clearGroupFilter").length > 0)
                        $("#clearGroupFilter")[0].onclick = null;
                    return false; 
                });

                $("#clearGroupFilter").on("click", function () {
                    clearGroupTabFilter();
                });
            }
            else {               
                clearWellTabFilter();

                $("input").on("keyup", function () {
                    IsDirty = true;
                    $("#clearWellFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                    if ($("#clearWellFilter").length > 0)
                        $("#clearWellFilter")[0].onclick = null;
                    return false;
                });

                $("#clearWellFilter").on("click", function () {
                    clearWellTabFilter();
                });
            }
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });
    if (typeof (qs("UserID")) == "undefined")
    {
        $("#back").hide();
        $($("#settingtabs").find("li")[1]).hide();
        $($("#settingtabs").find("li")[2]).hide();
    }
	 
	 
    $(document).on("click", "#btnCompany", function () {
        $("#dCompany").dialog('open');
        return false;
    });
    $("#dCompany").dialog({
        autoOpen: false,
        modal: true,
        title: "Company",
        height: 140,
        width: 500,
        buttons: {
            "OK": function () {
                $("#dvCompany").html($("#ddlCompany option:selected").text())
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    loadMemberships();
    loadAccessibleWells();
    populateCompany();
    $(window).keypress(function (e) {
        if (e.keyCode == 13) {
            searchFilter();
            return false;
        }
    });
    window.onbeforeunload = function () {
        if (IsDirty == true) {
            // $("#dSaveConfirm").html("You have unsaved changes.Do you want to save?").dialog('open');
           /* if (confirm("You have unsaved changes.Do you want to save?")) {
                //write save logic  and redirect to groups page
                return saveData();
                
            }
            else {
                return;
            } */
            return 'You have unsaved changes!';
        }
        //return;
    };
    loadData();
	var selectedtab = qs("tab");
	if(selectedtab=="g")
	    $("#settingtabs").tabs({ active: 1 });

	if ($("#dvCompany").html() != "OTHER") {
	    $("#btnCompany").hide();
	}
});

function DestoryRenderedDatatables() {
    $("tr[id='_filterRow']").find("input").val("");

    if ($.fn.dataTable.isDataTable("#" + groupGridSettings.GridId)) {
        var oTable1 = $("#" + groupGridSettings.GridId).dataTable();
        $("#" + groupGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }

    if ($.fn.dataTable.isDataTable("#" + EntitlementsGridSettings.GridId)) {
        var oTable1 = $("#" + EntitlementsGridSettings.GridId).dataTable();
        $("#" + EntitlementsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}

function clearGroupTabFilter() {
    IsDirty = false;
    $("#clearGroupFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryRenderedDatatables();   
    loadMemberships();
}

function clearWellTabFilter() {
    IsDirty = false;
    $("#clearWellFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryRenderedDatatables();   
    loadAccessibleWells();
}

function loadData() {
    //GetUserGuid(GetUserGUIDDetails);
    loadProvider();
}
var IsHalUser;
function loadFields() {
    var param ;
    if (typeof (qs("UserID")) == "undefined")
        param = "UserID='" + document.getElementById('userID').value + "'";
    else
        param = "UserID='" + qs("UserID") + "'";
    //GetUserDetailByUserID_SP?UserID='hb89866'
    GetXSpaceData(param, "GetUserDetailByUserID_SP", function (data) {
        IsHalUser = data[0].HAL_FLG;
        var data = GetXSpaceData(param, "GetUserSettings_SP", SetData);
    });
    
}
function loadNotification()
{   
    var data = GetXSpaceData("", "GetNotificationType_SP",  bindNotification);
}
function loadProvider() {
    var data = GetXSpaceData("", "GetCellPhoneProviderList_SP", bindProvider);
}
function populateCompany() {
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        var select = $("#ddlCompany")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CO_ID;
            option.text = data[i].CO_NM;
            select.options.add(option);
        }
    });
}
function SetData(data)
{    
    $("#dvUserName").html(data[0].USR_NM);
    $("#dvCompany").html(data[0].CO_NM);
    if (IsHalUser != 1) {
        $("#altEmailSpan").css("display", "");
        $("#altEmail").css("display", "");
    }
    if (data[0].FLDR_IN_ZIP_FLG == 1)
        $("#embedZip").attr("checked", true);
    if (data[0].ALT_EMAIL_ADDR_DESC != null && IsHalUser != 1)
        $("#altEmail").val(data[0].ALT_EMAIL_ADDR_DESC);
    if (data[0].WELL_NTFN_FLG == 1)
        $("#wellNotification").attr("checked", true);
    if (data[0].PHONE_NUM != null)
        $("#officePhone").val(maskValue(data[0].PHONE_NUM));
    if (data[0].DROP_BOX_NTFN_FLG == 1)
        $("#dropboxNotification").attr("checked", true);
    if (data[0].EMAIL_NTFN_FLG == 1)
        $("#DropboxTextNotification").attr("checked", true);
    if (data[0].TXT_NTFN_FLG == 1)
        $("#WellTextNotification").attr("checked", true);
    if (data[0].CELL_PHONE_NUM != null)
        $("#cellPhone").val(maskValue(data[0].CELL_PHONE_NUM));
    if (data[0].FILE_ACTV_DY_CNT != null)
        $("#activeWell").val(data[0].FILE_ACTV_DY_CNT);
   // $("#notificationMethod").val(data[0].NTFN_TYP_CD);
    $("#provider").val(data[0].CELL_PHONE_PRVDR_CD);
	textNotificationValidation();
    
}
function validate() {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var email = $.trim($("#altEmail").val());
    if (email != "") {
        if (!regex.test(email)) {
            $("#alert").html("Invalid alternate email.").dialog('open');
            return false;
        }
    }
    var regExphone = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
    var phone = $.trim($("#officePhone").val());
    if (phone != "") {
        if (!regExphone.test(phone)) {
            $("#alert").html("Invalid office phone number.").dialog('open');
            return false;
        }
    }
    var cell = $.trim($("#cellPhone").val());
	if (cell == "") {        
        $("#alert").html("Please enter cell phone number.").dialog('open');
        return false;
        
    }
    if (cell != "") {
        if (!regExphone.test(cell)) {
            $("#alert").html("Invalid cell phone number.").dialog('open');
            return false;
        }
    }

    if (cell != "")
    {
        if ($("#provider").val() == "")
        {
            $("#alert").html("Please select a cell phone provider.").dialog('open');
            return false;

        }
    }
    return true;
}
function bindNotification(data) {
    //var select = document.getElementById("notificationMethod");
    //var option = document.createElement('option');
    // select.add(option);
    // for (var i = 0; i < data.length; i++) {
    //    option = document.createElement('option');
    //    option.text = data[i].NTFN_TYP_NM;
    //    option.value = data[i].NTFN_TYP_CD;
    //    select.add(option);
    //}
    // select.selectedIndex = 0;
     loadProvider();
}
function bindProvider(data) {
    var select = document.getElementById("provider");
    var option = document.createElement('option');
    select.add(option);
    for (var i = 0; i < data.length; i++) {
        option = document.createElement('option');
        option.text = data[i].CELL_PHONE_PRVDR_NM;
        option.value = data[i].CELL_PHONE_PRVDR_CD;
        select.add(option);
    }
    select.selectedIndex = 0;
    loadFields();
}
function saveData() {
    var param;
    if (typeof(qs("UserID"))=="undefined")
        param = "UserID='" + document.getElementById('userID').value + "'";
    else
        param = "UserID='" + qs("UserID") + "'";
    if ($("#embedZip")[0].checked == true)
        param = param + "%26FolderZipFlg='1'";
    else
        param = param + "%26FolderZipFlg=''";
    if ($("#wellNotification")[0].checked == true)
        param = param + "%26WellNotifyFlg='1'";
    else
        param = param + "%26WellNotifyFlg=''";

    if ($("#WellTextNotification")[0].checked == true)
        param = param + "%26WellNotifyTxtFlg='1'";
    else
        param = param + "%26WellNotifyTxtFlg=''";

    if ($("#dropboxNotification")[0].checked == true)
        param = param + "%26DropBoxNotifyFlg='1'";
    else
        param = param + "%26DropBoxNotifyFlg=''";

    if ($("#DropboxTextNotification")[0].checked == true)
        param = param + "%26DropBoxNotifyTxtFlg='1'";
    else
        param = param + "%26DropBoxNotifyTxtFlg=''";
   // if ($("#notificationMethod").val() != "")
      //  param = param + "%26NotifyType='" + $("#notificationMethod").val() + "'";
   // else
        param = param + "%26NotifyType=''";
    if ($("#provider").val() != "")
        param = param + "%26CellProviderType='" + $("#provider").val() + "'";
    else
        param = param + "%26CellProviderType=''";
    if ($.trim($("#officePhone").val()) != "")
        param = param + "%26OfficePhone='" + $.trim($("#officePhone").val()) + "'";
    else
        param = param + "%26OfficePhone=''";
    if ($.trim($("#cellPhone").val()) != "")
        param = param + "%26CellPhone='" + $.trim($("#cellPhone").val()) + "'";
    else
        param = param + "%26CellPhone=''";
    if ($.trim($("#altEmail").val()) != "")
        param = param + "%26AltEmailAddress='" + $.trim($("#altEmail").val()) + "'";
    else
        param = param + "%26AltEmailAddress=''";
    if ($.trim($("#activeWell").val()) == "")
        param = param + "%26FileActDays=0";
    else
        param = param + "%26FileActDays=" + $.trim($("#activeWell").val());
    
    if ($("#ddlCompany").val() != "")
        param = param + "%26CompanyID='" + $("#ddlCompany").val() +"'";

    var data = GetXSpaceData(param, "UpdateUserSettings_SP", dataSaved);
}
function dataSaved() {
    $("#alert").html("Settings saved successfully.").dialog('open');
    IsDirty = false;
    $("#save").attr("src", "../images/save_32x32.png");
    goBack();
    return;
}
function loadMemberships()
{
    var param;
    if (typeof (qs("UserID")) == "undefined")
        param = "UserID='" + document.getElementById('userID').value + "'";
    else
        param = "UserID='" + qs("UserID") + "'";
    GetXSpaceData(param, groupGridSettings.DataSource, bindMemberships);
}
function bindMemberships(data) {
    if (data.length >= 0)
    {
        $("#membershipCount").html(data.length);
    }
    $("#" + groupGridSettings.GridId).renderGrid(groupGridSettings, data);
}
function loadAccessibleWells() {
    var param;
    if (typeof (qs("UserID")) == "undefined")
        param = "UserID='" + document.getElementById('userID').value + "'";
    else
        param = "UserID='" + qs("UserID") + "'";
    GetXSpaceData(param, EntitlementsGridSettings.DataSource, bindAccessibleWells);
}
function bindAccessibleWells(data) {
    if (data.length >= 0) {
        $("#accessibleWellCount").html(data.length);
    }
    $("#" + EntitlementsGridSettings.GridId).renderGrid(EntitlementsGridSettings, data);
}
function editGroup(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?editUser=" + qs("UserID") + "&GroupID=" + full.USR_GRP_GUID + "'>" + full.USR_GRP_NM + "</a>";
}
function editUser(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=U&GroupID=" + full.USR_GRP_GUID +"&editUser="+qs('UserID')+"'>" + full.USR_CNT + "</a>";
}
function editEnt(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=E&GroupID=" + full.USR_GRP_GUID +"&editUser="+qs('UserID')+"'>" + full.ENTLMNT_CNT + "</a>";
}

function goBack() {
    if (typeof (qs("CompanyID")) != "undefined")
        window.location.href = "/_layouts/15/XSP/Pages/EditCompany.aspx?tab=U&CompanyID=" + qs("CompanyID");
    else if (typeof (qs("type")) != "undefined" && qs("type")=="activity")
        window.location.href = "/_layouts/15/XSP/Pages/ActivityLog.aspx";
    else if (typeof (qs("UserID")) != "undefined")
        window.location.href = "/_layouts/15/XSP/Pages/Users.aspx?tab=A"
}

function textNotificationValidation(){	
var cellPhone=$.trim($("#cellPhone").val());
var provider=$("#provider").val();
	if(cellPhone!="" && provider!=""){
		$("#WellTextNotification").removeAttr("disabled");
		$("#DropboxTextNotification").removeAttr("disabled");
	}
	else{
		$("#WellTextNotification").attr("checked", false);
		$("#WellTextNotification").attr("disabled", true)
		$("#DropboxTextNotification").attr("checked", false);
		$("#DropboxTextNotification").attr("disabled", true)
		
	}	
}
