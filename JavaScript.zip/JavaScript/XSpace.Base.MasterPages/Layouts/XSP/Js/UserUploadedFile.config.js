﻿var UserUploadedDataGridSettings = {
    GridId: "UserUploadedDataGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: true,
    PagingCount: 20,
    IsScrollY: true,
    DataSource: "GetDataFileUploadByUser_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [
         {
             Name: "",
             Visible: true,
             Enabled: true,
             DataType: "string",
             Style: "Text", // Text,Image,Action,URL
             CssClass: "",
             HeaderVisible: true,
             data: "DATA_FILE_GUID",
             DataIndex: 1,
             renderAction: "RenderNewFileInfo",
             Width: "4%",
             IsFilterable: false,
             IsSortable: false
         },
         {
        Name: "File Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "DATA_FILE_LNM",
        renderAction: "renderDownloadFile",
        DataIndex: 2,
        Width: "12%",
        IsFilterable: true,
        IsSortable: true
        },
        {
            Name: "Size(MB)",
            Visible: true,
            Enabled: true,
            DataType: "string",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader rText",
            HeaderVisible: true,
            data: "FILE_SZ_VAL",
            DataIndex: 3,
            renderAction: "GenerateFormattedSize",
            Width: "7%",
            IsFilterable: false,
            IsSortable: true
        },

        {
            Name: "Status",
            Visible: true,
            Enabled: true,
            DataType: "string",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader lText",
            //CssClass: "comment",
            HeaderVisible: true,
            data: "FILE_STATUS",
            DataIndex: 4,
            Width: "8%",
            IsFilterable: true,
            IsSortable: true
        },
        {
            Name: "Comments",
            Visible: true,
            Enabled: true,
            DataType: "comment",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader lText",
            //CssClass: "comment",
            HeaderVisible: true,
            renderAction: "renderComment",
            data: "DATA_FILE_CMNT",
            DataIndex: 5,
            Width: "5%",
            IsFilterable: true,
            IsSortable: true
        },
        {
            Name: "Well Name",
            Visible: true,
            Enabled: true,
            DataType: "string",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader lText",
            HeaderVisible: true,
            data: "WELL_NM",
            DataIndex: 6,
            Width: "7%",
            IsFilterable: true,
            IsSortable: true
        },
        {
            Name: "Company Name",
            Visible: true,
            Enabled: true,
            DataType: "string",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader lText",
            HeaderVisible: true,
            data: "CO_NM",
            DataIndex: 7,
            Width: "10%",
            IsFilterable: true,
            IsSortable: true
        },
        {
            Name: "Upload Date",
            Visible: true,
            Enabled: true,
            DataType: "Date",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "cHeader lText",
            HeaderVisible: true,
            data: "UPLOAD_DATE",
            DataIndex: 8,
            Width: "10%",
            IsFilterable: true,
            IsSortable: true
        }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Rename",
            Action: "RenameFile",
            Icon: "rename_32x32.png",
            Text: "Rename File",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Move",
            Action: "MoveFile",
            Icon: "move_32x32.png",
            Text: "Move File",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "EditUploadComments",
            Action: "EditComments",
            Icon: "edit_desc_32x32.png",
            Text: "Edit Comments",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "EditStatus",
            Action: "EditStatusDialog",
            Icon: "edit_file_32x32.png",
            Text: "Edit Status",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "DeleteFile",
            Icon: "delete_file_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};

var fileListGridSettings = {
    GridId: "fileListGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "150px",
    ColumnCollection: [{
                        Name: "File Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FileName",
                        DataIndex: 0,
                        Width: "60%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Size(MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "Size",
                        DataIndex: 1,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    }],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};

