﻿var selectedEntitlement;
$(document).ready(function () {
    $("#MoveLeft").on("click", function () {
        var availableEntTable = $("#" + AvailableEntitlementsGridettings.GridId).DataTable();
        var rows = availableEntTable.rows(".selected");
        if (rows.length == 0) {
            $("#alert").html("Please select entitlements to move.").dialog('open');
            return false;
        }
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + SelectedEntitlementsGridettings.GridId).DataTable().row.add(item).draw(false);
        }
        availableEntTable.row('.selected').remove().draw(false);
        if (availableEntTable.rows().data().length == 0) {
            $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#SelectedEntitlementsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#SelectedEntitlementsGrid_wrapper").find("tr").removeClass("selected");
    });
    $("#MoveRight").on("click", function () {
        var selectedEntTable = $("#" + SelectedEntitlementsGridettings.GridId).DataTable()
        var rows = selectedEntTable.rows(".selected");
        if (rows.length == 0) {
            $("#alert").html("Please select entitlements to move.").dialog('open');
            return false;
        }
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + AvailableEntitlementsGridettings.GridId).DataTable().row.add(item).draw(false);
        }
        selectedEntTable.row('.selected').remove().draw(false);
        if (selectedEntTable.rows().data().length == 0) {
            $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#AvailableEntitlementsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#AvailableEntitlementsGrid_wrapper").find("tr").removeClass("selected");
    });
    $("#AvailableEntitlementsGrid_info").hide();
    $("#SelectedEntitlementsGrid_info").hide();
    $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
    $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
});
function loadEntitlements() {
   
    populateAvailableEntitlements();
    $("#AvailableEntitlementsGrid_info").hide();
    $("#SelectedEntitlementsGrid_info").hide();
}
function populateAvailableEntitlements() {
    if ($.fn.dataTable.isDataTable("#" + AvailableEntitlementsGridettings.GridId)) {
        var oTable1 = $("#" + AvailableEntitlementsGridettings.GridId).dataTable();
        $("#" + AvailableEntitlementsGridettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    if ($.fn.dataTable.isDataTable("#" + SelectedEntitlementsGridettings.GridId)) {
        var oTable1 = $("#" + SelectedEntitlementsGridettings.GridId).dataTable();
        $("#" + SelectedEntitlementsGridettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    GetXSpaceData("", "GetFolderType_SP", function (data) {
        folderSelectedList = [];
        if (selectedEntitlement != null && selectedEntitlement != "") {
            var selectedfolderList = selectedEntitlement.split(",");
            for (var selectedListCount = 0; selectedListCount < selectedfolderList.length; selectedListCount++) {
                for (var availableCount = 0; availableCount < data.length; availableCount++) {
                    if (data[availableCount].FLDR_TYP_ID == $.trim(selectedfolderList[selectedListCount])) {
                        var item = new Object();
                        item.FLDR_TYP_ID = data[availableCount].FLDR_TYP_ID;
                        item.FLDR_TYP_NM = data[availableCount].FLDR_TYP_NM;
                        folderSelectedList.push(item);
                        data.splice(availableCount, 1);
                        break;

                    }

                }
            }
        }
        $("#" + AvailableEntitlementsGridettings.GridId).renderGrid(AvailableEntitlementsGridettings, data);
        $("#" + SelectedEntitlementsGridettings.GridId).renderGrid(SelectedEntitlementsGridettings, folderSelectedList);
        $("#AvailableEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
        $("#SelectedEntitlementsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
        $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
    });

}