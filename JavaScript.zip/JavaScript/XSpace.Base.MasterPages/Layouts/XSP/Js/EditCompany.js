﻿var IsDirty = false;
var redirectToParentRequired = false;

$(document).ready(function () {
	$("#ddlCountry").css("width",$("#txtAddress").width()+4);
	$("#confirm").dialog({
		autoOpen: false,
		modal: true,
		title: "Confirm Delete",
		height: 140,
		width: 350,
		buttons: {
			"Yes": function () {
				var activeTabIndex = $('#editCompanytabs').tabs('option', 'active');
				if (activeTabIndex == 1) {
					var data = $("#" + userGridSettings.GridId).DataTable().rows(".selected").data();
					DeleteUserData(data);
					var table = $("#" + userGridSettings.GridId).DataTable();
					if (table.row('.selected').length > 0) {
						table.row('.selected').remove().draw(false);
					}
				}
				if (activeTabIndex == 2) {
					var data = $("#" + groupGridSettings.GridId).DataTable().rows(".selected").data();
					DeleteGroupData(data);
					var table = $("#" + groupGridSettings.GridId).DataTable();
					if (table.row('.selected').length > 0) {
						table.row('.selected').remove().draw(false);
					}
				}

				$(this).dialog('close');
			},
			"No": function () {
				$(this).dialog('close');
			}
		}
	});
	$("#alert").dialog({
		autoOpen: false,
		modal: true,
		title: "Alert",
		height: 120,
		width: 300,
		buttons: {
			"OK": function () {
				$(this).dialog('close');
			}
		},
		close: function () {
		    if (redirectToParentRequired == true) {
		        $("#back").click();
		    }
		}
	});

	$('#txtPhone').mask("000-000-0000", { placeholder: "___-___-____" });
	$('#txtZip').mask("00000", { placeholder: "_____" });

   
	$("#save").on("click", function () {      
		saveDetails();
	});

	$("select.edit,input.edit").on("change", function () {
		//// condition to exclude Well tab
		var activeTabIndex = $('#editCompanytabs').tabs('option', 'active');
		if (activeTabIndex != 3) {
			IsDirty = true;
			if (typeof ($(this).attr("readonly")) == 'undefined')
				$("#save").attr("src", "../images/save_dirty_24x24.png");
		}       
	});

	$("input.edit").on("keyup", function () {
		//// condition to exclude Well tab
		var activeTabIndex = $('#editCompanytabs').tabs('option', 'active');
		if (activeTabIndex != 3) {
			IsDirty = true;
			if (typeof ($(this).attr("readonly")) == 'undefined')
				$("#save").attr("src", "../images/save_dirty_24x24.png");
		}
	});
	$(document).on("saveAsEvent", {}, function (event, groupId, groupName, affiliatedCompany) {
		IsDirty = false;
		window.location.href = "/_layouts/15/XSP/Pages/CreateGroup.aspx?GroupID=" + groupId + "&CompanyID=" + affiliatedCompany +"&Page=EditCompany"
	});

	populateCountryTab();
	populatePSLTab();
	loadCoutries();

	$("#editCompanytabs").tabs({
		beforeLoad: function (event, ui) {
			ui.newPanel.text('Retrieving data...');
		},
		activate: function (event, ui) {
			if (ui.newPanel.is("#details")) {
				
			}
			else if (ui.newPanel.is("#users")) {
				clearUserTabFilter();

				$("input").on("keyup", function () {
					$("#clearUserFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
					if ($("#clearUserFilter").length > 0)
						$("#clearUserFilter")[0].onclick = null;
					return false;
				});
				if ($("#clearUserFilter").length > 0)
					$("#clearUserFilter")[0].onclick = null;
				if ($("#DeleteUser").length > 0)
					$("#DeleteUser")[0].onclick = null;
				$("#clearUserFilter").on("click", function () {
					clearUserTabFilter();
				});
				$("#DeleteUser").on("click", function () {
					DeleteUser();
				});
			}
			else if (ui.newPanel.is("#groups")) {
				clearGroupTabFilter();

				$("input").on("keyup", function () {
					$("#clearGroupFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
					if ($("#clearGroupFilter").length > 0)
						$("#clearGroupFilter")[0].onclick = null;
					return false;
				});

				$("#clearGroupFilter").on("click", function () {
					clearGroupTabFilter();
				});
			}
			else if (ui.newPanel.is("#wells")) {
				DestoryRenderedDatatables();
				wellUserControlGridSettings.RowSelectionStyle = "None";
				wellUserControlGridSettings.RowSelectionType = "Single";
				var param = "UserID='" + USERID + Sep() + "Company='" + $("#txtCmpName").val() + "'";
				GetXSpaceData(param, wellUserControlGridSettings.DataSource, UCPopulateWellData);
				
				FilterWellsByCompany($("#txtCmpName").val());
			}
			else if (ui.newPanel.is("#countries")) {
				$("#AvailableCountriesGrid_info").hide();
				$("#SelectedCountriesGrid_info").hide();
				$("#AvailableCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
				$("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
				
			}
			else { ///PSL's
				$("#AvailablePSLsGrid_info").hide();
				$("#SelectedPSLsGrid_info").hide();
				$("#AvailablePSLsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
				$("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
			}
			$($.fn.dataTable.tables(true)).DataTable().columns.adjust();
		}
	});

	setTab();
	

	$(document).on("change", "#ddlCountry", function () {
		if ($(this).val() != "")
			loadStates();
		else
			$("#ddlState").find('option').remove();
	});

	$(document).on("click", "#back", function () {
		if (((typeof (qs("Page")) != "undefined") && qs("Page") == "EditGroup")) {
			window.location.href = "/_layouts/15/XSP/Pages/CreateGroup.aspx?GroupID=" + qs("GroupID") + "&CompanyID=" +  qs("CompanyID") + "&tab=G";
		}
		else {
			window.location.href = "/_layouts/15/XSP/Pages/Companies.aspx"
		}		
	});
	$("#txtCmpName").css("background-color", "#f0f0f0");
	
	SetMoveCountry();
	SetMovePSL();
	$(window).keypress(function (e) {
	    if (e.keyCode == 13) {
	        searchFilter();
	        return false;
	    }
	});
	window.onbeforeunload = function () {
		if (IsDirty == true) {          
		/*if (confirm("You have unsaved changes.Do you want to save?")) {               
				return saveDetails();
			}
			else {
				return;
			}*/
		return 'You have unsaved changes!';
		}
		//return;
	};
});

function SetMoveCountry() {

	$("#MoveCountryLeft").on("click", function () {
		var availableEntTable = $("#" + AvailableCountriesGridSettings.GridId).DataTable();
		var rows = availableEntTable.rows(".selected");
		if (rows.length == 0) {
			$("#alert").html("Please select country(s) to move.").dialog('open');
			return false;
		}
		$("#save").attr("src", "../images/save_dirty_24x24.png");
		IsDirty = true;
		var data = rows.data();
		for (var i = 0; i < data.length; i++) {
			var item = new Object();
			item.CNTRY_ID = data[i].CNTRY_ID;
			item.CNTRY_NM = data[i].CNTRY_NM;
			$('#' + SelectedCountriesGridSettings.GridId).DataTable().row.add(item).draw(false);
		}
		availableEntTable.row('.selected').remove().draw(false);
		if (availableEntTable.rows().data().length == 0) {
			if ($("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
				$("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
		}
		$("#SelectedCountriesGrid_wrapper").find("input:checked").removeAttr("checked");
		$("#SelectedCountriesGrid_wrapper").find("tr").removeClass("selected");
	});

	$("#MoveCountryRight").on("click", function () {
		var selectedEntTable = $("#" + SelectedCountriesGridSettings.GridId).DataTable()
		var rows = selectedEntTable.rows(".selected");
		if (rows.length == 0) {
			$("#alert").html("Please select country(s) to move.").dialog('open');
			return false;
		}
		$("#save").attr("src", "../images/save_dirty_24x24.png");
		IsDirty = true;
		var data = rows.data();
		for (var i = 0; i < data.length; i++) {
			var item = new Object();
			item.CNTRY_ID = data[i].CNTRY_ID;
			item.CNTRY_NM = data[i].CNTRY_NM;
			$('#' + AvailableCountriesGridSettings.GridId).DataTable().row.add(item).draw(false);
		}
		selectedEntTable.row('.selected').remove().draw(false);
		if (selectedEntTable.rows().data().length == 0) {
			if ($("AvailableCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
				$("AvailableCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
		}
		$("#AvailableCountriesGrid_wrapper").find("input:checked").removeAttr("checked");
		$("#AvailableCountriesGrid_wrapper").find("tr").removeClass("selected");
	});

}

function SetMovePSL() {

	$("#MovePSLLeft").on("click", function () {
		var availableEntTable = $("#" + AvailablePSLsGridSettings.GridId).DataTable();
		var rows = availableEntTable.rows(".selected");
		if (rows.length == 0) {
			$("#alert").html("Please select PSL(s) to move.").dialog('open');
			return false;
		}
		$("#save").attr("src", "../images/save_dirty_24x24.png");
		IsDirty = true;
		var data = rows.data();
		for (var i = 0; i < data.length; i++) {
			var item = new Object();
			item.PSL_ID = data[i].PSL_ID;
			item.PSL_NM = data[i].PSL_NM;
			$('#' + SelectedPSLsGridSettings.GridId).DataTable().row.add(item).draw(false);
		}
		availableEntTable.row('.selected').remove().draw(false);
		if (availableEntTable.rows().data().length == 0) {
			if ($("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
				$("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
		}
		$("#SelectedPSLsGrid_wrapper").find("input:checked").removeAttr("checked");
		$("#SelectedPSLsGrid_wrapper").find("tr").removeClass("selected");
	});
	$("#MovePSLRight").on("click", function () {
		var selectedEntTable = $("#" + SelectedPSLsGridSettings.GridId).DataTable()
		var rows = selectedEntTable.rows(".selected");
		if (rows.length == 0) {
			$("#alert").html("Please select PSL(s) to move.").dialog('open');
			return false;
		}
		$("#save").attr("src", "../images/save_dirty_24x24.png");
		IsDirty = true;
		var data = rows.data();
		for (var i = 0; i < data.length; i++) {
			var item = new Object();
			item.PSL_ID = data[i].PSL_ID;
			item.PSL_NM = data[i].PSL_NM;
			$('#' + AvailablePSLsGridSettings.GridId).DataTable().row.add(item).draw(false);
		}
		selectedEntTable.row('.selected').remove().draw(false);
		if (selectedEntTable.rows().data().length == 0) {
			if ($("AvailablePSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
				$("AvailablePSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
		}
		$("#AvailablePSLsGrid_wrapper").find("input:checked").removeAttr("checked");
		$("#AvailablePSLsGrid_wrapper").find("tr").removeClass("selected");
	});
}


function setTab() {
	if(qs("tab")=="U")
		$("#editCompanytabs").tabs("option", "active", 1);
	else if (qs("tab") == "G")
		$("#editCompanytabs").tabs("option", "active", 2);
	else if (qs("tab") == "W")
		$("#editCompanytabs").tabs("option", "active", 3);
	else if (qs("tab") == "P")
		$("#editCompanytabs").tabs("option", "active", 5);

}
function populateCountryTab() {
	var param = "CompanyID=" + qs("CompanyID");
	GetXSpaceData(param, "GetCompanyCountryAvailable_SP", function (data) {
		$("#" + AvailableCountriesGridSettings.GridId).renderGrid(AvailableCountriesGridSettings, data);
		GetXSpaceData(param, "GetCompanyCountryOperating_SP", function (data) {
			$("#" + SelectedCountriesGridSettings.GridId).renderGrid(SelectedCountriesGridSettings, data);
		});
	});
}
function populatePSLTab() {
	var param = "CompanyID=" + qs("CompanyID");
	GetXSpaceData(param, "GetCompanyPslAvailable_SP", function (data) {
		$("#" + AvailablePSLsGridSettings.GridId).renderGrid(AvailablePSLsGridSettings, data);
		GetXSpaceData(param, "GetCompanyPslAssociated_SP", function (data) {
			$("#" + SelectedPSLsGridSettings.GridId).renderGrid(SelectedPSLsGridSettings, data);
		});
	});
}
function DeleteUser() {
	if ($("#" + userGridSettings.GridId).DataTable().row(".selected").length > 0) {
		$("#confirm").html("Are you sure to delete?").dialog('open');
	}
	else {
		$("#alert").html("Please select a user to delete.").dialog('open');
	}
}
function DeleteUserData(data) {
	if (data.length > 0) {
		for (var i = 0; i < data.length; i++) {
			var param = "UserID='" + data[i].USR_AD_NM + Sep();
			GetXSpaceData(param, "DeleteUser_SP", undefined);
		}
	}
}

function DestoryRenderedDatatables() {
	$("tr[id='_filterRow']").find("input").val("");

	if ($.fn.dataTable.isDataTable("#" + groupGridSettings.GridId)) {
		var oTable1 = $("#" + groupGridSettings.GridId).dataTable();
		$("#" + groupGridSettings.GridId + "tbody").html("");
		oTable1.dataTable().fnDestroy();
	}

	if ($.fn.dataTable.isDataTable("#" + userGridSettings.GridId)) {
		var oTable1 = $("#" + userGridSettings.GridId).dataTable();
		$("#" + userGridSettings.GridId + "tbody").html("");
		oTable1.dataTable().fnDestroy();
	}

	if ($.fn.dataTable.isDataTable("#" + wellUserControlGridSettings.GridId)) {
		var oTable = $("#" + wellUserControlGridSettings.GridId).dataTable();
		$("#" + wellUserControlGridSettings.GridId + "tbody").html("");
		oTable.dataTable().fnDestroy();       
	}
}

////load details tab data
function loadCompanyDetails() {
	var param = "CompanyID=" +qs("CompanyID");
	GetXSpaceData(param, "GetCompanyDetails_SP", function (data) {
		if (data.length > 0)
		{
			$("#txtCmpName").val(data[0].CO_NM);
			$("#txtAddress").val(data[0].ADDR_1);
			$("#txtPhone").val(data[0].PHONE_NUM);
			$("#txtCity").val(data[0].CITY_NM);
			$("#ddlCountry").val(data[0].CNTRY_ID);
			if (data[0].CNTRY_ID != "")
				loadStates();
			$("#ddlState").val(data[0].GEO_LVL1_ID);
			$("#txtZip").val(data[0].ZIP);
			if (data[0].CO_TYP_CD == "CNSLTNG")
				$("#Consulting")[0].checked = true;
			if (data[0].CO_TYP_CD == "OPRTNG")
				$("#Operating")[0].checked = true;
		}
	});
}

function loadCoutries() {
	GetXSpaceData("", "GetCountryList_SP", function (data) {
		var select = $("#ddlCountry")[0];
		var option = new Option();
		option.value = "";
		option.text = "";
		select.options.add(option);
		for (var i = 0; i < data.length; i++) {
			option = new Option();
			option.value = data[i].CNTRY_ID;
			option.text = data[i].CNTRY_NM;
			select.options.add(option);
		}
		$("#ddlState").width($("#ddlCountry").width());
		loadCompanyDetails();
	});
}

function loadStates() {
	var param = "CntryID='" + $("#ddlCountry").val() + "'";
	GetXSpaceData(param, "GetStateList_SP", function (data) {
		$("#ddlState").find('option').remove();
		if (data.length > 0) {
			var select = $("#ddlState")[0];
			var option = new Option();
			option.value = "";
			option.text = "";
			select.options.add(option);
			for (var i = 0; i < data.length; i++) {
				option = new Option();
				option.value = data[i].GEO_LVL1_ID;
				option.text = data[i].GEO_LVL1_NM;
				select.options.add(option);
			}
		}
	});
}

////Users
function loadUsersData() {
	var param = "CompanyID=" + qs("CompanyID");
	GetXSpaceData(param, "GetCompanyUsers_SP", function (data) {
		$("#" + userGridSettings.GridId).renderGrid(userGridSettings, data);
	});   
}

function clearUserTabFilter() {
	IsDirty = false;
	$("#clearUserFilter").attr("src", "../images/clear_filter_32x32.png");
	DestoryRenderedDatatables();
	loadUsersData();
}

function editUser(data, type, full, meta) {
	return "<a class='edithref' href='/_layouts/15/XSP/Pages/Settings.aspx?CompanyID=" + qs("CompanyID") + "&UserID=" + full.USR_AD_NM + "'>" + full.USR_NM + "</a>";
}

function mailTo(data, type, full, meta) {
	return "<a class='edithref' href='mailto:" + full.EMAIL_ADDR_DESC + "' target=\"_top\">" + full.EMAIL_ADDR_DESC + "</a>";
}

function groupAction(data, type, full, meta) {
	if (full.GRP_CNT == "0")
		return full.GRP_CNT;
	return "<a style='color:blue;' href='/_layouts/15/XSP/Pages/Settings.aspx?tab=g&UserID=" + full.USR_AD_NM + "'>" + full.GRP_CNT + "</a>";
}


//// groups
function loadGroupsData() {
	var param = "CompanyID=" + qs("CompanyID");
	GetXSpaceData(param, "GetCompanyUserGroups_SP", function (data) {
		$("#" + groupGridSettings.GridId).renderGrid(groupGridSettings, data);
	});
}

function clearGroupTabFilter() {
	IsDirty = false;
	$("#clearGroupFilter").attr("src", "../images/clear_filter_32x32.png");
	DestoryRenderedDatatables();
	loadGroupsData();
}

function editUserCount(data, type, full, meta) {
	return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=U&GroupID=" + full.USR_GRP_GUID + "&Page=EditCompany'>" + full.USR_CNT + "</a>";
}

function editGroup(data, type, full, meta) {
	return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?CompanyID=" + qs("CompanyID") + "&GroupID=" + full.USR_GRP_GUID + "&Page=EditCompany'>" + full.USR_GRP_NM + "</a>";
}

function editEnt(data, type, full, meta) {
	return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?tab=E&GroupID=" + full.USR_GRP_GUID + "&Page=EditCompany'>" + full.ENTLMNT_CNT + "</a>";
}

function AddGroup_Company() {
	$("#txtAffiliatedCompanyName").val($("#txtCmpName").val());
	$("#dialog-saveasgroup").data('param', "saveAsGroup").dialog('open');
}

function DeleteGroup_Company() {
	if ($("#" + groupGridSettings.GridId).DataTable().row(".selected").length > 0) {
		$("#confirm").html("Are you sure to delete group(s)?").dialog('open');
	}
	else {
		$("#alert").html("Please select group to delete.").dialog('open');
	}
}

function DeleteGroupData(data) {
	if (data.length > 0) {
		for (var i = 0; i < data.length; i++) {
			var param = "GroupGuid='" + data[i].USR_GRP_GUID + Sep() + "UserID='" + USERID + Sep();
			GetXSpaceData(param, "DeleteUserGroup_SP", undefined);
		}
	}
}

function saveDetails() {
	var param = "CompanyID=" + qs("CompanyID");
	if ($("#txtAddress").val() != "")
		param= param + "%26Address1='" + $("#txtAddress").val() + "'";
	if ($("#txtPhone").val() != "")
		param = param + "%26Phone='" + $("#txtPhone").val() + "'";
	if ($("#txtCity").val() != "")
		param = param + "%26City='" + $("#txtCity").val() + "'";
	if ($("#txtZip").val() != "")
		param = param + "%26Zip='" + $("#txtZip").val() + "'";
	if ($("#ddlCountry").val() != "")
		param = param + "%26CntryID='" + $("#ddlCountry").val() + "'";
	if ($("#ddlState").val() != "" && $("#ddlState").val() != null)
		param = param + "%26StateID='" + $("#ddlState").val() + "'";
	if ($("#Consulting")[0].checked == true)
		param = param + "%26Type='CNSLTNG'";
	if ($("#Operating")[0].checked == true)
		param = param + "%26Type='OPRTNG'";
   
	GetXSpaceData(param, "UpdateCompanyDetails_SP", function (data) {
		saveSelectedCountries();
	});
}
function saveSelectedCountries() {
	var param = "CompanyID=" + qs("CompanyID");
	var data = $("#" + SelectedCountriesGridSettings.GridId).DataTable().rows().data();
	var selCountryIds = "";
	
		for (var i = 0; i < data.length; i++) {
			selCountryIds = selCountryIds + data[i].CNTRY_ID + ","
		}
		if (selCountryIds != "") {
			param = param + "%26Separator=','%26CntryIDList='" + selCountryIds + "'";
			GetXSpaceData(param, "UpdateCompanyCountryOperating_SP", function (data) {
				saveSelectedPSLs();
			});
		}
		else {
			saveSelectedPSLs();
		}
   
}
function saveSelectedPSLs() {
	var param = "CompanyID=" + qs("CompanyID");
	var data = $("#" + SelectedPSLsGridSettings.GridId).DataTable().rows().data();
	var selPSLIds = "";
   
		for (var i = 0; i < data.length; i++) {
			selPSLIds = selPSLIds + data[i].PSL_ID + ","
		}
		if (selPSLIds!="")
		{
			param = param + "%26Separator=','%26PslIDList='" + selPSLIds +"'";
			GetXSpaceData(param, "UpdateCompanyPslAssociated_SP", function (data) {
				dataSaved();
			});  
		}
		else
		{
			dataSaved();
		}
}

function dataSaved() {
	$("#alert").html("Company details saved successfully.").dialog('open');
	IsDirty = false;
	$("#save").attr("src", "../images/save_32x32.png");
	redirectToParentRequired = true;
	return;
}