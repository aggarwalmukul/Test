﻿var deleteType;
var IsDirty = false;
var testID = "12345";
var adminType;
var ADMIN_TYPE = { SYS: "SYS", SUP: "SUP", PSL: "PSL" };
var userRole;

$(document).ready(function () {
	GetUserGuid(GetUserDetails);
	$("#confirm").dialog({
		autoOpen: false,
		modal: true,
		title: "Confirm",
		height: 140,
		width: 300,
		buttons: {
			"Yes": function () {
				var data, table;
				if (deleteType == ADMIN_TYPE.SYS) {
					data = $("#" + systemAdminGridSettings.GridId).DataTable().rows(".selected").data();
					table = $("#" + systemAdminGridSettings.GridId).DataTable();

				} else if (deleteType == ADMIN_TYPE.SUP) {
					data = $("#" + regionalSuperAdminGridSettings.GridId).DataTable().rows(".selected").data();
					table = $("#" + regionalSuperAdminGridSettings.GridId).DataTable();

				} else if (deleteType == ADMIN_TYPE.PSL) {
					data = $("#" + regionalPSLAdminGridSettings.GridId).DataTable().rows(".selected").data();
					table = $("#" + regionalPSLAdminGridSettings.GridId).DataTable();
				}
				if (table.row('.selected').length > 0) {
					for (var i = 0; i < data.length; i++)
						DeleteAdmin(data[i], deleteType);

					table.row('.selected').remove().draw(false);
				}

				$(this).dialog('close');
			},
			"No": function () {
				$(this).dialog('close');
			}
		}
	});

   

	$("input").on("keyup", function () {
		IsDirty = true;
		$("#clearSystemFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
		if ($("#clearSystemFilter").length > 0)
			$("#clearSystemFilter")[0].onclick = null;
		return false;
	});

	$("#clearSystemFilter").on("click", function () {
		clearSystemFilter();
	});

	


});

function GetUserDetails(data) {
	var GetUserGUID = data;   
	userRole = GetUserGUID[0].ROLE_CD;
	performUserAction();
}

function performUserAction(){
	if(userRole == USERROLE_TYPE.CustomerUser || userRole == USERROLE_TYPE.CustomerAdministrator || userRole == USERROLE_TYPE.InternalUser){
		window.location.href = "/_layouts/15/XSP/Pages/Home.aspx";
		return;
	}
	
	if(userRole != USERROLE_TYPE.SystemAdministrator){
		 populateRegionalPSLList();	
		$("#admintabs").tabs({ active: 2 });
		$($("#admintabs").find("li")[0]).hide();		
		$($("#admintabs").find("li")[1]).hide();
		if(userRole == USERROLE_TYPE.PSLAdministrator){
			$("#Add").hide();
			$("#Delete").hide();
		}
		
	}
	else{
		populateSystemAdminList();	
	}	
	 
	$("#admintabs").tabs({
		activate: function (event, ui) {
			DestoryDataTableIfExists();
			if (ui.newPanel.is("#systemtab")) {
				$("#clearSystemFilter").attr("src", "../images/clear_filter_32x32.png");
				populateSystemAdminList();
			}
			else if (ui.newPanel.is("#regionalSupertab")) {
				populateRegionalSuperList();

				$("#clearRegionalSFilter").attr("src", "../images/clear_filter_32x32.png");
				$("input").on("keyup", function () {
					IsDirty = true;
					$("#clearRegionalSFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
					if ($("#clearRegionalSFilter").length > 0)
						$("#clearRegionalSFilter")[0].onclick = null;
					return false;
				});
				$("#clearRegionalSFilter").on("click", function () {
					clearRegionalSFilter();
				});
			}
			else {
				populateRegionalPSLList();

				$("#clearRegionalPSLFilter").attr("src", "../images/clear_filter_32x32.png");
				$("input").on("keyup", function () {
					IsDirty = true;
					$("#clearRegionalPSLFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
					if ($("#clearRegionalPSLFilter").length > 0)
						$("#clearRegionalPSLFilter")[0].onclick = null;
					return false;
				});
				$("#clearRegionalPSLFilter").on("click", function () {
					clearRegionalPSLFilter();
				});
			}

			$($.fn.dataTable.tables(true)).DataTable().columns.adjust();
		}
	});

	$($.fn.dataTable.tables(true)).DataTable().columns.adjust();
	$("input:not(:button)").val("");
	
	
	
}

function DestoryDataTableIfExists() {   
	$("input:not(:button)").val("");

	if ($.fn.dataTable.isDataTable("#" + systemAdminGridSettings.GridId)) {
		var oTable1 = $("#" + systemAdminGridSettings.GridId).dataTable();
		$("#" + systemAdminGridSettings.GridId + "tbody").html("");
		oTable1.dataTable().fnDestroy();
	}

	if ($.fn.dataTable.isDataTable("#" + regionalSuperAdminGridSettings.GridId)) {
		var oTable2 = $("#" + regionalSuperAdminGridSettings.GridId).dataTable();
		$("#" + regionalSuperAdminGridSettings.GridId + "tbody").html("");
		oTable2.dataTable().fnDestroy();
	}

	if ($.fn.dataTable.isDataTable("#" + regionalPSLAdminGridSettings.GridId)) {
		var oTable3 = $("#" + regionalPSLAdminGridSettings.GridId).dataTable();
		$("#" + regionalPSLAdminGridSettings.GridId + "tbody").html("");
		oTable3.dataTable().fnDestroy();
	}
}

function populateSystemAdminList() {
	adminType = ADMIN_TYPE.SYS;
	GetXSpaceData("", systemAdminGridSettings.DataSource, function (data) {
		$("#" + systemAdminGridSettings.GridId).renderGrid(systemAdminGridSettings, data);
	});
}
function populateRegionalSuperList() {
	adminType = ADMIN_TYPE.SUP;
	GetXSpaceData("", regionalSuperAdminGridSettings.DataSource, function (data) {
		$("#" + regionalSuperAdminGridSettings.GridId).renderGrid(regionalSuperAdminGridSettings, data);
	});
}
function populateRegionalPSLList() {
	adminType = ADMIN_TYPE.PSL;
	GetXSpaceData("", regionalPSLAdminGridSettings.DataSource, function (data) {
		$("#" + regionalPSLAdminGridSettings.GridId).renderGrid(regionalPSLAdminGridSettings, data);
	});
}

function clearSystemFilter() {
	IsDirty = false;
	$("#clearSystemFilter").attr("src", "../images/clear_filter_32x32.png");
	DestoryDataTableIfExists();
	populateSystemAdminList();
}
function clearRegionalSFilter() {
	IsDirty = false;
	$("#clearRegionalSFilter").attr("src", "../images/clear_filter_32x32.png");
	DestoryDataTableIfExists();
	populateRegionalSuperList();
}
function clearRegionalPSLFilter() {
	IsDirty = false;
	$("#clearRegionalPSLFilter").attr("src", "../images/clear_filter_32x32.png");
	DestoryDataTableIfExists();
	populateRegionalPSLList();
}

function RemoveSystemUsers() {
	deleteType = ADMIN_TYPE.SYS
	var table = $("#" + systemAdminGridSettings.GridId).DataTable();
	if (table.row('.selected')[0].length > 0) {
	    $("#confirm").html("Are you sure you want to delete system administrator(s) ?").dialog('open');
	}
	else {
		ShowCustomAlert("Please select administrator(s) to delete.", "Alert", 250);
	}
}
function RemoveRegionalSuperAdmin() {
	deleteType = ADMIN_TYPE.SUP;
	var table = $("#" + regionalSuperAdminGridSettings.GridId).DataTable();
	if (table.row('.selected')[0].length > 0) {	    
	    $("#confirm").html("Are you sure you want to delete Regional Super administrator(s) ?").dialog('open');
	}
	else {
		ShowCustomAlert("Please select administrator(s) to delete.", "Alert", 250);
	}
}
function RemoveRegionalPSLAdmin() {
	deleteType = ADMIN_TYPE.PSL;
	var table = $("#" + regionalPSLAdminGridSettings.GridId).DataTable();
	if (table.row('.selected')[0].length > 0) {
	    $("#confirm").html("Are you sure you want to delete Regional PSL administrator(s) ?").dialog('open');
	}
	else {
		ShowCustomAlert("Please select administrator(s) to delete.", "Alert", 250);
	}
}
function editUser(data, type, full, meta) {
	if(userRole == USERROLE_TYPE.PSLAdministrator)
		return full.USR_NM ;
	return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/AdminEditor.aspx?tab=C&type=" + adminType + "&ID=" + full.USR_AD_NM+ "&UName=" + full.USR_NM  + "\">" + full.USR_NM + "</a>";
}
function editCountry(data, type, full, meta) {
	if(userRole == USERROLE_TYPE.PSLAdministrator)
		return full.CNTRY_NM_LIST;
	return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/AdminEditor.aspx?tab=C&type=" + adminType + "&ID=" + full.USR_AD_NM+ "&UName=" + full.USR_NM + "\">" + full.CNTRY_NM_LIST + "</a>";
}
function mailTo(data, type, full, meta) {
	if(userRole == USERROLE_TYPE.PSLAdministrator)
		return full.EMAIL_ADDR_DESC ;
	return "<a class='edithref' href='mailto:" + full.EMAIL_ADDR_DESC + "' target=\"_top\">" + full.EMAIL_ADDR_DESC + "</a>";
}

function editPSLs(data, type, full, meta) {
	if(userRole == USERROLE_TYPE.PSLAdministrator)
		return full.PSL_NM_LIST ;
	return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/AdminEditor.aspx?tab=P&type=" + adminType + "&ID=" + full.USR_AD_NM + "&UName=" + full.USR_NM  + "\">" + full.PSL_NM_LIST + "</a>";
}

function editFolder(data, type, full, meta) {
	if(userRole == USERROLE_TYPE.PSLAdministrator)
		return full.FLDR_CNT ;
	return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/AdminEditor.aspx?tab=F&type=" + adminType + "&ID=" + full.USR_AD_NM + "&UName=" + full.USR_NM  + "\">" + full.FLDR_CNT + "</a>";
}
function AddSystemUsers(sourceGridID) {
	populatePersonelDialog(sourceGridID, ADMIN_TYPE.SYS)
}

function AddRegionalSuperAdmin(sourceGridID) {
	populatePersonelDialog(sourceGridID, ADMIN_TYPE.SUP)
}
function AddRegionalPSLAdmin(sourceGridID) {
	populatePersonelDialog(sourceGridID, ADMIN_TYPE.PSL)
}

//Data Event 

function populatePersonelDialog(sourceGridID, adminType) {
	var grid;
	PopulateRecipients(sourceGridID);
	if (adminType == ADMIN_TYPE.SYS) {
		grid = systemAdminGridSettings;
	}
	else if (adminType == ADMIN_TYPE.SUP) {
		grid = regionalSuperAdminGridSettings;
	} else if (adminType == ADMIN_TYPE.PSL) {
		grid = regionalPSLAdminGridSettings;
	}

	var currentTableSize = $("#" + grid.GridId).DataTable().rows().data().length;
	$("#dialog-personnel").dialog("open");
	$('#dialog-personnel').unbind('dialogclose');
	$('#dialog-personnel').on('dialogclose', function (event) {
		var updatedTableRow = $("#" + grid.GridId).DataTable().rows().data();
		if (updatedTableRow.length > currentTableSize) {
			var addedRow = updatedTableRow[updatedTableRow.length - 1];
			insertAdmin(addedRow.USR_AD_NM, adminType);
		}
	});
}

function insertAdmin(userId, adminType) {
	var param = "UserID='" + userId + Sep() + "ApproverUserID=" + "'" + USERID + Sep();
	var spName = "";

	if (adminType == ADMIN_TYPE.SYS) {
		spName = "InsertAdminSystem_SP";
	}
	else if (adminType == ADMIN_TYPE.SUP) {
		spName = "InsertAdminRegionSuper_SP";
	} else if (adminType == ADMIN_TYPE.PSL) {
		spName = "InsertAdminRegionPsl_SP";
	}
	GetXSpaceData(param, spName, undefined);
}

function DeleteAdmin(data, adminType) {
	var param = "UserID='" + data.USR_AD_NM + Sep() + "ApproverUserID=" + "'" + USERID + Sep();
	var spName = "";

	if (adminType == ADMIN_TYPE.SYS) {
		spName = "DeleteAdminSystem_SP";
	}
	else if (adminType == ADMIN_TYPE.SUP) {
		spName = "DeleteAdminRegionSuper_SP";
	} else if (adminType == ADMIN_TYPE.PSL) {
		spName = "DeleteAdminRegionPsl_SP";
	}
	GetXSpaceData(param, spName, undefined);
}