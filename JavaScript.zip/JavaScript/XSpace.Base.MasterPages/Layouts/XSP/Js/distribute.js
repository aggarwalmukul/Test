﻿var gridId;
var isLastFile = false;
var IsLastRecipient = false;
var dropboxflag = false;
var emailFlag = false;
var SendDistributionAttachmentEmail = true;
var D_TYPE_WELL="well",D_TYPE_DISTRICT="District",D_TYPE_PERSONAL="Personal"
var DISTRICTLIST="dl";
$(document).ready(function () {
	  GetUserGuid(GetUserGUIDDetails);
	  
	$("#s4-ribbonrow").hide();
	$("#logoutlink").hide();
		$("#SDistListType").on('change', function() {
			resetRecipients(DISTRICTLIST);
			fillDistriubtionList($(this).val());
		});
		
		$("#SDistList").on('change', function() {
			resetRecipients();
			fillRecipients($(this).val());
		});
		
		$('#' + filesGridSettings.GridId).on("click", " input.d_rowselect", function () {
		if ($(this)[0].checked == false) {
			$(this).closest("tr").removeClass("dropBox_selected");
		}
		else {
			$(this).closest("tr").addClass("dropBox_selected");
		}

		if ($(".d_rowselect").length == $(".d_rowselect:checked").length) {
			$(".select_AllDropBox", "#" + filesGridSettings.GridId + "_wrapper").prop("checked", true);
		} else {
			$(".select_AllDropBox", "#" + filesGridSettings.GridId + "_wrapper").removeAttr("checked");
		}

	});

	$('#' + filesGridSettings.GridId).on("click", " input.e_rowselect", function () {
		if ($(this)[0].checked == false) {
			$(this).closest("tr").removeClass("email_selected");
		}
		else {
			$(this).closest("tr").addClass("email_selected");
		}

		if ($(".e_rowselect", "#" + filesGridSettings.GridId + "_wrapper").length == $(".e_rowselect:checked", "#" + filesGridSettings.GridId + "_wrapper").length) {
			$(".select_AllEmail", "#" + filesGridSettings.GridId + "_wrapper").prop("checked", true);
		} else {
			$(".select_AllEmail", "#" + filesGridSettings.GridId + "_wrapper").removeAttr("checked");
		}
	});

	isLastFile = false;
	IsLastRecipient = false;
	$("#titleAreaRow").hide();
	$("#mainContent").hide();
	$("#confirm").dialog({
		autoOpen: false,
		modal: true,
		title: "Confirm Delete",
		height: 140,
		width: 350,
		buttons: {
			"Yes": function () {
				var table = $("#" + gridId).DataTable();
				if (table.row('.selected').length > 0) {
					table.row('.selected').remove().draw(false);
					$(this).dialog('close');
				}
			},
			"No": function () {
				$(this).dialog('close');
			}
		}
	});
	$("#alertDis").dialog({
		autoOpen: false,
		modal: true,
		title: "Alert",
		height: 120,
		width: 300,
		buttons: {
			"OK": function () {
				if (isLastFile == true && IsLastRecipient == true) {
					if (window.opener.parent.location.href.toLowerCase().indexOf("dropbox") > 0) {
						window.opener.load();
					}
					self.close();
				}
				$(this).dialog('close');
			}
		}
	});

	$("#alert_progress").dialog({
		autoOpen: false,
		modal: true,
		title: "Distribute Files",
		height: 120,
		width: 300       
	});
	$("#alertFileSize").dialog({
		autoOpen: false,
		modal: true,
		title: "Alert",
		height: 150,
		width: 500,
		buttons: {
			"OK": function () {

				$(this).dialog('close');
				SendDistributionAttachmentEmail = false;
				InsertDistributionList(GetDistributionGUID);

			},
			"Cancel": function () {
				$(this).dialog('close');
			}
		}
	});
	var selectedFiles = JSON.parse(localStorage.getItem("SelectedFiles"));
	var data = [];
	if (typeof (selectedFiles) != 'undefined' && selectedFiles.length != 0) {
		for (var i = 0; i < selectedFiles.length; i++) {
			var item = new Object();
			item.DATA_FILE_GUID = selectedFiles[i].DATA_FILE_GUID;
			item.DATA_FILE_LNM = selectedFiles[i].DATA_FILE_LNM;
			item.FILE_SZ_VAL = selectedFiles[i].FILE_SZ_VAL;
			item.FILE_TYPE = selectedFiles[i].FILE_TYPE;// TO DO:need to map
			item.EMAIL = false;
			item.DROPBOX = true;
			data.push(item);
		}
	}
	$("#" + filesGridSettings.GridId).renderGrid(filesGridSettings, data);
	//// select All DropBox and Email checkBox Implementation -
	if (typeof (filesGridSettings.IsScrollY) != "undefined" && filesGridSettings.IsScrollY == true) {
		$("#" + filesGridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead tr").find("th:contains('Dropbox')").html("My Files <br> <input type='checkbox' class='select_AllDropBox'></input>");
		$("#" + filesGridSettings.GridId + "_wrapper").find(".dataTables_scrollHead").find("table thead tr").find("th:contains('Email')").html("Email <br> <input type='checkbox' class='select_AllEmail'></input>");
	}
	else {
		$("#" + filesGridSettings.GridId).find("thead tr").find("th:contains('Dropbox')").html("My Files <br> <input type='checkbox' class='select_AllDropBox'></input>");
		$("#" + filesGridSettings.GridId).find("thead tr").find("th:contains('Email')").html("Email <br> <input type='checkbox' class='select_AllEmail'></input>");
	}

	$('.select_AllEmail').click(function (event) {
		var gridid = $("#" + filesGridSettings.GridId + "_wrapper").find(".dataTables_scrollBody").find("table").attr("id");
		if (this.checked) { // check select status
			$('.e_rowselect', "#" + gridid).each(function () {
				this.checked = true;
				$(this).closest("tr").addClass("email_selected");
			});
		} else {
			$('.e_rowselect', "#" + gridid).each(function () {
				this.checked = false;
				$(this).closest("tr").removeClass("email_selected");
			});
		}
		
		event.stopImmediatePropagation();
	});

	$('.select_AllDropBox').click(function (event) {
		var gridid = $("#" + filesGridSettings.GridId + "_wrapper").find(".dataTables_scrollBody").find("table").attr("id");
		var checkstate = this.checked;
		$('.d_rowselect', "#" + gridid).each(function () {
			this.checked = checkstate;
			$(this).closest("tr").toggleClass("dropBox_selected");
		});
		event.stopImmediatePropagation();
	});

  
	function UpdateDistricts(data) {       
		var districts = data;
		var select = document.getElementById("select");
		for (var i = 0; i < districts.length; i++) {
			var option = document.createElement('option');
			option.text = districts[i].DIST_NM;
			option.value = districts[i].DIST_GUID;
			select.add(option, 0);
		}
		select.selectedIndex = 0;
	}

	$("#btnCancel").on("click", function () {
		self.close();
	});
	$("#btnSend").on("click", function () {
		if ($("#comments").val().trim() == "") {
			$("#alertDis").html("Comments is mandatory.").dialog('open');
			return false;
		}
		if ($("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data().length == 0 && $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data().length == 0) {
			$("#alertDis").html("No recipients selected.").dialog('open');
			return false;
		}
		var oTableSource = $("#" + filesGridSettings.GridId).DataTable();
		var EmailFile = oTableSource.rows('.email_selected').data();
		var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
		var size = 0.0;

		if (emailUsers.length > 0) {
			for (var i = 0; i < EmailFile.length; i++) {
				size = size + parseFloat(EmailFile[i].FILE_SZ_VAL);
			}
		}
		if (size <= 10.0) {
			$("#alert_progress").html("File Distribution in progress....").dialog("open");
			InsertDistributionList(GetDistributionGUID);
		}
		else {
			$("#alertFileSize").html("Selected files have total size more than 10 MB. Email will not be sent to Email Recipients.").dialog("open");
		}
		return false;
	});


	function DistributeData(DSTGUID) {
		var oTableSource = $("#" + filesGridSettings.GridId).DataTable();
		var dropboxFile = oTableSource.rows('.dropBox_selected').data();
		var EmailFile = oTableSource.rows('.email_selected').data();
		if (dropboxFile.length == 0 && EmailFile.length == 0)
			$("#alertDis").html("Please select a file to distribute.").dialog("open");
		else {
			var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
			var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
			if (dropboxUsers.length == 0 && emailUsers.length == 0) {
				$("#alertDis").html("Please add a user for distribution.").dialog("open");
			}
			else {

					DistributeDataFile(DSTGUID, true, false, dropboxFile);
					DistributeDataFile(DSTGUID, false, true, EmailFile);
					isLastFile = true;
					IsLastRecipient = true;
					$("#alert_progress").dialog("close");
					$("#alertDis").html("File distribution complete.").dialog("open");
			}
		}
	}    
	function DistributeDataFile(DSTGUID, dropBox, Email, dropboxFile) {
		var dataFileGuid = [];
		var DataFileGuidDistributed = [];
		if (typeof (dropboxFile) != 'undefined' && dropboxFile.length > 0) {
          
		    for (var i = 0; i < dropboxFile.length; i++) {
		        FileGUID = dropboxFile[i].DATA_FILE_GUID;
		        dropboxflag = dropBox;
		        emailFlag = Email;

		        if (DataFileGuidDistributed.indexOf(FileGUID) == -1) {
		            if (dropboxFile[i].FILE_TYPE == "") {

		                if (typeof (DSTGUID) != 'undefined' && DSTGUID.length > 0) {
		                    if (dropBox == true) {
		                        InsertDistributionFile(DSTGUID, FileGUID, GetDistributionFileGUID);
		                    }
		                    dataFileGuid.push(FileGUID);

		                }
		            }
		            else {
		                var FileNamesDropBox = [];
		                DataFileGuidDistributed.push(FileGUID);
		                for (var j = 0; j < dropboxFile.length; j++) {
		                    if (dropboxFile[j].DATA_FILE_GUID == FileGUID) {
		                        FileNamesDropBox.push(dropboxFile[j].DATA_FILE_LNM);
		                    }
		                }
		                var urlstring = getAppURL()+ "/_layouts/15/FileHandler/FileService.aspx/PackageSelectedFileForDistribution";

		                if (FileNamesDropBox.length > 0) {
		                    var files = FileNamesDropBox.toString();
		                    var o = { Guid: FileGUID, FileNames: files };
		                    $.ajax({
		                        url: urlstring,
		                        type: "POST",
		                        dataType: "json",
		                        data: JSON.stringify(o),
		                        async: false,                                
		                        contentType: "application/json; charset=utf-8",
		                        error: function (errorThrown) {
		                        },
		                        success: function (dataFile) {
		                            var temp = JSON.parse(dataFile.d);
		                            if (temp.length > 0) {
		                                FileGUID = temp[0].FileGuid;
		                                if (typeof (DSTGUID) != 'undefined' && DSTGUID.length > 0) {
		                                    if(dropBox==true){
		                                        InsertDistributionFile(DSTGUID, FileGUID, GetDistributionFileGUID);
		                                    }
		                                    dataFileGuid.push(FileGUID);
		                                }
		                            }
		                        },
		                    });
		                }
		            }
		        }               
		    }
		
			var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
			if (SendDistributionAttachmentEmail == true && Email == true && emailUsers.length > 0) {
				
				var UserName = "";
				var EmailAddress = "";

				for (var i = 0; i < emailUsers.length-1; i++) {
					UserName = UserName + emailUsers[i].USR_NM + ",";
					EmailAddress = EmailAddress + emailUsers[i].EMAIL_ADDR_DESC + ",";

				}
				UserName = UserName + emailUsers[emailUsers.length - 1].USR_NM;
				EmailAddress = EmailAddress + emailUsers[emailUsers.length - 1].EMAIL_ADDR_DESC;
				DistributeFileNotification(dataFileGuid.toString(), UserName, EmailAddress, UserGUID);
			}

			var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
			if (dropBox == true && dropboxUsers.length > 0 )
			{
				var UserName = "";
				var EmailAddress = "";
				var UserGuids = ""; 

				for (var i = 0; i < dropboxUsers.length - 1; i++) {
					UserName = UserName + dropboxUsers[i].USR_NM + ",";
					EmailAddress = EmailAddress + dropboxUsers[i].EMAIL_ADDR_DESC + ",";
					UserGuids = UserGuids + dropboxUsers[i].USR_GUID + ",";

				}
				UserName = UserName + dropboxUsers[dropboxUsers.length - 1].USR_NM;
				EmailAddress = EmailAddress + dropboxUsers[dropboxUsers.length - 1].EMAIL_ADDR_DESC;
				UserGuids = UserGuids + dropboxUsers[dropboxUsers.length - 1].USR_GUID ;
				DistributeDropBoxFileNotification(dataFileGuid.toString(), UserName, EmailAddress,
					UserGuids, UserGUID, $("#comments").val());
			}
		}
	}
	function GetDistributionGUID(data) {
		var GetDist = data;
		DSTGUID = GetDist[0].DSTBN_GUID;
		DistributeData(DSTGUID);
		return;

	}
	function GetDistributionFileGUID(data) {
		var GetDistFile = data;
		var DSTFileGUID = GetDistFile[0].DSTBN_FILE_GUID;
		if (typeof (DSTGUID) != 'undefined' && DSTGUID.length > 0) {
			if (typeof (FileGUID) != 'undefined' && FileGUID.length > 0) {
				InsertDistributionRecipient(DSTGUID, FileGUID, GetDistributionRecptGUID)
			}
		}
	}
	function GetDistributionRecptGUID(data) {
		var GetDistRecpFile = data;
		var DSTFileRecptGUID = GetDistRecpFile[0].DSTBN_RCPT_GUID;
		if (isLastFile == true && IsLastRecipient == true) {
			$("#alert_progress").dialog("close");
			$("#alertDis").html("File distribution complete.").dialog("open");
		}
	}
	
	fillDistriubtionListType();
	$('.select_AllDropBox').click();
});

function InsertDistributionRecipient(DSTGUID, DFileGUID, callback) {

	if (dropboxflag) {
		var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
		if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
			for (var i = 0; i < dropboxUsers.length; i++) {
				if (isLastFile == true && i == dropboxUsers.length - 1)
					IsLastRecipient = true;
				var param = "DataFileGuid=" + "'" + DFileGUID + "'%26" + "DistributionGuid=" + "'" + DSTGUID + "'%26" + "RecUserGuid=" + "'" + dropboxUsers[i].USR_GUID + "'%26" + "Email=" + "'NULL'";
				var data = GetXSpaceData(param, "InsertDistributionRecipient_SP", callback);
			}
		}
	}

	if (emailFlag) {
		var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
		if (typeof (emailUsers) != 'undefined' && emailUsers.length > 0) {
			for (var i = 0; i < emailUsers.length; i++) {
				if (emailUsers[i].RCPT_TYPE == "USR_RCPT") {
					var param = "DataFileGuid=" + "'" + DFileGUID + "'%26" + "DistributionGuid=" + "'" + DSTGUID + "'%26" + "RecUserGuid='" + emailUsers[i].USR_GUID + "'%26" + "Email=" + "'" + emailUsers[i].EMAIL_ADDR_DESC + "'";
					var data = GetXSpaceData(param, "InsertDistributionRecipient_SP", callback);
				}
			}
		}
	}

}

function AddDropboxRecipients(sourceGridID) {
	PopulateRecipients(sourceGridID, emailRecipientsGridSettings.GridId, true);
	$("#dialog-personnel").dialog("open");
}

function RemoveRecipients(sourceGridID) {
	gridId = sourceGridID;
	var table = $("#" + sourceGridID).DataTable();
	if (table.row('.selected').length > 0) {
		$("#confirm").html("Are you sure to delete selected recipient(s)?").dialog("open");
	}
	else {
		$("#alertDis").html("Please select recipient(s) to delete.").dialog("open");
	}
}

function AddEmailRecipients(sourceGridID) {
	OpenEmailRecipientsDialog(sourceGridID, AddEmailRecipientData);
}

function AddEmailRecipientData(sourcegrid, recipientData) {   
	$('#' + sourcegrid).DataTable().row.add(recipientData).draw(false);
}

function getDistributionListTypeItem(dText,dValue){
	var distributionListItem={};
		distributionListItem={};
	 distributionListItem.text=dText;
	 distributionListItem.value=dValue;
	 return distributionListItem; 
}

function fillDistriubtionListType(){
	 var distributionList =[],distributionListItem={},selectControlID="SDistListType";
	 if(USERROLE != USERROLE_TYPE.CustomerUser && USERROLE != USERROLE_TYPE.CustomerAdministrator){
		 if(USERROLE !=  USERROLE_TYPE.InternalUser){
			 distributionList.push(getDistributionListTypeItem(D_TYPE_WELL,D_TYPE_WELL));
		 }			 
		 distributionList.push(getDistributionListTypeItem(D_TYPE_DISTRICT,D_TYPE_DISTRICT));
		 distributionList.push(getDistributionListTypeItem(D_TYPE_PERSONAL,D_TYPE_PERSONAL));
		}
	 
	$.each(distributionList, function(index, item) {
		  $("#"+selectControlID).get(0).options[$("#"+selectControlID).get(0).options.length] = new Option(item.text, item.value);
		 });
	var setDistTyeValue=D_TYPE_DISTRICT;
	if(USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.CustomerAdministrator){
		setDistTyeValue=D_TYPE_PERSONAL
		$("#lblDisType").hide();
		$("#"+selectControlID).hide();
	}
	$("#"+selectControlID).val(setDistTyeValue);
	$("#"+selectControlID).change();
	if(USERROLE != USERROLE_TYPE.CustomerUser && USERROLE != USERROLE_TYPE.CustomerAdministrator){
		defaultPSLPopulate();
	}
	
}

function fillDistriubtionList(disListType){	
	var sp="",param="",selectControlID="SDistList";
	
	if(disListType==D_TYPE_WELL)
		sp="GetWellDistributionList_SP";
	else if(disListType==D_TYPE_DISTRICT)
		sp="GetDistrictDistributionList_SP";
	else{
		param="UserID='"+USERID + Sep()
		sp="GetPersonalDistributionList_SP";	
	}
	
	$("#"+selectControlID).empty();	
	GetXSpaceData(param,sp, function(data){		
		$.each(data, function(index, item) {			
		  $("#"+selectControlID).get(0).options[$("#"+selectControlID).get(0).options.length] = new Option(item.DSTBN_LIST_NM, item.DSTBN_LIST_GUID);
		 });		 
	});
	$("#"+selectControlID).val("");
}

function fillRecipients(disListGUID){
		DestoryDataTableIfExists();
		GetXSpaceData("ListGuid='" + disListGUID + "'", "GetDistributionListUsers_SP", RenderDropBoxGrid);
		GetXSpaceData("ListGuid='" + disListGUID + "'", "GetDistributionListEmailRecpnt_SP", RenderExternalReceipentsGrid);        
}

function RenderDropBoxGrid(data)
{
	var dropBoxData = [];
	for (var i = 0; i < data.length ; i++) {
		if (data[i].DROP_BOX_NTFN_FLG == "1") {
			var object = new Object();
			object.USR_FIR_NM = data[i].USR_FIR_NM;
			object.USR_LST_NM = data[i].USR_LST_NM;
			object.USR_NM = data[i].USR_NM;
			object.USR_GUID = data[i].USR_GUID;
			object.CO_NM = data[i].RCPT_CO_NM;
			object.EMAIL_ADDR_DESC = data[i].EMAIL_ADDR_DESC;;
			object.DSTBN_LIST_RCPT_GUID = data[i].DSTBN_LIST_RCPT_GUID;
			object.DROP_BOX_NTFN_FLG = data[i].DROP_BOX_NTFN_FLG;
			object.EMAIL_NTFN_FLG = data[i].EMAIL_NTFN_FLG;
			dropBoxData.push(object);
		}
	}
	$("#" + dropBoxRecipientsGridSettings.GridId).renderGrid(dropBoxRecipientsGridSettings, dropBoxData);
}

function RenderExternalReceipentsGrid(data)
{
	var dropBoxData = [];
	for (var i = 0; i < data.length ; i++) {

		var object = new Object();
		object.USR_FIR_NM = data[i].RCPT_FIR_NM;
		object.USR_LST_NM = data[i].RCPT_LST_NM;
		object.USR_NM = data[i].RCPT_NM;
		object.CO_NM = data[i].RCPT_CO_NM;
		object.EMAIL_ADDR_DESC = data[i].EMAIL_ADDR_DESC;
		object.DSTBN_LIST_RCPT_GUID = data[i].DSTBN_LIST_RCPT_GUID;
		object.USR_GUID = data[i].RCPT_GUID;
		object.RCPT_TYPE = data[i].RCPT_TYPE;
		dropBoxData.push(object);
	}
	$("#" + emailRecipientsGridSettings.GridId).renderGrid(emailRecipientsGridSettings, dropBoxData);
}

function DestoryDataTableIfExists() {    
	if ($.fn.dataTable.isDataTable("#" + dropBoxRecipientsGridSettings.GridId)) {
		var oTable1 = $("#" + dropBoxRecipientsGridSettings.GridId).dataTable();
		$("#" + dropBoxRecipientsGridSettings.GridId + "tbody").html("");
		oTable1.dataTable().fnDestroy();
	}

	if ($.fn.dataTable.isDataTable("#" + emailRecipientsGridSettings.GridId)) {
		var oTable2 = $("#" + emailRecipientsGridSettings.GridId).dataTable();
		$("#" + emailRecipientsGridSettings.GridId + "tbody").html("");
		oTable2.dataTable().fnDestroy();
	}   

}

function resetRecipients(disListGUID){
		if(disListGUID!=undefined && disListGUID!="")
		$("#SDistList").empty();	
		DestoryDataTableIfExists();
		RenderDropBoxGrid([]);
		RenderExternalReceipentsGrid([]);		      
}

function defaultPSLPopulate() {
    var WBGuid = GetUrlParameter("WBGuid");
    if (WBGuid != undefined && WBGuid != "") {
        var param = "UserID='" + USERID + Sep();
        GetXSpaceData(param, "GetUserDetailByUserID_SP", function (data) {
            var param = "PslID='" + data[0].PSL_ID + Sep() + "WBJobGuid='" + WBGuid + Sep();
            //var param = "PslID='AL" + Sep() + "WBJobGuid='07392F75-A326-4583-AFD4-DC41738A965C'";
            GetXSpaceData(param, "GetWellDistributionListByPslID_SP", function (plsData) {
                if (plsData != null && plsData.length > 0 && plsData[0].DSTBN_LIST_GUID != null && plsData[0].DSTBN_LIST_GUID != "")
                     fillRecipients(plsData[0].DSTBN_LIST_GUID);
            });
        });
    }
}

function GetUrlParameter(key) {
    var href = window.location.href;
    href = href.replace('#', '');
    var vars = [], hash;
    var hashes = href.slice(href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars[key];
}