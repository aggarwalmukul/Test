﻿var fileheader = ["File Name", "New File", "Size (MB)", "Status", "Comments", "Uploaded By", "Upload Date", "Company Name"];
var WellDataFolders;
var WellGuid;
var machine;
var folderpath;
var driveGuid;
var action;
var ACTION_TYPE = { SO: "SO", RESTORE_FILE: "RF", GROUP: "GRP" };
var currentGroupRow = null;
var IsDirty = false;
var currentStatus="";
var fileExtension="";
$(document).ready(function () {
    GetUserGuid(GetUserGUIDDetails);
    $("#wTightHole").hide();
    $("#tighthole").hide();

    loadGroupData();
    loadSoData();
    var drives = GetStorageDrive(UpdateDrives);
    var WellFolders = GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);    
    $(document).on("click", ".headercheckbox", function () {
        $(this).parents('tr').find(':checkbox').prop('checked', this.checked);

    });
    $(document).on("click", "#EditStatus", function () {
        EditStatusDialog();
    });
    $("#divFileStatus").dialog({
        autoOpen: false,
        modal: true,
        title: "Edit File Status",
        height: 250,
        width: 400,
        open: function () {
			 var select = document.getElementById("FileSelectList");
			var selValue="";
			if(currentStatus=="Internal")
				selValue="INTRNL";
			else if(currentStatus=="Preliminary")
				selValue="PRELM";
			else if(currentStatus=="Final")
				selValue="FINAL";			
			
			$("#FileSelectList").val(selValue);
			selectedIndex=$("#FileSelectList option:selected").index();	
			select.selectedIndex =selectedIndex;	
        },        
        buttons: {
            "OK": function () {
                selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
                var guids = "";
                for (var index = 0; index < selectedFiles.length; index++) {
                    var param = "DataFileGuid='" + selectedFiles[index].DATA_FILE_GUID + "'%26" + "StatusCode='" + $("#FileSelectList").val() + "'";
                    guids = guids + selectedFiles[index].DATA_FILE_GUID + ",";
                    GetXSpaceData(param, "UpdateDataFile_SP", undefined);
                }
                guids = guids.substring(0, guids.length - 1);
                FileStatusChangeNotification(guids);
                $("#container").html("");
                GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);
                currentStatus = "";				
                $(this).dialog('close');                
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("click", "#EditComments", function () {
        EditComments();
    });
    $("#divComments").dialog({
        autoOpen: false,
        modal: true,
        title: "Comments",
        height: 250,
        width: 400,
        resizable: false,
        open: function () {

        },
        close: function () {

        },
        buttons: {
            "OK": function () {
                var param = "DataFileGuid='" + $("#fileGuid").val() + "'%26" + "Comments='" + $("#TextComments").val() + "'";
                GetXSpaceData(param, "UpdateDataFile_SP", function () {
                    $("#container").html("");
                    GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);
                });                
                $(this).dialog('close');                
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("click", "#DeleteSelected", function () {
        DeleteFile();
    });
    $("#divDelete").dialog({
        autoOpen: false,
        modal: true,
        title: "Delete File",
        height: 250,
        width: 400,
        open: function () {

        },
        close: function () {

        },
        buttons: {
            "OK": function () {
                var guids = $("#fileidlist").val().split(",");
                for (var i = 0; i < guids.length; i++) {
                    var param = "DataFileUploadGuid='" + guids[i] + "'";
                    GetXSpaceData(param, "DeleteDataFileUpload_SP", undefined);

                }
                $("#container").html("");
                GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("click", "#RenameSelected", function () {
        RenameFile();
    });

    $("#divRename").dialog({
        autoOpen: false,
        modal: true,
        title: "Rename File",
        height: 200,
        width: 500,
        open: function () {

        },
        close: function () {

        },
        buttons: {
            "OK": function () {  
				if($.trim($("#fileName").val())==""){
					 $("#alert").html("Please enter File Name.").dialog('open');
					 return false;
				}			
				var fileNameWithExtension=$.trim($.trim($("#fileName").val())+fileExtension);
                var o = { Guid: selectedFiles[0].DATA_FILE_GUID, FileName: fileNameWithExtension };
                var closedialog = false;                
                var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/RenameFile";

                $.ajax({
                    url: urlstring,
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify(o),
                    async: false,                   
                    contentType: "application/json; charset=utf-8",
                    error: function (errorThrown) {
                        alert(errorThrown);
                    },
                    success: function (status) {
                        var stat = JSON.parse(status.d);
                        if (stat == "success") {
                            closedialog = true;
                            $("#container").html("");
                            GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);

                        }
                        else {
                            $("#alert").html("A file with the same name already exists. Please specify a different file name.").dialog('open');

                        }
                    },
                });
                if (closedialog == true) {
                    $(this).dialog('close');
                }

            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("click", "#moveSelected", function () {
        MoveFile();
    });

    $("#divFileMove").dialog({
        autoOpen: false,
        modal: true,
        title: "Move File",
        height: 200,
        width: 400,
        open: function () {
            GetWellFolders(UpdateWellFolders);
        },
        close: function () {

        },
        buttons: {
            "OK": function () {
                for (var i = 0; i < selectedFiles.length; i++) {
                    var o = { Guid: selectedFiles[i].DATA_FILE_GUID, DataUploadGuid: selectedFiles[i].DATA_FILE_UPL_GUID, Folder: $("#FileFolderList :selected").text(), FolderType: $("#FileFolderList").val() };
                    var closedialog = false;                    
                    var urlstring = getAppURL() + "/_layouts/15/FileHandler/FileService.aspx/MoveFile";

                    $.ajax({
                        url: urlstring,
                        type: "POST",
                        dataType: "json",
                        data: JSON.stringify(o),
                        async: false,                        
                        contentType: "application/json; charset=utf-8",
                        error: function (errorThrown) {
                        },
                        success: function (status) {
                            var stat = JSON.parse(status.d);
                            if (stat == "success") {
                                closedialog = true;
                                $("#container").html("");
                                GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);

                            }
                            else {
                                $("#alert").html("A file with the same name already exists. Please specify a different file name.").dialog('open');
                            }
                        },
                    });
                    if (closedialog == true) {
                        $(this).dialog('close');
                    }
                }
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    document.getElementById('openAll').onclick = function () {
        if (typeof ($('#openAll').attr("state")) == 'undefined' || $('#openAll').attr("state") == "close") {
            $(".collapse").each(function () {
                var id = $(this).closest("tr").attr("id");
                $(this).html("<img src='/_layouts/15/XSP/images/toggle.png' width=16px height=16px style='border:0'/>");
                $("div[id='" + id + "']").css("display", "");
                $("div[id='" + id + "']").css("width", "100%");
            });
            $('#openAll').attr("state", "open");
            $('#openAll').attr("src", "../images/close_folder_32x32.png");
			$('#openAll').attr("title", "Close All");
        }
        else {
            $(".collapse").each(function () {
                var id = $(this).closest("tr").attr("id");
                var state = $(this).attr("state");

                $(this).html("<img src='/_layouts/15/XSP/images/toggle-expand.png' width=16px height=16px style='border:0'/>");
                $("div[id='" + id + "']").css("display", "none");
                $("div[id='" + id + "']").css("width", "100%");
            });
            $('#openAll').attr("state", "close");
            $('#openAll').attr("src", "../images/open_folder_32x32.png");
			$('#openAll').attr("title", "Open All");
        }
        $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
    }
    document.getElementById('selectAll').onclick = function () {
        if (typeof ($('#selectAll').attr("state")) == 'undefined' || $('#selectAll').attr("state") == "unchecked") {
            $("#divDownloadFiles").find("input[type=checkbox]").prop('checked', true);

            $("#divDownloadFiles").find('.rowselect').each(function () { //loop through each checkbox 
                $(this).closest("tr").addClass("selected");
            });
            $('#selectAll').attr("state", "checked");
            $('#selectAll').attr("src", "../images/select_all_32x32.png");
			$('#selectAll').attr("title", "Unselect All");
        }
        else {
            $("#divDownloadFiles").find("input[type=checkbox]").prop('checked', false);

            $("#divDownloadFiles").find('.rowselect').each(function () { //loop through each checkbox 
                $(this).closest("tr").removeClass("selected");
            });
            $('#selectAll').attr("state", "unchecked");
            $('#selectAll').attr("src", "../images/select_none_32x32.png");			
			$('#selectAll').attr("title", "Select All");
        }
    }

    $(document).on("click", "a.collapse", function () {
        var id = $(this).closest("tr").attr("id");
        if (typeof ($(this).attr("state")) == "undefined" || $(this).attr("state") == "collapse") {
            $(this).html("<img src='/_layouts/15/XSP/images/toggle-expand.png' width=16px height=16px style='border:0'/>");
            $("div[id='" + id + "']").css("display", "none");
            $("div[id='" + id + "']").css("width", "100%");
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
            $(this).attr("state", "expand");
        }
        else {
            $(this).html("<img src='/_layouts/15/XSP/images/toggle.png' width=16px height=16px style='border:0'/>");
            $("div[id='" + id + "']").css("display", "");
            $("div[id='" + id + "']").css("width", "100%");
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
            $(this).attr("state", "collapse");
        }
    });

    $(".collapse").each(function () {
        $(this).click();
    })
    $(".btnUpload_clickable").on("click", function () {
        return OpenUploadFiles();
    });

    document.getElementById('selectNew').onclick = function () {
        //remove first select all if checked
        if (typeof ($('#selectAll').attr("state")) != 'undefined' || $('#selectAll').attr("state") == "checked") {
            $("#divDownloadFiles").find("input[type=checkbox]").prop('checked', false);
            $("#divDownloadFiles").find('.rowselect').each(function () { //loop through each checkbox 
                $(this).closest("tr").removeClass("selected");
            });
            $('#selectAll').attr("state", "unchecked");
            $('#selectAll').attr("src", "../images/select_none_32x32.png");
        }

        $('.newFile').each(function () { //loop through each new file class 
             $(this).closest("tr").addClass("selected");
            // var cb = $(this).closest("tr").find("input[type=checkbox]");
             $(this).closest("tr").find("input.rowselect").prop('checked', true);
        });
    }
    loadWellDetails();   
    $("#tabs").tabs({
        beforeLoad: function (event, ui) {
            ui.newPanel.text('Retrieving data...');
        },
        activate: function (event, ui) {
            var currentTabIndex = ui.newTab.index().toString();
            sessionStorage.setItem('well-tab-index', currentTabIndex);
            if (ui.newPanel.is("#Details")) {
                
            }
            else if (ui.newPanel.is("#SONumber")) {
                clearSoFilter();
                if ($("#clearSoFilter").length > 0)
                    $("#clearSoFilter")[0].onclick = null;
              
                if ($("#AddSo").length > 0)
                    $("#AddSo")[0].onclick = null;
              
                if ($("#DeleteSo").length > 0)
                    $("#DeleteSo")[0].onclick = null;
                $("input", "#_filterRow").on("keyup", function () {
                    $("#clearSoFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                });
                hideAdminActions();
            }
            else if (ui.newPanel.is("#Groups")) {
                clearGroupFilter();
                if ($("#AddGroup").length > 0)
                    $("#AddGroup")[0].onclick = null;

                if ($("#clearGroupFilter").length > 0)
                    $("#clearGroupFilter")[0].onclick = null;
                $("input", "#_filterRow").on("keyup", function () {
                    $("#clearGroupFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                });
                hideAdminActions();
            }
            else if (ui.newPanel.is("#DL")) {
                clearDLFilter();
                if ($("#AddDL").length > 0)
                    $("#AddDL")[0].onclick = null;

                if ($("#clearDLFilter").length > 0)
                    $("#clearDLFilter")[0].onclick = null;
                $("input").on("keyup", function () {
                    $("#clearDLFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                });
                hideAdminActions();
            }
            else if (ui.newPanel.is("#Files")) {
               
                hideAdminActions();
            }
            else { ///recycle bin
                clearRBFilter();
                if ($("#Restore").length > 0)
                    $("#Restore")[0].onclick = null;

                if ($("#clearRBFilter").length > 0)
                    $("#clearRBFilter")[0].onclick = null;
                $("input", "#_filterRow").on("keyup", function () {
                    $("#clearRBFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                });
            }
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });
    var selectedtab = qs("operation");
    if (selectedtab == "FILE") {
        selectedtab = "4";
    }
    else if (selectedtab == "DETAIL") {
        selectedtab = "0";
    }

    else {
        if (sessionStorage.getItem('well-tab-index') != "null")
            selectedtab = sessionStorage.getItem('well-tab-index');
    }
    $("#tabs").tabs("option", "active", selectedtab);
   
    $(document).on("click", "#clearSoFilter", function () { clearSoFilter() });    
    $(document).on("click", "#AddSo", function () { AddSo() });  
    $(document).on("click", "#DeleteSo", function () { DeleteSo() });

    $(document).on("click", "#AddGroup", function () { AddGroup() });
    $(document).on("click", "#clearGroupFilter", function () { clearGroupFilter() });

    $(document).on("click", "#AddDL", function () { AddDL() });
    $(document).on("click", "#clearDLFilter", function () { clearDLFilter() });
    $(document).on("click", "#Restore", function () { Restore() });
    $(document).on("click", "#clearRBFilter", function () { clearRBFilter() });
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 300,
        buttons: {
            "Yes": function () {              
                if (action == ACTION_TYPE.RESTORE_FILE)
                {
                    var data = $("#" + recyclebinGridSettings.GridId).DataTable().rows(".selected").data();
                    var ids = '';
                    for (var i = 0; i < data.length; i++) {
                        if (i == data.length - 1)
                            ids = ids + data[i].WB_JOB_DATA_FILE_GUID
                        else
                            ids = ids + data[i].WB_JOB_DATA_FILE_GUID + ","
                    }
                    var param = "WBJobDataFileGuidList='" + ids + "'%26Separator=','"
                    GetXSpaceData(param, "RestoreWellBinFiles_SP", function () {
                        clearRBFilter()
                    });
                    RefreshWellFiles();
                }
                else if (action == ACTION_TYPE.SO) {
                    var data = $("#" + soGridSettings.GridId).DataTable().rows(".selected").data();
                    DeleteSOData(data);
                    var table = $("#" + soGridSettings.GridId).DataTable();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                }
                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dSelectEntitlements").dialog({
        autoOpen: false,
        modal: true,
        title: "Entitlements",
        height: 500,
        width: 600,
        open: function () { loadEntitlements(); },
        buttons: {
            "OK": function () {
                var entitlements = $("#" + SelectedEntitlementsGridettings.GridId).DataTable().rows().data();
                if (typeof (entitlements) == 'undefined' || entitlements.length==0)
                {
                    $("#alert").html("Please select entitlements.").dialog('open');
                    return false;
                }
              
               
               var strEntNm = '';
               var strEntId = '';
               for (var i = 0; i < entitlements.length; i++) {
                   if (i == entitlements.length - 1) {
                       strEntNm = strEntNm + entitlements[i].FLDR_TYP_NM;
                       strEntId = strEntId + entitlements[i].FLDR_TYP_ID;
                   }
                   else {
                       strEntNm = strEntNm + entitlements[i].FLDR_TYP_NM + ",";
                       strEntId = strEntId + entitlements[i].FLDR_TYP_ID + ",";
                   }
               }
               if (selectedEntitlement == null) {
                   var group = $("#" + dGroupGridSettings.GridId).DataTable().row(".selected").data();
               var row = new Object();
               row.USR_GRP_GUID = group.USR_GRP_GUID;
               row.USR_GRP_NM = group.USR_GRP_NM;
               row.FLDR_TYP_NM = strEntNm;
               row.FLDR_TYP_ID = strEntId;
               row.Action = "New";               
                   $('#' + groupsGridSettings.GridId).DataTable().row.add(row).draw(false);                   
               }
               else {
                   var table = $('#' + groupsGridSettings.GridId).DataTable();
                   var rowData = table.row(currentGroupRow).data();
                   rowData.FLDR_TYP_NM = strEntNm;
                   rowData.FLDR_TYP_ID = strEntId;
                   if (typeof (rowData.Action) == 'undefined')
                       rowData.Action = "Update";
                   table.row(currentGroupRow).data(rowData).draw();
               }
               groupData = $('#' + groupsGridSettings.GridId).DataTable().rows().data();
               $("#save").attr("src", "../images/save_dirty_24x24.png");
               IsDirty = true;
               $(this).dialog('close');

            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("keypress blur", "textarea", function () {
        removeSpecialChar($(this));
    });
    $("#addSo").dialog({
        autoOpen: false,
        modal: true,
        title: "Add SO Number",
        height: 140,
        width: 350,
        open: function () {
            $("#soNumber").val("");
            $("#soNumber").on("keypress", function () {
                evt = event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            });
        },
        buttons: {
            "OK": function () {
                if ($("#soNumber").val() == "") {
                    ShowCustomAlert("Please enter SO Number.","Alert",250);
                    return;
                }
				//Check for dublicate
				soList=$('#' + soGridSettings.GridId).DataTable().rows().data();
				for(var index=0;index<soList.length;index++){
					if(soList[index].SLORD_NUM==$("#soNumber").val()){
						ShowCustomAlert("SO Number already exists","Alert",250);
						return;
					}
				}
                var item = new Object();
                item.SLORD_NUM = $("#soNumber").val();
                item.WELL_GUID = qs("WBGuid");                
                $('#' + soGridSettings.GridId).DataTable().row.add(item).draw(true);
                SetDirtyFilter();
                soData = $('#' + soGridSettings.GridId).DataTable().rows().data();
                $(this).dialog('close');
               
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    GetXSpaceData("", "GetPSL_SP", UpdatePslDropDown);
    $("#dAddDL").dialog({
        autoOpen: false,
        modal: true,
        title: "Add Distribution List",
        height: 200,
        width: 500,
        open: function () { $("#dlName").val(""); $("#ddlPSL").val("");},
        buttons: {
            "OK": function () {
                if ($.trim($("#dlName").val()) == "")
                {
                    $("#alert").html("Please enter distribution list name.").dialog('open');
                    return false;
                }
                if ($("#ddlPSL").val() == "") {
                    $("#alert").html("Please select PSL.").dialog('open');
                    return false;
                }
                var param = "ListName='" + $("#dlName").val() + Sep() + "UserID='" + USERID + Sep() + "WBJobGuid='" + qs("WBGuid") + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
                GetXSpaceData(param, "InsertWellDistributionList_SP", InsertDLCallback);
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dSelectGroup").dialog({
        autoOpen: false,
        modal: true,
        title: "Select Group",
        height: 400,
        width: 600,
        open: function () {
            clearDGroupFilter();

            $("input").on("keyup", function () {
                $("#clearDGroupFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
            });
            if ($("#clearDGroupFilter").length > 0)
                $("#clearDGroupFilter")[0].onclick = null;
            $(document).on("click", "#clearDGroupFilter", function () { clearDGroupFilter(); });
        },
        buttons: {
            "OK": function () {
                var rows = $("#" + dGroupGridSettings.GridId).DataTable().row(".selected").data();
                if (typeof(rows) == 'undefined' && rows == null )
                {
                    $("#alert").html("Please select a group.").dialog('open');
                    return false;
                }
                for (var i = 0; i < groupData.length; i++) {
                    if (groupData[i].USR_GRP_GUID == rows.USR_GRP_GUID)
                    {
                        $("#alert").html("Selected group already exists.Please select another group.").dialog('open');
                        return false;
                    }
                }
                $("#dSelectEntitlements").dialog('open');
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 160,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    
    $("#save").on("click", function () {
        if (IsDirty && validate()) {
            GetXSpaceData(getUpdateParams(), "UpdateWellDetails_SP", function (data) {
                SaveSOData();
            });
        }
    });
    window.onbeforeunload = function () {       
        if (IsDirty == true) {
          /*  if (confirm("You have unsaved changes.Do you want to save?")) {
                $("#save").click();
                return;
            }
            else {
                return;
            } */
            return 'You have unsaved changes!';
        }
        //return;
    };
    $(document).on("keyup", "input.wDetails", function () {
        IsDirty = true;
        if (typeof ($(this).attr("readonly")) == 'undefined')
            $("#save").attr("src", "../images/save_dirty_24x24.png");
    });
    $(document).on("click", "input[type='checkbox'].wDetails", function () {
        IsDirty = true;
        if (typeof ($(this).attr("readonly")) == 'undefined')
            $("#save").attr("src", "../images/save_dirty_24x24.png");
    });
    $(document).on("change", "select.wDetails", function () {
        IsDirty = true;
        if (typeof ($(this).attr("readonly")) == 'undefined')
            $("#save").attr("src", "../images/save_dirty_24x24.png");
    });
    hideAdminActions();
});


function PerformInternalUserActions()
{
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.InternalUser
        || USERROLE == USERROLE_TYPE.CustomerAdministrator)
    {
        $("#save").hide();
        $("#tblWellDetails :input").attr("disabled", "disabled");
        //$("#tblWellDetails :select").attr("disabled", "disabled");
        $("#RenameSelected").hide();
        $("#moveSelected").hide();
        $("#EditComments").hide();
        $("#EditStatus").hide();
        $("#DeleteSelected").hide();
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.InternalUser)
        {
        $($("#tabs").find("li")[5]).hide();
       }
     }

    if( USERROLE == USERROLE_TYPE.InternalUser) 
    {
        $("#AddSo").hide();
        $("#DeleteSo").hide();
        $("#AddGroup").hide();
        $("#AddDL").hide();


    }
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.CustomerAdministrator)
        {
            $($("#tabs").find("li")[1]).hide();
            $($("#tabs").find("li")[2]).hide();
            $($("#tabs").find("li")[3]).hide();
        }

}
function hideAdminActions() {
    PerformInternalUserActions();
        return;
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.InternalUser) {
        $("#save").hide();
        $("#AddSo").hide();
        $("#DeleteSo").hide();
        $("#AddGroup").hide();
        $(".edithref").prop("disabled", true);
        $("#AddDL").hide();
        $("#RenameSelected").hide();
        $("#moveSelected").hide();
        $("#EditComments").hide();
        $("#EditStatus").hide();
        $("#DeleteSelected").hide();
        $($("#tabs").find("li")[5]).hide();
    }
}
function UpdateWellFolders(data) {    
    $("#FileFolderList").empty();
    var wellfoldersdata = data;

    var selectwellfolders = document.getElementById("FileFolderList");
    for (var i = wellfoldersdata.length - 1; i >= 0; i--) {
        var option = document.createElement('option');

        option.text = wellfoldersdata[i].FLDR_TYP_NM;
        option.value = wellfoldersdata[i].FLDR_TYP_ID;
        selectwellfolders.add(option, 0);
    }
    selectwellfolders.selectedIndex = 0;
}
function editWellDL(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/createDistributionList.aspx?WBGuid=" + qs("WBGuid") + "&type=W&DLID=" + full.DSTBN_LIST_GUID + "'>" + full.DSTBN_LIST_NM + "</a>";
}
function UpdatePslDropDown(data) {
    var PSLs = data;
    var select = document.getElementById("ddlPSL");
    var option = document.createElement('option');
    option.text = "";
    option.value = "";
    select.add(option);
    for (var i = 0; i < PSLs.length; i++) {
        option = document.createElement('option');
        option.text = PSLs[i].PSL_NM;
        option.value = PSLs[i].PSL_ID;
        select.add(option);
    }
   // SortOptions("#ddlPSL");
    select.selectedIndex = 0;
}
function InsertDLCallback(data) {
    if (data.length > 0) {
        window.location.href = "/_layouts/15/XSP/Pages/createDistributionList.aspx?type=W&DLID=" + data[0].DSTBN_LIST_GUID ;
    }
}
var soData = [];
function loadSoData() {
    var param = "WBJobGuid='" + qs("WBGuid") + "'";
    GetXSpaceData(param, soGridSettings.DataSource, function (data) {
        soData = data;
    });   
}
function bindSoGrid() {
    $("#" + soGridSettings.GridId).renderGrid(soGridSettings, soData);
}
function clearSoFilter() {
    $("input", "#_filterRow").val("");
    if ($.fn.dataTable.isDataTable("#" + soGridSettings.GridId)) {
        var oTable1 = $("#" + soGridSettings.GridId).dataTable();
        $("#" + soGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }    
    bindSoGrid();
    $("#clearSoFilter").attr("src", "../images/clear_filter_32x32.png");
}
function AddSo() {
    $("#addSo").dialog('open');
}
function DeleteSo() {
    action = ACTION_TYPE.SO;
    if ($("#" + soGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#confirm").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#alert").html("Please select a Sales Order Number to delete.").dialog('open');
    }
}
var groupData = [];
function loadGroupData() {
    GetXSpaceData("WBJobGuid='" + qs("WBGuid") + "'", groupsGridSettings.DataSource, function (data) {
        groupData=data;
    });
}
function BindGroupData() {
    $("#" + groupsGridSettings.GridId).renderGrid(groupsGridSettings, groupData);
}
function clearGroupFilter() {
    $("input", "#groupsGrid_wrapper").val("");
   
    if ($.fn.dataTable.isDataTable("#" + groupsGridSettings.GridId)) {
        var oTable1 = $("#" + groupsGridSettings.GridId).dataTable();
        $("#" + groupsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    BindGroupData();
    $("#clearGroupFilter").attr("src", "../images/clear_filter_32x32.png");
}
function AddGroup() {
    selectedEntitlement = null;
    $("#dSelectGroup").dialog('open');
}
function editGroup(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/CreateGroup.aspx?WBGuid=" + qs("WBGuid") + "&GroupID=" + full.USR_GRP_GUID + "'>" + full.USR_GRP_NM + "</a>";
}
function editEntitelements(data, type, full, meta) {
    if (USERROLE == USERROLE_TYPE.InternalUser)
        return data;
    return "<a class='edithref' style='cursor:pointer' onclick=\"openEditEntitlements('" + full.FLDR_TYP_ID + "')\">" + data + "</a>";
}
function openEditEntitlements(selectedEntity) {
    selectedEntitlement = selectedEntity;
    if (typeof (event.target) == "undefined") {
        currentGroupRow = $(event.srcElement).closest("tr");
    }
    else {
        currentGroupRow = $(event.target).closest("tr");
    }
    $("#dSelectEntitlements").dialog('open');
}
function loadDLData() {
    GetXSpaceData("WBJobGuid='" + qs("WBGuid") + "'", dlGridSettings.DataSource, function (data) {
        $("#" + dlGridSettings.GridId).renderGrid(dlGridSettings, data);
    });    
}

function clearDLFilter() {
    $("input", "#dlGrid_wrapper").val("");

    if ($.fn.dataTable.isDataTable("#" + dlGridSettings.GridId)) {
        var oTable1 = $("#" + dlGridSettings.GridId).dataTable();
        $("#" + dlGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    loadDLData();
    $("#clearDLFilter").attr("src", "../images/clear_filter_32x32.png");
}
function AddDL() {
    $("#dAddDL").dialog('open');
}
function loadRecyclebinData() {
    GetXSpaceData("WBJobGuid='" + qs("WBGuid") + "'", recyclebinGridSettings.DataSource, function (data) {
        $("#" + recyclebinGridSettings.GridId).renderGrid(recyclebinGridSettings, data);
    });
  
}
function clearRBFilter() {
    $("input", "#recyclebinGrid_wrapper").val("");

    if ($.fn.dataTable.isDataTable("#" + recyclebinGridSettings.GridId)) {
        var oTable1 = $("#" + recyclebinGridSettings.GridId).dataTable();
        $("#" + recyclebinGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    loadRecyclebinData();
    $("#clearRBFilter").attr("src", "../images/clear_filter_32x32.png");
}
function Restore() {
    action = ACTION_TYPE.RESTORE_FILE;
    if ($("#" + recyclebinGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#confirm").html("Are you sure to restore selected file(s)?").dialog('open');
    }
    else {
        $("#alert").html("Please select file(s) to restore.").dialog('open');
    }
}
function loadDGroupData() {
    GetXSpaceData("WBJobGuid='" + qs("WBGuid") + "'", dGroupGridSettings.DataSource, function (data) {
        $("#" + dGroupGridSettings.GridId).renderGrid(dGroupGridSettings, data);
    });    
}
function clearDGroupFilter() {
    $("input", "#dGroupGrid_wrapper").val("");

    if ($.fn.dataTable.isDataTable("#" + dGroupGridSettings.GridId)) {
        var oTable1 = $("#" + dGroupGridSettings.GridId).dataTable();
        $("#" + dGroupGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    loadDGroupData();
    $("#clearDGroupFilter").attr("src", "../images/clear_filter_32x32.png");
}
function UpdateDrives(data) {
    machine = data[0].DRV_PATH;
    folderpath = "";
    driveGuid = data[0].DRV_GUID;
}

function round(num, precision) {
    return Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision);
}


function UpdateDownloadUI(data) {
    var dataFiles = data;

    var WellFolders = WellDataFolders;
    var filefolders = [];
    var FinalDataArray = [];
    var AllFoldersArray = [];
    var NumberofFiles = [];
    var NewFiles = [];
    var FilesCount = 0;
    var NewFilesCount = 0;
    for (var i = 0 ; i < WellFolders.length; i++) {
        var folder = new Object();
        folder.Id = WellFolders[i].FLDR_TYP_ID;
        folder.Name = WellFolders[i].FLDR_TYP_NM;
		folder.FLDR_INDX = WellFolders[i].FLDR_INDX;
        
        FinalDataArray = [];
        FilesCount = 0;
        NewFilesCount = 0;
        for (var j = 0; j < dataFiles.length; j++) {
            if (dataFiles[j].FLDR_TYP_NM == WellFolders[i].FLDR_TYP_NM) {
                dataFiles[j].FILE_SZ_VAL = round(dataFiles[j].FILE_SZ_VAL, 2);                
                var data = new Object();
                data.DATA_FILE_LNM = dataFiles[j].DATA_FILE_LNM;
                data.NEW_FILE = dataFiles[j].NEW_FLG;
                data.FILE_SZ_VAL = dataFiles[j].FILE_SZ_VAL;
                data.FILE_STAT_CD = dataFiles[j].FILE_STATUS;
                data.DATA_FILE_CMNT = dataFiles[j].DATA_FILE_CMNT;
                data.UPLOADED_BY = dataFiles[j].UPLOADED_BY;
                data.UPLOAD_DATE = dataFiles[j].UPLOAD_DATE;
                data.CO_NM = dataFiles[j].CO_NM;;
                data.DATA_FILE_GUID = dataFiles[j].DATA_FILE_GUID;
                data.DT_RowId = WellFolders[i].FLDR_TYP_NM;
                data.FLDR_INDX = WellFolders[i].FLDR_INDX;
                data.DATA_FILE_UPL_GUID = dataFiles[j].DATA_FILE_UPL_GUID;
				
                FinalDataArray.push(data);
                FilesCount = FilesCount + 1;
                if (dataFiles[j].NEW_FLG == 1) {
                    NewFilesCount = NewFilesCount + 1;
                }
            }


            }
        if (FilesCount > 0)
        {
            filefolders.push(folder);
            AllFoldersArray.push(FinalDataArray);
            NumberofFiles.push(FilesCount);
            NewFiles.push(NewFilesCount);
        }

    }

    var dataArray = [];
    CreateFileView(filefolders, NumberofFiles, NewFiles, AllFoldersArray);
    $(".collapse").each(function () {
        $(this).click();
    })
}

function GetWellData(data) {
    WellGuid = GetUrlParameter("WBGuid");
    WellDataFolders = data;
    GetWellFiles(WellGuid, "GetDataFilesByWBJob_SP", UpdateDownloadUI);
}

function CreateFileView(filefolders, NumberofFiles, NewFiles, AllFoldersArray) {
    for (var i = 0; i < filefolders.length; i++) {
        AddNewWellItem(filefolders[i].Id, filefolders[i].Name, NumberofFiles[i], NewFiles[i], null,filefolders[i].FLDR_INDX);
        AddNewWellItem(filefolders[i].Id, filefolders[i].Name, NumberofFiles[i], NewFiles[i], AllFoldersArray[i],filefolders[i].FLDR_INDX);
    }
}

function getHeaderRowItem(folderId, folder, filecount, NewFiles) {
    var imagetag = "";
    var imagetagNewFiles = "";
    imagetag = "<img src='/_layouts/15/XSP/images/toggle.png' width=16px height=16px style='border:0'/>";
    imagetag = "<a state='collapse' class='collapse' style='cursor: pointer;' id=toggle" + folderId + "'>" + imagetag + "</a>"

    if (NewFiles > 0) {
        //imagetagNewFiles = "<img src='/_layouts/15/XSP/images/redAsterisk.png' width=8px height=8px style='border:0'/>" + "<span style='color:Red; font-weight:bold;'>(" + NewFiles + ")" + "</span>";
        imagetagNewFiles = "<img src='/_layouts/15/XSP/images/redAsterisk.png' width=8px height=8px style='border:0'/>" + "<span style='color:Red;'>(" + NewFiles + ")" + "</span>";
        //imagetagNewFiles = "<span style='color:Red; font-weight:bold;'>*</span>";
        //imagetagNewFiles = " " + imagetagNewFiles + "<FONT COLOR=\"#ff0000\">" + "<span style='color:Red; font-weight:bold;'>*</span>(" + NewFiles + ")" + "</FONT>";

    }

    var html = "<table width='100%'><tr style=\"line-height:40px;\" id='" + folderId + "'><td width=40%>" + imagetag
            + "<img src='/_layouts/15/XSP/images/folder.png'/>" + folder + "(" + filecount + ")" + imagetagNewFiles + "</td>";
    html = html + "</tr></table><div id='" + folderId + "' style='display:none;width:100%'></div>";
    return html;
}

function DownloadAllNewFiles() {
    DownloadAllFiles();
}

function DownloadSelectedFiles() {
   
    var FolderNames = "";// = "Guid1,Guid2,Guid3";
    var fileid = [];   
    var FileNames = "";
   
    var data = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
    if (data.length == 0) {
        ShowCustomAlert("No item selected.", "Alert", 200);
        return;
    }

    for (var i = 0; i < data.length; i++) {
        FileNames = FileNames + data[i].DATA_FILE_LNM + ",";
        FolderNames = FolderNames + data[i].DT_RowId + ",";
        fileid.push(data[i].DATA_FILE_GUID);
    }
    FileNames = FileNames.substring(0, FileNames.lastIndexOf(","));
    FolderNames = FolderNames.substring(0, FolderNames.lastIndexOf(","));

    DownloadSelectedAndLogAudit(FolderNames, WellGuid, fileid, machine, FileNames, WellDetails[0].CO_NM, WellDetails[0].FLD_NM, WellDetails[0].WELL_NM);
    return false;
}


function DistributeSelectedFiles() {

    var data = [];
    data = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();

    if (data.length == 0) {
        ShowCustomAlert("Please select file(s).","Alert", 250);
        return;
    }
    DistributeData(data);
    return false;
}


function AddNewWellItem(folderId, folder, NumberofFiles, NewFiles, files,folderIndex) {
    var table = $("#container");

    var row = $(table).find("tr[id='" + folderId + "']");
    if (files==null) {
        $(table).append(getHeaderRowItem(folderId, folder, NumberofFiles, NewFiles));
    }
    else {      
        var newfilesGridSettings = jQuery.extend(true, {}, filesGridSettings);
        if (files.length > 0) {
            var gridId  = folderId + "_grid";
            newfilesGridSettings.GridId = gridId;
            $("div[id='" + folderId + "']").html("<table id='" + gridId + "' class='display compact' width='100%' cellspacing='0'></table>");
			//if folderIndex (FLDR_INDX) is not null then that folder is entitle can download 
			//otherwise grid is only viewable
			if(folderIndex==null || folderIndex=="" ){
				newfilesGridSettings.RowSelectionStyle="None";
				$("#" + gridId).addClass('nonEntitled');
			}
			else{
				newfilesGridSettings.RowSelectionStyle="Checkbox";
			}
            $("#" + newfilesGridSettings.GridId + ".display").renderGrid(newfilesGridSettings, files);
        }
    }
}

function renderFileColom(data, type, full, meta) {
    if ((full.FLDR_INDX == null || full.FLDR_INDX == "") && USERROLE == USERROLE_TYPE.InternalUser) {
        return RenderDeniedFiles(data);
    }
    else
        return data;
}

function GenerateWellDownloadFormattedSize(data, type, full, meta) {
    if ((full.FLDR_INDX == null || full.FLDR_INDX == "") && USERROLE == USERROLE_TYPE.InternalUser ) {
        return RenderDeniedFiles(round(full.FILE_SZ_VAL, 2));
    }
    else {
        return round(full.FILE_SZ_VAL, 2);
    }
}

    function renderComment(data, type, full, meta) {
            var gid = meta.settings.sTableId;
            gridSettings = globalGridSettings[gid];

            return "<div class='ellipsis' style='width: 50px; padding-left:5px;' title=' " + data + "'>" + renderFileColom(data, type, full, meta) + "</div><img src='../images/comment_32x32.png' style='cursor:pointer; float:right;height:16px;width:16px;' onclick='openCommentDialog(event, this,\"" + gridSettings.GridId + "\");'/>";
    }

    function RenderDeniedFiles(data) {
    return "<font color=\"#888888\">" +data + "</font>"
    }
    function renderDownloadNewFile(data, type, full, meta) {
        if ((full.FLDR_INDX == null || full.FLDR_INDX == "") && USERROLE == USERROLE_TYPE.InternalUser) {
            if (full.NEW_FILE == 1) {
                //return RenderDeniedFiles(data) + " " + "<span style='color:Red; font-weight:bold;'>*</span>";
                return RenderDeniedFiles(data) + " " + "<img src='/_layouts/15/XSP/images/redAsterisk.png' class='newFile' width=8px height=8px style='border:0'/>";
        }
        else
            return RenderDeniedFiles(data);
        }
    if (full.NEW_FILE == 1) {
            return renderNewFile(data, type, full, meta);
    }

   return GetFileDownloadlink(full.DATA_FILE_GUID, data, full);
   }
   function renderNewFile(data, type, full, meta) {
       //return GetFileDownloadlink(full.DATA_FILE_GUID, data, full) + " " + "<span style='color:Red; font-weight:bold;'>*</span>";
       return GetFileDownloadlink(full.DATA_FILE_GUID, data, full) + " " + "<img src='/_layouts/15/XSP/images/redAsterisk.png' class='newFile' width=8px height=8px style='border:0'/>";
       }
function RenameFile(gridid) {   
    selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
    if (selectedFiles.length == 1) {
		var files=$.trim(selectedFiles[0].DATA_FILE_LNM);
		if(selectedFiles[0].DATA_FILE_LNM.lastIndexOf('.')>0){
		files=$.trim(selectedFiles[0].DATA_FILE_LNM.substring(0,selectedFiles[0].DATA_FILE_LNM.lastIndexOf('.')));        
		fileExtension=$.trim(selectedFiles[0].DATA_FILE_LNM.substring(selectedFiles[0].DATA_FILE_LNM.lastIndexOf('.'),selectedFiles[0].DATA_FILE_LNM.length));	
		}	
		else
			fileExtension="";
        $("#fileName").val(files);
        $("#divRename").dialog('open');
    }
    else if (selectedFiles.length > 1) {
        ShowMultipleFileMessage();
    }
    else {
        $("#alert").html("Please select a file to rename.").dialog('open');
        return;
    }
}
var selectedFiles = [];
    function MoveFile(gridid) {
        selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
        if (selectedFiles.length > 1) {
            var WellGuids = groupBy(selectedFiles, 'WB_JOB_GUID');
            if (WellGuids.length > 1) {
            $("#alert").html("Action is allowed for same Well only.").dialog('open');
                return;
    }
    }

    if (selectedFiles.length >0) {
    $("#WellName").val(WellDetails[0].WELL_NM);
    $("#divFileMove").dialog('open');
    }
    else {
        $("#alert").html("Please select file(s) to move.").dialog('open');
            return;
    }
    }

    function RefreshWellFiles()
    {
        $("#container").html("");
        GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);
    }

    function DeleteFile(gridid) {
        selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();
        var Filenames = "<br/>";
        var FileGuids = "";

        if (selectedFiles.length > 0) {
            for (var i = 0 ; i < selectedFiles.length; i++) {
                Filenames = Filenames + selectedFiles[i].DATA_FILE_LNM + "<br/>";
                if (i == selectedFiles.length - 1) {
                    FileGuids = FileGuids + selectedFiles[i].DATA_FILE_UPL_GUID;
                }
                else {
                    FileGuids = FileGuids + selectedFiles[i].DATA_FILE_UPL_GUID + ",";
                }
            }
            $("#fileidlist").val(FileGuids);

            var y = document.getElementById("fileNamelist");
            y.innerHTML = Filenames;
            $("#divDelete").dialog('open');
        }
        else {
            $("#alert").html("Please select file(s) to delete.").dialog('open');
            return;
        }
    }

    function ShowMultipleFileMessage() {
        $("#alert").html("Action is allowed for single file selection only. Please select single file and try again.").dialog('open');
        }
        function EditComments(sourceGridID) {
            selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();

            if (selectedFiles.length == 1) {
                $("#fileGuid").val(selectedFiles[0].DATA_FILE_GUID);
                $("#TextComments").val(selectedFiles[0].DATA_FILE_CMNT);
                $("#divComments").dialog('open');
            }
    else if (selectedFiles.length > 1) {
        ShowMultipleFileMessage();
    }
    else {
        $("#alert").html("Please select a file.").dialog('open');
                return;
    }

    }
    function EditStatusDialog(sourceGridID) {
        selectedFiles = $($.fn.dataTable.tables(false)).DataTable().rows(".selected").data();

        if (selectedFiles.length == 1) {
            $("#fileStatusGuid").val(selectedFiles[0].DATA_FILE_GUID);
            currentStatus = selectedFiles[0].FILE_STAT_CD;
            $("#divFileStatus").dialog('open');
        }
    else if (selectedFiles.length > 1) {
        //ShowMultipleFileMessage();
		currentStatus="";
        $("#divFileStatus").dialog('open');
    }
    else if  (selectedFiles.length == 0) {
        $("#alert").html("Please select a file.").dialog('open');
            return;
}
}


    function DeleteSOData(data) {
        if (data.length > 0) {
            var soGUIDS = '';
            for (var i = 0; i < data.length; i++) {
                if (i == data.length - 1)
                    soGUIDS = soGUIDS + data[i].WELL_SLORD_GUID;
                else
                    soGUIDS = soGUIDS + data[i].WELL_SLORD_GUID + ",";
            }

            var param = "WellSOGuidList='" + soGUIDS + "'%26Separator=','"
            GetXSpaceData(param, "DeleteWellSONumbers_SP", undefined);
        }
    }

    function SetDirtyFilter() {
        IsDirty = true;
        $("#save").attr("src", "../images/save_dirty_24x24.png");
}



    function validate() {
        return ValidateWellDetails();
    }

    function SaveSOData() {
        var data;
        var filteredData = [];

        if ($.fn.dataTable.isDataTable("#" + soGridSettings.GridId)) {
            data = $("#" + soGridSettings.GridId).DataTable().rows().data();
            for (var i = 0; i < data.length; i++) {
                if (typeof (data[i].WELL_SLORD_GUID) == "undefined") {
                    filteredData.push(data[i]);
                }
            }
        }
        if (filteredData.length > 0) {
            for (var i = 0; i < filteredData.length; i++) {
                var param = "WBJobGuid='" + qs("WBGuid") + Sep() + "SONumber='" + filteredData[i].SLORD_NUM + "'";
                GetXSpaceData(param, "InsertWellSONumber_SP", function (data) {
                    if (i == filteredData.length - 1)
                        saveWellGroupData();
                });
            }
        }
        else {
            saveWellGroupData();
        }
    }

    function saveWellGroupData() {
        if ($.fn.dataTable.isDataTable("#" +groupsGridSettings.GridId)) {
            var groupData = $("#" +groupsGridSettings.GridId).DataTable().rows().data();
            var filteredData =[];
            for (var i = 0; i < groupData.length; i++) {
            if (typeof (groupData[i].Action) != "undefined") {
                filteredData.push(groupData[i]);
            }
    }
    if (filteredData.length > 0) {
            for (var i = 0; i < filteredData.length; i++) {
                var param = "WBJobGuid='" +qs("WBGuid") + Sep() + "GroupGuid='" +filteredData[i].USR_GRP_GUID + Sep() + "FolderIDList='" +filteredData[i].FLDR_TYP_ID + "'%26Separator=','";
                GetXSpaceData(param, "UpdateWellUserGroups_SP", function (data) {
                    if (i == filteredData.length -1)
                        dataSaved();
            });
    }
    }
    else {
        dataSaved();
    }
    }
    else {
            dataSaved();
    }
    }

    function dataSaved() {
        ShowCustomAlert("Admin Well details saved successfully.", "Alert", 300);
        IsDirty = false;
        $("#save").attr("src", "../images/save_32x32.png");
        reloadFiles();
    }
    function reloadFiles(){
	 $("#container").html("");
     GetWellFoldersByUserID(GetUrlParameter("WBGuid"), USERID, GetWellData);
}

