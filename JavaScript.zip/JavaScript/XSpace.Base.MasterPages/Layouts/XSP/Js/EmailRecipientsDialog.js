﻿
function OpenEmailRecipientsDialog(sourceGridID, callback) {
 $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 130,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
				$("#txtGroupName").focus();
            }
        }
    });
    $("#emailRecipientsDialog").dialog({
        autoOpen: false,
        modal: true,
        title: "Add Email Recipients",
        height: 250,
        width: 500,
        open: function () {
            $("#fName").val("");
            $("#lName").val("");
            $("#email").val("");
            $("#CName").val("");
        },
        close: function (event, ui) {
            $("#fName").val("");
            $("#lName").val("");
            $("#email").val("");
            $("#CName").val("");
        },
        buttons: {
            "OK": function () {
                if ($.trim($("#fName").val()) == "") {
                    $("#alert").html("Please enter first name.").dialog('open');
                    return false;
                }
                var email = $.trim($("#email").val());
                if (email == "") {
                    $("#alert").html("Please enter email.").dialog('open');
                    return false;
                }
                var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

                if (!regex.test(email)) {
                    $("#alert").html("Invalid email.").dialog('open');
                    return false;
                }
                if ($.trim($("#CName").val()) == "") {
                    $("#alert").html("Please enter company name.").dialog('open');
                    return false;
                }
                var item = new Object();
                item.USR_FIR_NM = $("#fName").val();
                item.USR_LST_NM = $("#lName").val();
                item.USR_NM = $("#fName").val() + " " + $("#lName").val();
                item.EMAIL_ADDR_DESC = $("#email").val();
                item.CO_NM = $("#CName").val();
                item.EXTNL_RCPT_GUID = null;

                callback(sourceGridID, item);
               // SetDirtyFilter();
               //$('#' + sourceGridID).DataTable().row.add(item).draw(false);
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });

    $("#emailRecipientsDialog").dialog("open");


}

