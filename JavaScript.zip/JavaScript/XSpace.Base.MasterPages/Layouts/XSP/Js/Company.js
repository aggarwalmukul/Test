﻿var IsDirty = false;
$(document).ready(function () {
	GetUserGuid(function(data){
		 var GetUserGUID = data;   
		var userRole = GetUserGUID[0].ROLE_CD;
		if(userRole == USERROLE_TYPE.CustomerUser || userRole == USERROLE_TYPE.CustomerAdministrator || userRole == USERROLE_TYPE.InternalUser){
		window.location.href = "/_layouts/15/XSP/Pages/Home.aspx";		
	}
	else {
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 300,
        buttons: {
            "Yes": function () {
                //write code to delete				
                var data = $("#" + companyGridSettings.GridId).DataTable().rows(".selected").data();
                DeleteCompanyData(data);
                var table = $("#" + companyGridSettings.GridId).DataTable();
                if (table.row('.selected').length > 0) {
                    table.row('.selected').remove().draw(false);
                }

                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dialog-companydetails").dialog({
        autoOpen: false,
        modal: true,
        title: "Add Company",
        height: 320,
        width: 800,
        open: function () {
            $('#txtPhone').mask("000-000-0000", { placeholder: "___-___-____" });
            $('#txtZip').mask("00000", { placeholder: "_____" });
            loadCoutries();
            $(document).on("change", "#ddlCountry", function () {
                if ($(this).val() != "")
                    loadStates();
                else
                    $("#ddlState").find('option').remove();
            });
            $(document).on("keyup blur", "input", function () {
                var yourInput = $(this).val();
                re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
                var isSplChar = re.test(yourInput);
                if (isSplChar) {
                    var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
                    $(this).val(no_spl_char);
                }
            });
        },
        buttons: {
            "OK": function () {
                if ($.trim($("#txtCompany").val()) == "")
                {
                    $("#alert").html("Please enter company name.").dialog('open');
                    return;
                }

                saveCompanyDetails();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 150,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    populateCompanies();
    if ($("#clearFilter").length > 0)
        $("#clearFilter")[0].onclick = null;
    if ($("#DeleteCompany").length > 0)
        $("#DeleteCompany")[0].onclick = null;
    if ($("#AddCompany").length > 0)
        $("#AddCompany")[0].onclick = null;
    
    $("input").on("keyup", function () {
        if (!$(this).hasClass("edit")) {
            IsDirty = true;
            $("#clearFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
            return false;
        }
    });

    $("#clearFilter").on("click", function () {
        clearFilter();
    });   
    $("#DeleteCompany").on("click", function () {
        DeleteCompany();
    });
    $("#AddCompany").on("click", function () {
        AddCompany();
    });
    $("input").val("");
	}
});
});
function AddCompany() {
    $("#dialog-companydetails").dialog('open');
}
function clearFilter() {
    IsDirty = false;
    $("input").val("");
    $("#clearFilter").attr("src", "../images/clear_filter_32x32.png");
    if ($.fn.dataTable.isDataTable("#" + companyGridSettings.GridId)) {
        var oTable1 = $("#" + companyGridSettings.GridId).dataTable();
        $("#" + companyGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    populateCompanies();
}

function populateCompanies() {
      GetXSpaceData("", companyGridSettings.DataSource, function (data) {
         $("#" + companyGridSettings.GridId).renderGrid(companyGridSettings, data);
     });
}

function editCompany(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?CompanyID=" + full.CO_ID + "\">" + full.CO_NM + "</a>";
}

function editPSL(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?tab=P&CompanyID=" + full.CO_ID + "\">" + full.PSL_CNT + "</a>";
}

function editUsers(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?tab=U&CompanyID=" + full.CO_ID + "\">" + full.USR_CNT + "</a>";
}

function editGroups(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?tab=G&CompanyID=" + full.CO_ID + "\">" + full.GRP_CNT + "</a>";
}

function editWells(data, type, full, meta) {
    return "<a class='edithref' href=\"/_layouts/15/XSP/Pages/EditCompany.aspx?tab=W&CompanyID=" + full.CO_ID + "\">" + full.WELL_CNT + "</a>";
}

function DeleteCompany() {
    if ($("#" + companyGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#confirm").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#alert").html("Please select a company to delete.").dialog('open');
    }
}

function DeleteCompanyData(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var param = "CompanyID='" + data[i].CO_ID + Sep();
            GetXSpaceData(param, "DeleteCompany_SP", undefined);
        }
    }
}

function loadCoutries() {
    GetXSpaceData("", "GetCountryList_SP", function (data) {
        var select = $("#ddlCountry")[0];
        var option = new Option();
        option.value = "";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CNTRY_ID;
            option.text = data[i].CNTRY_NM;
            select.options.add(option);
        }     
       
    });
}

function loadStates() {
    var param = "CntryID='" + $("#ddlCountry").val() + "'";
    GetXSpaceData(param, "GetStateList_SP", function (data) {
        $("#ddlState").find('option').remove();
        if (data.length > 0) {
            var select = $("#ddlState")[0];
            var option = new Option();
            option.value = "";
            option.text = "";
            select.options.add(option);
            for (var i = 0; i < data.length; i++) {
                option = new Option();
                option.value = data[i].GEO_LVL1_ID;
                option.text = data[i].GEO_LVL1_NM;
                select.options.add(option);
            }
        }
    });
}


function saveCompanyDetails() {
    GetXSpaceData(getInsertParams(), "InsertCompanyDetails_SP", function (data) {
        window.location.href = "/_layouts/XSP/Pages/EditCompany.aspx?CompanyID=" + data[0].CO_ID;
    });
}

function getInsertParams() {
  
    var param = "CompanyName='" + $("#txtCompany").val() + "'";
    if ($("#txtAddress").val() != "")
        param = param + "%26Address1='" + $("#txtAddress").val() + "'";
    if ($("#txtPhone").val() != "")
        param = param + "%26Phone='" + $("#txtPhone").val() + "'";
    if ($("#txtCity").val() != "")
        param = param + "%26City='" + $("#txtCity").val() + "'";
    if ($("#txtZip").val() != "")
        param = param + "%26Zip='" + $("#txtZip").val() + "'";
    if ($("#ddlCountry").val() != "")
        param = param + "%26CntryID='" + $("#ddlCountry").val() + "'";
    if ($("#ddlState").val() != "" && $("#ddlState").val() != null)
        param = param + "%26StateID='" + $("#ddlState").val() + "'";
    if ($("#Consulting")[0].checked == true)
        param = param + "%26Type='CNSLTNG'";
    if ($("#Operating")[0].checked == true)
        param = param + "%26Type='OPRTNG'";

    //if (typeof (qs("UserID")) == "undefined")
    //    param = "UserID='" + document.getElementById('userID').value + "'";
    //else
    //    param = "UserID='" + qs("UserID") + "'";
   
    return param;
  
}

$(window).keypress(function (e) {
    if (e.keyCode == 13) {
        searchFilter();
        return false;
    }
});