﻿var distType = "";
$(document).ready(function () {
	   //$("input[type='radio'][name='distributionType']").on("change", function () {
	$("input[type='radio']").click(function () {
		var value = $(this).val();
		switch (this.id) {
			case "rdWell":
				$("#div_WellName").css("display", "");
				$("#txt_WellName").css("display", "");
				$("#imgSearchWell").css("display", "");

				$("#dv_District").css("display", "none");
				$("#ddl_District").css("display", "none");
				distType = "W";
				break;
			case "rdDistrict":
				$("#dv_District").css("display", "");
				$("#ddl_District").css("display", "");

				$("#div_WellName").css("display", "none");
				$("#txt_WellName").css("display", "none");
				$("#imgSearchWell").css("display", "none");
				distType = "D";
				break;
			case "rdPersonal":
				$("#dv_District").css("display", "none");
				$("#ddl_District").css("display", "none");

				$("#div_WellName").css("display", "none");
				$("#txt_WellName").css("display", "none");
				$("#imgSearchWell").css("display", "none");
				distType = "P";
				break;
		}
	});
if(USERROLE ==  USERROLE_TYPE.InternalUser){
		 $("#tblSelectHeader tr").first().hide();
		 $("#rdDistrict").prop("checked","true");
	}
if(USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.CustomerAdministrator){
		 $("#tblSelectHeader tr").first().hide();
		 $($("#tblSelectHeader tr")[1]).hide();
		 $("#rdPersonal").prop("checked","true");
}
	$("#imgSearchWell").on("click", function () {
	   // ShowCustomAlert("Well LookUp opening....");
		OpenWellDialog(SetSelectedWell);       
});

});

function SetSelectedWell(arrWells) {
	$("#txt_WellName").val(arrWells[0].WELL_NM);
	$("#txt_WellGuid").val(arrWells[0].WB_JOB_GUID);
	
}
var isSaveAs = false;
var saveParam;
function SetSaveAs() {
	isSaveAs = true;
}
function OpenSaveAsDLDialog(distrbutionType, callback) {
	$("#saveAsConfirm").dialog({
		autoOpen: false,
		modal: true,
		title: "Confirm",
		height: 140,
		width: 350,
		buttons: {
		    "Yes": function () {
		        var param = "WBJobGuid='" + $("#txt_WellGuid").val() + Sep() + "PslID='" + $("#ddl_PSL option:selected").val() + "'";
		        GetXSpaceData(param, "GetDistributionListByWBJobPslID_SP", function (data) {
		            //param = "ListName='" + $("#txt_dlName").val() + Sep() + "ListGuid='" +  data[0].DSTBN_LIST_GUID +"'";                    
		            //GetXSpaceData(param, "UpdateDistributionList_SP", undefined);
		            param = "UserID='" + USERID + Sep() + "ListGuid='" + data[0].DSTBN_LIST_GUID + "'";
		            // Updation involves a lot of cases. So we can create a fresh one.
		            GetXSpaceData(param, "DeleteDistributionList_SP", undefined);
		        });

		        $(document).trigger("saveAsEvent_DL", saveParam);			
				$(this).dialog('close');                
			},
			"No": function () {
				$(this).dialog('close');
			}
		}
	});
	$("#dialog-saveasdistributiongroup").dialog({
		autoOpen: false,
		height: 400,
		width: 450,
		modal: true,
		resizable: false,
		draggable: false,
		close: function (event, ui) {

		},
		open: function (event, ui) {
			$(document).on("keypress blur", "input", function () {
				if (!$(this).hasClass("exclude"))
					removeSpecialChar($(this));
			});
			if(USERROLE ==  USERROLE_TYPE.InternalUser && distrbutionType=="W"){
				distrbutionType="D";
			}
			if (distrbutionType == "W") {
				$("#rdWell").prop("checked", true);
				$("#rdWell").click();
			}
			else if (distrbutionType == "D") {
				$("#rdDistrict").prop("checked", true);
				$("#rdDistrict").click();
			}
			else {
				$("#rdPersonal").prop("checked", true);
				$("#rdPersonal").click();
			}
		},
		buttons: {
			"OK": function () {
				var sdistrict = "";
				var wellName = "";
				var sPSL = $("#ddl_PSL option:selected").val();
				distrbutionType = "P";
				////validation               
				var dlName = $.trim($("#txt_dlName").val());
				if (dlName == "") {
					ShowCustomAlert("Please enter Distribution List name.","Alert", 300)
					return false;
				}                

				if (distType == "W") {
					distrbutionType = "W";
					wellName = $.trim($("#txt_WellName").val());
					if (wellName == "") {
						ShowCustomAlert("Please select Well.","Alert", 300);
						return false;
					}
				}

				if (distType == "D") {
					distrbutionType = "D";
					sdistrict = $("#ddl_District option:selected").val();
				}

				if (distType == "P") {
					distrbutionType = "P";

				}
				var guid;
				if (distType == "D")
				    guid = sdistrict;
				if (distType == "W")
				    guid = $("#txt_WellGuid").val();
				isDistributionListNameAlreadyExist(distType, dlName, guid, function (data) {
					if (data) {
						ShowCustomAlert("Distribution List name already exist. Please choose another name.", "Alert", 300);
						return false;
					}
					GetXSpaceData("", "GetWellDistributionList_SP", function (data) {
					    if (!isSaveAs) {
					        if (distType == "W") {
					            for (var i = 0; i < data.length; i++) {
					                if (data[i].WB_JOB_GUID == $("#txt_WellGuid").val() && $("#ddl_PSL").val() == data[i].PSL_ID) {
					                    ShowCustomAlert("Distribution list already exists for selected Well and PSL.", "Alert", 410);
					                    return false;
					                }
					            }
					            $(document).trigger("saveAsEvent_DL", [distrbutionType, dlName, wellName, sdistrict, sPSL, $("#txt_WellGuid").val()]);
					        }
							else
								$(document).trigger("saveAsEvent_DL", [distrbutionType, dlName, wellName, sdistrict, sPSL, $("#txt_WellGuid").val()]);
						}
						else {
					        saveParam = [distrbutionType, dlName, wellName, sdistrict, sPSL, $("#txt_WellGuid").val()];
					        if (distType == "W") {
					            for (var i = 0; i < data.length; i++) {
					                if (data[i].WB_JOB_GUID == $("#txt_WellGuid").val() && $("#ddl_PSL").val() == data[i].PSL_ID) {
					                    $("#saveAsConfirm").html("Distribution list already exists for selected Well and PSL. Do you want to override?").dialog('open');
					                    return false;
					                }
					            }
					            $(document).trigger("saveAsEvent_DL", saveParam);
					        }
					        else
					            $(document).trigger("saveAsEvent_DL", saveParam);
						}
					});
					
				});
			   
			},
			"Cancel": function () {
				$(this).dialog("close");
			}
		}
	});

	GetAllDistricts(UpdateDistricts);
	GetXSpaceData("", "GetPSL_SP", UpdatePslDropDown);
	$("#dialog-saveasdistributiongroup").dialog('open');
}

function UpdatePslDropDown(data)
{
	var PSLs = data;
	var select = document.getElementById("ddl_PSL");
	for (var i = 0; i < PSLs.length; i++) {
		var option = document.createElement('option');
		option.text = PSLs[i].PSL_NM;
		option.value = PSLs[i].PSL_ID;
		select.add(option, 0);
	}
	SortOptions("#ddl_PSL");
	select.selectedIndex = 0;
}

function UpdateDistricts(data) {
	//var districts = JSON.parse(data.GetDistrict_SP);
	var districts = data;
	var select = document.getElementById("ddl_District");
	for (var i = 0; i < districts.length; i++) {
		var option = document.createElement('option');
		option.text = districts[i].DIST_NM;
		option.value = districts[i].DIST_GUID;
		select.add(option, 0);
	}
	SortOptions("#ddl_District");
	select.selectedIndex = 0;
}
