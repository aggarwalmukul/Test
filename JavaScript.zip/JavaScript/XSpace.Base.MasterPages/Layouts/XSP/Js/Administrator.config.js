﻿var systemAdminGridSettings = {
    GridId: "systemAdminGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,    
    Paging: false,
    DataSource: "GetAdminSystemList_SP",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        DataIndex: 1,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        renderAction: "mailTo",
                        DataIndex: 2,
                        Width: "35%",
                        IsFilterable: true,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Add",
            Action: "AddSystemUsers",
            Icon: "add_32x32.png",
            Text: "Add System User",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveSystemUsers",
            Icon: "delete_32x32.png",
            Text: "Delete System User",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearSystemFilter",
            Action: "clearSystemFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};


var regionalSuperAdminGridSettings = {
    GridId: "regionalSuperAdminGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,    
    Paging: false,
    DataSource: "GetAdminRegionSuperList_SP",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        renderAction: "editUser",
                        DataIndex: 1,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        renderAction: "mailTo",
                        DataIndex: 2,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Regions ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "RGN_NM_LIST",
                        DataIndex: 3,
                        Width: "19%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Countries ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM_LIST",
						renderAction: "editCountry",
                        DataIndex: 4,
                        Width: "19%",
                        IsFilterable: true,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Add",
            Action: "AddRegionalSuperAdmin",
            Icon: "add_32x32.png",
            Text: "Add Regional Super Admin",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveRegionalSuperAdmin",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearRegionalSFilter",
            Action: "clearRegionalSFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};


var regionalPSLAdminGridSettings = {
    GridId: "regionalPSLAdminGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,    
    Paging: false,
    DataSource: "GetAdminRegionPslList_SP",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        renderAction: "editUser",
                        DataIndex: 1,
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email Address ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        renderAction: "mailTo",
                        DataIndex: 2,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Regions ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "RGN_NM_LIST",
                        DataIndex: 3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Countries ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM_LIST",
						renderAction: "editCountry",
                        DataIndex: 4,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "PSLs ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM_LIST",
                        renderAction: "editPSLs",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Folders ",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLDR_CNT",
                        renderAction: "editFolder",
                        DataIndex: 6,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Add",
            Action: "AddRegionalPSLAdmin",
            Icon: "add_32x32.png",
            Text: "Add",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveRegionalPSLAdmin",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearRegionalPSLFilter",
            Action: "clearRegionalPSLFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};



