﻿var tID;
var deleteType;
var IsDirty = false;
var selectedtab;

$(document).ready(function () {
	GetUserGuid(GetUserGUIDDetails);
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 300,
        buttons: {
            "Yes": function () {
                //write code to delete
                if (deleteType == "Well")
                {
                    var data = $("#" + wellDLGridSettings.GridId).DataTable().rows(".selected").data();
                    DeleteDLData(data);
                    var table = $("#" + wellDLGridSettings.GridId).DataTable();
                    //var data = table.row('.selected').data();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                    

                    //write code to delete on server
                } else if (deleteType == "District") {
                    var data = $("#" + DistrictDLGridSettings.GridId).DataTable().rows(".selected").data();
                    DeleteDLData(data);
                    var table = $("#" + DistrictDLGridSettings.GridId).DataTable();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                    //var data = table.row('.selected').data();
                    
                    //write code to delete on server
                } else if (deleteType == "Perosnal") {
                    var data = $("#" + personalDLGridSettings.GridId).DataTable().rows(".selected").data();
                    DeleteDLData(data);
                    var table = $("#" + personalDLGridSettings.GridId).DataTable();
                    if (table.row('.selected').length > 0) {
                        table.row('.selected').remove().draw(false);
                    }
                    //var data = table.row('.selected').data();

                    //write code to delete on server
                }
                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });   
    
    selectedtab = qs("tab");
	if(USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.CustomerAdministrator){		
		selectedtab="P";		 
	 }
    if (selectedtab == null || selectedtab == "W") {
        GetXSpaceData("", wellDLGridSettings.DataSource, populateWellList);       
        $("#DLtabs").tabs({ active: 0 });
    }
    else if (selectedtab == "D") {
        GetXSpaceData("", DistrictDLGridSettings.DataSource, populateDistrictList);
        $("#DLtabs").tabs({ active: 1 });
    }
    else {
        var param = "UserID='" + USERID + "'";
        GetXSpaceData(param, personalDLGridSettings.DataSource, populatePersonalList);
        $("#DLtabs").tabs({ active: 2 });
    }
	
  performUserAction();    
    
  $("input").on("keyup", function () {
      if (!$(this).hasClass("edit")) {
          IsDirty = true;
          $("#clearFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
      }
        return false;
    });
    $("#DLtabs").tabs({
        activate: function (event, ui) {
            DestoryDataTableIfExists();
            if (ui.newPanel.is("#Welltab")) {
                $("#clearFilter").attr("src", "../images/clear_filter_32x32.png");
                GetXSpaceData("", wellDLGridSettings.DataSource, populateWellList);	
				selectedtab="W"	;		
				performUserAction();
            }
            else if (ui.newPanel.is("#Districttab")) {              
                GetXSpaceData("", DistrictDLGridSettings.DataSource, populateDistrictList);
                $("#clearDistrictFilter").attr("src", "../images/clear_filter_32x32.png");
                $("input").on("keyup", function () {
                    if (!$(this).hasClass("edit")) {
                        IsDirty = true;
                        $("#clearDistrictFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                        if ($("#clearDistrictFilter").length > 0)
                            $("#clearDistrictFilter")[0].onclick = null;
                    }
                    return false;
                });
                $("#clearDistrictFilter").on("click", function () {
                    clearDistrictFilter();
                });
				selectedtab="D"	;
				performUserAction();
            }
            else {
                var param = "UserID='" + USERID + "'";
                GetXSpaceData(param, personalDLGridSettings.DataSource, populatePersonalList);
                $("#clearPerosnalFilter").attr("src", "../images/clear_filter_32x32.png");
                $("input").on("keyup", function () {
                    if (!$(this).hasClass("edit")) {
                        IsDirty = true;
                        $("#clearPersonalFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                        if ($("#clearPersonalFilter").length > 0)
                            $("#clearPersonalFilter")[0].onclick = null;
                    }
                    return false;
                });
                $("#clearPersonalFilter").on("click", function () {
                    clearPersonalFilter();
                });
				selectedtab="P"	;
				performUserAction();
            }

            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });

    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
    
    
    $(document).on("saveAsEvent_DL", {}, function (event, distrbutionType, dlName, wellName, sdistrict, sPSL, wellguid) {
        window.location.href = "/_layouts/15/XSP/Pages/createDistributionList.aspx?type=" + distrbutionType + "&dl=" + dlName + "&well=" + wellName + "&dt=" + sdistrict + "&PSL=" + sPSL + "&Guid=" + wellguid;
    });
   // $("input").val("");
   $("input:not(:button)").val("");
})

function DeleteDLData(data)
{

    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {

            GetXSpaceData("ListGuid='" + data[i].DSTBN_LIST_GUID + "'", "DeleteDistributionList_SP", undefined);
        }
    }

}
function DeleteList(listIds)
{
    
    var data = $("#" + listIds).val().split("$");
    if( data.length > 0 )
    {
        for( var i=0; i < data.length; i++)
        {

            GetXSpaceData("ListGuid='" + data[i] + "'", "DeleteDistributionList_SP", undefined);
        }
    }
}
function DestoryDataTableIfExists() {
   // $("input").val("");
   $("input:not(:button)").val("");
    if ($.fn.dataTable.isDataTable("#" + wellDLGridSettings.GridId)) {
        var oTable1 = $("#" + wellDLGridSettings.GridId).dataTable();
        $("#" + wellDLGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }

    if ($.fn.dataTable.isDataTable("#" + DistrictDLGridSettings.GridId)) {
        var oTable2 = $("#" + DistrictDLGridSettings.GridId).dataTable();
        $("#" + DistrictDLGridSettings.GridId + "tbody").html("");
        oTable2.dataTable().fnDestroy();
    }

    if ($.fn.dataTable.isDataTable("#" + personalDLGridSettings.GridId)) {
        var oTable3 = $("#" + personalDLGridSettings.GridId).dataTable();
        $("#" + personalDLGridSettings.GridId + "tbody").html("");
        oTable3.dataTable().fnDestroy();
    }

}
function populateWellList(data) {
   
    $("#" + wellDLGridSettings.GridId).renderGrid(wellDLGridSettings, data);
}
function populateDistrictList(data) {
    
    $("#" + DistrictDLGridSettings.GridId).renderGrid(DistrictDLGridSettings, data);
}
function populatePersonalList(data) {   
    $("#" + personalDLGridSettings.GridId).renderGrid(personalDLGridSettings, data);
}
function editWellDL(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/createDistributionList.aspx?type=W&DLID=" + full.DSTBN_LIST_GUID + "'>" + full.DSTBN_LIST_NM + "</a>";
}
function editDistrictDL(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/createDistributionList.aspx?type=D&DLID=" + full.DSTBN_LIST_GUID + "'>" + full.DSTBN_LIST_NM + "</a>";
}
function editPersonalDL(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/createDistributionList.aspx?type=P&DLID=" + full.DSTBN_LIST_GUID + "'>" + full.DSTBN_LIST_NM + "</a>";
}
function AddWellDL()
{
    OpenSaveAsDLDialog("W");
 
}
function AddDistrictDL() {
    OpenSaveAsDLDialog("D");
 
}
function AddPersonalDL() {
    OpenSaveAsDLDialog("P");
 
}
function DeleteWellDL() {
    deleteType = "Well";
    var table = $("#" + wellDLGridSettings.GridId).DataTable();
    if (table.row('.selected')[0].length > 0) {      
    $("#confirm").html("Are you sure to delete well distribution list?").dialog('open');
}
    else {
        ShowCustomAlert("No item selected.");
    }
}
function DeleteDistrictDL() {
    deleteType = "District";
    var table = $("#" + DistrictDLGridSettings.GridId).DataTable();
    if (table.row('.selected')[0].length > 0) {
    $("#confirm").html("Are you sure to delete district distribution list?").dialog('open');
}
    else {
        ShowCustomAlert("No item selected.");
    }   
}
function DeletePersonalDL() {
    deleteType = "Perosnal";
    var table = $("#" + personalDLGridSettings.GridId).DataTable();
    if (table.row('.selected')[0].length > 0) {
    $("#confirm").html("Are you sure to delete personal distribution list?").dialog('open');
}
    else {
        ShowCustomAlert("No item selected.");
    }    
}
function openEdit(me) {
    window.location.href = "/_layouts/15/XSP/Pages/createDistributionList.aspx?DLID=" + me ;
}

    function clearWellFilter() {
        IsDirty = false;
        $("#clearFilter").attr("src", "../images/clear_filter_32x32.png");
        DestoryDataTableIfExists();
        GetXSpaceData("", wellDLGridSettings.DataSource, populateWellList);
    }
    function clearDistrictFilter() {
        IsDirty = false;
        $("#clearDistrictFilter").attr("src", "../images/clear_filter_32x32.png");
        DestoryDataTableIfExists();
        GetXSpaceData("", DistrictDLGridSettings.DataSource, populateDistrictList);

    }
    function clearPersonalFilter() {
        IsDirty = false;
        $("#clearPerosnalFilter").attr("src", "../images/clear_filter_32x32.png");
        DestoryDataTableIfExists();
        var param = "UserID='" + USERID + "'";
        GetXSpaceData(param, personalDLGridSettings.DataSource, populatePersonalList);
    }

    function qs(key) {
        return GetUrlParameter(key);
        //var vars = [], hash;
        //var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        //for (var i = 0; i < hashes.length; i++) {
        //    hash = hashes[i].split('=');
        //    vars.push(hash[0]);
        //    vars[hash[0]] = hash[1];
        //}
        //return vars[key];
    }

    function ShareDL(sourceGridID) {

        personnelsGridSettings.RowSelectionStyle = "Checkbox";
        personnelsGridSettings.RowSelectionType = "Multiple";
        allPersonnelsGridSettings.RowSelectionStyle = "Checkbox";
        allPersonnelsGridSettings.RowSelectionType = "Multiple";

        PopulateRecipients(sourceGridID);
        $("#dialog-personnel").dialog("open");
        
       
    }

    function SearchPersonal(sourceGridID) {

        personnelsGridSettings.RowSelectionStyle = "RadioButton";
        personnelsGridSettings.RowSelectionType = "Single";
        allPersonnelsGridSettings.RowSelectionStyle = "RadioButton";
        allPersonnelsGridSettings.RowSelectionType = "Single";

        PopulateRecipients(sourceGridID);
        $("#dialog-personnel").dialog("open");

    }

    function ShareSelectedPersonnel(arrPersonnels) {
        var personelDLData = $("#" + personalDLGridSettings.GridId).DataTable().rows('.selected').data();
        //// write code to share data on server....
    }

    function FilterSelectedPersonnel(arrPersonnels) {
        var personelName = arrPersonnels[0].USR_FIR_NM + " " + arrPersonnels[0].USR_LST_NM;
        var table = $("#" + personalDLGridSettings.GridId).DataTable();
        table.column(3).search(personelName);
        table.draw();

        IsDirty = true;
        $("#clearPersonalFilter").attr("src", "../images/clear_filter_dirty_24x24.png");       
    }

function SearchWell(sourceGridID) {
    OpenWellDialog(FilterSelectedWell);
}

function FilterSelectedWell(arrWell) {
    //selected well data 
    var wellName = arrWell[0].WELL_NM;
    var table = $("#" + wellDLGridSettings.GridId).DataTable();
    table.column(1).search(wellName);
    table.draw();

    IsDirty = true;
    $("#clearFilter").attr("src", "../images/clear_filter_dirty_24x24.png");   
}

function performUserAction(){
	
	if(USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.CustomerAdministrator){		
		 $($("#DLtabs").find("li")[0]).hide();		
		 $($("#DLtabs").find("li")[1]).hide();	 	
		 
	 }
	 if(USERROLE ==  USERROLE_TYPE.InternalUser && selectedtab=="W"){
		 $("#AddDL").hide();
		 $("#DeleteDL").hide();
	 }	
}