﻿var groupGridSettings = {
    GridId: "groupGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetUserGroupsByUserID_SP ",
    DataSourceParam: "",
    ColumnCollection: [{
        Name: "Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "USR_GRP_NM",
        renderAction: "editGroup",
        DataIndex: 0,
        Width: "15%",
        IsFilterable: true,
        IsSortable: true
    },

                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 1,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "# of Users",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "USR_CNT",
                        renderAction: "editUser",
                        DataIndex: 2,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "# of Entitlements",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "ENTLMNT_CNT",
                        renderAction: "editEnt",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearGroupFilter",
            Action: "clearGroupTabFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearGroupFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};

var EntitlementsGridSettings = {
    GridId: "EntitlementsGrid",
    RowSelectionStyle: "None",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc   
    Paging: false,
    IsScrollY: true,
    DataSource: "GetUserGroupEntitlementsByUserID_SP",
    DataSourceParam: "UserID",
    ColumnCollection: [
                    {
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        DataIndex: 0,
                        renderAction:"GenerateRenderWellName",
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 1,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FLD_NM",
                        DataIndex: 2,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Country",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex:3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "UWI/API",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "GOVT_ID_NUM",
                        DataIndex: 4,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "County",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTY_NM",
                        DataIndex: 5,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Last Edited Date",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "LST_UPDT_TMSTMP",
                        DataIndex: 6,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Entitled Folders",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,                        
                        data: "FLDR_TYP_NM",
                        DataIndex: 7,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [        
        {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearWellFilter",
            Action: "clearWellTabFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearWellFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};