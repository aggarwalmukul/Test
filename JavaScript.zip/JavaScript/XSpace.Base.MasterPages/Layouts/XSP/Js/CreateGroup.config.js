﻿var UsersGridSettings = {
	GridId: "UsersGrid",
	RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
	RowSelectionType: "Multiple", // Multiple , Single
	DefaultColumnSort: -1, // positive column index, if no sort -1
	DefaultColumnSortOrder: "asc", // asc/desc  
	DataSource: "GetUserGroupUsers_SP ",
	DataSourceParam: "GroupGuid",   
	Paging: false,
	IsScrollY: true,
	ColumnCollection: [					
					{
						Name: "Name",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "USR_NM",
						DataIndex: 0,
						Width: "50%",
						IsFilterable: true,
						IsSortable: true
					},
					{
						Name: "Email Address ",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "EMAIL_ADDR_DESC",
						DataIndex: 1,
						Width: "45%",
						IsFilterable: false,
						IsSortable: true
					}
	],
	FilterRow: {
		Visible: false,
		Enabled: true
	},
	ToolbarCollection: [{
		Name: "Filter",
		Visible: true,
		Enabled: true,
		ButtonCollection: [{
			Name: "AddUsers",
			Action: "AddGroupUser",
			Icon: "add_32x32.png",
			Text: "Add User",
			Appearance: "Icon", // (Text or Icon)
			Visible: true,
			Enabled: true
		},
		{
			Name: "RemoveUsers",
			Action: "RemoveGroupUsers",
			Icon: "delete_32x32.png",
			Text: "Remove User(s)",
			Appearance: "Icon", // (Text or Icon)
			Visible: true,
			Enabled: true
		}
		]
	}]
};

var EntitlementsGridSettings = {
	GridId: "EntitlementsGrid",
	RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
	RowSelectionType: "Multiple", // Multiple , Single
	DefaultColumnSort: -1, // positive column index, if no sort -1
	DefaultColumnSortOrder: "asc", // asc/desc 
	Paging: false,
	IsScrollY: true,
	DataSource: "GetUserGroupEntitlements_SP",
	DataSourceParam: "GroupGuid",
	ColumnCollection: [										
					{
						Name: "Well Name",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "WELL_NM",
						renderAction: "GenerateRenderWellName",
						DataIndex: 1,
						Width: "15%",
						IsFilterable: true,
						IsSortable: true
					},
					{
						Name: "Company",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "CO_NM",
						renderAction:"editCompany",

						DataIndex: 2,
						Width: "15%",
						IsFilterable: true,
						IsSortable: true
					},
					{
						Name: "Field",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "FLD_NM",
						DataIndex: 3,
						Width: "15%",
						IsFilterable: false,
						IsSortable: true
					},
					{
						Name: "UWI/API",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "GOVT_ID_NUM",
						DataIndex: 4,
						Width: "15%",
						IsFilterable: false,
						IsSortable: true
					},
					{
						Name: "Entitled Folders",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						renderAction: "editEntitelements",
						data: "FLDR_TYP_NM",
						DataIndex: 5,
						Width: "30%",
						IsFilterable: false,
						IsSortable: true
					}
	],
	FilterRow: {
		Visible: false,
		Enabled: true
	},
	ToolbarCollection: [{
		Name: "Filter",
		Visible: true,
		Enabled: true,
		ButtonCollection: [{
			Name: "openAddEntitlement",
			Action: "openAddEntitlements",
			Icon: "add_32x32.png",
			Text: "Add Entitlement",
			Appearance: "Icon", // (Text or Icon)
			Visible: true,
			Enabled: true
		},
		{
			Name: "RemoveEntitlements",
			Action: "RemoveEntitlements",
			Icon: "delete_32x32.png",
			Text: "Remove Entitlement(s)",
			Appearance: "Icon", // (Text or Icon)
			Visible: true,
			Enabled: true
		}
		]
	}]
};

var AvailableEntitlementsGridettings = {
	GridId: "AvailableEntitlementsGrid",
	RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
	RowSelectionType: "Multiple", // Multiple , Single
	DefaultColumnSort: -1, // positive column index, if no sort -1
	DefaultColumnSortOrder: "asc", // asc/desc
	IsScrollY: true,
	ScrollYHeight: "120px",
	Paging: false,
	ColumnCollection: [						
					{
						Name: "Available Entitlements",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "FLDR_TYP_NM",
						DataIndex: 1,
						Width: "90%",
						IsFilterable: false,
						IsSortable: true
					}
	],
	FilterRow: {
		Visible: false,
		Enabled: true
	},
	ToolbarCollection: []
};
var SelectedEntitlementsGridettings = {
	GridId: "SelectedEntitlementsGrid",
	RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
	RowSelectionType: "Multiple", // Multiple , Single
	DefaultColumnSort: -1, // positive column index, if no sort -1
	DefaultColumnSortOrder: "asc", // asc/desc
	IsScrollY: true,
	ScrollYHeight: "120px",
	Paging: false,
	ColumnCollection: [
					
					{
						Name: "Selected Entitlements",
						Visible: true,
						Enabled: true,
						DataType: "string",
						Style: "Text", // Text,Image,Action,URL
						CssClass: "cHeader lText",
						HeaderVisible: true,
						data: "FLDR_TYP_NM",
						DataIndex: 1,
						Width: "90%",
						IsFilterable: false,
						IsSortable: true
					}
	],
	FilterRow: {
		Visible: false,
		Enabled: true
	},
	ToolbarCollection: []
};