﻿$(document).ready(function () {
    //GetUserGuid(GetUserGUIDDetails);
    if (USERROLE == USERROLE_TYPE.CustomerUser || USERROLE == USERROLE_TYPE.InternalUser) {
        $("#nav_rootMenu li.rootMenu_activityLog").hide();
        $("#imgActivityLog").hide();
        $("#Activity").hide();
    }

        
        
    if (USERROLE == USERROLE_TYPE.CustomerUser) {      
        $("#home_nav li.home_nav_imgSO").hide();
        $("#ImgSO").hide();
        $("#uploadSO").hide();
    }

    populateActiveWellGrid();
    $(window).keypress(function (e) {
        if (e.keyCode == 13) {
            searchFilter();
            return false;
        }
    });
});
var activeWellData = [];
function DestoryDataTableIfExists() {   
    if ($.fn.dataTable.isDataTable("#" + activeWellGridSettings.GridId)) {
        var oTable1 = $("#" + activeWellGridSettings.GridId).dataTable();
        $("#" + activeWellGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}
var timeout;
function populateActiveWellGrid() {   
    var param = "UserID='" + document.getElementById('userID').value + "'";
    GetXSpaceData(param, activeWellGridSettings.DataSource, function (data) {
        activeWellData = data;
        bindActiveWellData();
         timeout = window.setTimeout(function () {
            $("#" + activeWellGridSettings.GridId).DataTable().columns.adjust();
            window.clearTimeout(timeout)}, 1000);
	  });   
}
function bindActiveWellData() {
    DestoryDataTableIfExists();
    $("#" + activeWellGridSettings.GridId).renderGrid(activeWellGridSettings, activeWellData);
}