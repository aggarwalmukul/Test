﻿
var userGridSettings = {
    GridId: "userGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetUsers_SP ",
    DataSourceParam: "",
    ColumnCollection: [{
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_NM",
                        renderAction: "editUser",
                        DataIndex: 1,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Email",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "EMAIL_ADDR_DESC",
                        renderAction: "mailTo",
                        DataIndex: 2,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Phone",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PHONE_NUM",
                        renderAction: "formatPhoneNumber",
                        DataIndex: 3,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "# of Groups",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "GRP_CNT",
                        renderAction: "groupAction",
                        DataIndex: 4,
                        Width: "20%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "DeleteUser",
            Action: "DeleteUser",
            Icon: "delete_32x32.png",
            Text: "DeleteUser",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearUserFilter",
            Action: "clearUserFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearUserFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};


var groupGridSettings = {
    GridId: "groupGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetUserGroupsByUserID_SP ",
    DataSourceParam: "",
    ColumnCollection: [{
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "USR_GRP_NM",
                        renderAction: "editGroup",
                        DataIndex: 1,
                        Width: "25%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "# of Users",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "USR_CNT",
                        renderAction: "editUserCount",
                        DataIndex: 2,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                    {
                        Name: "# of Entitlements",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader cText",
                        HeaderVisible: true,
                        data: "ENTLMNT_CNT",
                        renderAction: "editEnt",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Created By",
                         Visible: true,
                         Enabled: true,
                         DataType: "string",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CREAT_BY_USRID",
                         DataIndex: 4,
                         Width: "10%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                    {
                        Name: "Last Edited By",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "LST_UPDT_USRID",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Create Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "CREAT_TMSTMP",
                         DataIndex: 6,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     },
                     {
                         Name: "Last Edited Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 7,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     }

    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddGroup",
            Action: "AddGroup_Company",
            Icon: "create_32x32.png",
            Text: "AddGroup",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteGroup",
            Action: "DeleteGroup_Company",
            Icon: "delete_32x32.png",
            Text: "DeleteGroup",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearGroupFilter",
            Action: "clearGroupTabFilter",
            Icon: "clear_filter_32x32.png",
            Text: "clearGroupFilter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};

var AvailableCountriesGridSettings = {
    GridId: "AvailableCountriesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
    ColumnCollection: [
                    {
                        Name: "Available Countries",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var SelectedCountriesGridSettings = {
    GridId: "SelectedCountriesGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
    ColumnCollection: [

                    {
                        Name: "Selected Countries",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CNTRY_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var AvailablePSLsGridSettings = {
    GridId: "AvailablePSLsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
    ColumnCollection: [
                    {
                        Name: "Available PSLs",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};
var SelectedPSLsGridSettings = {
    GridId: "SelectedPSLsGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "200px",
    Paging: false,
    ColumnCollection: [

                    {
                        Name: "Selected PSLs",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 1,
                        Width: "90%",
                        IsFilterable: false,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};