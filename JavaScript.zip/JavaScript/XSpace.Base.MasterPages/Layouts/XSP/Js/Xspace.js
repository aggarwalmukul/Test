$(document).ready(function () {
    var index = sessionStorage.CurrentNav;// $.cookie('active-nav');
    if (typeof (index) != "undefined") {
        $('#nav').find('a').removeClass('active');
        $('#nav').find('li').removeClass('active');
        if (index != -1 && getPageName() != "ActivityLog") {
            $("#nav").find('a').eq(index).addClass('active');
            $("#nav").find('a').eq(index).parent().addClass('active');
        }
    }
    else {
        $("#nav").find('a').eq(0).addClass('active');
        $("#nav").find('a').eq(0).parent().addClass('active');
    }
    $('#nav').on('click', 'li a', function (e) {
        $('#nav').find('a').removeClass('active');
        $('#nav').find('li').removeClass('active');
        $(this).addClass('active');
        $(this).parent().addClass('active');
        //$.cookie('active-nav', $('#nav a').index(this), { expires: null });
        sessionStorage.CurrentNav = $('#nav a').index(this);
    });
    $('#nav_rootMenu').on('click', 'li a', function (e) {
        //$.cookie('active-nav', -1, { expires: null });
        sessionStorage.CurrentNav = -1;
    });
    $(".userToUserTransfer_clickable").on('click', function () {
        PopupCenter("UserToUserTransfer.aspx", "_blank", "1200", "550");
    });
});
function PopupCenter(pageURL, title, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2)-10;
    var targetWin = window.open(pageURL, title, 'scrollbars=no,toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    return targetWin;
}

function DivertToUploadPage(data)
{
    var wellguid = data;
    var SalesOrderNumber = $("#txtSONumber").val();
    if (wellguid.length > 0) {
        WellGUID = wellguid[0].WB_JOB_GUID;
        var wellname = wellguid[0].WELL_NM;
        var Operator = wellguid[0].CO_NM;
        var FieldName = wellguid[0].FLD_NM;
        var customWellName = Operator + " " + FieldName + " " + wellname;

        var w = PopupCenter("/_layouts/XSP/Pages/Upload.aspx?SO=" + SalesOrderNumber + "&WBGuid=" + WellGUID + "&WellName="
                + customWellName, '_blank', 1200, 450);
        
        //window.open("/_layouts/XSP/Pages/Upload.aspx?SO=" + SalesOrderNumber + "&WBGuid=" + WellGUID + "&WellName=" + wellname, '_blank', 'location=yes,resizable=yes,scrollbars=yes');
        $('#divSODialogBox').dialog('close');
    }
    else {
        ShowCustomAlert("No well found matching SO# " + SalesOrderNumber,"Alert",250);
    }

}

$(function () {
    $("#divSODialogBox").dialog({
        autoOpen: false,
        modal: true,
        title: "Upload Data Via Service Order Number",
        height: 150,
        width: 450,
        buttons: {
            "Submit": function () {               
                var SalesOrderNumber = $("#txtSONumber").val();
                StartUploadFromSOTicket(SalesOrderNumber, "GetWellBySO_SP", DivertToUploadPage);           
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });

    $(".activityLog_clickable").on('click', function () {
        window.location.href = "/_layouts/15/XSP/Pages/ActivityLog.aspx";
    });
    $(".uploadSO_clickable").on('click', function () {
        $("#divSODialogBox").dialog('open');
    });

    $("#btnCancelSoNumber").on('click', function () {        
        $('#divSODialogBox').dialog('close');
        return false;

    });

    $("#btnSONumber").on('click', function () {
        var SalesOrderNumber = $("#txtSONumber").val();
        StartUploadFromSOTicket(SalesOrderNumber, "GetWellBySO_SP", DivertToUploadPage);
         });
});

function ReturnColumnValuesBasedOnColumnTypeAndData(data, colType, row, ImageURL, RedirectURL) {
    if (colType === 'img') {
        return "<a href=" + RedirectURL + "><img src=" + ImageURL + "></a>"
        }
    else if (colType === 'anchor') {
        return "<a href=" + RedirectURL + " style='color:red;'>" + row[2] + "</a>";
    }
    else if (colType === 'checkbox') {
        return "<input type='checkbox' id='checkId'></input>";
    }
    else if (colType === 'radio') {
        return "<input type='radio' id='radioId'></input>" + row[3];
    }
}

//Remove the selected row...
function RemoveSelectedRows() {
    var table = $('#GridViewWebPart').DataTable();
    table.row('.selected').remove().draw(false);
    ShowCustomAlert("removed");
}

$(document).ready(function () {
    //Maxlength for textarea using jQuery
    var maxLength = parseInt($('textarea[maxlength]').attr('maxlength'));
    if ($("#commentCharCount").length == 0) {
        $('textarea[maxlength]').after("<div style='float:right;font-size:.7em;' id='commentCharCount'><span id='remainingLengthTempId'>"
                             + maxLength + "</span> characters remaining</div>");
    }

    $('textarea[maxlength]').bind("keyup change input paste", function () {
        currentLengthInTextarea = $(this).val().length;
        $(remainingLengthTempId).text(parseInt(maxLength) - parseInt(currentLengthInTextarea));
        if (currentLengthInTextarea > (maxLength)) {
            // Trim the field current length over the maxlength.
            $(this).val($(this).val().slice(0, maxLength));
            $(remainingLengthTempId).text(0);
        }
    });
});

/// Custom alert using jquery UI modal box
function ShowCustomAlert(output_msg, title_msg,width) {
    if (!title_msg)
        title_msg = 'Alert';

    if (!output_msg)
        output_msg = 'No Message to Display.';
    if (!width)
        width = 120;
    $("<div></div>").html(output_msg).dialog({
        title: title_msg,
        resizable: false,
        modal: true,
        height: 140,
        width: width,
        buttons: {
            "OK": function () {
                $(this).dialog("close");
            }
        }
    });
}

function getPageName() {
    var index = window.location.href.lastIndexOf("/") + 1,
        filenameWithExtension = window.location.href.substr(index),
        filename = filenameWithExtension.split(".")[0];

    return filename;
}
function qs(key) {
    return GetUrlParameter(key);
}
function maskValue(value) {
    if (value != "" && value != null && value.indexOf("-") == -1)
        return value.substr(0, 3) + "-" + value.substr(3, 3) + "-" + value.substr(6, 4);
    else
        return value;
}