﻿var IsDirty = false;
var editUserID;
var editUserName;
var adminType;
$(document).ready(function () {
    
    $("#save").on("click", function () {        
        saveEditorData();
    });

    if (qs("type") == "sup") {
         populateCountryTab();
    }
	editUserID=qs("ID");	
	editUserName=qs("UName");	
	populateCountryTab();
    populatePSLTab();
    populateFolderTab();

    $("#adminEditortabs").tabs({
        beforeLoad: function (event, ui) {
            ui.newPanel.text('Retrieving data...');
        },
        activate: function (event, ui) {
            if (ui.newPanel.is("#countriestab")) {
                //$("#AvailableCountriesGrid_info").hide();
                //$("#SelectedCountriesGrid_info").hide();
                $("#AvailableCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
                $("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
            }             
            else if (ui.newPanel.is("#PSLtab")) {
               // $("#AvailablePSLsGrid_info").hide();
               // $("#SelectedPSLsGrid_info").hide();
                $("#AvailablePSLsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
                $("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
                
            }
            else { ///Folder tab
                //$("#AvailableFolderGrid_info").hide();
                //$("#SelectedFolderGrid_info").hide();
                $("#AvailableFolderGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
                $("#SelectedFolderGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
            }
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });

    setTab();       
    SetMoveCountry();
    SetMovePSL();
    SetMoveFolder();

    window.onbeforeunload = function () {
        if (IsDirty == true) {
            // $("#dSaveConfirm").html("You have unsaved changes.Do you want to save?").dialog('open');
          /*  if (confirm("You have unsaved changes.Do you want to save?")) {
                //write save logic  and redirect to groups page
                return saveEditorData();
            }
            else {
                return;
            } */
            return 'You have unsaved changes!';
        }
        //return;
    };
});

function SetMoveCountry() {

    $("#MoveCountryLeft").on("click", function () {
        var availableEntTable = $("#" + AvailableCountriesGridSettings.GridId).DataTable();
        var rows = availableEntTable.rows(".selected");
        if (rows.length == 0) {           
            ShowCustomAlert("Please select country(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.CNTRY_ID = data[i].CNTRY_ID;
            item.CNTRY_NM = data[i].CNTRY_NM;
            $('#' + SelectedCountriesGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        availableEntTable.row('.selected').remove().draw(false);
        if (availableEntTable.rows().data().length == 0) {
            if ($("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#SelectedCountriesGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#SelectedCountriesGrid_wrapper").find("tr").removeClass("selected");
    });

    $("#MoveCountryRight").on("click", function () {
        var selectedEntTable = $("#" + SelectedCountriesGridSettings.GridId).DataTable()
        var rows = selectedEntTable.rows(".selected");
        if (rows.length == 0) {            
            ShowCustomAlert("Please select country(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.CNTRY_ID = data[i].CNTRY_ID;
            item.CNTRY_NM = data[i].CNTRY_NM;
            $('#' + AvailableCountriesGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        selectedEntTable.row('.selected').remove().draw(false);
        if (selectedEntTable.rows().data().length == 0) {
            if ($("AvailableCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("AvailableCountriesGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#AvailableCountriesGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#AvailableCountriesGrid_wrapper").find("tr").removeClass("selected");
    });

}

function SetMovePSL() {

    $("#MovePSLLeft").on("click", function () {
        var availableEntTable = $("#" + AvailablePSLsGridSettings.GridId).DataTable();
        var rows = availableEntTable.rows(".selected");
        if (rows.length == 0) {          
            ShowCustomAlert("Please select PSL(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.PSL_ID = data[i].PSL_ID;
            item.PSL_NM = data[i].PSL_NM;
            $('#' + SelectedPSLsGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        availableEntTable.row('.selected').remove().draw(false);
        if (availableEntTable.rows().data().length == 0) {
            if ($("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#SelectedPSLsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#SelectedPSLsGrid_wrapper").find("tr").removeClass("selected");
    });
    $("#MovePSLRight").on("click", function () {
        var selectedEntTable = $("#" + SelectedPSLsGridSettings.GridId).DataTable()
        var rows = selectedEntTable.rows(".selected");
        if (rows.length == 0) {
            ShowCustomAlert("Please select PSL(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.PSL_ID = data[i].PSL_ID;
            item.PSL_NM = data[i].PSL_NM;
            $('#' + AvailablePSLsGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        selectedEntTable.row('.selected').remove().draw(false);
        if (selectedEntTable.rows().data().length == 0) {
            if ($("AvailablePSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("AvailablePSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#AvailablePSLsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#AvailablePSLsGrid_wrapper").find("tr").removeClass("selected");
    });
}

function SetMoveFolder() {
    
    $("#MoveFolderLeft").on("click", function () {
        var availableFolderTable = $("#" + AvailableFolderGridSettings.GridId).DataTable();
        var rows = availableFolderTable.rows(".selected");
        if (rows.length == 0) {
            ShowCustomAlert("Please select Folder(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + SelectedFolderGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        availableFolderTable.row('.selected').remove().draw(false);
        if (availableFolderTable.rows().data().length == 0) {
            if ($("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("#SelectedPSLsGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#SelectedPSLsGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#SelectedPSLsGrid_wrapper").find("tr").removeClass("selected");
    });

    $("#MoveFolderRight").on("click", function () {
        var selectedFolderTable = $("#" + SelectedFolderGridSettings.GridId).DataTable()
        var rows = selectedFolderTable.rows(".selected");
        if (rows.length == 0) {
            ShowCustomAlert("Please select Folder(s) to move.", "Alert", 300);
            return false;
        }
        $("#save").attr("src", "../images/save_dirty_24x24.png");
        IsDirty = true;
        var data = rows.data();
        for (var i = 0; i < data.length; i++) {
            var item = new Object();
            item.FLDR_TYP_ID = data[i].FLDR_TYP_ID;
            item.FLDR_TYP_NM = data[i].FLDR_TYP_NM;
            $('#' + AvailableFolderGridSettings.GridId).DataTable().row.add(item).draw(false);
        }
        selectedFolderTable.row('.selected').remove().draw(false);
        if (selectedFolderTable.rows().data().length == 0) {
            if ($("AvailableFolderGrid_wrapper").find(".dataTables_scrollHead").find("input:checked").length > 0)
                $("AvailableFolderGrid_wrapper").find(".dataTables_scrollHead").find("input:checked")[0].checked = false;
        }
        $("#AvailableFolderGrid_wrapper").find("input:checked").removeAttr("checked");
        $("#AvailableFolderGrid_wrapper").find("tr").removeClass("selected");
    });
}

function setTab() {
    if (qs("type") == "SYS") {
        $("#adminEditortabs ul li:eq(0)").hide();
        $("#lblHeader").html("System Administrator: " +decodeURIComponent(editUserName));
    }
    else if (qs("type") == "SUP") {
        $("#adminEditortabs ul li:eq(0)").show();
		$("#adminEditortabs ul li:eq(1)").hide();
		$("#adminEditortabs ul li:eq(2)").hide();
        $("#lblHeader").html("Regional Super Administrator: " +decodeURIComponent(editUserName));
    }
    else if (qs("type") == "PSL") {
        $("#adminEditortabs ul li:eq(0)").show();
        $("#lblHeader").html("Regional PSL Administrator: " +decodeURIComponent(editUserName));
    }
	
	 if(qs("tab")=="C")
        $("#adminEditortabs").tabs("option", "active", 0);
    else if (qs("tab") == "P")
        $("#adminEditortabs").tabs("option", "active", 1);
    else if (qs("tab") == "F")
        $("#adminEditortabs").tabs("option", "active", 2);
   
}
function populateCountryTab() {   
    var countryAvailable;
	var countrySelected;
	var countrySelectedList;
    var param = "UserID='" + editUserID + Sep() ;
	
    GetXSpaceData(param, AvailableCountriesGridSettings.DataSource, function (data) {
		  countryAvailableList =data;
		  $("#" + AvailableCountriesGridSettings.GridId).renderGrid(AvailableCountriesGridSettings, data);
	 });
	  GetXSpaceData(param, SelectedCountriesGridSettings.DataSource, function (data) {
		  countrySelectedList=data;
		   $("#" + SelectedCountriesGridSettings.GridId).renderGrid(SelectedCountriesGridSettings, data);
	 });
	  $("#AvailableCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
                $("#SelectedCountriesGrid_wrapper").find(".dataTables_scrollBody").css("height", "300px");
}
function populatePSLTab() {    
	var param = "UserID='" + editUserID + Sep() ;
	
    GetXSpaceData(param, AvailablePSLsGridSettings.DataSource, function (data) {		  
		  $("#" + AvailablePSLsGridSettings.GridId).renderGrid(AvailablePSLsGridSettings, data);
	 });
	  GetXSpaceData(param, SelectedPSLsGridSettings.DataSource, function (data) {		 
		   $("#" + SelectedPSLsGridSettings.GridId).renderGrid(SelectedPSLsGridSettings, data);
	 });
}
function populateFolderTab() {
   var param = "UserID='" + editUserID + Sep() ;
	GetXSpaceData("", AvailableFolderGridSettings.DataSource, function (data) {		  
		  $("#" + AvailableFolderGridSettings.GridId).renderGrid(AvailableFolderGridSettings, data);
	 });
	  GetXSpaceData(param, SelectedFolderGridSettings.DataSource, function (data) {		 
		   $("#" + SelectedFolderGridSettings.GridId).renderGrid(SelectedFolderGridSettings, data);
	 });
}


function saveEditorData() {
    saveSelectedData(SelectedCountriesGridSettings.GridId,"UpdateAdminCountryOperating_SP","CNTRY_ID","CntryIDList");
	saveSelectedData(SelectedPSLsGridSettings.GridId,"UpdateAdminPslAssociated_SP","PSL_ID","PslIDList");
	saveSelectedData(SelectedFolderGridSettings.GridId,"UpdateAdminFolderAssociated_SP","FLDR_TYP_ID","FolderIDList");
	dataSaved();
}

function saveSelectedCountries() {
	var selectedCountry="",seperator=";";
    var selectedCountryData = $("#" + SelectedCountriesGridSettings.GridId).DataTable().rows().data();
    if (typeof (selectedCountryData) != 'undefined' && selectedCountryData.length > 0) {
        for (var i = 0; i < selectedCountryData.length; i++) {
			selectedCountry=selectedCountry+selectedCountryData[i].CNTRY_ID+seperator;
		}
	}
	if(selectedCountry!=null && selectedCountry!="") {
		selectedCountry=selectedCountry.substr(0,selectedCountry.length-1);
		var param = "UserID='"+ editUserID + Sep() + "CntryIDList='"+ selectedCountry + Sep() + "Separator='" + seperator + Sep() + "ApproverUserID='" + USERID + Sep();		
		var data = GetXSpaceData(param, "UpdateAdminCountryOperating_SP", undefined);
	}
	dataSaved();
}
function saveSelectedPSLs() {
   
}
function saveSelectedFolder() {
   
}

function saveSelectedData(gridID,spName,idColumn,paramList){	
	var selectedID="",seperator=";";
    var selectedData = $("#" + gridID).DataTable().rows().data();
    if (typeof (selectedData) != 'undefined' && selectedData.length > 0) {
        for (var i = 0; i < selectedData.length; i++) {
			selectedID=selectedID+selectedData[i][idColumn]+seperator;
		}
	}
	if(selectedID!=null && selectedID!="") {
		selectedID=selectedID.substr(0,selectedID.length-1);		
	}
	var param = "UserID='"+ editUserID + Sep() + paramList+"='"+ selectedID + Sep() + "Separator='" + seperator + Sep() + "ApproverUserID='" + USERID + Sep();		
		var data = GetXSpaceData(param, spName, undefined);
}

function dataSaved() {
    ShowCustomAlert("Admin Editor details saved successfully.","Alert", 300);
    IsDirty = false;
    $("#save").attr("src", "../images/save_32x32.png");
	 window.location.href = "/_layouts/15/XSP/Pages/Admin.aspx";
    return;
}

function getUserType(){
	var param = "UserID='" + editUserID + Sep() ;
	 GetXSpaceData(param, "GetUserDetailByUserID_SP", function (data) {
		 adminType=data;
	 });
}