﻿var IsDirty = false;
var rGridID = "";

$(document).ready(function () {
	$("#confirm").dialog({
		autoOpen: false,
		modal: true,
		title: "Confirm Delete",
		height: 140,
		width: 350,
		buttons: {
			"Yes": function () {
				SetDirtyFilter();
			   
				var data = $("#" + rGridID).DataTable().rows(".selected").data();

				var table = $("#" + rGridID).DataTable();
			   
				if (table.row('.selected').length > 0) {
					table.row('.selected').remove().draw(false);
				}                              
				$(this).dialog('close');
				$(".selectall", "#" + rGridID + "_wrapper").removeAttr("checked");
			},
			"No": function () {
				$(this).dialog('close');
			}
		}
	});

	$("#alert").dialog({
		autoOpen: false,
		modal: true,
		title: "Alert",
		height: 120,
		width: 300,
		buttons: {
			"OK": function () {
				$(this).dialog('close');
			}
		}
	});
	SetControlVisibility();
	
	$("#SaveAs").on("click", function () {  
		OpenSaveAsDLDialog(qs("type"));
		SetSaveAs()
		$("#txt_dlName").val($("#txtdlName").val());
		$("#ddl_District").val($("#ddlDistrict").val());
		$("#txt_WellName").val($("#txtWellName").val());
		$("#txt_WellGuid").val($("#txtWellGuid").val());
		$("#ddl_PSL").val($("#ddlPSL").val());

	});

	$(document).on("saveAsEvent_DL", {}, function (event, distrbutionType, dlName, wellName, sdistrict, sPSL, wellguid) {
		IsDirty = false;
		if (distrbutionType == "D") {
			var param = "ListName='" + dlName + Sep() + "UserID='" + USERID + Sep() + "DistrictGuid='" + sdistrict + Sep() + "PslID='" + sPSL + "'";
			GetXSpaceData(param, "InsertDistrictDistributionList_SP", InsertDLCallback);
		}

		if (distrbutionType == "W") {
			var param = "ListName='" + dlName + Sep() + "UserID='" + USERID + Sep() + "WBJobGuid='" + wellguid + Sep() + "PslID='" + sPSL + "'";
			GetXSpaceData(param, "InsertWellDistributionList_SP", InsertDLCallback);
		}

		if (distrbutionType == "P") {          
			var param = "ListName='" + dlName + Sep() + "UserID='" + USERID + Sep() + "UserGuid='" + UserGUID + Sep() + "PslID='" + sPSL + "'";
			GetXSpaceData(param, "InsertPersonalDistributionList_SP", InsertDLCallback);
		}
		goback(distrbutionType);
	});

	$(document).on("click", "#back", function () {
		goback();
	});
	$("#save").on("click", function () {
		//// validate dl name, should not be empty.
		IsDirty = false;
		var welllist = false;
		var dlName = $.trim($("#txtdlName").val());
		if (dlName == "") {
			ShowCustomAlert("Please enter Distribution List name.", "Alert", 220);
			return false;
		}
		//save based on qs("type") == "D" D-district,W-well,P-perosnal
		if (typeof (qs("DLID")) == 'undefined') {
			if (qs("type") == "D") {
				var param = "ListName='" + $("#txtdlName").val() + Sep()
+ "UserID='" + USERID + Sep() + "DistrictGuid='" + $("#ddlDistrict").val() + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
				GetXSpaceData(param, "InsertDistrictDistributionList_SP", InsertDLCallback);

			}
			if (qs("type") == "W") {
				welllist = true;
				GetXSpaceData("", "GetWellDistributionList_SP", SaveWellList);
			}
			if (qs("type") == "P") {
				var param = "ListName='" + $("#txtdlName").val() + Sep()
				+ "UserID='" + USERID + Sep() + "UserGuid='" + UserGUID + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
				GetXSpaceData(param, "InsertPersonalDistributionList_SP", InsertDLCallback);
			}
		}
		else {
			var param = "UserID='" + USERID + Sep() + "ListGuid='" + qs("DLID") + "'";
			// Updation involves a lot of cases. So we can create a fresh one.
			GetXSpaceData(param, "DeleteDistributionList_SP", undefined);
			if (qs("type") == "D") {
				var param = "ListName='" + $("#txtdlName").val() + Sep()
+ "UserID='" + USERID + Sep() + "DistrictGuid='" + $("#ddlDistrict").val() + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
				GetXSpaceData(param, "InsertDistrictDistributionList_SP", InsertDLCallback);

			}
			if (qs("type") == "W") {
				var param = "ListName='" + $("#txtdlName").val() + Sep()
+ "UserID='" + USERID + Sep() + "WBJobGuid='" + $("#txtWellGuid").val() + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
				GetXSpaceData(param, "InsertWellDistributionList_SP", InsertDLCallback);
			}
			if (qs("type") == "P") {
				var param = "ListName='" + $("#txtdlName").val() + Sep()
				+ "UserID='" + USERID + Sep() + "UserGuid='" + UserGUID + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
				GetXSpaceData(param, "InsertPersonalDistributionList_SP", InsertDLCallback);
			}
		}
		if (welllist == false) {
			goback();
		}
	});
	if (typeof (qs("DLID")) == 'undefined') {
		$("input").on("keyup", function () {
			IsDirty = true;
			$("#save").attr("src", "../images/save_dirty_24x24.png");
		});
		$("select").on("change", function () {
			IsDirty = true;
			$("#save").attr("src", "../images/save_dirty_24x24.png");
		});
	}
   
	GetUserGuid(GetUserGUIDDetails);
	GetAllDistricts(UpdateDLDistricts);
	GetXSpaceData("", "GetPSL_SP", UpdatePslDLDropDown);

	$("#txtWellGuid").val(GetUrlParameter("Guid"));
	$("#txtWellName").val(decodeURIComponent(GetUrlParameter("well")));
   
	$("#txtdlName").val(decodeURIComponent(GetUrlParameter("dl")));
	$("#ddlDistrict").val(GetUrlParameter("dt"));
	$("#ddlPSL").val(GetUrlParameter("PSL"));
	if (typeof (qs("DLID")) == 'undefined') {
		var data = [];

		$("#" + dropBoxRecipientsGridSettings.GridId).renderGrid(dropBoxRecipientsGridSettings, data);
		var data = [];
		$("#" + emailRecipientsGridSettings.GridId).renderGrid(emailRecipientsGridSettings, data);
	}
	else {
		GetXSpaceData("ListGuid='" + qs("DLID") + "'", "GetDistributionListUsers_SP", RenderDropBoxGrid);
		GetXSpaceData("ListGuid='" + qs("DLID") + "'", "GetDistributionListEmailRecpnt_SP", RenderExternalReceipentsGrid);
		GetXSpaceData("ListGuid='" + qs("DLID") + "'", "GetDistributionListByGuid_SP", RenderUI);
	}
	  
	window.onbeforeunload = function () {
		if (IsDirty == true) {
		   /* if (confirm("You have unsaved changes.Do you want to save?")) {
				$("#save").click();
				return;
			}
			else {
				return;
			} */
			return 'You have unsaved changes!';
		}
	   // return;
	};
	performUserAction();
});

function SaveWellList(data)
{
	for (var i = 0; i < data.length; i++)
	{
		if( data[i].WB_JOB_GUID == $("#txtWellGuid").val() && $("#ddlPSL").val() == data[i].PSL_ID)
		{
			ShowCustomAlert("Distribution list already exists for selected Well and PSL.", "Alert", 410);
			return false;
		}
	}
	var param = "ListName='" + $("#txtdlName").val() + Sep()
+ "UserID='" + USERID + Sep() + "WBJobGuid='" + $("#txtWellGuid").val() + Sep() + "PslID='" + $("#ddlPSL").val() + "'";
	GetXSpaceData(param, "InsertWellDistributionList_SP", InsertDLCallback);
	goback();
	return true;

}
function UpdatePslDLDropDown(data) {
	var PSLs = data;
	var select = document.getElementById("ddlPSL");
	for (var i = 0; i < PSLs.length; i++) {
		var option = document.createElement('option');
		option.text = PSLs[i].PSL_NM;
		option.value = PSLs[i].PSL_ID;
		select.add(option, 0);
	}
	SortOptions("#ddlPSL");
	select.selectedIndex = 0;
}

function UpdateDLDistricts(data) {    
	var districts = data;
	var select = document.getElementById("ddlDistrict");
	for (var i = 0; i < districts.length; i++) {
		var option = document.createElement('option');
		option.text = districts[i].DIST_NM;
		option.value = districts[i].DIST_GUID;
		select.add(option, 0);
	}
	SortOptions("#ddlDistrict");
	select.selectedIndex = 0;
}
function UpdateDLCallback(data) {
	{
		var distGuid = qs("DLID");
		var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
		if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
			for (var i = 0; i < dropboxUsers.length; i++) {
				Reciepentitem = dropboxUsers[i];

				if (Reciepentitem.DSTBN_LIST_RCPT_GUID == null || Reciepentitem.DSTBN_LIST_RCPT_GUID == undefined) {
					var param = "ListGuid=" + "'" + distGuid + "'%26" + "DropboxFlg='" + "1" + "'%26" + "UserGuid=" + "'" + dropboxUsers[i].USR_GUID + "'%26" + "EmailFlg='" + "1'";
					var data = GetXSpaceData(param, "InsertDistributionListUsers_SP", UpdateExternalReciepent);
				}
			}
		}
		dropboxUsers = deletedDropBoxUser;
		if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
			for (var i = 0; i < dropboxUsers.length; i++) {
				Reciepentitem = dropboxUsers[i];

				if (Reciepentitem != null && Reciepentitem != undefined) {
					var param = "ListRcptGuid=" + "'" + Reciepentitem + "'";
					var data = GetXSpaceData(param, "DeleteDistributionListUser_SP", undefined);
				}
			}
		}

		var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
		if (typeof (emailUsers) != 'undefined' && emailUsers.length > 0) {
			for (var i = 0; i < emailUsers.length; i++) {
				Reciepentitem = emailUsers[i];
				if (Reciepentitem.EXTNL_RCPT_GUID == null || Reciepentitem.EXTNL_RCPT_GUID == undefined) {

					var param = "ListGuid=" + "'" + distGuid + "'%26" + "FirstName=" + "'" + emailUsers[i].USR_FIR_NM + "'%26" + "LastName=" + "'" + emailUsers[i].USR_LST_NM + "'%26" +
			"CompanyName='" + emailUsers[i].CO_NM + "'%26" + "EmailAddress=" + "'" + emailUsers[i].EMAIL_ADDR_DESC + "'";
					var data = GetXSpaceData(param, "InsertDistributionListExternRecpnt_SP", UpdateExternalReciepent);
				}
			}
		}

		dropboxUsers = deletedExternalUser;
		if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
			for (var i = 0; i < dropboxUsers.length; i++) {
				Reciepentitem = dropboxUsers[i];

				if (Reciepentitem != null && Reciepentitem != undefined) {
					var param = "ListRcptGuid=" + "'" + Reciepentitem + "'";
					var data = GetXSpaceData(param, "DeleteDistributionListExternRecpnt_SP", undefined);
				}
			}
		}
	}
	deletedDropBoxUser = [];
	deletedExternalUser = [];
}

var deletedDropBoxUser = [];
var deletedExternalUser = [];
var deletedEmailUser = [];
var deleteExternalUserGuid = [];
var deletedEmailUserGuid = [];
var deletedDropBoxUserGuid = [];

function CreateNewListForInternalUsersUpdateDList() {
	var Users = [];
	var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
	var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
	var FinalList = [];

	for (var i = 0; i < dropboxUsers.length; i++) {
		if (dropboxUsers[i].DSTBN_LIST_RCPT_GUID == null) {
			Users.push(dropboxUsers[i].USR_GUID);
		}
	}
	for (var j = 0; j < emailUsers.length; j++) {
		if (emailUsers[j].DSTBN_LIST_RCPT_GUID == null) {
			if (Users.indexOf(emailUsers[j].USR_GUID) == -1 && emailUsers[j].RCPT_TYPE == "USR_RCPT") {
				var object = new Object();
				object.USR_GUID = emailUsers[j].USR_GUID;
				object.EmailFlag = "1";
				object.dropBoxFlag = "0";
				FinalList.push[object];

			}
			else if (Users.indexOf(emailUsers[j].USR_GUID) >= 0 && emailUsers[j].RCPT_TYPE == "USR_RCPT") {
				var index = Users.indexOf(emailUsers[j].USR_GUID);
				Users = Users.splice(index);
				var object = new Object();
				object.USR_GUID = emailUsers[j].USR_GUID;
				object.EmailFlag = "1";
				object.dropBoxFlag = "1";
				FinalList.push[object];

			}
		}
	}
	for (var j = 0; i < Users.length; i++) {
		var object = new Object();
		object.USR_GUID = Users[j].USR_GUID;
		object.EmailFlag = "0";
		object.dropBoxFlag = "1";
		FinalList.push[object];
	}
	return FinalList;
}
function IsKeyExists(list, key) {
	for (i = 0; i < list.length; i++) {
		if (list[i].USR_GUID == key)
			return i;
	}
	return -1;
}

function CreateNewListForInternalUsersUpdateList() {
	var Users = [];
	var dropboxUsers = $("#" + dropBoxRecipientsGridSettings.GridId).DataTable().rows().data();
	var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
	var FinalList = [];
	for (var i = 0; i < dropboxUsers.length; i++) {
		var object = new Object();
		object.USR_GUID = dropboxUsers[i].USR_GUID;
		object.EmailFlag = "0";
		object.dropBoxFlag = "1";
		FinalList.push(object);
	}
	for (var i = 0; i < emailUsers.length; i++) {
		var index = IsKeyExists(FinalList, emailUsers[i].USR_GUID);
		if (index >= 0) {
			FinalList[index].EmailFlag = "1";
		}
		else if (emailUsers[i].RCPT_TYPE == "USR_RCPT") {
			var object = new Object();
			object.USR_GUID = emailUsers[i].USR_GUID;
			object.EmailFlag = "1";
			object.dropBoxFlag = "0";
			FinalList.push(object);
		}
	}
	return FinalList;
}

function GenerateFullName(data, type, full, meta) {
	return full.USR_FIR_NM + " " + full.USR_LST_NM;
}

var Reciepentitem;
function InsertDLCallback(data) {
	if (data.length > 0) {
		var distGuid = data[0].DSTBN_LIST_GUID;
		var dropboxUsers = CreateNewListForInternalUsersUpdateList();
		if (typeof (dropboxUsers) != 'undefined' && dropboxUsers.length > 0) {
			for (var i = 0; i < dropboxUsers.length; i++) {
				Reciepentitem = dropboxUsers[i];

				var param = "ListGuid=" + "'" + distGuid + "'%26" + "DropboxFlg='" + dropboxUsers[i].dropBoxFlag + "'%26" + "UserGuid=" + "'" + dropboxUsers[i].USR_GUID + "'%26" + "EmailFlg='" + dropboxUsers[i].EmailFlag + "'";
				var data = GetXSpaceData(param, "InsertDistributionListUsers_SP", undefined);
			}
		}
		var emailUsers = $("#" + emailRecipientsGridSettings.GridId).DataTable().rows().data();
		if (typeof (emailUsers) != 'undefined' && emailUsers.length > 0) {
			for (var i = 0; i < emailUsers.length; i++) {
				if (emailUsers[i].RCPT_TYPE != "USR_RCPT") {
					Reciepentitem = emailUsers[i];
					var param = "ListGuid=" + "'" + distGuid + "'%26" + "FirstName=" + "'" + emailUsers[i].USR_FIR_NM.trim() + "'%26" + "LastName=" + "'" + emailUsers[i].USR_LST_NM.trim() + "'%26" +
			"CompanyName='" + emailUsers[i].CO_NM.trim() + "'%26" + "EmailAddress=" + "'" + emailUsers[i].EMAIL_ADDR_DESC.trim() + "'";
					var data = GetXSpaceData(param, "InsertDistributionListExternRecpnt_SP", undefined);
				}
			}
		}
	}
}
function UpdateExternalReciepent(data) {
	if (data.length > 0) {
		Reciepentitem.EXTNL_RCPT_GUID = data.EXTNL_RCPT_GUID;
		Reciepentitem.DSTBN_LIST_RCPT_GUID = data.DSTBN_LIST_EXTNL_RCPT_GUID;
	}
}

function RenderUI(data)
{
	if( data.length  > 0 )
	{
		$("#txtdlName").val(data[0].DSTBN_LIST_NM);
		$("#ddlDistrict").val(data[0].DIST_GUID);
		$("#ddlPSL").val(data[0].PSL_ID);
		$("#txtWellGuid").val(data[0].WB_JOB_GUID);
		if( qs("type") == "W")
		{
			GetXSpaceData("WBJobGuid='" + data[0].WB_JOB_GUID + "'", "GetWellDataByWBJobGuid_SP", UpdateWellName);
		}
	}
}

function UpdateWellName(data)
{
	if (data.length > 0) {
		$("#txtWellName").val(data[0].WELL_NM);
	}
}

function RenderExternalReceipentsGrid(data)
{
	var dropBoxData = [];
	for (var i = 0; i < data.length ; i++) {

		var object = new Object();
		object.USR_FIR_NM = data[i].RCPT_FIR_NM;
		object.USR_LST_NM = data[i].RCPT_LST_NM;
		object.CO_NM = data[i].RCPT_CO_NM;
		object.EMAIL_ADDR_DESC = data[i].EMAIL_ADDR_DESC;
		object.DSTBN_LIST_RCPT_GUID = data[i].DSTBN_LIST_RCPT_GUID;
		object.USR_GUID = data[i].RCPT_GUID;
		object.RCPT_TYPE = data[i].RCPT_TYPE;
		dropBoxData.push(object);
	}
	$("#" + emailRecipientsGridSettings.GridId).renderGrid(emailRecipientsGridSettings, dropBoxData);
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust();
}
function RenderDropBoxGrid(data)
{
	var dropBoxData = [];
	for (var i = 0; i < data.length ; i++) {
		if (data[i].DROP_BOX_NTFN_FLG == "1") {
			var object = new Object();
			object.USR_FIR_NM = data[i].USR_FIR_NM;
			object.USR_LST_NM = data[i].USR_LST_NM;
			object.USR_NM = data[i].USR_NM;
			object.USR_GUID = data[i].USR_GUID;
			object.CO_NM = data[i].RCPT_CO_NM;
			object.EMAIL_ADDR_DESC = data[i].EMAIL_ADDR_DESC;;
			object.DSTBN_LIST_RCPT_GUID = data[i].DSTBN_LIST_RCPT_GUID;
			object.DROP_BOX_NTFN_FLG = data[i].DROP_BOX_NTFN_FLG;
			object.EMAIL_NTFN_FLG = data[i].EMAIL_NTFN_FLG;
			dropBoxData.push(object);
		}
	}
	$("#" + dropBoxRecipientsGridSettings.GridId).renderGrid(dropBoxRecipientsGridSettings, dropBoxData);
	$($.fn.dataTable.tables(true)).DataTable().columns.adjust();
}

function SetControlVisibility() {
	$("#txtdlName").val(decodeURIComponent(qs("dl")));
	$("#ddlPSL").val(qs("PSL"));

	if (qs("type") == "W") {
		$("#divWellName").css("display", "");
		$("#txtWellName").css("display", "");
		$("#txtWellName").val(qs("well"));
	}
	if (qs("type") == "D") {
		$("#dvDistrict").css("display", "");
		$("#ddlDistrict").css("display", "");
	}

	if (typeof (qs("DLID")) != 'undefined') {
		$("#ddlDistrict").css("background-color", "#f0f0f0");
		$("#ddlDistrict").attr("disabled", "disabled");

		$("#txtWellName").css("background-color", "#f0f0f0");
		$("#txtWellName").attr("readonly", "readonly");

		$("#ddlPSL").css("background-color", "#f0f0f0");
		$("#ddlPSL").attr("disabled", "disabled");
	}

	$("#txtdlName").on("keyup", function () {
		SetDirtyFilter();
	});
}

function AddDropboxRecipients(sourceGridID) {
	PopulateRecipients(sourceGridID, emailRecipientsGridSettings.GridId, true);
	$("#dialog-personnel").dialog("open");
	SetDirtyFilter();   
}
function AddBlankRow(sourceGridID) {    
   OpenEmailRecipientsDialog(sourceGridID, AddEmailRecipientData);
}

function AddEmailRecipientData(sourcegrid, recipientData) {
	SetDirtyFilter();
	$('#' +sourcegrid).DataTable().row.add(recipientData).draw(false);
}

var gridId;
function RemoveRecipients(sourceGridID) {
	rGridID = sourceGridID;
	var table = $("#" + sourceGridID).DataTable();
	if (table.row('.selected').length > 0) {
		$("#confirm").html("Are you sure to delete selected recipient(s)?").dialog("open");
	}
	else {        
		ShowCustomAlert("Please select recipient(s) to delete.","Alert",210);
	}
}

function SetSelectedWell(arrWells) {
	$("#txtWellGuid").val(arrWells[0].WB_JOB_GUID);
	$("#txtWellName").val(arrWells[0].WELL_NM);
}

function SetDirtyFilter()
{
	IsDirty = true;
	$("#save").attr("src", "../images/save_dirty_24x24.png");  
}

function mailTo(data, type, full, meta) {
	return "<a class='edithref' href='mailto:" + full.EMAIL_ADDR_DESC + "' target=\"_top\">" + full.EMAIL_ADDR_DESC + "</a>";
}

function goback(tabType) {   

	if (typeof (qs("WBGuid")) != "undefined") {
		sessionStorage.setItem('well-tab-index', null);
		window.location.href = "/_layouts/15/XSP/Pages/download.aspx?operation=3&WBGuid=" + qs("WBGuid");
	}
	else
		if (typeof (tabType) != "undefined") {
			window.location.href = "/_layouts/15/XSP/Pages/DistributionList.aspx?tab=" + tabType;
		}
		else {
			window.location.href = "/_layouts/15/XSP/Pages/DistributionList.aspx?tab=" + qs("type");
		}       
}

function performUserAction(){
	 if(qs("type")=="W" && USERROLE ==  USERROLE_TYPE.InternalUser){
		 $("#save").hide();
		 $("#dropBoxRecipientsGridtoolbar").hide();
		 $("#emailRecipientsGridtoolbar").hide();
	 }	
}