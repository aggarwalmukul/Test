﻿var newFileGridSettings = {
    GridId: "NewFileGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: true,
    PagingCount: 50,
    IsScrollY: true,
    DataSource: "GetDataFilesNewByWBJob_SP",
    DataSourceParam: "WELL_GUID",
    ColumnCollection: [{
                        Name: "",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DATA_FILE_GUID",
                        DataIndex: 0,
                        renderAction: "RenderNewFileInfo",
                        Width: "3%",
                        IsFilterable: true,
                        IsSortable: false
                    },
                    {
                        Name: "File Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DATA_FILE_LNM",
                        DataIndex: 1,
                        renderAction:"RenderNewFilesDownloadLink",
                        Width: "29%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Size (MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "FILE_SZ_VAL",
                        DataIndex: 2,
                        renderAction: "GenerateFormattedSize",
                        Width: "8%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Status",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "FILE_STATUS",
                        DataIndex: 3,
                        Width: "8%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Well",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        DataIndex: 4,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Comments",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "DATA_FILE_CMNT",
                        DataIndex: 5,                        
                        Width: "12%",
						 renderAction: "renderComment",
                        IsFilterable: true,
                        IsSortable: true
                    }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "download",
            Action: "DownloadDropBoxSelectedFiles",
            Icon: "download_32x32.png",
            Text: "download",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "distribute",
            Action: "DistributeSelectedFiles",
            Icon: "distribute_32x32.png",
            Text: "Go to distribution list",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};