﻿var recentPersonnelsRecipientsData;
var allPersonnelsRecipientsData;
var isDataExists = false;


function PopulateRecipients(sourceGridID, emailRecipientGridID, isMultiplePersonalDialog, companyID) {
    $(window).keypress(function (e) {
        if (e.keyCode == 13) {
            searchFilter();
            return false;
        }
    });
    $("#dialog-personnel").dialog({
        autoOpen: false,
        height: 550,
        width: 1000,
        modal: true,
        resizable: false,
        draggable: false,
        close: function (event, ui) {
            DestoryActiveDatatable();
            // $(this).dialog("destroy");
            $("#tabs").tabs("destroy");
        },
        open: function (event, ui) {
            $("#tabs").tabs("option", "active", 0);
            //// Initialize the tabs with the activate callback specified
            $("#tabs").on("tabsactivate", function (event, ui) {
                // alert(ui.newPanel.attr('id'));
            });           
            if (typeof(companyID) != "undefined") {
                var param = "CompanyID='" + companyID + "'";
                GetXSpaceData(param, allPersonnelsGridSettings.DataSource, PopulateAllRecipientsData);
                GetXSpaceData(param, personnelsGridSettings.DataSource, PopulateRecentRecipientsData);
            }
            else {
                GetUsers(allPersonnelsGridSettings.DataSource, PopulateAllRecipientsData);
                GetUsers(personnelsGridSettings.DataSource, PopulateRecentRecipientsData);
            }
            ApplyClearFilters();
        },
        buttons: {
            "OK": function () {
                if (isMultiplePersonalDialog) {
                    //AddMultiplePersonnelToBothRecipientsGrid(sourceGridID, emailRecipientGridID)
                    AddMultiplePersonnelToBothGrid(sourceGridID, emailRecipientGridID)
                }
                else {
                    //AddPersonnelToRecipientGrid(sourceGridID);
                    AddPersonnelToGrid(sourceGridID);
                }
                // $(this).dialog("close");
            },
            "Cancel": function () {
                $(this).dialog("close");
            }
        },
        create: function () {
            // $(this).addClass("dlgClass");           
        }
    });

    //// Bind an event listener to the tabsactivate event
    $("#tabs").tabs({
        activate: function (event, ui) {
            $("#AllPersonnelsGrid_wrapper").find("input").val("");
            $("#PersonnelsGrid_wrapper").find("input").val("");
            if (ui.newPanel.is("#fragment-1")) {
                $("#clearRecentFilter").attr("src", "../images/clear_filter_32x32.png");
                bindRecentRecipients();
            }
            else {
                bindAllRecipients();
                $("#clearAllFilter").attr("src", "../images/clear_filter_32x32.png");
            }
                 $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
            }
    });

}

function AddPersonnelToGrid(sourceGridID){
    //Validation if any one is selected
    if(personnelsGridSettings.RowSelectionStyle=="RadioButton"){
        var selectedTab=$("#tabs").tabs('option', 'active');
        if(isTabTableSelected(selectedTab)==0){
             ShowCustomAlert("No item selected.");
            return;
        }
        AddPersonnelToRecipientGrid(selectedTab,sourceGridID);
    }	
    else{
        if(isTabTableSelected(0)==0 && isTabTableSelected(1)==0){
             ShowCustomAlert("No item selected.");
            return;
        }
        AddPersonnelToRecipientGrid(0,sourceGridID);
        AddPersonnelToRecipientGrid(1,sourceGridID);
    }
     $("#dialog-personnel").dialog("close");
}

function AddPersonnelToRecipientGrid(selectedTab,sourceGridID, isMultiplePersonalType) {
    var oTableSource = (selectedTab == 1 ? $("#" + allPersonnelsGridSettings.GridId).DataTable() : $("#" + personnelsGridSettings.GridId).DataTable());

    // var oTableSource = $("#" + personnelsGridSettings.GridId).DataTable();
    //var oTableDest = $("#" + recipientsGridSettings.GridId).DataTable();
    var oTableDest = $("#" + sourceGridID).DataTable();
    var oTableDestCount = oTableDest.rows().data().length;
    var oTableDestData = oTableDest.rows().data();   
    var aData = oTableSource.rows('.selected').data();
   

    ////validation    
    for (var i = 0; i < aData.length; i++) {
        isDataExists = false;
        for (var j = 0; j < oTableDestData.length; j++) {
            if (oTableDestData[j].USR_GUID == aData[i].USR_GUID) {
                isDataExists = true;
                break;
            }
        }
        if (!isDataExists){
        oTableDestCount = oTableDestCount + 1;
        aData[i].DT_RowId = oTableDestCount;
        aData[i].USR_GRP_ASGMNT_GUID = "";
        aData[i].RGN_NM_LIST = "";
        aData[i].CNTRY_NM_LIST = "";
        aData[i].PSL_NM_LIST = "";
        aData[i].FLDR_CNT = "";
        oTableDest.row.add(aData[i]).draw();
        //oTableSource.row('.selected').remove().draw(false);        
    }
    }

   
}

function AddMultiplePersonnelToBothGrid(sourceGridID, emailRecipientGridID){
    //Validation if any one is selected
    
    if(!isTabTableMultipleSelected(0,sourceGridID, emailRecipientGridID) && !isTabTableMultipleSelected(1,sourceGridID, emailRecipientGridID)){
         ShowCustomAlert("No item selected.");
        return;
    }
    AddMultiplePersonnelToBothRecipientsGrid(0,sourceGridID, emailRecipientGridID);
    AddMultiplePersonnelToBothRecipientsGrid(1,sourceGridID, emailRecipientGridID);
     $("#dialog-personnel").dialog("close");
}

function AddMultiplePersonnelToBothRecipientsGrid(selectedTab,dropboxRecipientGrid, emailRecipientGrid) {

    var oTableSource = ( selectedTab== 1 ? $("#" + allPersonnelsGridSettings.GridId).DataTable() : $("#" + personnelsGridSettings.GridId).DataTable());

    var oTableDropBox = $("#" + dropboxRecipientGrid).DataTable();
    var oTableDropBoxData = oTableDropBox.rows().data();
    var oTableDropBoxRecordsCount = oTableDropBox.rows().data().length;

    var oTableEmail = $("#" + emailRecipientGrid).DataTable();
    var oTableEmailData = oTableEmail.rows().data();
    var oTableEmailRecordsCount = oTableDropBox.rows().data().length;

    var selectedDropBoxData = oTableSource.rows('.dropBox_selected').data();
    var selectedEmailData = oTableSource.rows('.email_selected').data();   
   

    for (var i = 0; i < selectedDropBoxData.length; i++) {
        isDataExists = false;
        for (var j = 0; j < oTableDropBoxData.length; j++) {
            if (oTableDropBoxData[j].USR_GUID == selectedDropBoxData[i].USR_GUID) {
                isDataExists = true;
                break;
            }
        }
        if (!isDataExists) {
        oTableDropBoxRecordsCount = oTableDropBoxRecordsCount + 1;
        selectedDropBoxData[i].DT_RowId = oTableDropBoxRecordsCount;
        selectedDropBoxData[i].RCPT_TYPE = "USR_RCPT";
        oTableDropBox.row.add(selectedDropBoxData[i]).draw();
        //oTableSource.row('.selected').remove().draw(false);        
    }
    }

    for (var i = 0; i < selectedEmailData.length; i++) {
        isDataExists = false;
        for (var j = 0; j < oTableEmailData.length; j++) {
            if (oTableEmailData[j].USR_GUID == selectedEmailData[i].USR_GUID) {
                isDataExists = true;
                break;
            }
        }
        if (!isDataExists) {
        oTableEmailRecordsCount = oTableEmailRecordsCount + 1;
        selectedEmailData[i].DT_RowId = oTableEmailRecordsCount;
        selectedEmailData[i].RCPT_TYPE = "USR_RCPT";
        oTableEmail.row.add(selectedEmailData[i]).draw();
        //oTableSource.row('.selected').remove().draw(false);        
    }
    }

   // $("#dialog-personnel").dialog("close");
}

function DestoryActiveDatatable() {
    if ($.fn.dataTable.isDataTable("#" + personnelsGridSettings.GridId)) {
        var oTable1 = $("#" + personnelsGridSettings.GridId).dataTable();
        $("#" + personnelsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    if ($.fn.dataTable.isDataTable("#" + allPersonnelsGridSettings.GridId)) {
        var oTable1 = $("#" + allPersonnelsGridSettings.GridId).dataTable();
        $("#" + allPersonnelsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}
function bindRecentRecipients() {
    if ($.fn.dataTable.isDataTable("#" + personnelsGridSettings.GridId)) {
        var oTable1 = $("#" + personnelsGridSettings.GridId).dataTable();
        $("#" + personnelsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    $("#" + personnelsGridSettings.GridId).renderGrid(personnelsGridSettings, recentPersonnelsRecipientsData);
}
function PopulateRecentRecipientsData(data)
{
    recentPersonnelsRecipientsData = data;   
    $("#" + personnelsGridSettings.GridId).renderGrid(personnelsGridSettings, recentPersonnelsRecipientsData);
    RenderSelectAllOption(personnelsGridSettings.GridId);
}
function bindAllRecipients()
{
    if ($.fn.dataTable.isDataTable("#" + allPersonnelsGridSettings.GridId)) {
        var oTable1 = $("#" + allPersonnelsGridSettings.GridId).dataTable();
        $("#" + allPersonnelsGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
    $("#" + allPersonnelsGridSettings.GridId).renderGrid(allPersonnelsGridSettings, allPersonnelsRecipientsData);
}
function PopulateAllRecipientsData(data) {
    allPersonnelsRecipientsData = data;
    $("#" + allPersonnelsGridSettings.GridId).renderGrid(allPersonnelsGridSettings, allPersonnelsRecipientsData);
    RenderSelectAllOption(allPersonnelsGridSettings.GridId);
}

function RenderSelectAllOption(sourceGridID) {
    //// selectAll DropBox and Email checkBox Implementation -
    $("#" + sourceGridID + "_wrapper").find(".dataTables_scrollHead").find("table thead tr").find("th:contains('Dropbox')").html("My Files <br> <input type='checkbox' class='select_AllDropBox'></input>");
    $("#" + sourceGridID + "_wrapper").find(".dataTables_scrollHead").find("table thead tr")
        .find("th:contains('Email')")
        .filter(function (index) { return $(this).text() === 'Email'; })
        .html("Email <br> <input type='checkbox' class='select_AllEmail'></input>");

    $('.select_AllDropBox').click(function (event) {
        var gridid = $("#" + sourceGridID + "_wrapper").find(".dataTables_scrollBody").find("table").attr("id");
        var checkstate = this.checked;
        $('.d_rowselect', "#" + gridid).each(function () {
            this.checked = checkstate;
            if (checkstate == true) {
                $(this).closest("tr").addClass("dropBox_selected");
            }
            else {
                $(this).closest("tr").removeClass("dropBox_selected");
            }
        });
        event.stopImmediatePropagation();
    });

    $('.select_AllEmail').click(function (event) {
        var gridid = $("#" + sourceGridID + "_wrapper").find(".dataTables_scrollBody").find("table").attr("id");
        var checkstate = this.checked;
        $('.e_rowselect', "#" + gridid).each(function () {
            this.checked = checkstate;
            if (checkstate == true) {
                $(this).closest("tr").addClass("email_selected");
            }
            else {
                $(this).closest("tr").removeClass("email_selected");
            }
            //$(this).closest("tr").toggleClass("email_selected");
        });
        event.stopImmediatePropagation();
    });
}


$(window).keypress(function (e) {
 
    if (e.keyCode == 13) {
        
        searchFilter();
        return false;
    }
});

function renderDropBoxCheckbox(data, type, full, meta) {   
    return "<input type='checkbox' class='d_rowselect'/>";
}

function renderEmailCheckbox(data, type, full, meta) {   
    return "<input type='checkbox' class='e_rowselect'/>";
}

$(document).ready(function () {
   
    $('#' + personnelsGridSettings.GridId).on("click", " input.d_rowselect", function () {
        if ($(this)[0].checked == false) {
            $(this).closest("tr").removeClass("dropBox_selected");
        }
        else {
            $(this).closest("tr").addClass("dropBox_selected");
        }
        //$("#" + personnelsGridSettings.GridId).find("tbody tr").removeClass("dropBox_selected"); 
        validateDropBoxSelection();
    });

    $('#' + personnelsGridSettings.GridId).on("click", " input.e_rowselect", function () {
        if ($(this)[0].checked == false) {
            $(this).closest("tr").removeClass("email_selected");
        }
        else {
            $(this).closest("tr").addClass("email_selected");
        }
        validateEmailSelection();
    });


    $('#' + allPersonnelsGridSettings.GridId).on("click", " input.d_rowselect", function () {
        $(this).closest("tr").toggleClass("dropBox_selected");
        validateDropBoxSelection();
       
    });
    $('#' + allPersonnelsGridSettings.GridId).on("click", " input.e_rowselect", function () {
        $(this).closest("tr").toggleClass("email_selected");
        validateEmailSelection();       
    });
    
    
    
});

function ApplyClearFilters() {

    $("#PersonnelsGrid_wrapper").find("input").val("");
    $("#AllPersonnelsGrid_wrapper").find("input").val("");
    $("#PersonnelsGrid_wrapper").find("input").on("keyup", function () {
        $("#clearRecentFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
        if ($("#clearRecentFilter").length > 0)
            $("#clearRecentFilter")[0].onclick = null;	
        return false;
    });

    $("#AllPersonnelsGrid_wrapper").find("input").on("keyup", function () {
        $("#clearAllFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
        if ($("#clearAllFilter").length > 0)
            $("#clearAllFilter")[0].onclick = null;
        return false;
    });


    $("#clearRecentFilter").on("click", function () {
        clearRecentFilter();
    });

    $("#clearAllFilter").on("click", function () {
        clearAllFilter();
});
}
function clearRecentFilter() {
    $("#PersonnelsGrid_wrapper").find("input").val("");   
    $("#clearRecentFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryActiveDatatable();
    ReloadGridData();
    }

function clearAllFilter() {
 $("#AllPersonnelsGrid_wrapper").find("input").val("");
    $("#clearAllFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryActiveDatatable();
    ReloadGridData();
    }
function ReloadGridData() {
    var current_index = $("#tabs").tabs("option", "active");
    if (current_index == 0) {
        $("#" +personnelsGridSettings.GridId).renderGrid(personnelsGridSettings, recentPersonnelsRecipientsData);
        RenderSelectAllOption(personnelsGridSettings.GridId);
        }
    else {
        $("#" +allPersonnelsGridSettings.GridId).renderGrid(allPersonnelsGridSettings, allPersonnelsRecipientsData);
        RenderSelectAllOption(allPersonnelsGridSettings.GridId);
    }
}

function validateDropBoxSelection() {
    if ($(".d_rowselect").length == $(".d_rowselect:checked").length) {
        $(".select_AllDropBox").prop("checked", true);
    } else {
        $(".select_AllDropBox").removeAttr("checked");
    }
}

function validateEmailSelection() {
    if ($(".e_rowselect").length == $(".e_rowselect:checked").length) {
        $(".select_AllEmail").prop("checked", true);
    } else {
        $(".select_AllEmail").removeAttr("checked");
    }
}

function isTabTableSelected(selectedTab){
    var oTableSource = (selectedTab == 1 ? $("#" + allPersonnelsGridSettings.GridId).DataTable() : $("#" + personnelsGridSettings.GridId).DataTable());
   
    var aData = oTableSource.rows('.selected').data();
    return aData.length;
}

function isTabTableMultipleSelected(selectedTab,dropboxRecipientGrid, emailRecipientGrid){
    var oTableSource = ( selectedTab== 1 ? $("#" + allPersonnelsGridSettings.GridId).DataTable() : $("#" + personnelsGridSettings.GridId).DataTable());

    var oTableDropBox = $("#" + dropboxRecipientGrid).DataTable();
    var oTableDropBoxData = oTableDropBox.rows().data();
    var oTableDropBoxRecordsCount = oTableDropBox.rows().data().length;

    var oTableEmail = $("#" + emailRecipientGrid).DataTable();
    var oTableEmailData = oTableEmail.rows().data();
    var oTableEmailRecordsCount = oTableDropBox.rows().data().length;

    var selectedDropBoxData = oTableSource.rows('.dropBox_selected').data();
    var selectedEmailData = oTableSource.rows('.email_selected').data();   
   
    if (selectedDropBoxData.length == 0 && selectedEmailData.length == 0) 
       return false;
    else
        return true;
}
    
   