﻿var IsDirty = false;
$(document).ready(function () {
	GetUserGuid(function(data){
		 var GetUserGUID = data;   
		var userRole = GetUserGUID[0].ROLE_CD;
		if(userRole == USERROLE_TYPE.CustomerUser || userRole == USERROLE_TYPE.CustomerAdministrator || userRole == USERROLE_TYPE.InternalUser){
		window.location.href = "/_layouts/15/XSP/Pages/Home.aspx";		
	}
	else {
    $("#confirm").dialog({
        autoOpen: false,
        modal: true,
        title: "Confirm",
        height: 140,
        width: 300,
        buttons: {
            "Yes": function () {
                //write code to delete				
                var data = $("#" + approvedUserGridSettings.GridId).DataTable().rows(".selected").data();
                DeleteUserData(data);
                var table = $("#" + approvedUserGridSettings.GridId).DataTable();
                if (table.row('.selected').length > 0) {
                    table.row('.selected').remove().draw(false);
                }

                $(this).dialog('close');
            },
            "No": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dApproveUser").dialog({
        autoOpen: false,
        modal: true,
        title: "Approve",
        height: 250,
        width: 300,
        open: function () {
            var data = $("#" + pendingApprovalGridSettings.GridId).DataTable().rows(".selected").data();
            var html = '';
            for (var i = 0; i < data.length; i++) {
                html = html + "<tr>";
                html = html + "<td>" + data[i].USR_NM + "</td></tr>";
            }
            $("#approveUsersList").html(html);
        },
        buttons: {
            "OK": function () {
                var table= $("#" + pendingApprovalGridSettings.GridId).DataTable();	
                var data = table.rows(".selected").data();
                for (var i = 0; i < data.length; i++) {                   
                    var param = "UserID='" + data[i].USR_AD_NM  +"'%26ApproverUserID='" + document.getElementById('userID').value+"'";
                    GetXSpaceData(param, "UpdateUserApproved_SP", undefined);
                    UserApprovedNotification(data[i].USR_AD_NM);
                }
                clearPendingFilter();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#dRejectUser").dialog({
        autoOpen: false,
        modal: true,
        title: "Reject",
        height: 250,
        width: 300,
        open: function () {
            $("#rejectionComment").html($("#txtRejectionComment").val());
            var data = $("#" + pendingApprovalGridSettings.GridId).DataTable().rows(".selected").data();
            var html = '';
            for (var i = 0; i < data.length; i++) {
                html = html + "<tr>";
                html = html + "<td>" + data[i].USR_NM + "</td></tr>";
            }
            $("#rejectUsersList").html(html);
        },
        buttons: {
            "OK": function () {                			
                var data = $("#" + pendingApprovalGridSettings.GridId).DataTable().rows(".selected").data();
                for (var i = 0; i < data.length; i++) {
                    var param = "UserID='" + data[i].USR_AD_NM + "'%26Comments='" + $("#txtRejectionComment").val() + "'%26ApproverUserID='" + document.getElementById('userID').value + "'";
                    GetXSpaceData(param, "UpdateUserRejected_SP", undefined);
                }
                clearPendingFilter();
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#rejectReason").dialog({
        autoOpen: false,
        modal: true,
        title: "Reject",
        height: 260,
        width: 350,
        open: function () {
            $("#txtRejectionComment").val("");
            $("#txtRejectionComment").trigger("change");
        },
        buttons: {
            "OK": function () {
                if ($.trim($("#txtRejectionComment").val()) != "") {
                    $("#dRejectUser").dialog('open');
                    $(this).dialog('close');
                }
                else {
                    $("#alert").html("Please enter reject reason.").dialog('open');
                    return false;
                }
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $(document).on("keypress blur", "textarea", function () { removeSpecialChar($(this)); });
    $("#dEditUserDetails").dialog({
        autoOpen: false,
        modal: true,
        title: "Details",
        height: 450,
        width: 580,
        open: function () {
            $("#dRejectionComment").val("");
            $("#dRejectionComment").trigger("change");
            $(".cssbtnreject").addClass("ui-button-disabled");
            $(".cssbtnreject").addClass("ui-state-disabled");
            $("#dvUserName").html(pendingUserRow.USR_NM);
            $("#dvCompany").html(pendingUserRow.CO_NM);
            $("#dvEmail").html(pendingUserRow.EMAIL_ADDR_DESC);
            $("#dvAccManage").html(pendingUserRow.AC_MGR);
            $("#dvRegistered").html(pendingUserRow.RGSTR_DTTM);
            $(document).on("keyup", "#dRejectionComment", function () {
                if ($.trim($("#dRejectionComment").val()).length > 0) {
                    $(".cssbtnreject").removeClass("ui-button-disabled");
                    $(".cssbtnreject").removeClass("ui-state-disabled");
                }
                else {
                    $(".cssbtnreject").addClass("ui-button-disabled");
                    $(".cssbtnreject").addClass("ui-state-disabled");
                }
            });
            
        },
        buttons: [
       {
           text: "Approve",
           icons: { primary: "check" },
           click: function () {
               var param = "UserID='" + pendingUserRow.USR_AD_NM + "'%26ApproverUserID='" + document.getElementById('userID').value + "'";
               if ($("#dRejectionComment").val().length > 0) {
                   param = param + "%26Comments='" + $("#dRejectionComment").val() + "'";
               }
               if ($("#ddlCompany").val() != "") {
                   param = param + "%26CompanyID='" + $("#ddlCompany").val() + "'";
               }
               GetXSpaceData(param, "UpdateUserApproved_SP", undefined);
               clearPendingFilter();
               $(this).dialog("close");
           }
       },
       {
           text: "Reject",
           icons: { primary: "reject" },
           "class": "cssbtnreject",          
           click: function () {
               var param = "UserID='" + pendingUserRow.USR_AD_NM + "'%26Comments='" + $("#txtRejectionComment").val() + "'%26ApproverUserID='" + document.getElementById('userID').value + "'";
               param = param + "%26Comments='" + $("#dRejectionComment").val() + "'";

               GetXSpaceData(param, "UpdateUserRejected_SP", undefined);

               clearPendingFilter();
               $(this).dialog("close");
           }
       },
       {
           text: "Cancel",          
           click: function () {
               $(this).dialog("close");
           }
       }
        ]       
    });
    $("#dCompany").dialog({
        autoOpen: false,
        modal: true,
        title: "Company",
        height: 140,
        width: 500,
        open: function () {
            $("#ddlCompany").val("");
        },
        buttons: {
            "OK": function () {
                $("#dvCompany").html($("#ddlCompany option:selected").text());
                $(this).dialog('close');
            },
            "Cancel": function () {
                $(this).dialog('close');
            }
        }
    });
    $("#alert").dialog({
        autoOpen: false,
        modal: true,
        title: "Alert",
        height: 120,
        width: 300,
        buttons: {
            "OK": function () {
                $(this).dialog('close');
            }
        }
    });
    GetUserGuid(GetUserGUIDDetails);
    populatePendingApproval();
   // populateApprovedUser();
    if ($("#clearPendingFilter").length > 0)
        $("#clearPendingFilter")[0].onclick = null;
    if ($("#clearApprovedFilter").length > 0)
        $("#clearApprovedFilter")[0].onclick = null;
    if ($("#clearApprovedFilter").length > 0)
        $("#clearApprovedFilter")[0].onclick = null;
    if ($("#Approve").length > 0)
        $("#Approve")[0].onclick = null;
    if ($("#RejectUser").length > 0)
        $("#RejectUser")[0].onclick = null;
    $("input").on("keyup", function () {
        IsDirty = true;
        $("#clearPendingFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
        if ($("#clearPendingFilter").length > 0)
            $("#clearPendingFilter")[0].onclick = null;
        return false;
    });
    $("#clearPendingFilter").on("click", function () {
        clearPendingFilter();
    });
    $(document).on("click","#clearApprovedFilter", function () {
        clearApprovedFilter();
    });
    $(document).on("click", "#btnCompany", function () {
        $("#dCompany").dialog('open');
        return false;
    });
    $(document).on("click", "#Approve", function () {
        Approve();
    });
    
    $("#RejectUser").on("click", function () {
        RejectUser();
    });
    populateCompany();
    //$("input").val("");
    $("#usersTab").tabs({
        activate: function (event, ui) {           
            if (ui.newPanel.is("#PendingApproval")) {                
                clearPendingFilter();
            }
            else {
               
                clearApprovedFilter();
                $("input").on("keyup", function () {
                    IsDirty = true;
                    $("#clearApprovedFilter").attr("src", "../images/clear_filter_dirty_24x24.png");
                    if ($("#clearApprovedFilter").length > 0)
                        $("#clearApprovedFilter")[0].onclick = null;
                    return false;
                });
                if ($("#DeleteUser").length > 0)
                    $("#DeleteUser")[0].onclick = null;
            }
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        }
    });
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
    $(document).on("click", "#DeleteUser", function () { DeleteUser() });
    var selectedtab = qs("tab");
    if (selectedtab == "A") {        
        $("#usersTab").tabs({ active: 1 });
    }
	
	}
	});
});
function clearPendingFilter() {
    IsDirty = false;
    $("#clearPendingFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryPendingApproval();
    populatePendingApproval();
}
function clearApprovedFilter() {
    IsDirty = false;
    $("#clearApprovedFilter").attr("src", "../images/clear_filter_32x32.png");
    DestoryApproved();
    populateApprovedUser();
}
function DestoryPendingApproval() {
    $("input[type=text]").val("");
    if ($.fn.dataTable.isDataTable("#" + pendingApprovalGridSettings.GridId)) {
        var oTable1 = $("#" + pendingApprovalGridSettings.GridId).dataTable();
        $("#" + pendingApprovalGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}
function DestoryApproved() {
    $("input[type=text]").val("");
    if ($.fn.dataTable.isDataTable("#" + approvedUserGridSettings.GridId)) {
        var oTable1 = $("#" + approvedUserGridSettings.GridId).dataTable();
        $("#" + approvedUserGridSettings.GridId + "tbody").html("");
        oTable1.dataTable().fnDestroy();
    }
}
function populateCompany() {
    GetXSpaceData("", "GetCompanyList_SP", function (data) {
        var select = $("#ddlCompany")[0];
        var option = new Option();
        option.value ="";
        option.text = "";
        select.options.add(option);
        for (var i = 0; i < data.length; i++) {
            option = new Option();
            option.value = data[i].CO_ID;
            option.text = data[i].CO_NM;
            select.options.add(option);
        }
    });
}
function populatePendingApproval() {
    var param = "UserID='" + document.getElementById('userID').value + "'";
    GetXSpaceData(param, pendingApprovalGridSettings.DataSource, function (data) {
        $("#pendingCount").html(data.length);
        $("#pandingApprovalUserCount").html("[" + data.length + "]");//for menu count
        $("#" + pendingApprovalGridSettings.GridId).renderGrid(pendingApprovalGridSettings, data);
    });
}
function populateApprovedUser() {
    var param = "UserID='" + document.getElementById('userID').value + "'";
    GetXSpaceData(param, approvedUserGridSettings.DataSource, function (data) {
        $("#" + approvedUserGridSettings.GridId).renderGrid(approvedUserGridSettings, data);
    });
}
var pendingUserRow;
function openEditUserDetails(userAdID) {
    if (typeof (event.target) == "undefined")
        pendingUserRow = $("#" + pendingApprovalGridSettings.GridId).DataTable().row($(event.srcElement).closest("tr")).data();
    else
        pendingUserRow = $("#" + pendingApprovalGridSettings.GridId).DataTable().row($(event.target).closest("tr")).data();
    $("#dEditUserDetails").dialog('open');
}
function editUser(data, type, full, meta) {
    return "<a class='edithref' href='/_layouts/15/XSP/Pages/Settings.aspx?tab=g&UserID=" + full.USR_AD_NM + "'>" + full.USR_NM + "</a>";
}

function editUserDetails(data, type, full, meta) {
    pendingUserRow = full;
    return "<a class='edithref' href='#' onclick='openEditUserDetails(\"" + full.USR_AD_NM + "\")'>" + full.USR_NM + "</a>";
}
function mailTo(data, type, full, meta) {
    return "<a class='edithref' href='mailto:" + full.EMAIL_ADDR_DESC + "' target=\"_top\">" + full.EMAIL_ADDR_DESC + "</a>";
}

function RejectUser() {
    if ($("#" + pendingApprovalGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#rejectReason").dialog('open');
    }
    else {
        $("#alert").html("Please select a user to reject.").dialog('open');
    }
}

function DeleteUser() {
    if ($("#" + approvedUserGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#confirm").html("Are you sure to delete?").dialog('open');
    }
    else {
        $("#alert").html("Please select a user to delete.").dialog('open');
    }
}

function DeleteUserData(data) {
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            var param = "UserID='" +data[i].USR_AD_NM + Sep();
            GetXSpaceData(param, "DeleteUser_SP", undefined);
        }
    }
}
$(window).keypress(function (e) {

    if (e.keyCode == 13) {

        searchFilter();
        return false;
    }
});

function groupAction(data, type, full, meta)
{
    if (full.GRP_CNT == "0")
        return full.GRP_CNT;
   
	 return "<a class='edithref' href='/_layouts/15/XSP/Pages/Settings.aspx?UserID=" + full.USR_AD_NM + "&tab=g'>" + full.GRP_CNT + "</a>";
}
function Approve() {
    if ($("#" + pendingApprovalGridSettings.GridId).DataTable().row(".selected").length > 0) {
        $("#dApproveUser").dialog('open');
    }
    else {
        $("#alert").html("Please select a user to approve.").dialog('open');
    }
}