﻿var inboxGridSettings = {
    GridId: "inboxGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetInboxFilesByUser_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [
        {
            Name: "",
            Visible: true,
            Enabled: true,
            DataType: "string",
            Style: "Text", // Text,Image,Action,URL
            CssClass: "",
            HeaderVisible: true,
            data: "DATA_FILE_GUID",
            DataIndex: 0,
            renderAction: "RenderNewFileInfo",
            Width: "4%",
            IsFilterable: false,
            IsSortable: false
        },
        {
                        Name: "File Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "DATA_FILE_LNM",
                        DataIndex: 0,
                        renderAction: "RenderNewFilesDownloadLink",
                        Width: "20%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Size(MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "FILE_SZ_VAL",
                        DataIndex: 1,
                        renderAction: "GenerateFormattedSize",
                        Width: "9%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "From",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "SENDER",
                        DataIndex: 2,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Company",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CO_NM",
                        DataIndex: 3,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Well Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "WELL_NM",
                        DataIndex: 4,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Comments",
                        Visible: true,
                        Enabled: true,
                        DataType: "comment",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "DATA_FILE_CMNT",
                        DataIndex: 5,
                        renderAction: "renderComment",
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: false
                    },
                     {
                         Name: "Received",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "REC_DATE",
                         DataIndex: 6,
                         Width: "10%",
                         IsFilterable: true,
                         IsSortable: true
                     },
                     {
                         Name: "Delete Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "DEL_DATE",
                         DataIndex: 7,
                         Width: "15%",
                         IsFilterable: true,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "Download",
            Action: "DownloadFiles",
            Icon: "download_32x32.png",
            Text: "Download",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Distribute",
            Action: "DistributeFile",
            Icon: "distribute_32x32.png",
            Text: "Distribute",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "Delete",
            Action: "RemoveFile",
            Icon: "delete_32x32.png",
            Text: "Delete",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var fileListGridSettings = {
    GridId: "fileListGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1, // positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    IsScrollY: true,
    ScrollYHeight: "150px",
    ColumnCollection: [{
        Name: "File Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "FileName",
        DataIndex: 0,
        Width: "60%",
        IsFilterable: true,
        IsSortable: true
    },
                    {
                        Name: "Size(MB)",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader rText",
                        HeaderVisible: true,
                        data: "Size",
                        DataIndex: 1,
                        Width: "30%",
                        IsFilterable: true,
                        IsSortable: true
                    }],
    FilterRow: {
        Visible: false,
        Enabled: true
    },
    ToolbarCollection: []
};