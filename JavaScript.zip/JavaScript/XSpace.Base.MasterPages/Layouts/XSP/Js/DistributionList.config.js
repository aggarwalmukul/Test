﻿var wellDLGridSettings = {
    GridId: "WellDLGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetWellDistributionList_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [{
                        Name: "Well Name",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "WELL_NM",
        renderAction: "GenerateRenderWellName",
        DataIndex:1,
        Width: "10%",
        IsFilterable: true,
        IsSortable: true
                    },
                    {
                        Name: "DL Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        renderAction: "editWellDL",
                        data: "DSTBN_LIST_NM",
                        DataIndex: 2,                        
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    }, {
                         Name: "Company",
                         Visible: true,
                         Enabled: true,
                         DataType: "string",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,                        
                         data: "CO_NM",
                         DataIndex: 3,
                         Width: "10%",
                         IsFilterable: true,
                         IsSortable: true
                    }, {
                        Name: "Field",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,                       
                        data: "FLD_NM",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "PSL",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 4,                       
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Created By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CREAT_BY_USR_NM",
                        DataIndex: 6,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Edited By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "LST_UPDT_USR_NM",
                        DataIndex: 7,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Last Edited Date",
                        Visible: true,
                        Enabled: true,
                        DataType: "Date",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "LST_UPDT_TMSTMP",
                        DataIndex: 8,                        
                        Width: "15%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Last Used Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 9,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddDL",
            Action: "AddWellDL",
            Icon: "create_32x32.png",
            Text: "New Distribution List",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteDL",
            Action: "DeleteWellDL",
            Icon: "delete_32x32.png",
            Text: "Delete DL",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "searchWell",
            Action: "SearchWell",
            Icon: "magnifying_glass_32x32.png",
            Text: "Search Well",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearFilter",
            Action: "clearWellFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};

var DistrictDLGridSettings = {
    GridId: "DistrictDLGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetDistrictDistributionList_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [{
        Name: "District",
        Visible: true,
        Enabled: true,
        DataType: "string",
        Style: "Text", // Text,Image,Action,URL
        CssClass: "cHeader lText",
        HeaderVisible: true,
        data: "DIST_NM",
        DataIndex: 1,
        Width: "20%",
        IsFilterable: true,
        IsSortable: true
    },
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        renderAction: "editDistrictDL",
                        data: "DSTBN_LIST_NM",
                        DataIndex: 2,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "PSL",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Created By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CREAT_BY_USR_NM",
                        DataIndex: 4,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Edited By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "LST_UPDT_USR_NM",
                        DataIndex: 5,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Last Edited Date",
                        Visible: true,
                        Enabled: true,
                        DataType: "Date",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "LST_UPDT_TMSTMP",
                        DataIndex: 6,
                        Width: "15%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Last Used Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 7,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddDL",
            Action: "AddDistrictDL",
            Icon: "create_32x32.png",
            Text: "New Distribution List",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteDL",
            Action: "DeleteDistrictDL",
            Icon: "delete_32x32.png",
            Text: "Delete DL",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearDistrictFilter",
            Action: "clearDistrictFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
var personalDLGridSettings = {
    GridId: "PersonalDLGrid",
    RowSelectionStyle: "Checkbox",  //Checkbox/ RadioButton/Row/None
    RowSelectionType: "Multiple", // Multiple , Single
    DefaultColumnSort: -1,// positive column index, if no sort -1
    DefaultColumnSortOrder: "asc", // asc/desc
    Paging: false,
    IsScrollY: true,
    DataSource: "GetPersonalDistributionList_SP ",
    DataSourceParam: "USERID",
    ColumnCollection: [
                    {
                        Name: "Name",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        renderAction: "editPersonalDL",
                        data: "DSTBN_LIST_NM",
                        DataIndex: 1,
                        Width: "15%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "PSL",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "PSL_NM",
                        DataIndex: 2,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Created By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "CREAT_BY_USR_NM",
                        DataIndex: 3,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Edited By",
                        Visible: true,
                        Enabled: true,
                        DataType: "string",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        HeaderVisible: true,
                        data: "LST_UPDT_USR_NM",
                        DataIndex: 4,
                        Width: "10%",
                        IsFilterable: true,
                        IsSortable: true
                    },
                    {
                        Name: "Last Edited Date",
                        Visible: true,
                        Enabled: true,
                        DataType: "Date",
                        Style: "Text", // Text,Image,Action,URL
                        CssClass: "cHeader lText",
                        //CssClass: "comment",
                        HeaderVisible: true,
                        data: "LST_UPDT_TMSTMP",
                        DataIndex: 5,
                        Width: "15%",
                        IsFilterable: false,
                        IsSortable: true
                    },
                     {
                         Name: "Last Used Date",
                         Visible: true,
                         Enabled: true,
                         DataType: "Date",
                         Style: "Text", // Text,Image,Action,URL
                         CssClass: "cHeader lText",
                         HeaderVisible: true,
                         data: "LST_UPDT_TMSTMP",
                         DataIndex: 6,
                         Width: "15%",
                         IsFilterable: false,
                         IsSortable: true
                     }
    ],
    FilterRow: {
        Visible: true,
        Enabled: true
    },
    ToolbarCollection: [{
        Name: "Filter",
        Visible: true,
        Enabled: true,
        ButtonCollection: [{
            Name: "AddDL",
            Action: "AddPersonalDL",
            Icon: "create_32x32.png",
            Text: "New Distribution List",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "DeleteDL",
            Action: "DeletePersonalDL",
            Icon: "delete_32x32.png",
            Text: "Delete DL",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }, {
            Name: "Filter",
            Action: "searchFilter",
            Icon: "filter_32x32.png",
            Text: "Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        },
        {
            Name: "clearPersonalFilter",
            Action: "clearPersonalFilter",
            Icon: "clear_filter_32x32.png",
            Text: "Clear Filter",
            Appearance: "Icon", // (Text or Icon)
            Visible: true,
            Enabled: true
        }
        ]
    }]
};
